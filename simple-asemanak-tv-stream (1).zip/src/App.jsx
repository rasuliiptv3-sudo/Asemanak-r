import { useState, useEffect, useLayoutEffect, useRef, lazy, Suspense } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useNavigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AnimatePresence, motion } from "framer-motion";
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

const Home = lazy(() => import('@/pages/Home'));
const Channels = lazy(() => import('@/pages/Channels'));
const Favorites = lazy(() => import('@/pages/Favorites'));
const Settings = lazy(() => import('@/pages/Settings'));
const AdminStats = lazy(() => import('@/pages/AdminStats'));
import SplashScreen from '@/components/SplashScreen';
const Media = lazy(() => import('@/pages/Media'));
const Entry = lazy(() => import('@/pages/Entry'));
const Welcome = lazy(() => import('@/pages/Welcome'));
import SetupScreen from '@/components/SetupScreen';
const SearchPage = lazy(() => import('@/pages/Search'));
const Player = lazy(() => import('@/pages/Player'));
import MobileTabBar from '@/components/layout/MobileTabBar';
import { useIsTV } from '@/lib/useIsTV';
import { applySeasonalTheme } from '@/lib/seasonalTheme';
import { useTVRemote } from '@/lib/useTVRemote';
import { killAllMedia } from '@/lib/killAllMedia';
const Login = lazy(() => import('@/pages/Login'));
const Register = lazy(() => import('@/pages/Register'));
const ForgotPassword = lazy(() => import('@/pages/ForgotPassword'));
const ResetPassword = lazy(() => import('@/pages/ResetPassword'));

// ── Dedicated Android TV pages — completely separate from mobile ──
const TVHome = lazy(() => import('@/pages/tv/TVHome'));
const TVChannels = lazy(() => import('@/pages/tv/TVChannels'));
const TVMedia = lazy(() => import('@/pages/tv/TVMedia'));
const TVSettings = lazy(() => import('@/pages/tv/TVSettings'));
const TVSearch = lazy(() => import('@/pages/tv/TVSearch'));
const TVFavorites = lazy(() => import('@/pages/tv/TVFavorites'));

// Lazy-loading fallback — matches the existing auth loading spinner
const PageLoader = () => (
  <div className="fixed inset-0 flex items-center justify-center bg-black">
    <div className="w-8 h-8 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin"></div>
  </div>
);

// Route transitions — slide left (forward) / slide right (back) using framer-motion.
// Direction is derived from a lightweight in-memory path stack so back-navigation slides right.
function AnimatedRoutes({ isTV = false }) {
  const location = useLocation();
  const stackRef = useRef([location.pathname]);
  const [direction, setDirection] = useState(0);

  useLayoutEffect(() => {
    const stack = stackRef.current;
    const top = stack[stack.length - 1];
    const next = location.pathname;
    if (next === top) return;
    const idx = stack.indexOf(next);
    if (idx !== -1) {
      stackRef.current = stack.slice(0, idx + 1);
      setDirection(-1); // back → slide right
    } else {
      stackRef.current = [...stack, next];
      setDirection(1); // forward → slide left
    }
  }, [location.pathname]);

  // Kill ALL lingering media (YouTube iframes, video, audio) the instant the route
  // changes — before the exit animation even starts, so no audio bleeds into the next page.
  useEffect(() => {
    killAllMedia();
  }, [location.pathname]);

  // Auto-focus first focusable element on route change (TV only).
  // Ensures D-pad navigation always has a starting point on every screen.
  useEffect(() => {
    if (!document.documentElement.classList.contains('is-tv')) return;
    const timer = setTimeout(() => {
      const active = document.activeElement;
      if (!active || active === document.body || active.tagName === 'BODY') {
        const first = document.querySelector('[data-remote], button, a, [tabindex]:not([tabindex="-1"])');
        if (first) first.focus();
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [location.pathname]);

  const variants = {
    enter: (dir) => ({ x: dir >= 0 ? "100%" : "-100%" }),
    center: { x: 0 },
    exit: (dir) => ({ x: dir >= 0 ? "-100%" : "100%" }),
  };

  return (
    <div className="relative w-full h-full overflow-hidden">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={location.pathname.split("/")[1] || "/"}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
          className="absolute inset-0 w-full h-full"
        >
          <Suspense fallback={<PageLoader />}>
          <Routes location={location}>
            {isTV ? (
              <>
                <Route path="/" element={<TVHome />} />
                <Route path="/Home" element={<TVChannels />} />
                <Route path="/Media" element={<TVMedia />} />
                <Route path="/Favorites" element={<TVFavorites />} />
                <Route path="/Settings" element={<TVSettings />} />
                <Route path="/Settings/:tab" element={<TVSettings />} />
                <Route path="/Search" element={<TVSearch />} />
                <Route path="/Player/:id" element={<TVChannels />} />
                <Route path="/AdminStats" element={<AdminStats />} />
                <Route path="*" element={<TVHome />} />
              </>
            ) : (
              <>
                <Route path="/" element={<Entry />} />
                <Route path="/Home" element={<Home />} />
                <Route path="/Channels" element={<Channels />} />
                <Route path="/Favorites" element={<Favorites />} />
                <Route path="/Settings" element={<Settings />} />
                <Route path="/Settings/:tab" element={<Settings />} />
                <Route path="/Search" element={<SearchPage />} />
                <Route path="/Media" element={<Media />} />
                <Route path="/Player/:id" element={<Player />} />
                <Route path="/AdminStats" element={<AdminStats />} />
                <Route path="*" element={<PageNotFound />} />
              </>
            )}
          </Routes>
          </Suspense>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, user } = useAuth();
  const isTV = useIsTV();
  useTVRemote(isTV);
  const [authTimedOut, setAuthTimedOut] = useState(false);
  useEffect(() => {
    if (!isLoadingAuth && !isLoadingPublicSettings) { setAuthTimedOut(false); return; }
    const t = setTimeout(() => setAuthTimedOut(true), 8000);
    return () => clearTimeout(t);
  }, [isLoadingAuth, isLoadingPublicSettings]);

  // Apply seasonal / occasion theme — admin only
  useEffect(() => {
    if (user?.role !== 'admin') return;
    const cleanup = applySeasonalTheme(true);
    return cleanup;
  }, [user]);
  const [showSplash, setShowSplash] = useState(() => {
    try { return !sessionStorage.getItem("ayeneh_splash_done"); } catch { return true; }
  });
  const [showSetup, setShowSetup] = useState(false);
  const [showWelcome, setShowWelcome] = useState(() => {
    const welcomed = localStorage.getItem("ayeneh_welcomed");
    return !welcomed;
  });
  const navigate = useNavigate();
  // On fresh page load / refresh, always return to the main menu (Entry).
  // Skip when running inside the native WebView wrapper (?webview=1) so the
  // wrapper can restore the last route and deep links.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const isWebViewWrapper = params.get("webview") === "1";
    if (!isWebViewWrapper && window.location.pathname !== "/") {
      navigate("/", { replace: true });
    }
  }, []);

  // Suppress native browser context menu (download/share/print on long-press)
  useEffect(() => {
    const handler = (e) => { e.preventDefault(); return false; };
    window.addEventListener("contextmenu", handler);
    return () => window.removeEventListener("contextmenu", handler);
  }, []);

  // ── Splash: show FIRST, let it complete fully (always reaches 100%) ──
  // The splash runs its full 5.8s animation without interruption. Auth checks
  // happen AFTER, so the progress bar never gets cut off at 32% (which was
  // happening because the auth network request resolved mid-animation and
  // unmounted the splash). On return from login (same session), skip splash.
  if (showSplash) {
    return <SplashScreen onDone={() => {
      try { sessionStorage.setItem("ayeneh_splash_done", "true"); } catch {}
      setShowSplash(false);
    }} />;
  }

  // ── After splash: wait for auth if still loading (slow network) ──
  if (isLoadingPublicSettings || isLoadingAuth) {
    if (authTimedOut) {
      return (
        <div className="fixed inset-0 flex flex-col items-center justify-center bg-black gap-6">
          <div className="text-white/60 text-lg text-center px-8 max-w-md">
            {isTV ? "Connection is taking too long. Check your internet and try again." : "اتصال طول کشید. اینترنت را بررسی و دوباره تلاش کنید."}
          </div>
          <button onClick={() => window.location.reload()} data-remote
            className="px-8 py-3 bg-cyan-600 hover:bg-cyan-500 rounded-xl text-white font-semibold text-base">
            {isTV ? "Retry" : "تلاش مجدد"}
          </button>
        </div>
      );
    }
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black">
        <div className="w-8 h-8 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  // ── Auth gate: redirect to login via SPA navigation (no page reload) ──
  if (authError?.type === 'auth_required') {
    const returnTo = (window.location.pathname + window.location.search) || '/';
    return <Navigate to={`/login?returnTo=${encodeURIComponent(returnTo)}`} replace />;
  }
  if (authError?.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  if (showWelcome) {
    return (
      <Suspense fallback={<PageLoader />}>
        <Welcome onDone={() => {
          setShowWelcome(false);
          localStorage.setItem("ayeneh_welcomed", "true");
        }} />
      </Suspense>
    );
  }

  if (showSetup) {
    return <SetupScreen onDone={() => setShowSetup(false)} />;
  }

  if (authError) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center bg-black gap-4">
        <p className="text-white text-lg">Unable to load the app</p>
        <button onClick={() => window.location.reload()} data-remote
          className="px-6 py-2 bg-cyan-600 rounded-xl text-white">Retry</button>
      </div>
    );
  }

  return (
    <>
      {isTV ? (
        <AnimatedRoutes isTV={true} />
      ) : (
        <>
          <AnimatedRoutes isTV={false} />
          <MobileTabBar />
        </>
      )}
    </>
  );
};

function App() {
  // Seasonal themes are applied in AuthenticatedApp — admin only

  // Register service worker for offline support — production only (dev SW caches stale Vite chunks)
  useEffect(() => {
    if (!import.meta.env.DEV && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
      // Unregister any stale dev workers + clear caches
    } else if (import.meta.env.DEV && 'serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistrations().then(regs => regs.forEach(r => r.unregister().catch(() => {})));
      if (window.caches) caches.keys().then(names => names.forEach(n => caches.delete(n).catch(() => {})));
    }
  }, []);

  // Best-effort: enter fullscreen on first user interaction (TV remote / click).
  // Mobile/iPad: follow device orientation freely (no lock). TV: lock landscape.
  // Small mobiles (width < 768px): lock PORTRAIT — never landscape.
  // Only when running as a top-level window (installed PWA), not inside the editor preview iframe.
  useEffect(() => {
    if (window.self !== window.top) return;
    const ua = navigator.userAgent || "";
    const uaTV = /tv|smarttv|google ?tv|netcast|baidutv|crkey|smart-tv|googletv|webos|tizen|bravia|firetv|fire-tv|aftt|aftm|aftb|aftd|shield|leanback/i.test(ua);
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const isAndroidTVBox = /android/i.test(ua) && !hasTouch && window.innerWidth > window.innerHeight;
    const isTV = uaTV || isAndroidTVBox;

    const enterFs = () => {
      try {
        const el = document.documentElement;
        if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen().catch(() => {});
      } catch {}
      try {
        const isTablet = /ipad|tablet|playbook|silk/i.test(ua);
        const isMobile = /android|iphone|ipod/i.test(ua);
        const isSmallScreen = window.innerWidth < 768;
        if (isSmallScreen && (isMobile || !uaTV) && screen.orientation && screen.orientation.lock) {
          screen.orientation.lock("portrait").catch(() => {});
        }
        else if (isTV && !(isTablet || isMobile) && screen.orientation && screen.orientation.lock) {
          screen.orientation.lock("landscape").catch(() => {});
        }
      } catch {}
    };

    // On TV: try fullscreen immediately (some WebViews allow it without gesture)
    if (isTV) enterFs();
    window.addEventListener("keydown", enterFs, { once: true });
    window.addEventListener("pointerdown", enterFs, { once: true });
    return () => {
      window.removeEventListener("keydown", enterFs);
      window.removeEventListener("pointerdown", enterFs);
    };
  }, []);

  // Pause all media when the app is backgrounded/closed — no lingering audio.
  useEffect(() => {
    const onPause = () => {
      if (document.visibilityState !== "hidden") return;
      document.querySelectorAll("video").forEach(v => { try { v.pause(); } catch {} });
      document.querySelectorAll("audio").forEach(a => { try { a.pause(); } catch {} });
      document.querySelectorAll("iframe").forEach(f => {
        try { f.contentWindow.postMessage(JSON.stringify({ event: "command", func: "pauseVideo", args: "" }), "*"); } catch {}
      });
    };
    document.addEventListener("visibilitychange", onPause);
    return () => document.removeEventListener("visibilitychange", onPause);
  }, []);

  // Global tap-vs-swipe guard: suppress clicks that follow a touch movement
  // (a scroll/swipe) so dragging to scroll never accidentally opens a card/button.
  useEffect(() => {
    let sx = null, sy = null, moved = false;
    const ts = (e) => {
      if (e.touches.length === 1) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; moved = false; }
    };
    const tm = (e) => {
      if (sx === null) return;
      if (Math.abs(e.touches[0].clientX - sx) > 10 || Math.abs(e.touches[0].clientY - sy) > 10) moved = true;
    };
    const guard = (e) => {
      if (moved) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); moved = false; }
    };
    document.addEventListener("touchstart", ts, { passive: true, capture: true });
    document.addEventListener("touchmove", tm, { passive: true, capture: true });
    document.addEventListener("click", guard, { capture: true });
    return () => {
      document.removeEventListener("touchstart", ts, { capture: true });
      document.removeEventListener("touchmove", tm, { capture: true });
      document.removeEventListener("click", guard, { capture: true });
    };
  }, []);

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="*" element={<AuthenticatedApp />} />
          </Routes>
          </Suspense>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;