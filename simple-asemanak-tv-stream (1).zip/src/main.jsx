import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'

// Clear stale local caches BEFORE React mounts — only when the app version changes,
// so every page load doesn't wipe the service worker, HTTP cache, and IndexedDB.
;(async () => {
  const STORAGE_VERSION_KEY = "ayeneh_cache_version";
  // import.meta.url changes per build in production (Vite content hash in filename),
  // so this naturally purges only when a new build is deployed.
  const currentVersion = import.meta.url;
  let lastVersion;
  try { lastVersion = localStorage.getItem(STORAGE_VERSION_KEY); } catch (e) {}
  if (lastVersion === currentVersion) return; // already purged for this version
  // Unregister any service worker so stale JS isn't served.
  try {
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
  } catch (e) {}
  // Clear HTTP caches (old JS bundles).
  try {
    const names = await caches.keys();
    await Promise.all(names.map(n => caches.delete(n)));
  } catch (e) {}
  // Clear stale IndexedDB "series" store.
  try {
    const req = indexedDB.open("ayeneh_db");
    req.onsuccess = () => {
      try {
        const db = req.result;
        if (db.objectStoreNames && db.objectStoreNames.contains("series")) {
          db.transaction("series", "readwrite").objectStore("series").clear();
        }
        db.close();
      } catch (e) {}
    };
  } catch (e) {}
  try { localStorage.setItem(STORAGE_VERSION_KEY, currentVersion); } catch (e) {}
})();

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)