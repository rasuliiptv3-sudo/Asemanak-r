import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { LayoutGrid } from "lucide-react";
import ExitConfirmModal from "@/components/entry/ExitConfirmModal";
import DynamicBackground from "@/components/entry/DynamicBackground";
import BackgroundPicker from "@/components/entry/BackgroundPicker";
import NavCards from "@/components/entry/NavCardsDnD";
import TopNav from "@/components/entry/TopNav";
import { useAuth } from "@/lib/AuthContext";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

export default function Entry() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showExit, setShowExit] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [isFa, setIsFa] = useState(true);
  const isAdmin = user?.role === "admin";

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    syncLang();
    window.addEventListener("storage", syncLang);
    window.addEventListener("ayeneh-settings-changed", syncLang);
    return () => {
      window.removeEventListener("storage", syncLang);
      window.removeEventListener("ayeneh-settings-changed", syncLang);
    };
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.target?.isContentEditable) return;
      if (["Backspace", "Escape", "GoBack", "XF86Back"].includes(e.key)) { e.preventDefault(); setShowExit(true); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const dir = isFa ? "rtl" : "ltr";

  return (
    <div className="fixed inset-0 overflow-hidden flex flex-col" style={{ background: "#08000f", fontFamily: "Vazirmatn, sans-serif", direction: dir, imageRendering: "high-quality", WebkitFontSmoothing: "antialiased", textRendering: "geometricPrecision", WebkitTapHighlightColor: "transparent" }}>
      <DynamicBackground />

      {/* YOUR APPS — fixed/sticky at top, stays visible when scrolling */}
      <div className="absolute left-0 right-0 z-20 px-4"
        style={{ top: "calc(clamp(140px,20vh,220px) + env(safe-area-inset-top))", paddingLeft: "clamp(16px,4vw,48px)", paddingRight: "clamp(16px,4vw,48px)" }}>
        <div className="hidden md:flex items-center gap-3 mb-5 md:mb-6">
          <span className="rounded-full" style={{ width: "clamp(6px,0.8vw,10px)", height: "clamp(6px,0.8vw,10px)", background: "#22d3ee", boxShadow: "0 0 12px #22d3ee" }} />
          <LayoutGrid className="text-cyan-400" style={{ width: "clamp(18px,2vw,26px)", height: "clamp(18px,2vw,26px)" }} strokeWidth={2.5} />
          <h2 className="text-white font-bold" style={{ fontSize: "clamp(16px,2vw,24px)", letterSpacing: "0.08em" }}>
            {isFa ? "برنامه‌های شما" : "Your Apps"}
          </h2>
          <div className="flex-1 h-px ml-3" style={{ background: "linear-gradient(90deg, rgba(34,211,238,0.3), transparent)" }} />
        </div>
        <NavCards />
      </div>

      {/* Header — floats over content */}
      <TopNav isFa={isFa} onOpenPicker={() => setShowPicker(true)} />

      {showPicker && <BackgroundPicker isFa={isFa} onClose={() => setShowPicker(false)} />}
      {showExit && <ExitConfirmModal onCancel={() => setShowExit(false)} />}
    </div>
  );
}