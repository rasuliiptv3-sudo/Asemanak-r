import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Users, ArrowLeft, RefreshCw, Shield, Calendar, Mail } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function AdminStats() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [checking, setChecking] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    base44.auth.me()
      .then(u => {
        if (u?.role === "admin") {
          setIsAdmin(true);
          loadUsers();
        } else {
          setChecking(false);
          setLoading(false);
        }
      })
      .catch(() => { setChecking(false); setLoading(false); });
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    const all = await base44.entities.User.list("-created_date", 200);
    setUsers(all || []);
    setLoading(false);
    setChecking(false);
  };

  if (checking) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center space-y-4">
          <Shield className="w-16 h-16 text-red-400 mx-auto" />
          <p className="text-white text-lg font-bold">دسترسی محدود</p>
          <p className="text-white/40 text-sm">فقط ادمین‌ها می‌توانند این صفحه را ببینند</p>
          <button onClick={() => { if (window.history.length > 1) navigate(-1); else navigate("/Home", { replace: true }); }} className="inline-flex items-center gap-2 text-cyan-400 text-sm hover:underline">
            <ArrowLeft className="w-4 h-4" /> بازگشت
          </button>
        </div>
      </div>
    );
  }

  const adminCount = users.filter(u => u.role === "admin").length;
  const userCount = users.filter(u => u.role !== "admin").length;

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10" style={{ background: "rgba(13,17,23,0.98)" }}>
        <button onClick={() => { if (window.history.length > 1) navigate(-1); else navigate("/Home", { replace: true }); }} className="text-white/60 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <Users className="w-5 h-5 text-cyan-400" />
        <span className="text-lg font-bold">آمار کاربران</span>
        <button onClick={loadUsers} className="ml-auto p-2 rounded-lg hover:bg-white/10 transition-colors" title="Refresh">
          <RefreshCw className={`w-4 h-4 text-white/50 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Stats cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-2xl p-4 text-center border border-cyan-500/20" style={{ background: "rgba(6,182,212,0.08)" }}>
            <p className="text-3xl font-black text-cyan-400">{users.length}</p>
            <p className="text-white/50 text-xs mt-1">کل کاربران</p>
          </div>
          <div className="rounded-2xl p-4 text-center border border-purple-500/20" style={{ background: "rgba(168,85,247,0.08)" }}>
            <p className="text-3xl font-black text-purple-400">{adminCount}</p>
            <p className="text-white/50 text-xs mt-1">ادمین</p>
          </div>
          <div className="rounded-2xl p-4 text-center border border-white/10" style={{ background: "rgba(255,255,255,0.04)" }}>
            <p className="text-3xl font-black text-white">{userCount}</p>
            <p className="text-white/50 text-xs mt-1">کاربر عادی</p>
          </div>
        </div>

        {/* User list */}
        <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.03)" }}>
          <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
            <p className="text-sm font-bold text-white/60 uppercase tracking-wider">لیست کاربران</p>
            <span className="text-xs text-white/50">{users.length} نفر</span>
          </div>
          {loading ? (
            <div className="p-8 flex justify-center">
              <div className="w-8 h-8 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
            </div>
          ) : users.length === 0 ? (
            <div className="p-8 text-center text-white/50 text-sm">هیچ کاربری یافت نشد</div>
          ) : (
            <div className="divide-y divide-white/5">
              {users.map((u, i) => (
                <div key={u.id} className="flex items-center gap-3 px-4 py-3">
                  <div className="w-8 h-8 rounded-full bg-cyan-600/20 border border-cyan-500/20 flex items-center justify-center flex-shrink-0 text-xs font-bold text-cyan-400">
                    {(u.full_name || u.email || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white font-medium truncate">{u.full_name || "—"}</p>
                    <p className="text-xs text-white/40 truncate flex items-center gap-1">
                      <Mail className="w-3 h-3 flex-shrink-0" />{u.email}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                      u.role === "admin"
                        ? "bg-purple-500/20 text-purple-400 border-purple-500/30"
                        : "bg-white/5 text-white/40 border-white/10"
                    }`}>
                      {u.role || "user"}
                    </span>
                    {u.created_date && (
                      <span className="text-[10px] text-white/50 flex items-center gap-1">
                        <Calendar className="w-2.5 h-2.5" />
                        {new Date(u.created_date).toLocaleDateString("fa-IR")}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}