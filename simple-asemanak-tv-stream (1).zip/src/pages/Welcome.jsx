import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Check, ChevronLeft } from "lucide-react";

const LANGUAGES = [
  { code: "da", name: "دری", flag: "🇦🇫" },
  { code: "fa", name: "فارسی", flag: "🇮🇷" },
  { code: "en", name: "English", flag: "🇺🇸" },
];

// Pure-CSS 3D triangle logo (no image) — purple gradient with depth
function TriangleLogo() {
  return (
    <svg viewBox="0 0 120 120" style={{ width: "clamp(80px,12vw,130px)", height: "auto", filter: "drop-shadow(0 0 30px rgba(142,101,255,0.6))" }}>
      <defs>
        <linearGradient id="triLight" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e9d5ff" />
          <stop offset="100%" stopColor="#a855f7" />
        </linearGradient>
        <linearGradient id="triDark" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7c3aed" />
          <stop offset="100%" stopColor="#4c1d95" />
        </linearGradient>
      </defs>
      <polygon points="60,15 15,100 60,100" fill="url(#triLight)" />
      <polygon points="60,15 105,100 60,100" fill="url(#triDark)" />
      <polygon points="60,15 15,100 60,100" fill="none" stroke="#e9d5ff" strokeWidth="1.5" opacity="0.5" />
      <polygon points="60,15 105,100 60,100" fill="none" stroke="#c77dff" strokeWidth="1.5" opacity="0.4" />
      <line x1="60" y1="15" x2="60" y2="100" stroke="#fff" strokeWidth="1" opacity="0.2" />
    </svg>
  );
}

export default function Welcome({ onDone }) {
  const navigate = useNavigate();
  const [selected, setSelected] = useState(null);
  const [confirming, setConfirming] = useState(false);

  const confirm = () => {
    if (!selected) return;
    setConfirming(true);
    try {
      const settings = JSON.parse(localStorage.getItem("ayeneh_settings") || "{}");
      settings.language = selected;
      localStorage.setItem("ayeneh_settings", JSON.stringify(settings));
      localStorage.setItem("ayeneh_welcomed", "true");
      window.dispatchEvent(new Event("ayeneh-settings-changed"));
    } catch {}
    setTimeout(() => {
      if (onDone) onDone();
      else navigate("/");
    }, 600);
  };

  return (
    <div className="fixed inset-0 flex overflow-hidden" style={{ background: "#050510" }}>
      {/* ── Left panel: branding (pure CSS, no image) ── */}
      <div className="hidden md:flex flex-col items-center justify-center flex-shrink-0 relative overflow-hidden"
        style={{ width: "42%", background: "radial-gradient(ellipse at 50% 40%, #1a0b2e 0%, #0a0518 70%)" }}>
        {/* Starfield */}
        {[...Array(30)].map((_, i) => (
          <div key={i} className="absolute rounded-full bg-white" style={{
            width: `${1 + (i % 3)}px`, height: `${1 + (i % 3)}px`,
            top: `${(i * 37) % 100}%`, left: `${(i * 53) % 100}%`,
            animation: `twinkleStar ${2 + (i % 4)}s ease-in-out ${i * 0.15}s infinite`,
          }} />
        ))}
        {/* Nebula glow */}
        <div className="absolute" style={{ width: "60%", height: "60%", top: "20%", left: "20%", background: "radial-gradient(circle, rgba(142,101,255,0.15) 0%, transparent 70%)", filter: "blur(40px)" }} />

        {/* Logo */}
        <div style={{ animation: "logoFloat 4s ease-in-out infinite" }}>
          <TriangleLogo />
        </div>
        {/* Brand name */}
        <h1 className="text-white font-black mt-6" style={{ fontSize: "clamp(28px,4vw,48px)", letterSpacing: "0.08em", textShadow: "0 0 24px rgba(142,101,255,0.6)" }}>SEMANAK TV</h1>
        {/* Slogan */}
        <p className="text-white/60 mt-2" style={{ fontFamily: "Vazirmatn, sans-serif", fontSize: "clamp(14px,1.8vw,20px)" }}>دنیای سرگرمی در یک جا</p>

        {/* Progress bar at bottom */}
        <div className="absolute bottom-0 left-0 right-0" style={{ height: "4px", background: "rgba(255,255,255,0.06)" }}>
          <div style={{ height: "100%", background: "linear-gradient(90deg, #6e3cf5, #c77dff)", boxShadow: "0 0 12px rgba(142,101,255,0.8)", animation: "progressLoad 1.5s ease-out" }} />
        </div>
      </div>

      {/* ── Right panel: language selection ── */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8 relative overflow-y-auto"
        style={{ background: "#0c0f1a" }}>
        {/* Mobile branding */}
        <div className="md:hidden flex flex-col items-center mb-8" style={{ animation: "fadeIn 0.8s ease-out" }}>
          <div style={{ animation: "logoFloat 4s ease-in-out infinite" }}>
            <TriangleLogo />
          </div>
          <p className="text-white font-bold mt-3" style={{ fontSize: "18px", letterSpacing: "0.08em" }}>SEMANAK TV</p>
          <p className="text-white/40 text-xs" style={{ fontFamily: "Vazirmatn, sans-serif" }}>دنیای سرگرمی در یک جا</p>
        </div>

        {/* Header */}
        <div className="text-center mb-8" style={{ animation: "fadeIn 0.8s ease-out 0.1s both" }}>
          <h2 className="text-white font-bold mb-2" style={{ fontFamily: "Vazirmatn, sans-serif", fontSize: "clamp(22px,3vw,30px)" }}>
            زبان برنامه را انتخاب کنید
          </h2>
          <p className="text-white/50" style={{ fontFamily: "Vazirmatn, sans-serif", fontSize: "clamp(13px,1.4vw,16px)" }}>
            زبان دلخواه خود را برای استفاده از برنامه انتخاب کنید.
          </p>
        </div>

        {/* Language cards */}
        <div className="flex flex-col gap-3 w-full max-w-sm" style={{ animation: "fadeIn 0.8s ease-out 0.3s both" }}>
          {LANGUAGES.map(lang => (
            <button
              key={lang.code}
              onClick={() => setSelected(lang.code)}
              className="flex items-center gap-4 px-5 py-4 rounded-2xl transition-all hover:scale-[1.02] active:scale-95 text-right"
              style={{
                background: selected === lang.code ? "rgba(110,60,245,0.12)" : "rgba(22,26,43,0.6)",
                border: selected === lang.code ? "2px solid rgba(110,60,245,0.6)" : "1px solid rgba(255,255,255,0.08)",
                backdropFilter: "blur(12px)",
                boxShadow: selected === lang.code ? "0 0 24px rgba(110,60,245,0.25), inset 0 0 20px rgba(110,60,245,0.05)" : "none",
              }}>
              <span className="text-3xl flex-shrink-0">{lang.flag}</span>
              <p className="flex-1 text-white font-bold" style={{ fontFamily: lang.code === "en" ? "Inter, sans-serif" : "Vazirmatn, sans-serif", fontSize: "clamp(16px,1.8vw,20px)" }}>
                {lang.name}
              </p>
              <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                style={{
                  border: selected === lang.code ? "2px solid #6e3cf5" : "2px solid rgba(255,255,255,0.2)",
                  background: selected === lang.code ? "#6e3cf5" : "transparent",
                  boxShadow: selected === lang.code ? "0 0 14px rgba(110,60,245,0.6)" : "none",
                }}>
                {selected === lang.code && <Check className="w-3.5 h-3.5 text-white" />}
              </div>
            </button>
          ))}
        </div>

        {/* Confirm button */}
        <button
          onClick={confirm}
          disabled={!selected || confirming}
          className="mt-8 flex items-center gap-2 px-8 py-3.5 rounded-2xl text-white font-bold transition-all hover:scale-105 active:scale-95 disabled:opacity-40 disabled:hover:scale-100"
          style={{
            background: selected ? "linear-gradient(135deg, #6e3cf5, #9d4edd)" : "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            fontFamily: "Vazirmatn, sans-serif",
            fontSize: "15px",
            boxShadow: selected ? "0 0 24px rgba(110,60,245,0.4)" : "none",
            animation: "fadeIn 0.8s ease-out 0.5s both",
          }}>
          {confirming ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              در حال ادامه...
            </span>
          ) : (
            <>
              تایید و ادامه
              <ChevronLeft className="w-5 h-5" />
            </>
          )}
        </button>
      </div>

      <style>{`
        @keyframes fadeIn { 0% { opacity: 0; transform: translateY(15px); } 100% { opacity: 1; transform: translateY(0); } }
        @keyframes twinkleStar { 0%, 100% { opacity: 0.1; transform: scale(0.8); } 50% { opacity: 0.7; transform: scale(1.2); } }
        @keyframes logoFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        @keyframes progressLoad { from { width: 0; } to { width: 100%; } }
      `}</style>
    </div>
  );
}