import { useState, useEffect, useMemo, useRef } from "react";
import { useRemoteNav } from "@/lib/useRemoteNav";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Search as SearchIcon, Tv, Clapperboard, Film, PawPrint, Settings as SettingsIcon, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { idbGet } from "@/lib/idb";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

export default function SearchPage() {
  const navigate = useNavigate();
  const navRef = useRef(null);
  useRemoteNav(navRef, "button, a, [data-remote], [tabindex]:not([tabindex='-1'])", { autoFocus: false });
  const [query, setQuery] = useState("");
  const [isFa, setIsFa] = useState(true);
  const [channels, setChannels] = useState([]);
  const [media, setMedia] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    syncLang();
    window.addEventListener("ayeneh-settings-changed", syncLang);
    return () => window.removeEventListener("ayeneh-settings-changed", syncLang);
  }, []);

  useEffect(() => {
    // Load channels from cache
    try {
      const cached = JSON.parse(localStorage.getItem("ayeneh_channels_cache") || "[]");
      setChannels(cached);
    } catch {}

    // Load media from IndexedDB
    idbGet("series", "all").then(data => {
      if (Array.isArray(data)) setMedia(data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  // TV remote: Back key returns to main menu
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        navigate("/");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const dir = isFa ? "rtl" : "ltr";

  // Filter results
  const channelResults = useMemo(() => {
    if (!query.trim() || channels.length === 0) return [];
    const q = query.toLowerCase();
    return channels.filter(ch => ch.name?.toLowerCase().includes(q) || ch.name_fa?.toLowerCase().includes(q)).slice(0, 12);
  }, [query, channels]);

  const mediaResults = useMemo(() => {
    if (!query.trim() || media.length === 0) return [];
    const q = query.toLowerCase();
    return media.filter(m => m.title?.toLowerCase().includes(q)).slice(0, 12);
  }, [query, media]);

  // Settings quick links
  const settingsResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    const items = isFa ? [
      { label: "حساب کاربری", tab: "account" },
      { label: "عمومی", tab: "general" },
      { label: "پخش‌کننده", tab: "player" },
      { label: "عملکرد", tab: "performance" },
      { label: "زبان", tab: "language" },
      { label: "پلی‌لیست‌ها", tab: "playlists" },
      { label: "امنیت", tab: "security" },
      { label: "درباره", tab: "about" },
      { label: "تاریخ و آب‌وهوا", tab: "datetime" },
    ] : [
      { label: "Account", tab: "account" },
      { label: "General", tab: "general" },
      { label: "Player", tab: "player" },
      { label: "Performance", tab: "performance" },
      { label: "Language", tab: "language" },
      { label: "Playlists", tab: "playlists" },
      { label: "Security", tab: "security" },
      { label: "About", tab: "about" },
      { label: "Date & Weather", tab: "datetime" },
    ];
    return items.filter(i => i.label.toLowerCase().includes(q));
  }, [query, isFa]);

  const hasResults = channelResults.length > 0 || mediaResults.length > 0 || settingsResults.length > 0;

  return (
    <div ref={navRef} className="fixed inset-0 flex flex-col text-white overflow-hidden" style={{ background: "#0a0d16", direction: dir, fontFamily: "Vazirmatn, sans-serif" }}>
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 py-4 flex-shrink-0 z-20"
        style={{ background: "rgba(0,0,0,0.6)", borderBottom: "1px solid rgba(168,85,247,0.2)", paddingTop: "calc(1rem + env(safe-area-inset-top))", paddingLeft: "calc(1rem + env(safe-area-inset-left))", paddingRight: "calc(1rem + env(safe-area-inset-right))" }}>
        <button data-remote onClick={() => { if (window.history.length > 1) navigate(-1); else navigate("/", { replace: true }); }} className="text-white/60 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">
          <ArrowLeft className="w-5 h-5" style={{ transform: isFa ? "rotate(0deg)" : "rotate(180deg)" }} />
        </button>
        <div className="flex items-center gap-2.5 flex-1">
          <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0" style={{ boxShadow: "0 0 10px rgba(123,44,191,0.4)" }}>
            <img src={LOGO_URL} alt="Asemanak TV" className="w-full h-full object-cover" />
          </div>
          <p className="text-white font-bold text-sm">{isFa ? "جستجو" : "Search"}</p>
        </div>
      </div>

      {/* Search input */}
      <div className="px-4 py-4 flex-shrink-0">
        <div className="relative">
          <SearchIcon className="absolute top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" style={isFa ? { right: "16px" } : { left: "16px" }} />
          <input
            autoFocus
            data-remote
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder={isFa ? "جستجوی کانال‌ها، سریال‌ها، تنظیمات..." : "Search channels, series, settings..."}
            className="w-full rounded-2xl px-12 py-3.5 text-sm text-white placeholder:text-white/30 outline-none transition-all"
            style={{
              background: "rgba(255,255,255,0.05)", border: "1px solid rgba(168,85,247,0.3)",
              backdropFilter: "blur(10px)",
            }}
          />
          {query && (
            <button data-remote onClick={() => setQuery("")} className="absolute top-1/2 -translate-y-1/2 text-white/30 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center"
              style={isFa ? { left: "16px" } : { right: "16px" }}>
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto px-4 pb-[calc(5rem_+_env(safe-area-inset-bottom))] md:pb-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
          </div>
        ) : !query.trim() ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)" }}>
              <SearchIcon className="w-8 h-8 text-purple-400" />
            </div>
            <p className="text-white/40 text-sm">{isFa ? "برای جستجو تایپ کنید" : "Type to search"}</p>
            {/* Quick links */}
            <div className="flex flex-wrap gap-2 justify-center mt-4">
              {[
                { icon: Tv, label: isFa ? "تلویزیون زنده" : "Live TV", route: "/Home" },
                { icon: Clapperboard, label: isFa ? "سریال‌ها" : "Series", route: "/Media?cat=series" },
                { icon: Film, label: isFa ? "فیلم‌ها" : "Movies", route: "/Media?cat=movies" },
                { icon: PawPrint, label: isFa ? "انیمیشن" : "Animation", route: "/Media?cat=animation" },
                { icon: SettingsIcon, label: isFa ? "تنظیمات" : "Settings", route: "/Settings" },
              ].map((item, i) => {
                const Icon = item.icon;
                return (
                  <button key={i} data-remote onClick={() => navigate(item.route)}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", backdropFilter: "blur(8px)" }}>
                    <Icon className="w-4 h-4 text-cyan-400" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        ) : !hasResults ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <SearchIcon className="w-12 h-12 text-white/20" />
            <p className="text-white/40 text-sm">{isFa ? "نتیجه‌ای یافت نشد" : "No results found"}</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Channels */}
            {channelResults.length > 0 && (
              <div>
                <h3 className="text-sm font-bold text-cyan-400/70 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <Tv className="w-3.5 h-3.5" /> {isFa ? "کانال‌ها" : "Channels"} ({channelResults.length})
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {channelResults.map(ch => (
                    <button key={ch.id} data-remote onClick={() => navigate("/Home")}
                      className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-left transition-all hover:scale-[1.02]"
                      style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
                      {ch.logo_url && <img src={ch.logo_url} alt="" className="w-8 h-8 rounded-lg object-cover flex-shrink-0" />}
                      <span className="text-sm text-white/80 truncate flex-1">{ch.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Media */}
            {mediaResults.length > 0 && (
              <div>
                <h3 className="text-sm font-bold text-purple-400/70 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <Clapperboard className="w-3.5 h-3.5" /> {isFa ? "سریال و انیمیشن" : "Series & Media"} ({mediaResults.length})
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {mediaResults.map(m => (
                    <button key={m.id} data-remote onClick={() => navigate(`/Media?cat=${m.category || "series"}`)}
                      className="flex flex-col rounded-xl overflow-hidden text-left transition-all hover:scale-[1.02]"
                      style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
                      {m.poster && <img src={m.poster} alt="" className="w-full h-24 object-cover" />}
                      <span className="text-sm text-white/80 truncate px-2 py-2">{m.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Settings */}
            {settingsResults.length > 0 && (
              <div>
                <h3 className="text-sm font-bold text-amber-400/70 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <SettingsIcon className="w-3.5 h-3.5" /> {isFa ? "تنظیمات" : "Settings"} ({settingsResults.length})
                </h3>
                <div className="flex flex-wrap gap-2">
                  {settingsResults.map((s, i) => (
                    <button key={i} data-remote onClick={() => navigate(`/Settings/${s.tab}`)}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-white/80 transition-all hover:scale-105"
                      style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}