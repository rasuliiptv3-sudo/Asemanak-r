import { useState, useEffect, useCallback, useRef } from "react";
import { useRemoteNav } from "@/lib/useRemoteNav";
import { base44 } from "@/api/base44Client";
import { Star, Tv, ArrowLeft, Play, X, Heart, Film, RefreshCw } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { idbGet } from "@/lib/idb";
import { usePullToRefresh } from "@/lib/usePullToRefresh";

const MEDIA_FAV_KEY = "ayeneh_media_favorites";

export default function Favorites() {
  const navigate = useNavigate();
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_favorites") || "[]"); } catch { return []; }
  });
  const [mediaSeries, setMediaSeries] = useState([]);
  const [mediaFavs, setMediaFavs] = useState(() => {
    try { return JSON.parse(localStorage.getItem(MEDIA_FAV_KEY) || "[]"); } catch { return []; }
  });
  const [tab, setTab] = useState("channels");

  useEffect(() => {
    // Use cache for instant render, then refresh from server
    try {
      const cached = JSON.parse(localStorage.getItem("ayeneh_channels_cache") || "[]");
      if (cached.length) { setChannels(cached); setLoading(false); }
    } catch {}
    base44.entities.Channel.list("-created_date", 500).then((data) => {
      if (data?.length) setChannels(data);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    idbGet("series", "all").then(data => {
      if (Array.isArray(data)) setMediaSeries(data);
    });
    const onMediaFavChange = () => {
      try { setMediaFavs(JSON.parse(localStorage.getItem(MEDIA_FAV_KEY) || "[]")); } catch {}
    };
    window.addEventListener("ayeneh-media-favorites-changed", onMediaFavChange);
    return () => window.removeEventListener("ayeneh-media-favorites-changed", onMediaFavChange);
  }, []);

  const reload = useCallback(async () => {
    try {
      const data = await base44.entities.Channel.list("-created_date", 500);
      if (data?.length) setChannels(data);
    } catch {}
    try {
      const data = await idbGet("series", "all");
      if (Array.isArray(data)) setMediaSeries(data);
    } catch {}
  }, []);
  const { ref, pull, refreshing } = usePullToRefresh({ onRefresh: reload });
  const navRef = useRef(null);
  const setOuterRef = useCallback((el) => { ref.current = el; navRef.current = el; }, [ref]);
  useRemoteNav(navRef, "button, a, [data-remote], [tabindex]:not([tabindex='-1'])");

  // TV remote: Back key returns to main menu
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        navigate("/");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const removeFavorite = (id) => {
    setFavorites((prev) => {
      const next = prev.filter((f) => f !== id);
      try { localStorage.setItem("ayeneh_favorites", JSON.stringify(next)); }
      catch { return prev; }
      return next;
    });
  };

  const removeMediaFav = (id) => {
    setMediaFavs((prev) => {
      const next = prev.filter((f) => f !== id);
      try { localStorage.setItem(MEDIA_FAV_KEY, JSON.stringify(next)); }
      catch { return prev; }
      return next;
    });
  };

  const playChannel = (ch) => {
    localStorage.setItem("ayeneh_last_channel", ch.id);
    navigate("/Home");
  };

  const playMedia = (s) => {
    navigate("/Media");
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent("ayeneh-play-series", { detail: s.id }));
    }, 500);
  };

  const favChannels = channels.filter((ch) => favorites.includes(ch.id));
  const favMedia = mediaSeries.filter((s) => mediaFavs.includes(s.id));
  const channelCount = favChannels.length;
  const mediaCount = favMedia.length;

  const TabBtn = ({ id, label, icon, count }) => (
    <button data-remote onClick={() => setTab(id)}
      className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-bold transition-all ${tab === id ? "text-white" : "text-white/60 hover:text-white/80"}`}
      style={tab === id ? { background: "linear-gradient(135deg, rgba(168,85,247,0.25), rgba(6,182,212,0.15))", border: "1px solid rgba(168,85,247,0.4)" } : { border: "1px solid rgba(255,255,255,0.08)" }}>
      {icon}
      {label}
      {count > 0 && <span className="text-sm bg-white/10 rounded-full px-1.5 py-0.5">{count}</span>}
    </button>
  );

  return (
    <div ref={setOuterRef} className="relative h-full overflow-y-auto text-white" style={{ background: "linear-gradient(180deg, #0f1520 0%, #0a0f1a 100%)" }} dir="rtl">
      {/* Pull-to-refresh indicator (mobile) */}
      {(pull > 0 || refreshing) && (
        <div className="absolute left-1/2 top-0 z-30 flex flex-col items-center pointer-events-none"
          style={{ transform: `translateX(-50%) translateY(${pull}px)` }}>
          <RefreshCw className={`w-5 h-5 text-cyan-300 ${refreshing ? "animate-spin" : ""}`} style={{ opacity: Math.min(1, pull / 70) }} />
        </div>
      )}
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10 sticky top-0 z-10" style={{ background: "rgba(13,17,23,0.98)", paddingTop: "calc(1rem + env(safe-area-inset-top))" }}>
        <button onClick={() => { if (window.history.length > 1) navigate(-1); else navigate("/", { replace: true }); }} data-remote className="text-white/60 hover:text-white min-w-[44px] min-h-[44px] flex items-center justify-center">
          <ArrowLeft className="w-5 h-5 rotate-180" />
        </button>
        <Heart className="w-5 h-5 text-pink-400 fill-pink-400" />
        <span className="text-lg font-bold">علاقه‌مندی‌ها</span>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 px-5 py-3 border-b border-white/5">
        <TabBtn id="channels" label="کانال‌ها" icon={<Tv className="w-4 h-4" />} count={channelCount} />
        <TabBtn id="media" label="فیلم و سریال" icon={<Film className="w-4 h-4" />} count={mediaCount} />
      </div>

      <div className="max-w-5xl mx-auto px-4 pt-6 pb-[calc(5.5rem_+_env(safe-area-inset-bottom))] md:pb-6">
        {/* Channels tab */}
        {tab === "channels" && (
          <>
            {loading && channels.length === 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="rounded-xl overflow-hidden animate-pulse" style={{ background: "rgba(255,255,255,0.05)" }}>
                    <div className="h-28" style={{ background: "rgba(255,255,255,0.06)" }} />
                    <div className="p-3"><div className="h-3 rounded w-3/4" style={{ background: "rgba(255,255,255,0.08)" }} /></div>
                  </div>
                ))}
              </div>
            ) : favChannels.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {favChannels.map((ch) => (
                  <div key={ch.id} data-remote tabIndex={0}
                    onClick={() => playChannel(ch)}
                    className="group relative rounded-2xl overflow-hidden cursor-pointer transition-all border"
                    style={{ background: "rgba(255,255,255,0.04)", borderColor: "rgba(255,255,255,0.08)" }}>
                    <div className="h-28 flex items-center justify-center relative" style={{ background: "linear-gradient(135deg, rgba(168,85,247,0.15), rgba(6,182,212,0.12))" }}>
                      {ch.logo_url ? (
                        <img src={ch.logo_url} alt={ch.name} className="max-h-16 max-w-[70%] object-contain"
                          onError={(e) => { e.target.style.display = "none"; }} />
                      ) : (
                        <Tv className="w-10 h-10 text-white/20" />
                      )}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: "rgba(0,0,0,0.4)" }}>
                        <div className="w-11 h-11 rounded-full bg-cyan-500 flex items-center justify-center">
                          <Play className="w-5 h-5 fill-white text-white" />
                        </div>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); removeFavorite(ch.id); }} data-remote aria-label="Remove from favorites"
                        className="absolute top-2 left-2 w-11 h-11 rounded-full flex items-center justify-center transition-colors"
                        style={{ background: "rgba(0,0,0,0.5)" }}
                        title="حذف از علاقه‌مندی‌ها">
                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      </button>
                    </div>
                    <div className="px-3 py-2.5">
                      <p className="text-sm font-medium truncate">{ch.name}</p>
                      {ch.country && <p className="text-sm text-white/60 truncate mt-0.5">{ch.country}</p>}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState icon={<Tv className="w-8 h-8 text-white/20" />} text="هنوز کانال مورد علاقه‌ای ندارید" sub="با زدن ستاره روی کانال‌ها آن‌ها را اینجا ذخیره کنید" />
            )}
          </>
        )}

        {/* Media tab */}
        {tab === "media" && (
          <>
            {favMedia.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {favMedia.map((s) => (
                  <div key={s.id} data-remote tabIndex={0}
                    onClick={() => playMedia(s)}
                    className="group relative rounded-2xl overflow-hidden cursor-pointer transition-all border"
                    style={{ background: "rgba(255,255,255,0.04)", borderColor: "rgba(255,255,255,0.08)" }}>
                    <div className="h-40 flex items-center justify-center relative" style={{ background: "linear-gradient(135deg, rgba(168,85,247,0.15), rgba(6,182,212,0.12))" }}>
                      {s.poster ? (
                        <img src={s.poster} alt={s.title} className="w-full h-full object-cover"
                          onError={(e) => { e.target.style.display = "none"; }} />
                      ) : (
                        <Film className="w-10 h-10 text-white/20" />
                      )}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: "rgba(0,0,0,0.4)" }}>
                        <div className="w-11 h-11 rounded-full bg-purple-500 flex items-center justify-center">
                          <Play className="w-5 h-5 fill-white text-white" />
                        </div>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); removeMediaFav(s.id); }} data-remote aria-label="Remove from favorites"
                        className="absolute top-2 left-2 w-11 h-11 rounded-full flex items-center justify-center transition-colors"
                        style={{ background: "rgba(0,0,0,0.5)" }}
                        title="حذف از علاقه‌مندی‌ها">
                        <Heart className="w-4 h-4 text-pink-400 fill-pink-400" />
                      </button>
                    </div>
                    <div className="px-3 py-2.5">
                      <p className="text-sm font-medium truncate">{s.title}</p>
                      <p className="text-sm text-white/60 truncate mt-0.5">{(s.episodes || []).length} قسمت</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState icon={<Film className="w-8 h-8 text-white/20" />} text="هنوز فیلم یا سریالی در علاقه‌مندی‌ها ندارید" sub="از منوی سریال‌ها، روی هر سریال نگه دارید تا به علاقه‌مندی‌ها اضافه شود" />
            )}
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ icon, text, sub }) {
  return (
    <div className="text-center py-24">
      <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
        {icon}
      </div>
      <p className="text-lg font-semibold">{text}</p>
      <p className="text-white/60 mt-1 mb-6 text-sm">{sub}</p>
      <Link to="/" className="inline-flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-3 rounded-xl font-semibold transition-all">
        <Tv className="w-4 h-4" /> بازگشت به منو
      </Link>
    </div>
  );
}