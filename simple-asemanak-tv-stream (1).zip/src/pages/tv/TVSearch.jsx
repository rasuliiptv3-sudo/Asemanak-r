import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Tv, Clapperboard, Loader2, Delete } from "lucide-react";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import { base44 } from "@/api/base44Client";
import { idbGet } from "@/lib/idb";
import TVTopBar from "@/components/tv/TVTopBar";

export default function TVSearch() {
  const navigate = useNavigate();
  const [isFa, setIsFa] = useState(true);
  const [query, setQuery] = useState("");
  const [channels, setChannels] = useState([]);
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [focusArea, setFocusArea] = useState("keyboard"); // keyboard | results
  const inputRef = useRef(null);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try { setIsFa(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  // Load data
  useEffect(() => {
    const load = async () => {
      const cached = await idbGet("channels", "all");
      if (Array.isArray(cached)) setChannels(cached);
      try {
        const s = await base44.entities.Series.list("-updated_date", 100);
        setSeries(s || []);
      } catch {}
      setLoading(false);
    };
    load();
  }, []);

  // Search results
  const filteredChannels = query
    ? channels.filter((c) => (c.name || "").toLowerCase().includes(query.toLowerCase())).slice(0, 10)
    : [];
  const filteredSeries = query
    ? series.filter((s) => (s.title || "").toLowerCase().includes(query.toLowerCase())).slice(0, 10)
    : [];

  // Keyboard layout
  const faRows = [
    ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"],
    ["ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ"],
    ["ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و", "چ", "پاک"],
  ];
  const enRows = [
    ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"],
    ["K", "L", "M", "N", "O", "P", "Q", "R", "S", "T"],
    ["U", "V", "W", "X", "Y", "Z", " ", "⌫"],
  ];
  const rows = isFa ? faRows : enRows;

  const typeKey = (key) => {
    if (key === "⌫" || key === "پاک") {
      setQuery((q) => q.slice(0, -1));
    } else if (key === " ") {
      setQuery((q) => q + " ");
    } else {
      setQuery((q) => q + key);
    }
  };

  // Spatial navigation hook handles D-pad movement between keyboard and results automatically

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
      <TVTopBar title={isFa ? "جستجو" : "Search"} isFa={isFa} />

      <div className="flex-1 overflow-y-auto" style={{ padding: "24px 5%" }}>
        {/* Search input display */}
        <div className="mb-6 rounded-2xl px-6 py-5 flex items-center gap-4" style={{ background: "rgba(255,255,255,0.05)", border: "2px solid rgba(34,211,238,0.3)" }}>
          <Search className="w-8 h-8 text-cyan-400 flex-shrink-0" />
          <span className="text-2xl text-white flex-1">{query || (isFa ? "حروف را تایپ کنید..." : "Type to search...")}</span>
          {query && (
            <button data-remote onClick={() => setQuery("")} className="text-white/40 hover:text-white">
              <Delete className="w-7 h-7" />
            </button>
          )}
        </div>

        {/* On-screen keyboard */}
        <div className="mb-8" data-keyboard-area>
          {rows.map((row, ri) => (
            <div key={ri} className="flex gap-3 justify-center mb-3">
              {row.map((key) => (
                <button
                  key={key}
                  data-remote
                  onClick={() => typeKey(key)}
                  onFocus={() => setFocusArea("keyboard")}
                  className="rounded-2xl font-bold transition-all"
                  style={{
                    minWidth: key === " " ? "120px" : "64px",
                    minHeight: "64px",
                    background: key === "⌫" || key === "پاک" ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.06)",
                    border: "2px solid rgba(255,255,255,0.08)",
                    color: "#fff",
                    fontSize: "1.5rem",
                  }}
                >
                  {key === "⌫" || key === "پاک" ? "⌫" : key}
                </button>
              ))}
            </div>
          ))}
        </div>

        {/* Search results */}
        <div data-results-area>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
            </div>
          ) : query && filteredChannels.length === 0 && filteredSeries.length === 0 ? (
            <p className="text-white/30 text-xl text-center py-8">{isFa ? "نتیجه‌ای یافت نشد" : "No results found"}</p>
          ) : (
            <>
              {filteredChannels.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-xl font-bold text-white/60 mb-4">{isFa ? "کانال‌ها" : "Channels"}</h3>
                  <div className="flex flex-col gap-3">
                    {filteredChannels.map((ch) => (
                      <button
                        key={ch.id}
                        data-remote
                        onClick={() => navigate("/Home")}
                        className="flex items-center gap-4 rounded-2xl px-5 py-4 transition-all"
                        style={{ background: "rgba(255,255,255,0.04)", border: "2px solid rgba(255,255,255,0.06)", minHeight: "72px" }}
                      >
                        <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center" style={{ background: "rgba(255,255,255,0.08)" }}>
                          {ch.logo_url ? <img src={ch.logo_url} alt="" className="w-full h-full object-cover" /> : <Tv className="w-6 h-6 text-white/20" />}
                        </div>
                        <span className="text-xl font-bold text-white">{ch.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {filteredSeries.length > 0 && (
                <div>
                  <h3 className="text-xl font-bold text-white/60 mb-4">{isFa ? "سریال‌ها" : "Series"}</h3>
                  <div className="flex flex-col gap-3">
                    {filteredSeries.map((s) => (
                      <button
                        key={s.id}
                        data-remote
                        onClick={() => navigate(`/Media?series=${s.id}`)}
                        className="flex items-center gap-4 rounded-2xl px-5 py-4 transition-all"
                        style={{ background: "rgba(255,255,255,0.04)", border: "2px solid rgba(255,255,255,0.06)", minHeight: "72px" }}
                      >
                        <div className="w-12 h-16 rounded-lg overflow-hidden flex-shrink-0">
                          {s.poster ? <img src={s.poster} alt="" className="w-full h-full object-cover" /> : <Clapperboard className="w-8 h-8 text-white/20" />}
                        </div>
                        <span className="text-xl font-bold text-white">{s.title}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}