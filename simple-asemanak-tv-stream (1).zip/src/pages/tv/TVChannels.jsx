import { useState, useEffect, useRef } from "react";
import { Tv, Loader2, Star } from "lucide-react";
import Hls from "hls.js";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import { base44 } from "@/api/base44Client";
import { idbGet, idbSet } from "@/lib/idb";
import { killAllMedia } from "@/lib/killAllMedia";
import TVTopBar from "@/components/tv/TVTopBar";

const isYoutube = (url) => url && (url.includes("youtube.com") || url.includes("youtu.be"));
const getYoutubeEmbed = (url) => {
  if (!url) return url;
  if (url.includes("/embed/")) return url.includes("autoplay") ? url : url + (url.includes("?") ? "&autoplay=1" : "?autoplay=1");
  if (url.includes("watch?v=")) return url.replace("watch?v=", "embed/") + "?autoplay=1";
  if (url.includes("youtu.be/")) return "https://www.youtube.com/embed/" + url.split("youtu.be/")[1].split("?")[0] + "?autoplay=1";
  return url;
};

export default function TVChannels() {
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [videoLoading, setVideoLoading] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_favorites") || "[]"); } catch { return []; }
  });
  const [isFa, setIsFa] = useState(true);
  const videoRef = useRef(null);
  const hlsRef = useRef(null);
  const listRef = useRef(null);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try { setIsFa(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  // Load channels from IndexedDB cache first, then server
  useEffect(() => {
    const load = async () => {
      const cached = await idbGet("channels", "all");
      if (Array.isArray(cached) && cached.length > 0) {
        setChannels(cached);
        setLoading(false);
        const lastId = localStorage.getItem("ayeneh_last_channel");
        if (lastId) {
          const idx = cached.findIndex((c) => c.id === lastId);
          setSelectedIdx(idx >= 0 ? idx : 0);
        }
      }
      const cachedAt = (await idbGet("meta", "channels_updated_at")) || 0;
      const STALE_MS = 24 * 60 * 60 * 1000;
      if (cached?.length && Date.now() - cachedAt < STALE_MS) return;

      try {
        const all = await base44.entities.Channel.list("-created_date", 500);
        if (all?.length) {
          setChannels(all);
          await idbSet("channels", "all", all);
          await idbSet("meta", "channels_updated_at", Date.now());
        }
      } catch {}
      setLoading(false);
    };
    load();
  }, []);

  const selectedChannel = channels[selectedIdx];

  // Save last channel
  useEffect(() => {
    if (selectedChannel) localStorage.setItem("ayeneh_last_channel", selectedChannel.id);
  }, [selectedChannel]);

  // Scroll selected channel into view
  useEffect(() => {
    if (!listRef.current) return;
    const items = listRef.current.querySelectorAll("[data-remote]");
    if (items[selectedIdx]) items[selectedIdx].scrollIntoView({ block: "nearest" });
  }, [selectedIdx]);

  // HLS playback
  useEffect(() => {
    if (!selectedChannel?.stream_url) return;
    if (isYoutube(selectedChannel.stream_url)) return;

    setVideoLoading(true);
    setVideoError(false);
    const video = videoRef.current;
    if (!video) return;

    if (hlsRef.current) { try { hlsRef.current.destroy(); } catch {} hlsRef.current = null; }

    const url = selectedChannel.stream_url;

    if (Hls.isSupported() && (url.includes(".m3u8") || url.startsWith("http"))) {
      const hls = new Hls({ enableWorker: true, lowLatencyMode: true, maxBufferLength: 30 });
      hlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); setVideoLoading(false); });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) { setVideoLoading(false); setVideoError(true); }
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = url;
      video.play().catch(() => {});
    } else {
      video.src = url;
      video.play().catch(() => {});
    }

    return () => {
      if (videoRef.current) { try { videoRef.current.pause(); videoRef.current.src = ""; } catch {} }
      if (hlsRef.current) { try { hlsRef.current.destroy(); } catch {} hlsRef.current = null; }
    };
  }, [selectedChannel]);

  // Cleanup on unmount
  useEffect(() => () => killAllMedia(), []);

  const toggleFavorite = (id) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id];
      try { localStorage.setItem("ayeneh_favorites", JSON.stringify(next)); } catch {}
      return next;
    });
  };

  // Channel up/down via remote
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.defaultPrevented) return;
      if (["MediaTrackNext", "XF86ChannelUp", "ChannelUp", "PageUp"].includes(e.key)) {
        e.preventDefault();
        setSelectedIdx((i) => Math.min(channels.length - 1, i + 1));
      }
      if (["MediaTrackPrevious", "XF86ChannelDown", "ChannelDown", "PageDown"].includes(e.key)) {
        e.preventDefault();
        setSelectedIdx((i) => Math.max(0, i - 1));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [channels.length]);

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
      <TVTopBar title={isFa ? "تلویزیون زنده" : "Live TV"} isFa={isFa} />

      <div className="flex flex-1 min-h-0">
        {/* Channel list — left side */}
        <div
          ref={listRef}
          className="overflow-y-auto flex-shrink-0"
          style={{ width: "clamp(320px, 28vw, 420px)", padding: "16px", background: "rgba(8,0,15,0.6)" }}
        >
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
            </div>
          ) : (
            channels.map((ch, i) => {
              const isActive = i === selectedIdx;
              return (
                <button
                  key={ch.id}
                  data-remote
                  onClick={() => setSelectedIdx(i)}
                  className="w-full flex items-center gap-4 rounded-2xl px-4 py-4 mb-2 transition-all"
                  style={{
                    minHeight: "72px",
                    background: isActive ? "rgba(34,211,238,0.15)" : "rgba(255,255,255,0.03)",
                    border: isActive ? "2px solid rgba(34,211,238,0.5)" : "2px solid transparent",
                  }}
                >
                  <span className="text-xl font-mono text-white/40 flex-shrink-0" style={{ width: "40px" }}>{i + 1}</span>
                  <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center" style={{ background: "rgba(255,255,255,0.08)" }}>
                    {ch.logo_url ? (
                      <img src={ch.logo_url} alt="" className="w-full h-full object-cover" onError={(e) => { e.target.style.display = "none"; }} />
                    ) : (
                      <Tv className="w-6 h-6 text-white/20" />
                    )}
                  </div>
                  <span className="flex-1 text-left text-lg font-semibold text-white truncate">{ch.name}</span>
                  {favorites.includes(ch.id) && <Star className="w-5 h-5 text-yellow-400 fill-yellow-400 flex-shrink-0" />}
                </button>
              );
            })
          )}
        </div>

        {/* Video player — right side, fills remaining space */}
        <div className="flex-1 relative overflow-hidden bg-black min-w-0">
          {selectedChannel?.stream_url ? (
            isYoutube(selectedChannel.stream_url) ? (
              <iframe
                key={selectedChannel.id}
                src={getYoutubeEmbed(selectedChannel.stream_url)}
                className="absolute inset-0 w-full h-full"
                allowFullScreen
                allow="autoplay; encrypted-media"
                title={selectedChannel.name}
              />
            ) : (
              <video
                ref={videoRef}
                className="absolute inset-0 w-full h-full object-cover"
                autoPlay
                playsInline
                onCanPlay={() => setVideoLoading(false)}
                onPlaying={() => setVideoLoading(false)}
                onError={() => { setVideoLoading(false); setVideoError(true); }}
              />
            )
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
              <Tv className="w-20 h-20 text-white/20" />
              <p className="text-white/30 text-xl">{isFa ? "یک کانال انتخاب کنید" : "Select a channel"}</p>
            </div>
          )}

          {videoLoading && (
            <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.6)" }}>
              <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
            </div>
          )}

          {videoError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3" style={{ background: "rgba(0,0,0,0.8)" }}>
              <p className="text-white text-xl font-bold">{selectedChannel?.name}</p>
              <p className="text-red-400 text-lg">{isFa ? "کانال در دسترس نیست" : "Channel unavailable"}</p>
            </div>
          )}

          {/* Channel info overlay */}
          {selectedChannel && (
            <div className="absolute top-6 left-6 z-10 rounded-2xl px-6 py-4" style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(12px)" }}>
              <div className="flex items-center gap-4">
                {selectedChannel.logo_url && <img src={selectedChannel.logo_url} alt="" className="w-14 h-14 rounded-xl object-cover" />}
                <div>
                  <p className="text-2xl font-bold text-white">{selectedChannel.name}</p>
                  {selectedChannel.category && <p className="text-lg text-white/50 capitalize">{selectedChannel.category}</p>}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}