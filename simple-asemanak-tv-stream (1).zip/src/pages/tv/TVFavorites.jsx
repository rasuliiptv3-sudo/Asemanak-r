import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Star, Tv, Clapperboard, Loader2 } from "lucide-react";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import { base44 } from "@/api/base44Client";
import { idbGet } from "@/lib/idb";
import TVTopBar from "@/components/tv/TVTopBar";

export default function TVFavorites() {
  const navigate = useNavigate();
  const [isFa, setIsFa] = useState(true);
  const [channels, setChannels] = useState([]);
  const [series, setSeries] = useState([]);
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_favorites") || "[]"); } catch { return []; }
  });
  const [loading, setLoading] = useState(true);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try { setIsFa(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  useEffect(() => {
    const load = async () => {
      const cached = await idbGet("channels", "all");
      if (Array.isArray(cached)) setChannels(cached);
      try {
        const s = await base44.entities.Series.list("-updated_date", 100);
        setSeries(s || []);
      } catch {}
      setLoading(false);
    };
    load();
  }, []);

  const favChannels = channels.filter((c) => favorites.includes(c.id));
  const favSeries = series.filter((s) => favorites.includes(s.id));

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
      <TVTopBar title={isFa ? "محبوب‌ترین‌ها" : "Favorites"} isFa={isFa} />

      <div className="flex-1 overflow-y-auto" style={{ padding: "24px 5%" }}>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
          </div>
        ) : favChannels.length === 0 && favSeries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4">
            <Star className="w-20 h-20 text-white/20" />
            <p className="text-white/30 text-xl">{isFa ? "محبوبی وجود ندارد" : "No favorites yet"}</p>
          </div>
        ) : (
          <>
            {favChannels.length > 0 && (
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-white mb-5">{isFa ? "کانال‌های محبوب" : "Favorite Channels"}</h2>
                <div className="flex flex-col gap-3 max-w-4xl">
                  {favChannels.map((ch) => (
                    <button
                      key={ch.id}
                      data-remote
                      onClick={() => navigate("/Home")}
                      className="flex items-center gap-4 rounded-2xl px-5 py-4 transition-all"
                      style={{ background: "rgba(255,255,255,0.04)", border: "2px solid rgba(255,255,255,0.06)", minHeight: "72px" }}
                    >
                      <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0 flex items-center justify-center" style={{ background: "rgba(255,255,255,0.08)" }}>
                        {ch.logo_url ? <img src={ch.logo_url} alt="" className="w-full h-full object-cover" /> : <Tv className="w-6 h-6 text-white/20" />}
                      </div>
                      <span className="text-xl font-bold text-white flex-1 text-left">{ch.name}</span>
                      <Star className="w-6 h-6 text-yellow-400 fill-yellow-400" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {favSeries.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-white mb-5">{isFa ? "سریال‌های محبوب" : "Favorite Series"}</h2>
                <div className="flex gap-5 overflow-x-auto pb-4" style={{ scrollbarWidth: "none" }}>
                  {favSeries.map((s) => (
                    <button
                      key={s.id}
                      data-remote
                      onClick={() => navigate(`/Media?series=${s.id}`)}
                      className="flex-shrink-0 rounded-2xl overflow-hidden transition-all"
                      style={{ width: "220px", border: "2px solid rgba(255,255,255,0.06)" }}
                    >
                      {s.poster ? (
                        <img src={s.poster} alt={s.title} className="w-full object-cover" style={{ height: "300px" }} />
                      ) : (
                        <div className="w-full flex items-center justify-center" style={{ height: "300px", background: "rgba(255,255,255,0.05)" }}>
                          <Clapperboard className="w-12 h-12 text-white/20" />
                        </div>
                      )}
                      <div className="p-3" style={{ background: "rgba(0,0,0,0.6)" }}>
                        <p className="text-lg font-bold text-white truncate">{s.title}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}