import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tv, Clapperboard, Star, Search, Settings, Film } from "lucide-react";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import { base44 } from "@/api/base44Client";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

export default function TVHome() {
  const navigate = useNavigate();
  const [isFa, setIsFa] = useState(true);
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try { setIsFa(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  useEffect(() => {
    base44.entities.Series.list("-updated_date", 12)
      .then(setSeries)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const sections = [
    { icon: Tv, title: isFa ? "تلویزیون زنده" : "Live TV", route: "/Home", color: "#00d4ff" },
    { icon: Clapperboard, title: isFa ? "سریال‌ها" : "Series", route: "/Media?cat=series", color: "#9d4edd" },
    { icon: Film, title: isFa ? "انیمیشن" : "Animation", route: "/Media?cat=animation", color: "#f43f5e" },
    { icon: Star, title: isFa ? "محبوب‌ترین‌ها" : "Favorites", route: "/Favorites", color: "#fbbf24" },
    { icon: Search, title: isFa ? "جستجو" : "Search", route: "/Search", color: "#34d399" },
    { icon: Settings, title: isFa ? "تنظیمات" : "Settings", route: "/Settings", color: "#6366f1" },
  ];

  return (
    <div
      className="fixed inset-0 flex flex-col overflow-hidden"
      dir={isFa ? "rtl" : "ltr"}
      style={{ background: "linear-gradient(135deg, #0a0418 0%, #150a28 40%, #08000f 100%)", padding: "5%" }}
    >
      {/* Logo + title */}
      <div className="flex items-center gap-5 mb-8 flex-shrink-0">
        <img src={LOGO_URL} alt="Asemanak TV" className="w-20 h-20 rounded-2xl" />
        <div>
          <h1 className="text-4xl font-black text-white">آسمانک تی‌وی</h1>
          <p className="text-xl text-cyan-400/60 mt-1">{isFa ? "پلتفرم پخش آنلاین" : "Streaming Platform"}</p>
        </div>
      </div>

      {/* Main sections grid */}
      <div className="grid gap-6 mb-8 flex-shrink-0" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
        {sections.map((s) => (
          <button
            key={s.route}
            data-remote
            onClick={() => navigate(s.route)}
            className="flex flex-col items-center justify-center gap-5 rounded-3xl transition-all"
            style={{
              background: `linear-gradient(135deg, ${s.color}18, ${s.color}08)`,
              border: "2px solid rgba(255,255,255,0.08)",
              minHeight: "clamp(160px, 18vh, 220px)",
            }}
          >
            <s.icon className="w-16 h-16" style={{ color: s.color }} strokeWidth={1.5} />
            <span className="text-2xl font-bold text-white">{s.title}</span>
          </button>
        ))}
      </div>

      {/* New Series row */}
      <div className="flex-1 min-h-0 overflow-hidden">
        <h2 className="text-2xl font-bold text-white mb-4">{isFa ? "سریال‌های جدید" : "New Series"}</h2>
        {loading ? (
          <div className="flex items-center gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="rounded-2xl animate-pulse" style={{ width: "200px", height: "280px", background: "rgba(255,255,255,0.05)" }} />
            ))}
          </div>
        ) : series.length > 0 ? (
          <div className="flex gap-5 overflow-x-auto pb-4" style={{ scrollbarWidth: "none" }}>
            {series.map((s) => (
              <button
                key={s.id}
                data-remote
                onClick={() => navigate(`/Media?series=${s.id}`)}
                className="flex-shrink-0 rounded-2xl overflow-hidden transition-all"
                style={{ width: "200px", border: "2px solid rgba(255,255,255,0.06)" }}
              >
                {s.poster ? (
                  <img src={s.poster} alt={s.title} className="w-full object-cover" style={{ height: "280px" }} />
                ) : (
                  <div className="w-full flex items-center justify-center" style={{ height: "280px", background: "rgba(255,255,255,0.05)" }}>
                    <Clapperboard className="w-12 h-12 text-white/20" />
                  </div>
                )}
                <div className="p-3" style={{ background: "rgba(0,0,0,0.6)" }}>
                  <p className="text-lg font-bold text-white truncate">{s.title}</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-white/30 text-lg">{isFa ? "محتوایی موجود نیست" : "No content available"}</p>
        )}
      </div>
    </div>
  );
}