import { useState, useEffect } from "react";
import { ArrowLeft, Play, List, Loader2 } from "lucide-react";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import { base44 } from "@/api/base44Client";
import { killAllMedia } from "@/lib/killAllMedia";
import HlsVideoPlayer from "@/components/media/HlsVideoPlayer";
import YouTubePlayer from "@/components/media/YouTubePlayer";

export default function TVSeriesDetail({ seriesId, onBack }) {
  const [series, setSeries] = useState(null);
  const [loading, setLoading] = useState(true);
  const [playingEpisode, setPlayingEpisode] = useState(null);
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [isFa, setIsFa] = useState(true);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try { setIsFa(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  useEffect(() => {
    if (!seriesId) return;
    setLoading(true);
    base44.entities.Series.get(seriesId)
      .then(setSeries)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [seriesId]);

  // Cleanup media on unmount
  useEffect(() => () => killAllMedia(), []);

  // Kill media when leaving player
  useEffect(() => {
    if (!playingEpisode) killAllMedia();
  }, [playingEpisode]);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={{ background: "#08000f" }}>
        <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
      </div>
    );
  }

  if (!series) {
    return (
      <div className="fixed inset-0 flex flex-col items-center justify-center gap-4" style={{ background: "#08000f" }}>
        <p className="text-white/40 text-xl">{isFa ? "سریال یافت نشد" : "Series not found"}</p>
        <button onClick={onBack} data-remote className="px-8 py-4 rounded-2xl bg-cyan-600 text-white text-lg font-bold">
          {isFa ? "بازگشت" : "Back"}
        </button>
      </div>
    );
  }

  // ── Playing mode: full-screen player ──
  if (playingEpisode) {
    return (
      <div className="fixed inset-0 bg-black overflow-hidden">
        {playingEpisode.embedUrl ? (
          <iframe src={playingEpisode.embedUrl} allow="autoplay; fullscreen" allowFullScreen className="absolute inset-0 w-full h-full" frameBorder="0" />
        ) : playingEpisode.fileUrl ? (
          <HlsVideoPlayer
            key={playingEpisode._playId || playingEpisode.fileUrl}
            src={playingEpisode.fileUrl}
            onVideoClick={() => {}}
            seriesTitle={series.title}
            seriesPoster={series.poster}
            posterPosition={series.posterPosition}
          />
        ) : playingEpisode.videoId ? (
          <YouTubePlayer
            key={playingEpisode._playId || playingEpisode.videoId}
            videoId={playingEpisode.videoId}
            onVideoClick={() => {}}
            seriesTitle={series.title}
            seriesPoster={series.poster}
            posterPosition={series.posterPosition}
            hideInfo
          />
        ) : null}

        {/* Back button overlay — top left, always visible. data-tv-player-back lets the spatial nav hook exit the player on Back key */}
        <button
          onClick={() => { setPlayingEpisode(null); }}
          data-remote
          data-tv-player-back
          className="absolute top-6 left-6 z-50 flex items-center gap-3 rounded-2xl px-6 py-4 transition-all"
          style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.15)" }}
        >
          <ArrowLeft className="w-8 h-8 text-white" />
          <span className="text-xl font-bold text-white">{isFa ? "بازگشت" : "Back"}</span>
        </button>
      </div>
    );
  }

  // ── Detail mode: hero + episode list ──
  const allEpisodes = (series.episodes || []).slice().sort((a, b) => a.number - b.number);
  const seasons = [...new Set(allEpisodes.map((e) => Number(e.season) || 1))].sort((a, b) => a - b);
  const currentSeason = seasons.includes(selectedSeason) ? selectedSeason : (seasons[0] || 1);
  const episodes = allEpisodes.filter((e) => (Number(e.season) || 1) === currentSeason);

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
      {/* Hero section */}
      <div className="relative flex-shrink-0" style={{ height: "clamp(280px, 35vh, 400px)" }}>
        {series.poster && (
          <img
            src={series.poster}
            alt={series.title}
            className="absolute inset-0 w-full h-full object-cover"
            style={{ objectPosition: series.posterPosition || "center 20%" }}
            onError={(e) => { e.target.style.display = "none"; }}
          />
        )}
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(8,0,15,0.4) 0%, rgba(8,0,15,0.85) 70%, #08000f 100%)" }} />

        {/* Back button */}
        <button
          onClick={onBack}
          data-remote
          className="absolute top-6 left-6 z-10 flex items-center gap-3 rounded-2xl px-6 py-4 transition-all"
          style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.15)" }}
        >
          <ArrowLeft className="w-8 h-8 text-white" />
          <span className="text-xl font-bold text-white">{isFa ? "بازگشت" : "Back"}</span>
        </button>

        {/* Title + info */}
        <div className="absolute bottom-0 left-0 right-0 p-8 z-10">
          <h1 className="text-4xl font-black text-white mb-2 drop-shadow-lg">{series.title}</h1>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-2 text-cyan-300 text-xl font-semibold bg-cyan-600/20 border border-cyan-500/30 rounded-full px-4 py-1">
              <List className="w-5 h-5" /> {allEpisodes.length} {isFa ? "قسمت" : "episodes"}
            </span>
          </div>
          {series.description && (
            <p className="text-white/60 text-lg mt-3 max-w-3xl line-clamp-2">{series.description}</p>
          )}
        </div>
      </div>

      {/* Season selector + episode list */}
      <div className="flex-1 overflow-y-auto" style={{ padding: "24px 5%" }}>
        {seasons.length > 1 && (
          <div className="flex gap-3 mb-6">
            {seasons.map((s) => (
              <button
                key={s}
                data-remote
                onClick={() => setSelectedSeason(s)}
                className="px-6 py-3 rounded-2xl text-lg font-bold transition-all"
                style={
                  currentSeason === s
                    ? { background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", color: "#fff", boxShadow: "0 4px 16px rgba(123,44,191,0.4)" }
                    : { background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.1)" }
                }
              >
                {isFa ? `فصل ${s}` : `Season ${s}`}
              </button>
            ))}
          </div>
        )}

        <div className="flex flex-col gap-3 max-w-4xl">
          {episodes.map((ep, i) => (
            <button
              key={`${ep.videoId || ep.fileUrl}-${i}`}
              data-remote
              onClick={() => setPlayingEpisode({ ...ep, _playId: Date.now() })}
              className="flex items-center gap-5 rounded-2xl px-5 py-4 transition-all text-left"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "2px solid rgba(255,255,255,0.06)",
                minHeight: "80px",
              }}
            >
              <div className="w-14 h-14 flex-shrink-0 flex items-center justify-center rounded-2xl text-2xl font-bold" style={{ background: "rgba(123,44,191,0.2)", border: "1px solid rgba(123,44,191,0.4)", color: "#c77dff" }}>
                {ep.number}
              </div>
              <div className="relative w-32 h-20 flex-shrink-0 rounded-xl overflow-hidden bg-black/40">
                {ep.fileUrl ? (
                  <video src={ep.fileUrl} className="w-full h-full object-cover" muted preload="metadata" />
                ) : ep.videoId ? (
                  <img src={`https://img.youtube.com/vi/${ep.videoId}/mqdefault.jpg`} alt="" className="w-full h-full object-cover" onError={(e) => { e.target.style.display = "none"; }} />
                ) : null}
                <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.3)" }}>
                  <Play className="w-8 h-8 text-white/80" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xl font-bold text-white truncate">
                  {/^(قسمت|Episode)\s+\d+$/i.test((ep.title || "").trim()) ? `${isFa ? "قسمت" : "Episode"} ${ep.number}` : (ep.title || `${isFa ? "قسمت" : "Episode"} ${ep.number}`)}
                </p>
                <p className="text-base text-white/40 mt-1">{isFa ? "قسمت" : "Episode"} {ep.number}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}