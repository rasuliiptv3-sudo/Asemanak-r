import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Clapperboard, Film, Loader2, Play } from "lucide-react";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import { base44 } from "@/api/base44Client";
import TVTopBar from "@/components/tv/TVTopBar";
import TVSeriesDetail from "@/pages/tv/TVSeriesDetail";

export default function TVMedia() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const seriesId = searchParams.get("series");
  const cat = searchParams.get("cat");
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFa, setIsFa] = useState(true);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try { setIsFa(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  useEffect(() => {
    base44.entities.Series.list("-updated_date", 100)
      .then(setSeries)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  // If a series is selected, show the series detail page
  if (seriesId) {
    return <TVSeriesDetail seriesId={seriesId} onBack={() => setSearchParams({})} />;
  }

  // Group series by category
  const categories = {};
  series.forEach((s) => {
    const c = s.category || "series";
    if (!categories[c]) categories[c] = [];
    categories[c].push(s);
  });

  const categoryLabels = {
    series: isFa ? "سریال‌ها" : "Series",
    movies: isFa ? "فیلم‌ها" : "Movies",
    animation: isFa ? "انیمیشن" : "Animation",
    comedy: isFa ? "کمدی" : "Comedy",
    drama: isFa ? "درام" : "Drama",
    occasional: isFa ? "مناسبتی" : "Occasional",
  };

  // If a category is selected, show only that category
  const displayCategories = cat ? { [cat]: categories[cat] || [] } : categories;

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
      <TVTopBar title={isFa ? "سریال‌ها و فیلم‌ها" : "Series & Movies"} isFa={isFa} />

      <div className="flex-1 overflow-y-auto" style={{ padding: "32px 5%" }}>
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
          </div>
        ) : Object.keys(displayCategories).length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4">
            <Clapperboard className="w-20 h-20 text-white/20" />
            <p className="text-white/30 text-xl">{isFa ? "محتوایی موجود نیست" : "No content available"}</p>
          </div>
        ) : (
          Object.entries(displayCategories).map(([catKey, items]) => (
            <div key={catKey} className="mb-10">
              <h2 className="text-2xl font-bold text-white mb-5">{categoryLabels[catKey] || catKey}</h2>
              <div className="flex gap-5 overflow-x-auto pb-4" style={{ scrollbarWidth: "none" }}>
                {items.map((s) => (
                  <button
                    key={s.id}
                    data-remote
                    onClick={() => setSearchParams({ series: s.id })}
                    className="flex-shrink-0 rounded-2xl overflow-hidden transition-all"
                    style={{ width: "220px", border: "2px solid rgba(255,255,255,0.06)" }}
                  >
                    {s.poster ? (
                      <img src={s.poster} alt={s.title} className="w-full object-cover" style={{ height: "300px" }} />
                    ) : (
                      <div className="w-full flex items-center justify-center" style={{ height: "300px", background: "rgba(255,255,255,0.05)" }}>
                        <Film className="w-12 h-12 text-white/20" />
                      </div>
                    )}
                    <div className="p-3" style={{ background: "rgba(0,0,0,0.6)" }}>
                      <p className="text-lg font-bold text-white truncate">{s.title}</p>
                      <p className="text-sm text-white/40 mt-1">{(s.episodes || []).length} {isFa ? "قسمت" : "episodes"}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}