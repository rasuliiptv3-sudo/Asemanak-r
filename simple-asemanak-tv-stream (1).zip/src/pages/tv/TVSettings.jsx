import { useState, useEffect } from "react";
import { Settings, Lock, Trash2, Globe, Server, Film, ChevronRight, Check } from "lucide-react";
import { useTVSpatialNav } from "@/lib/useTVSpatialNav";
import TVTopBar from "@/components/tv/TVTopBar";

export default function TVSettings() {
  const [isFa, setIsFa] = useState(true);
  const [settings, setSettings] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
  });
  const [activeSection, setActiveSection] = useState(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  useTVSpatialNav();

  useEffect(() => {
    const read = () => {
      try {
        const s = JSON.parse(localStorage.getItem("ayeneh_settings") || "{}");
        setSettings(s);
        setIsFa(s.language !== "en");
      } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  const updateSetting = (key, value) => {
    const next = { ...settings, [key]: value };
    setSettings(next);
    try { localStorage.setItem("ayeneh_settings", JSON.stringify(next)); } catch {}
    window.dispatchEvent(new Event("ayeneh-settings-changed"));
  };

  const sections = [
    { id: "playback", icon: Film, label: isFa ? "پخش" : "Playback", color: "#9d4edd" },
    { id: "security", icon: Lock, label: isFa ? "امنیت" : "Security", color: "#ef4444" },
    { id: "cache", icon: Trash2, label: isFa ? "حافظه پنهان" : "Cache", color: "#f59e0b" },
    { id: "language", icon: Globe, label: isFa ? "زبان" : "Language", color: "#34d399" },
    { id: "server", icon: Server, label: isFa ? "وضعیت سرور" : "Server Status", color: "#00d4ff" },
  ];

  const clearCache = () => {
    try {
      if (window.caches) caches.keys().then((names) => names.forEach((n) => caches.delete(n)));
      localStorage.removeItem("ayeneh_channels_cache");
      sessionStorage.clear();
    } catch {}
    setShowClearConfirm(false);
  };

  // ── Clear cache confirmation ──
  if (showClearConfirm) {
    return (
      <div className="fixed inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.9)" }}>
        <div className="rounded-3xl p-10 max-w-lg" style={{ background: "rgba(20,14,35,0.95)", border: "2px solid rgba(239,68,68,0.3)" }}>
          <Trash2 className="w-16 h-16 text-red-400 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white text-center mb-4">{isFa ? "پاک کردن حافظه پنهان؟" : "Clear Cache?"}</h2>
          <p className="text-white/50 text-lg text-center mb-8">{isFa ? "این عمل قابل بازگشت نیست" : "This action cannot be undone"}</p>
          <div className="flex gap-4 justify-center">
            <button
              onClick={() => setShowClearConfirm(false)}
              data-remote
              className="px-8 py-4 rounded-2xl text-lg font-bold transition-all"
              style={{ background: "rgba(255,255,255,0.08)", color: "#fff" }}
            >
              {isFa ? "انصراف" : "Cancel"}
            </button>
            <button
              onClick={clearCache}
              data-remote
              className="px-8 py-4 rounded-2xl text-lg font-bold transition-all"
              style={{ background: "#ef4444", color: "#fff" }}
            >
              {isFa ? "پاک کن" : "Clear"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── Section detail view ──
  if (activeSection) {
    const section = sections.find((s) => s.id === activeSection);
    const Icon = section.icon;

    return (
      <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
        <TVTopBar title={section.label} isFa={isFa} />

        <div className="flex-1 overflow-y-auto" style={{ padding: "32px 5%" }}>
          {/* Playback settings */}
          {activeSection === "playback" && (
            <div className="flex flex-col gap-4 max-w-3xl">
              <SettingToggle
                label={isFa ? "حالت کم پهنای باند" : "Low Bandwidth Mode"}
                value={settings.lowBandwidth === true}
                isFa={isFa}
                onToggle={() => updateSetting("lowBandwidth", !settings.lowBandwidth)}
              />
              <SettingToggle
                label={isFa ? "تأخیر کم HLS" : "HLS Low Latency"}
                value={settings.hlsLowLatency !== false}
                isFa={isFa}
                onToggle={() => updateSetting("hlsLowLatency", settings.hlsLowLatency === false)}
              />
              <SettingToggle
                label={isFa ? "زیرنویس" : "Subtitles"}
                value={settings.subtitleEnabled === true}
                isFa={isFa}
                onToggle={() => updateSetting("subtitleEnabled", !settings.subtitleEnabled)}
              />
              <SettingToggle
                label={isFa ? "دوبله" : "Dubbing"}
                value={settings.dubbingEnabled === true}
                isFa={isFa}
                onToggle={() => updateSetting("dubbingEnabled", !settings.dubbingEnabled)}
              />
            </div>
          )}

          {/* Security settings */}
          {activeSection === "security" && (
            <div className="flex flex-col gap-4 max-w-3xl">
              <SettingToggle
                label={isFa ? "قفل پین" : "PIN Lock"}
                value={settings.pinLock === true}
                isFa={isFa}
                onToggle={() => updateSetting("pinLock", !settings.pinLock)}
              />
              <SettingButton
                label={isFa ? "تغییر پین" : "Change PIN"}
                isFa={isFa}
                onClick={() => {
                  const pin = window.prompt(isFa ? "پین جدید را وارد کنید" : "Enter new PIN");
                  if (pin) updateSetting("pin", pin);
                }}
              />
              <SettingButton
                label={isFa ? "حذف پین" : "Remove PIN"}
                isFa={isFa}
                onClick={() => { updateSetting("pin", null); updateSetting("pinLock", false); }}
              />
            </div>
          )}

          {/* Cache settings */}
          {activeSection === "cache" && (
            <div className="flex flex-col gap-4 max-w-3xl">
              <SettingButton
                label={isFa ? "پاک کردن حافظه پنهان" : "Clear Cache"}
                isFa={isFa}
                onClick={() => setShowClearConfirm(true)}
              />
              <SettingButton
                label={isFa ? "پاک کردن داده آفلاین" : "Clear Offline Data"}
                isFa={isFa}
                onClick={() => {
                  try { indexedDB.deleteDatabase("ayeneh_offline"); } catch {}
                  setShowClearConfirm(false);
                }}
              />
            </div>
          )}

          {/* Language settings */}
          {activeSection === "language" && (
            <div className="flex flex-col gap-4 max-w-3xl">
              <SettingButton
                label="فارسی"
                isFa={isFa}
                active={settings.language !== "en"}
                onClick={() => updateSetting("language", "fa")}
              />
              <SettingButton
                label="English"
                isFa={isFa}
                active={settings.language === "en"}
                onClick={() => updateSetting("language", "en")}
              />
            </div>
          )}

          {/* Server status */}
          {activeSection === "server" && (
            <div className="flex flex-col gap-4 max-w-3xl">
              <div className="rounded-2xl p-6" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-4 h-4 rounded-full" style={{ background: "#34d399", boxShadow: "0 0 12px #34d399" }} />
                  <span className="text-xl font-bold text-white">{isFa ? "سرور آنلاین" : "Server Online"}</span>
                </div>
                <p className="text-white/50 text-lg">{isFa ? "اتصال پایدار" : "Connection stable"}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── Main settings menu ──
  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ background: "#08000f" }}>
      <TVTopBar title={isFa ? "تنظیمات" : "Settings"} isFa={isFa} />

      <div className="flex-1 overflow-y-auto" style={{ padding: "32px 5%" }}>
        <div className="flex flex-col gap-4 max-w-3xl">
          {sections.map((s) => (
            <button
              key={s.id}
              data-remote
              onClick={() => setActiveSection(s.id)}
              className="flex items-center gap-5 rounded-2xl px-6 py-6 transition-all"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "2px solid rgba(255,255,255,0.06)",
                minHeight: "80px",
              }}
            >
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: `${s.color}20`, border: `1px solid ${s.color}40` }}>
                <s.icon className="w-8 h-8" style={{ color: s.color }} />
              </div>
              <span className="flex-1 text-left text-2xl font-bold text-white">{s.label}</span>
              <ChevronRight className="w-8 h-8 text-white/30" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function SettingToggle({ label, value, isFa, onToggle }) {
  return (
    <button
      data-remote
      onClick={onToggle}
      className="flex items-center gap-5 rounded-2xl px-6 py-5 transition-all"
      style={{ background: "rgba(255,255,255,0.04)", border: "2px solid rgba(255,255,255,0.06)", minHeight: "72px" }}
    >
      <span className="flex-1 text-left text-xl font-bold text-white">{label}</span>
      <div
        className="w-16 h-9 rounded-full flex items-center transition-all flex-shrink-0"
        style={{ background: value ? "#22d3ee" : "rgba(255,255,255,0.15)", justifyContent: value ? "flex-end" : "flex-start", padding: "2px" }}
      >
        <div className="w-7 h-7 rounded-full bg-white" />
      </div>
    </button>
  );
}

function SettingButton({ label, isFa, active, onClick }) {
  return (
    <button
      data-remote
      onClick={onClick}
      className="flex items-center gap-5 rounded-2xl px-6 py-5 transition-all"
      style={{
        background: active ? "rgba(34,211,238,0.15)" : "rgba(255,255,255,0.04)",
        border: active ? "2px solid rgba(34,211,238,0.5)" : "2px solid rgba(255,255,255,0.06)",
        minHeight: "72px",
      }}
    >
      <span className="flex-1 text-left text-xl font-bold text-white">{label}</span>
      {active && <Check className="w-7 h-7 text-cyan-400" />}
    </button>
  );
}