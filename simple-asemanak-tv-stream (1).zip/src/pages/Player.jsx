import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useParams, useNavigate } from "react-router-dom";
import { useRemoteNav } from "@/lib/useRemoteNav";
import { Star, Radio, AlertCircle, ExternalLink, Loader2, Volume2, VolumeX, Maximize2 } from "lucide-react";
import NavHeader from "@/components/layout/NavHeader";
import Hls from "hls.js";
import { registerHls, unregisterHls } from "@/lib/hlsRegistry";

const categoryColors = {
  news: "from-blue-600 to-blue-800",
  sports: "from-green-600 to-green-800",
  entertainment: "from-pink-600 to-purple-800",
  movies: "from-yellow-600 to-orange-800",
  music: "from-cyan-600 to-blue-800",
  kids: "from-orange-500 to-yellow-600",
  documentary: "from-teal-600 to-emerald-800",
  religious: "from-amber-600 to-yellow-800",
  lifestyle: "from-rose-600 to-pink-800",
};

export default function Player() {
  const navRef = useRef(null);
  const videoRef = useRef(null);
  const iframeRef = useRef(null);
  const hlsRef = useRef(null);
  useRemoteNav(navRef);
  const navigate = useNavigate();

  // TV remote: Back key returns to Channels list
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        if (window.history.length > 1) navigate(-1);
        else navigate("/Channels", { replace: true });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const [channel, setChannel] = useState(null);
  const [loading, setLoading] = useState(true);
  const [streamError, setStreamError] = useState(false);
  const [streamLoading, setStreamLoading] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [favorites, setFavorites] = useState(() => {
    const saved = localStorage.getItem("ayeneh_favorites");
    return saved ? JSON.parse(saved) : [];
  });

  const { id } = useParams();
  useEffect(() => {
    if (id) {
      base44.entities.Channel.filter({ id }).then((data) => {
        setChannel(data[0] || null);
        setLoading(false);
      });
    } else {
      setLoading(false);
    }
  }, [id]);

  const streamUrl = channel?.stream_url;
  const isHls = streamUrl && /\.m3u8(\?|#|$)/i.test(streamUrl);
  const isYoutube = streamUrl?.includes("youtube.com") || streamUrl?.includes("youtu.be");
  const isEmbeddable = !isHls && !isYoutube && (streamUrl?.includes("embed") || streamUrl?.includes("iframe") || streamUrl?.includes("dailymotion") || streamUrl?.includes("twitch"));

  // Play HLS stream using hls.js
  useEffect(() => {
    if (!isHls || !streamUrl || !videoRef.current) return;
    setStreamLoading(true);
    setStreamError(false);
    const video = videoRef.current;

    // Native HLS support (Safari, iOS)
    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = streamUrl;
      video.play().catch(() => {});
      const onErr = () => setStreamError(true);
      const onPlaying = () => { setStreamLoading(false); setStreamError(false); };
      video.addEventListener("error", onErr);
      video.addEventListener("playing", onPlaying);
      return () => {
        video.removeEventListener("error", onErr);
        video.removeEventListener("playing", onPlaying);
        video.src = "";
      };
    }

    // hls.js for all other browsers
    let hls;
    if (Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, lowLatencyMode: true });
      hlsRef.current = hls;
      registerHls(hls);
      hls.loadSource(streamUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          setStreamError(true);
          setStreamLoading(false);
        }
      });
      video.addEventListener("playing", () => { setStreamLoading(false); setStreamError(false); });
    } else {
      // Last resort: no native HLS and no hls.js — try plain HTML5 video source
      // binding. Some browsers/WebView implementations can still play it.
      video.src = streamUrl;
      video.play().catch(() => {
        setStreamError(true);
        setStreamLoading(false);
      });
      const onPlaying = () => { setStreamLoading(false); setStreamError(false); };
      const onErr = () => { setStreamError(true); setStreamLoading(false); };
      video.addEventListener("playing", onPlaying);
      video.addEventListener("error", onErr);
    }

    return () => {
      if (hls) { unregisterHls(hls); try { hls.destroy(); } catch {} }
      hlsRef.current = null;
    };
  }, [isHls, streamUrl]);

  // Stop the live stream when leaving the player (no background audio).
  useEffect(() => {
    return () => {
      if (hlsRef.current) { try { hlsRef.current.destroy(); } catch {} }
      if (videoRef.current) { try { videoRef.current.pause(); videoRef.current.src = ""; } catch {} }
      if (iframeRef.current) { iframeRef.current.src = ""; }
    };
  }, []);

  const toggleMute = () => {
    if (isHls && videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(videoRef.current.muted);
    }
  };

  const toggleFullscreen = () => {
    const container = videoRef.current?.parentElement;
    if (!container) return;
    if (!document.fullscreenElement) container.requestFullscreen?.().catch(() => {});
    else document.exitFullscreen?.().catch(() => {});
  };

  const toggleFavorite = () => {
    if (!channel) return;
    setFavorites((prev) => {
      const next = prev.includes(channel.id)
        ? prev.filter((f) => f !== channel.id)
        : [...prev, channel.id];
      localStorage.setItem("ayeneh_favorites", JSON.stringify(next));
      return next;
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[80vh]">
        <div className="w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!channel) {
    return (
      <div className="min-h-screen">
        <NavHeader title="Channel not found" fallbackTo="/Channels" />
        <div className="flex flex-col items-center justify-center gap-4" style={{ height: "calc(100dvh - 56px)" }}>
          <AlertCircle className="w-12 h-12 text-muted-foreground" />
          <p className="text-xl font-semibold">Channel not found</p>
        </div>
      </div>
    );
  }

  const isFav = favorites.includes(channel.id);
  const embedUrl = streamUrl?.includes("watch?v=")
    ? streamUrl.replace("watch?v=", "embed/")
    : streamUrl;

  return (
    <div ref={navRef} className="min-h-screen">
      <NavHeader title={channel.name} fallbackTo="/Channels" />
      <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Player */}
        <div className="lg:col-span-2">
          <div className="rounded-2xl overflow-hidden bg-black border border-border shadow-2xl">
            {streamUrl ? (
              <div className="relative aspect-video bg-black">
                {/* HLS stream — native video + hls.js */}
                {isHls && (
                  <>
                    <video
                      ref={videoRef}
                      className="w-full h-full"
                      autoPlay
                      playsInline
                      controls={false}
                      muted={false}
                    />
                    {streamLoading && !streamError && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/80 z-10">
                        <div className="flex flex-col items-center gap-3">
                          <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
                          <p className="text-white/60 text-sm">در حال بارگذاری استریم...</p>
                        </div>
                      </div>
                    )}
                    {streamError && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-10 px-6 text-center">
                        <AlertCircle className="w-12 h-12 text-red-400 mb-3" />
                        <p className="text-white font-semibold text-lg mb-1">پخش استریم ناموفق بود</p>
                        <p className="text-white/50 text-sm mb-4">این کانال ممکن است آفلاین یا محدود به منطقه باشد</p>
                        <a href={streamUrl} target="_blank" rel="noopener noreferrer" data-remote
                          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-cyan-600 hover:bg-cyan-500 transition-colors">
                          <ExternalLink className="w-4 h-4" /> باز کردن مستقیم
                        </a>
                      </div>
                    )}
                    {/* Floating controls */}
                    {!streamLoading && !streamError && (
                      <div className="absolute bottom-3 right-3 flex gap-2 z-20">
                        <button onClick={toggleMute} data-remote
                          className="min-w-[44px] min-h-[44px] rounded-full flex items-center justify-center bg-black/70 backdrop-blur-md border border-white/20 hover:bg-black/90 transition-colors">
                          {isMuted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
                        </button>
                        <button onClick={toggleFullscreen} data-remote
                          className="min-w-[44px] min-h-[44px] rounded-full flex items-center justify-center bg-black/70 backdrop-blur-md border border-white/20 hover:bg-black/90 transition-colors">
                          <Maximize2 className="w-5 h-5 text-white" />
                        </button>
                      </div>
                    )}
                  </>
                )}
                {/* YouTube / embeddable streams — iframe */}
                {(isYoutube || isEmbeddable) && (
                  <iframe
                    ref={iframeRef}
                    src={embedUrl}
                    className="w-full h-full"
                    allowFullScreen
                    allow="autoplay; encrypted-media; picture-in-picture"
                    title={channel.name}
                  />
                )}
                {/* Unknown stream type — try iframe as fallback */}
                {!isHls && !isYoutube && !isEmbeddable && (
                  <iframe
                    ref={iframeRef}
                    src={embedUrl}
                    className="w-full h-full"
                    allowFullScreen
                    allow="autoplay; encrypted-media; picture-in-picture"
                    title={channel.name}
                  />
                )}
              </div>
            ) : (
              <div className={`aspect-video flex flex-col items-center justify-center bg-gradient-to-br ${categoryColors[channel.category] || "from-purple-700 to-blue-800"}`}>
                <Radio className="w-16 h-16 text-white/50 mb-4" />
                <p className="text-white/70 font-semibold text-lg">No Stream Available</p>
                <p className="text-white/50 text-sm mt-1">Stream URL not configured</p>
              </div>
            )}
          </div>

          {/* Channel title row */}
          <div className="mt-4 flex items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black text-foreground">{channel.name}</h1>
              {channel.name_fa && <p className="text-muted-foreground font-vazir mt-0.5">{channel.name_fa}</p>}
              {channel.description && <p className="text-muted-foreground text-sm mt-2">{channel.description}</p>}
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                data-remote
                onClick={toggleFavorite}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-sm transition-all ${
                  isFav ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30" : "bg-secondary text-muted-foreground hover:text-foreground border border-border"
                }`}
              >
                <Star className={`w-4 h-4 ${isFav ? "fill-yellow-400" : ""}`} />
                {isFav ? "Saved" : "Save"}
              </button>
              {streamUrl && (
                <a
                  data-remote
                  href={streamUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-sm bg-secondary text-muted-foreground hover:text-foreground border border-border transition-all"
                >
                  <ExternalLink className="w-4 h-4" />
                  Open
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar info */}
        <div className="space-y-4">
          {/* Channel logo card */}
          <div className={`rounded-2xl overflow-hidden bg-gradient-to-br ${categoryColors[channel.category] || "from-purple-700 to-blue-800"} p-8 flex items-center justify-center`}>
            {channel.logo_url ? (
              <img src={channel.logo_url} alt={channel.name} className="w-24 h-24 object-contain rounded-xl" />
            ) : (
              <Radio className="w-20 h-20 text-white/50" />
            )}
          </div>

          {/* Details */}
          <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">Channel Info</h3>
            <InfoRow label="Category" value={channel.category} />
            {channel.language && <InfoRow label="Language" value={channel.language} />}
            {channel.country && <InfoRow label="Country" value={channel.country} />}
            <div className="flex items-center gap-2 pt-1">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-sm font-medium text-red-400">Live Now</span>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="text-sm font-medium capitalize">{value}</span>
    </div>
  );
}