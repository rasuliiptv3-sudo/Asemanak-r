import { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Search, Play, Tv, X, Star, Settings, List, Lock, ChevronRight, Menu, ChevronDown, Loader2, Globe, Volume2, VolumeX, ChevronUp, ChevronLeft, Flag, Wifi, WifiOff, Filter, Users, Bookmark, Clapperboard, RefreshCw } from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { usePullToRefresh } from "@/lib/usePullToRefresh";
import MediaSplash from "@/components/media/MediaSplash";
import { FixedSizeList } from "react-window";
import Hls from "hls.js";
import EPGPanel from "@/components/home/EPGPanel";
import OptionsPanel from "@/components/home/OptionsPanel";
import VideoOverlayControls from "@/components/home/VideoOverlayControls";
import ChannelOptionsMenu from "@/components/home/ChannelOptionsMenu";
import GestureControl from "@/components/home/GestureControl";
import SubtitleOverlay from "@/components/home/SubtitleOverlay";
import { idbGet, idbSet } from "@/lib/idb";
import { registerHls, unregisterHls } from "@/lib/hlsRegistry";
import { killAllMedia } from "@/lib/killAllMedia";

const ITEM_H = 60;

const isYoutube = (url) => url && (url.includes("youtube.com") || url.includes("youtu.be"));
const isRtmp = (url) => url && url.startsWith("rtmp");
const isRtsp = (url) => url && url.startsWith("rtsp");
// Detect if URL needs HLS.js (m3u8) or can be played natively
const needsHls = (url) => url && url.includes(".m3u8");
const getYoutubeEmbed = (url) => {
  if (!url) return url;
  // Already an embed URL (live_stream?channel= or /embed/)
  if (url.includes("/embed/")) {
    // add autoplay if not already present
    return url.includes("autoplay") ? url : url + (url.includes("?") ? "&autoplay=1" : "?autoplay=1");
  }
  if (url.includes("watch?v=")) return url.replace("watch?v=", "embed/") + "?autoplay=1";
  if (url.includes("youtu.be/")) return "https://www.youtube.com/embed/" + url.split("youtu.be/")[1].split("?")[0] + "?autoplay=1";
  return url;
};

export default function Home() {
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [search, setSearch] = useState("");
  const [countrySearch, setCountrySearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [panel, setPanel] = useState("channels");
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_favorites") || "[]"); } catch { return []; }
  });

  const [showList, setShowList] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [lockedChannels, setLockedChannels] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_locked") || "[]"); } catch { return []; }
  });
  const [videoLoading, setVideoLoading] = useState(false);
  const [videoLoadingSlow, setVideoLoadingSlow] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showMediaSplash, setShowMediaSplash] = useState(false);
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Router-driven overlays: EPG (?epg=id) and channel options menu (?menu=id).
  // Opening pushes a history entry so the iOS/Android back swipe closes the overlay
  // instead of leaving the screen; closing removes the param.
  const epgId = searchParams.get("epg");
  const menuId = searchParams.get("menu");
  const optsOpen = searchParams.get("opts") === "1";
  const epgChannel = epgId ? channels.find((c) => c.id === epgId) || null : null;
  const channelOptionsMenu = menuId ? channels.find((c) => c.id === menuId) || null : null;

  const openEpg = (ch) => { if (!ch) return; setSearchParams((prev) => { const p = new URLSearchParams(prev); p.set("epg", ch.id); p.delete("menu"); p.delete("opts"); return p; }); };
  const openMenu = (ch) => { if (!ch) return; setSearchParams((prev) => { const p = new URLSearchParams(prev); p.set("menu", ch.id); p.delete("epg"); p.delete("opts"); return p; }); };
  const openOptions = () => setSearchParams((prev) => { const p = new URLSearchParams(prev); p.set("opts", "1"); p.delete("epg"); p.delete("menu"); return p; });
  const closeOverlays = () => setSearchParams((prev) => { const p = new URLSearchParams(prev); p.delete("epg"); p.delete("menu"); p.delete("opts"); return p; }, { replace: true });

  // Keep local showOptions state in sync with the ?opts router param so the
  // system back gesture (which pops the ?opts history entry) closes the panel.
  useEffect(() => { setShowOptions(optsOpen); }, [optsOpen]);

  const menuOpenRef = useRef(false);
  useEffect(() => { menuOpenRef.current = !!channelOptionsMenu; }, [channelOptionsMenu]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showVideoControls, setShowVideoControls] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportSent, setReportSent] = useState(false);

  const videoControlsTimer = useRef(null);
  const okLongPressTimer = useRef(null);
  const channelScrollRef = useRef(null); // FixedSizeList outer scroll node (for pull-to-refresh)

  // TV focus state: "list" | "toolbar_toggle" | "toolbar_media"
  const [tvFocus, setTvFocus] = useState("list");

  // Ref for the list toggle button (TV remote focus)
  const listToggleRef = useRef(null);

  // Drag state
  const [dragIdx, setDragIdx] = useState(null);
  const [dragOverIdx, setDragOverIdx] = useState(null);

  const videoRef = useRef(null);
  const listRef = useRef(null); // FixedSizeList ref
  const slowTimer = useRef(null);
  const touchStartX = useRef(null);
  const videoTouchStartX = useRef(null);
  const videoTouchMoved = useRef(false);
  const filteredChannelsRef = useRef([]);
  const channelsRef = useRef(channels);
  const showSidebarRef = useRef(showSidebar);
  const showOptionsRef = useRef(showOptions);
  const epgChannelRef = useRef(epgChannel);

  useEffect(() => { showSidebarRef.current = showSidebar; }, [showSidebar]);
  useEffect(() => { showOptionsRef.current = showOptions; }, [showOptions]);
  useEffect(() => { epgChannelRef.current = epgChannel; }, [epgChannel]);
  const showListRef = useRef(showList);
  useEffect(() => { showListRef.current = showList; }, [showList]);

  useEffect(() => { channelsRef.current = channels; }, [channels]);

  useEffect(() => {
    base44.auth.me().then((u) => { if (u?.role === "admin") setIsAdmin(true); }).catch(() => {});
  }, []);

  const [uiSettings, setUiSettings] = useState(() => { try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; } });
  const reverseNavRef = useRef(false);
  useEffect(() => {
    const read = () => {
      try {
        const s = JSON.parse(localStorage.getItem("ayeneh_settings") || "{}");
        setUiSettings(s);
        reverseNavRef.current = s.reverseChannelNav === true;
      } catch {}
    };
    read();
    window.addEventListener("storage", read);
    return () => window.removeEventListener("storage", read);
  }, []);

  // Load channels — instant restore from IndexedDB; fetch from server only if cache missing/stale.
  // This makes the app load once (no re-fetch every open) and supports 18000+ channels.
  useEffect(() => {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const loadAll = async () => {
      const lastId = localStorage.getItem("ayeneh_last_channel");
      // Instant restore from IndexedDB
      const cached = await idbGet("channels", "all");
      const cachedAt = (await idbGet("meta", "channels_updated_at")) || 0;
      if (Array.isArray(cached) && cached.length > 0) {
        setChannels(cached);
        setLoading(false);
        if (lastId) {
          const last = cached.find((c) => c.id === lastId);
          setSelectedChannel(last || cached[0]);
        } else {
          setSelectedChannel(cached[0]);
        }
      }
      // Cache fresh (<24h)? Skip server fetch — load once. Realtime subscription keeps it live.
      const STALE_MS = 24 * 60 * 60 * 1000;
      if (cached?.length && (Date.now() - cachedAt) < STALE_MS) return;

      const all = [];
      let page = 0;
      const PAGE_SIZE = 500;
      const MAX_PAGES = 100; // safety limit (50,000 channels)
      while (page < MAX_PAGES) {
        let batch;
        let retries = 0;
        while (retries < 5) {
          try {
            batch = await base44.entities.Channel.list("-created_date", PAGE_SIZE, page * PAGE_SIZE);
            break;
          } catch (e) {
            retries++;
            if (retries >= 5) break;
            await sleep(2000 * retries);
          }
        }
        if (!batch?.length) break;
        all.push(...batch);
        setChannels([...all]);
        if (batch.length < PAGE_SIZE) break;
        page++;
        await sleep(150);
      }
      setLoading(false);
      if (all.length > 0) {
        await idbSet("channels", "all", all);
        await idbSet("meta", "channels_updated_at", Date.now());
        setSelectedChannel(prev => {
          if (prev) { const fresh = all.find(c => c.id === prev.id); return fresh || prev; }
          if (lastId) { const last = all.find((c) => c.id === lastId); return last || all[0]; }
          return all[0];
        });
      }
    };
    loadAll();
  }, []);

  // Save last channel
  useEffect(() => {
    if (selectedChannel) localStorage.setItem("ayeneh_last_channel", selectedChannel.id);
  }, [selectedChannel]);

  // HLS.js player
  const hlsRef = useRef(null);

  useEffect(() => {
    if (!selectedChannel?.stream_url) return;
    if (isYoutube(selectedChannel.stream_url)) return;
    // RTMP/RTSP not playable in browser — show error
    if (isRtmp(selectedChannel.stream_url) || isRtsp(selectedChannel.stream_url)) {
      setVideoError(true);
      return;
    }

    setVideoLoading(true);
    setVideoLoadingSlow(false);
    setVideoError(false);
    clearTimeout(slowTimer.current);
    slowTimer.current = setTimeout(() => setVideoLoadingSlow(true), 5000);

    const video = videoRef.current;
    if (!video) return;

    // destroy previous hls instance
    if (hlsRef.current) { hlsRef.current.destroy(); hlsRef.current = null; }

    const url = selectedChannel.stream_url;
    const s = (() => { try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; } })();
    const isLowBW = s.lowBandwidth === true;
    const isLowLatency = s.hlsLowLatency !== false;
    const maxRetries = parseInt(s.maxRetries || "3", 10);

    // Try HLS.js for m3u8 or any HTTP stream
    if (Hls.isSupported() && (url.includes(".m3u8") || url.startsWith("http"))) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: isLowLatency && !isLowBW,
        maxBufferLength: isLowBW ? 60 : 30,
        maxMaxBufferLength: isLowBW ? 120 : 60,
        maxBufferSize: isLowBW ? 30 * 1000 * 1000 : 60 * 1000 * 1000,
        manifestLoadingTimeOut: isLowBW ? 30000 : 15000,
        manifestLoadingMaxRetry: maxRetries,
        manifestLoadingRetryDelay: 1000,
        levelLoadingTimeOut: isLowBW ? 30000 : 15000,
        levelLoadingMaxRetry: maxRetries,
        levelLoadingRetryDelay: 1000,
        fragLoadingTimeOut: isLowBW ? 40000 : 20000,
        fragLoadingMaxRetry: maxRetries,
        fragLoadingRetryDelay: 1000,
        startFragPrefetch: !isLowBW,
        // ── Adaptive Bitrate (ABR) ──
        testBandwidth: true,
        abrEwmaDefaultEstimate: isLowBW ? 500000 : 1500000,
        abrEwmaDefaultEstimateMax: 5000000,
        abrBandWidthFactor: 0.95,       // Use 95% of measured bandwidth for level selection
        abrBandWidthUpFactor: 0.7,     // Be conservative when upgrading to higher quality
        abrMaxWithFastBitrate: 2,      // Max bitrate multiplier for fast connections
        maxStarvationDelay: 4,          // Max delay before switching to lower quality (seconds)
        maxLoadingDelay: 4,             // Max loading delay before ABR downgrade (seconds)
        capLevelToPlayerSize: true,    // Don't load higher quality than the player can display
        ignoreFragmentedTrackLevelError: true,
        startLevel: -1,                 // Auto-select starting level based on bandwidth
      });
      hlsRef.current = hls;
      registerHls(hls);
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => {});

        // ── Adaptive Bitrate: monitor and auto-adjust quality ──
        let lastBufferLevel = 0;
        let fragLoadStalls = 0;
        hls.on(Hls.Events.FRAG_LOADED, (_, data) => {
          const stats = data.frag?.stats;
          if (stats) {
            const totalMs = (stats.loading
              ? (stats.loading.end - stats.loading.start)
              : 0);
            const loadedBytes = stats.total || 0;
            if (totalMs > 0 && loadedBytes > 0) {
              const bandwidth = (loadedBytes * 8) / (totalMs / 1000);
              // If bandwidth is too low, force ABR to pick lower quality next time
              if (bandwidth < 400000 && hls.autoLevelEnabled) {
                // Below 400kbps — hls.js ABR will auto-downgrade
              }
            }
          }
        });
        hls.on(Hls.Events.LEVEL_SWITCHED, (_, data) => {
          // Track quality changes — hls.js handles auto-switching
          const level = hls.levels[data.level];
          if (level) {
            // Quality auto-switched to: level.height (e.g. 720, 1080)
          }
        });
        hls.on(Hls.Events.FRAG_BUFFERED, (_, data) => {
          const buffered = video.buffered;
          if (buffered.length > 0) {
            const currentBuffer = buffered.end(buffered.length - 1) - video.currentTime;
            if (currentBuffer < 2) {
              fragLoadStalls++;
              if (fragLoadStalls >= 3 && hls.autoLevelEnabled && hls.currentLevel > 0) {
                // Repeatedly stalling — force ABR to consider lower quality
                fragLoadStalls = 0;
              }
            } else {
              fragLoadStalls = 0;
            }
          }
        });

        // Subtitle track management — enable embedded subtitle tracks based on settings
        if (s.subtitleEnabled) {
          const subLang = s.subtitleLang || "en";
          const langMap = {
            en: ["eng", "en", "english"],
            hi: ["hin", "hi", "hindi"],
            tr: ["tur", "tr", "turkish"],
            fa: ["per", "fa", "fas", "farsi", "persian"],
          };
          const targetLangs = langMap[subLang] || langMap.en;
          const tryEnableSubtitles = () => {
            const tracks = hls.subtitleTracks;
            if (tracks.length === 0) return;
            let idx = tracks.findIndex(t => targetLangs.some(l => (t.lang || "").toLowerCase().includes(l)));
            if (idx === -1) {
              idx = tracks.findIndex(t => ["per", "fa", "fas", "farsi", "persian"].some(l => (t.lang || "").toLowerCase().includes(l)));
            }
            if (idx === -1) idx = 0;
            hls.subtitleTrack = idx;
            // Ensure text track mode is showing
            setTimeout(() => {
              const textTracks = video.textTracks;
              for (let i = 0; i < textTracks.length; i++) {
                if (textTracks[i].mode !== "showing") textTracks[i].mode = "showing";
              }
            }, 200);
          };
          tryEnableSubtitles();
          hls.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, tryEnableSubtitles);
        }

        // Audio track (dubbing) management — switch to target language audio track
        if (s.dubbingEnabled) {
          const dubLang = s.dubbingLang || "tr";
          const langMap = {
            tr: ["tur", "tr", "turkish"],
            hi: ["hin", "hi", "hindi"],
            en: ["eng", "en", "english"],
            fa: ["per", "fa", "fas", "farsi", "persian"],
          };
          const targetLangs = langMap[dubLang] || langMap.tr;
          const tryEnableDubbing = () => {
            const tracks = hls.audioTracks;
            if (tracks.length <= 1) return;
            let idx = tracks.findIndex(t => targetLangs.some(l => (t.lang || "").toLowerCase().includes(l)));
            if (idx === -1) {
              idx = tracks.findIndex(t => ["per", "fa", "fas", "farsi", "persian"].some(l => (t.lang || "").toLowerCase().includes(l)));
            }
            if (idx !== -1) hls.audioTrack = idx;
          };
          setTimeout(tryEnableDubbing, 1000);
          hls.on(Hls.Events.AUDIO_TRACKS_UPDATED, tryEnableDubbing);
        }
      });
      let retryCount = 0;
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          if (retryCount < 3) {
            retryCount++;
            setTimeout(() => { hls.startLoad(); video.play().catch(() => {}); }, 2000 * retryCount);
          } else {
            setVideoLoading(false);
            setVideoLoadingSlow(false);
            setVideoError(true);
            clearTimeout(slowTimer.current);
          }
        }
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      // Safari native HLS
      video.src = url;
      video.play().catch(() => {});
    } else {
      // mp4, ts, or other direct streams
      video.src = url;
      video.play().catch(() => {});
    }

    return () => {
      clearTimeout(slowTimer.current);
      if (videoRef.current) { try { videoRef.current.pause(); videoRef.current.src = ""; } catch {} }
      if (hlsRef.current) { unregisterHls(hlsRef.current); hlsRef.current.destroy(); hlsRef.current = null; }
    };
  }, [selectedChannel]);

  // Mute sync
  useEffect(() => {
    if (videoRef.current) videoRef.current.muted = isMuted;
  }, [isMuted]);

  // Show video controls on tap, auto-hide after 3s
  const showControlsTemporarily = useCallback(() => {
    setShowVideoControls(true);
    clearTimeout(videoControlsTimer.current);
    videoControlsTimer.current = setTimeout(() => setShowVideoControls(false), 3000);
  }, []);

  // Scroll active channel into view in virtual list
  useEffect(() => {
    if (!selectedChannel || !listRef.current) return;
    const idx = filteredChannelsRef.current.findIndex((c) => c.id === selectedChannel.id);
    if (idx >= 0) listRef.current.scrollToItem(idx, "smart");
  }, [selectedChannel]);

  // Channel number input state
  const [channelInput, setChannelInput] = useState("");
  const [showChannelInput, setShowChannelInput] = useState(false);
  const channelInputTimer = useRef(null);
  const channelInputRef = useRef("");

  const jumpToChannelNumber = useCallback((numStr) => {
    const num = parseInt(numStr, 10);
    const list = filteredChannelsRef.current;
    if (!list.length) return;
    // channel numbers are 1-based
    const idx = num - 1;
    if (idx >= 0 && idx < list.length) {
      setSelectedChannel(list[idx]);
    }
    setChannelInput("");
    setShowChannelInput(false);
    channelInputRef.current = "";
  }, []);

  // TV remote refs for toolbar links
  const mediaLinkRef = useRef(null);

  // Sync real DOM focus with tvFocus state so Enter key works natively
  useEffect(() => {
    if (tvFocus === "toolbar_media") {
      mediaLinkRef.current?.focus();
    } else if (tvFocus === "toolbar_toggle") {
      listToggleRef.current?.focus();
    }
  }, [tvFocus]);

  // Real-time sync: subscribe to channel changes — updates state + cache in-place
  // without invalidating the cache timestamp (which would cause full re-fetch on re-entry).
  useEffect(() => {
    const unsub = base44.entities.Channel.subscribe((event) => {
      if (event.type === "create") {
        setChannels((prev) => {
          if (prev.find((c) => c.id === event.data.id)) return prev;
          const next = [event.data, ...prev];
          idbSet("channels", "all", next);
          return next;
        });
      } else if (event.type === "update") {
        setChannels((prev) => {
          const next = prev.map((c) => c.id === event.data.id ? { ...c, ...event.data } : c);
          idbSet("channels", "all", next);
          return next;
        });
      } else if (event.type === "delete") {
        setChannels((prev) => {
          const next = prev.filter((c) => c.id !== event.data.id);
          idbSet("channels", "all", next);
          return next;
        });
      }
    });
    return () => { unsub(); };
  }, []);

  // Realtime subscription (above) keeps the channel list live; no full periodic re-fetch needed.

  // ─── TV Remote Key Map ────────────────────────────────────────────────────
  // Android TV / Fire TV / Android Box remote keycodes
  const KEYS = {
    UP:        ["ArrowUp"],
    DOWN:      ["ArrowDown"],
    LEFT:      ["ArrowLeft"],
    RIGHT:     ["ArrowRight"],
    OK:        ["Enter", "Return", "XF86Select", "MediaSelect", "Accept", "XF86OK", " "],
    BACK:      ["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"],
    PLAY:      ["MediaPlay",  "XF86Play"],
    PAUSE:     ["MediaPause", "XF86Pause"],
    PLAYPAUSE: ["MediaPlayPause", "XF86PlayPause", "PlayPause", "p"],
    STOP:      ["MediaStop",  "XF86Stop"],
    CH_UP:     ["MediaTrackNext",     "XF86ChannelUp",   "ChannelUp",   "PageUp",   "VolumeUp"],
    CH_DOWN:   ["MediaTrackPrevious", "XF86ChannelDown", "ChannelDown", "PageDown", "VolumeDown"],
    MENU:      ["ContextMenu", "XF86Menu", "m"],
    INFO:      ["XF86Info", "i"],
  };
  const matchKey = (e, group) => KEYS[group].includes(e.key) || KEYS[group].includes("Key" + e.key);

  const navChannel = (dir) => {
    setShowList(true);
    setTvFocus("list");
    clearTimeout(channelInputTimer.current);
    channelInputRef.current = "";
    setChannelInput("");
    setShowChannelInput(false);
    setSelectedChannel((prev) => {
      const list = filteredChannelsRef.current;
      if (!list.length) return prev;
      const idx = list.findIndex((c) => c.id === prev?.id);
      if (dir === 1) return list[Math.min(list.length - 1, idx + 1)];
      return list[Math.max(0, idx - 1)];
    });
  };

  // Keyboard / TV remote navigation
  useEffect(() => {
    const onKey = (e) => {
      // Skip if user is typing in an input/textarea
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;

      // ── Number keys: channel jump ──
      if (e.key >= "0" && e.key <= "9") {
        e.preventDefault();
        const newInput = channelInputRef.current + e.key;
        channelInputRef.current = newInput;
        setChannelInput(newInput);
        setShowChannelInput(true);
        setShowList(true);
        setTvFocus("list");
        clearTimeout(channelInputTimer.current);
        channelInputTimer.current = setTimeout(() => jumpToChannelNumber(channelInputRef.current), 1500);
        return;
      }

      // ── Arrow Down ──
      if (matchKey(e, "DOWN")) {
        e.preventDefault();
        if (tvFocus === "toolbar_toggle") {
          setTvFocus("list"); setShowList(true);
        } else if (tvFocus === "toolbar_media") {
          setTvFocus("toolbar_toggle");
        } else {
          navChannel(1);
        }
        return;
      }

      // ── Arrow Up ──
      if (matchKey(e, "UP")) {
        e.preventDefault();
        if (tvFocus === "list") {
          const list = filteredChannelsRef.current;
          const idx = list.findIndex((c) => c.id === selectedChannel?.id);
          if (idx <= 0) { setTvFocus("toolbar_toggle"); setShowList(true); return; }
        }
        navChannel(-1);
        return;
      }

      // ── Arrow Left ──
      if (matchKey(e, "LEFT")) {
        e.preventDefault();
        if (tvFocus === "toolbar_media") { setTvFocus("toolbar_toggle"); return; }
        if (tvFocus === "toolbar_toggle") { setTvFocus("list"); setShowList(true); return; }
        setShowList(true); setTvFocus("list");
        return;
      }

      // ── Arrow Right ──
      if (matchKey(e, "RIGHT")) {
        e.preventDefault();
        if (tvFocus === "list") { setTvFocus("toolbar_media"); return; }
        if (tvFocus === "toolbar_media") return;
        setTvFocus("toolbar_media");
        return;
      }

      // ── OK / Enter — short press toggles list, long press opens channel options ──
      if (matchKey(e, "OK")) {
        e.preventDefault();
        if (tvFocus === "toolbar_media") { mediaLinkRef.current?.click(); return; }
        if (tvFocus === "toolbar_toggle") { listToggleRef.current?.click(); return; }
        if (channelInputRef.current) {
          clearTimeout(channelInputTimer.current);
          jumpToChannelNumber(channelInputRef.current);
          return;
        }
        // Start long-press timer on keydown
        if (!okLongPressTimer.current) {
          okLongPressTimer.current = setTimeout(() => {
            okLongPressTimer.current = null;
            // Open channel options menu for current channel
            const ch = filteredChannelsRef.current.find(c => c.id === selectedChannel?.id);
            if (ch) openMenu(ch);
          }, 600);
        }
        return;
      }

      // ── Play ──
      if (matchKey(e, "PLAY")) {
        e.preventDefault();
        videoRef.current?.play().catch(() => {});
        return;
      }

      // ── Pause ──
      if (matchKey(e, "PAUSE")) {
        e.preventDefault();
        videoRef.current?.pause();
        return;
      }

      // ── Play/Pause toggle ──
      if (matchKey(e, "PLAYPAUSE")) {
        e.preventDefault();
        const v = videoRef.current;
        if (v) { v.paused ? v.play().catch(() => {}) : v.pause(); }
        return;
      }

      // ── Stop ──
      if (matchKey(e, "STOP")) {
        e.preventDefault();
        videoRef.current?.pause();
        return;
      }

      // ── Channel Up (next channel) ──
      if (matchKey(e, "CH_UP")) {
        e.preventDefault();
        navChannel(reverseNavRef.current ? -1 : 1);
        return;
      }

      // ── Channel Down (prev channel) ──
      if (matchKey(e, "CH_DOWN")) {
        e.preventDefault();
        navChannel(reverseNavRef.current ? 1 : -1);
        return;
      }

      // ── Menu ──
      if (matchKey(e, "MENU")) {
        e.preventDefault();
        setShowSidebar(v => !v);
        return;
      }

      // ── Back / Escape ──
      if (matchKey(e, "BACK")) {
        e.preventDefault();
        if (channelInputRef.current) {
          const trimmed = channelInputRef.current.slice(0, -1);
          channelInputRef.current = trimmed;
          setChannelInput(trimmed);
          if (!trimmed) setShowChannelInput(false);
        } else if (showSidebarRef.current) {
          setShowSidebar(false);
        } else if (showOptionsRef.current) {
          closeOverlays();
        } else if (epgChannelRef.current || menuOpenRef.current) {
          closeOverlays();
        } else if (showListRef.current) {
          // List visible → hide it first
          setShowList(false);
        } else {
          // Nothing open → kill all media then go back to main menu
          killAllMedia();
          navigate("/");
        }
        return;
      }
    };
    const onKeyUp = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (matchKey(e, "OK")) {
        if (okLongPressTimer.current) {
          // Released before long-press fired → short press → toggle list
          clearTimeout(okLongPressTimer.current);
          okLongPressTimer.current = null;
          if (tvFocus !== "toolbar_media" && !channelInputRef.current) {
            setShowList(v => !v);
          }
        }
      }
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [jumpToChannelNumber, tvFocus, selectedChannel]);

  // Country grouping
  const countryMap = {};
  channels.forEach((ch) => {
    const c = ch.country || "Undefined";
    if (!countryMap[c]) countryMap[c] = [];
    countryMap[c].push(ch);
  });
  const sortedCountries = Object.keys(countryMap).sort((a, b) => {
    if (a === "Undefined") return 1; if (b === "Undefined") return -1; return a.localeCompare(b);
  });
  const filteredCountries = sortedCountries.filter((c) => c.toLowerCase().includes(countrySearch.toLowerCase()));

  // Category list from channels
  const categorySet = new Set();
  channels.forEach(ch => { if (ch.category) categorySet.add(ch.category); });
  const availableCategories = Array.from(categorySet).sort();

  const activeChannels = selectedCountry === "__favorites__"
    ? channels.filter((ch) => favorites.includes(ch.id))
    : selectedCountry ? (countryMap[selectedCountry] || []) : channels;

  const filteredChannels = activeChannels.filter((ch) => {
    const matchesSearch = !search || ch.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !selectedCategory || ch.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  filteredChannelsRef.current = filteredChannels;

  const channelIndexMap = {};
  channels.forEach((ch, i) => { channelIndexMap[ch.id] = i + 1; });

  const toggleFavorite = (id) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id];
      try { localStorage.setItem("ayeneh_favorites", JSON.stringify(next)); }
      catch { return prev; }
      return next;
    });
  };

  const toggleLock = (id) => {
    setLockedChannels((prev) => {
      const next = prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id];
      try { localStorage.setItem("ayeneh_locked", JSON.stringify(next)); }
      catch { return prev; }
      return next;
    });
  };

  // Drag & drop reorder
  const handleDragStart = (e, idx) => {
    setDragIdx(idx);
    e.dataTransfer.effectAllowed = "move";
  };
  const handleDragOver = (e, idx) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDragOverIdx(idx);
  };
  const handleDrop = (e, toIdx) => {
    e.preventDefault();
    if (dragIdx === null || dragIdx === toIdx) { setDragIdx(null); setDragOverIdx(null); return; }
    // find actual indices in full channels array
    const fromCh = filteredChannels[dragIdx];
    const toCh = filteredChannels[toIdx];
    setChannels((prev) => {
      const arr = [...prev];
      const fromI = arr.findIndex((c) => c.id === fromCh.id);
      const toI = arr.findIndex((c) => c.id === toCh.id);
      if (fromI < 0 || toI < 0) return prev;
      const [removed] = arr.splice(fromI, 1);
      arr.splice(toI, 0, removed);
      try { localStorage.setItem("ayeneh_channels_cache", JSON.stringify(arr)); } catch {}
      return arr;
    });
    setDragIdx(null);
    setDragOverIdx(null);
  };
  const handleDragEnd = () => { setDragIdx(null); setDragOverIdx(null); };

  // Touch drag (mobile/TV)
  const touchDragIdx = useRef(null);
  const touchDragOverIdx = useRef(null);
  const longPressTimer = useRef(null);
  const rowTouchStartY = useRef(null); // track vertical movement per row
  

  const handleTouchDragStart = (e, idx) => {
    touchDragIdx.current = idx;
  };
  const handleTouchDragMove = (e) => {
    if (touchDragIdx.current === null) return;
    const listEl = document.getElementById("channel-list-inner");
    if (!listEl) return;
    const rect = listEl.getBoundingClientRect();
    const y = e.touches[0].clientY - rect.top;
    const overIdx = Math.max(0, Math.min(filteredChannelsRef.current.length - 1, Math.floor(y / ITEM_H)));
    touchDragOverIdx.current = overIdx;
    setDragOverIdx(overIdx);
  };
  const handleTouchDragEnd = () => {
    const from = touchDragIdx.current;
    const to = touchDragOverIdx.current;
    if (from !== null && to !== null && from !== to) {
      const fromCh = filteredChannelsRef.current[from];
      const toCh = filteredChannelsRef.current[to];
      setChannels((prev) => {
        const arr = [...prev];
        const fromI = arr.findIndex((c) => c.id === fromCh.id);
        const toI = arr.findIndex((c) => c.id === toCh.id);
        if (fromI < 0 || toI < 0) return prev;
        const [removed] = arr.splice(fromI, 1);
        arr.splice(toI, 0, removed);
        idbSet("channels", "all", arr);
        return arr;
      });
    }
    touchDragIdx.current = null;
    touchDragOverIdx.current = null;
    setDragIdx(null);
    setDragOverIdx(null);
  };

  // Panel swipe — only switch panels if swipe is clearly horizontal (dx > dy)
  const touchStartY = useRef(null);
  const onTouchStart = (e) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  };
  const onTouchEnd = (e) => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    const dy = Math.abs(e.changedTouches[0].clientY - touchStartY.current);
    // Only trigger panel switch if horizontal swipe is dominant (dx > dy * 1.5) and large enough
    if (Math.abs(dx) > 80 && Math.abs(dx) > dy * 1.5) {
      if (dx < 0) setPanel("countries");
      else setPanel("channels");
    }
    touchStartX.current = null;
    touchStartY.current = null;
  };

  // Video area tap/swipe
  const onVideoTouchStart = (e) => { videoTouchStartX.current = e.touches[0].clientX; videoTouchMoved.current = false; };
  const onVideoTouchMove = (e) => {
    if (videoTouchStartX.current === null) return;
    if (Math.abs(e.touches[0].clientX - videoTouchStartX.current) > 10) videoTouchMoved.current = true;
  };
  const onVideoTouchEnd = (e) => {
    if (videoTouchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - videoTouchStartX.current;
    if (dx > 60) openOptions();
    else if (dx < -60) closeOverlays();
    else if (!videoTouchMoved.current) {
      e.preventDefault();
      // Single tap toggles the channel list
      setShowList(v => !v);
    }
    videoTouchStartX.current = null;
    videoTouchMoved.current = false;
  };
  const onVideoClick = (e) => {
    if (e.detail === 0) return;
    // Single click toggles the channel list (if no controls are showing)
    if (showList) {
      setShowList(false);
    } else {
      setShowList(true);
    }
  };

  // Virtual list row renderer
  const ChannelRow = useCallback(({ index, style }) => {
    const ch = filteredChannels[index];
    if (!ch) return null;
    const isActive = selectedChannel?.id === ch.id;
    const isDraggingOver = dragOverIdx === index && dragIdx !== index;
    const num = channelIndexMap[ch.id] || (index + 1);
    return (
      <div
        data-remote
        tabIndex={0}
        role="button"
        onKeyDown={(e) => { if (["Enter", " ", "XF86OK", "Accept"].includes(e.key)) { e.preventDefault(); setSelectedChannel(ch); } }}
        style={{
          ...style,
          display: 'flex',
          alignItems: 'center',
          cursor: 'pointer',
          paddingLeft: '12px',
          paddingRight: '12px',
          opacity: dragIdx === index ? 0.4 : 1,
          userSelect: 'none',
          background: isActive
            ? 'rgba(60,90,200,0.5)'
            : isDraggingOver ? 'rgba(80,120,255,0.08)' : 'transparent',
          borderRadius: isActive ? '10px' : '0',
          margin: isActive ? '2px 6px' : '0',
          width: isActive ? 'calc(100% - 12px)' : '100%',
          borderBottom: '1px solid rgba(255,255,255,0.04)',
          border: isActive ? '1px solid rgba(80,130,255,0.4)' : undefined,
          transition: 'background 0.15s',
        }}
        draggable
        onDragStart={(e) => handleDragStart(e, index)}
        onDragOver={(e) => handleDragOver(e, index)}
        onDrop={(e) => handleDrop(e, index)}
        onDragEnd={handleDragEnd}
        onTouchStart={(e) => {
          rowTouchStartY.current = e.touches[0].clientY;
          longPressTimer.current = setTimeout(() => {
            longPressTimer.current = null;
            openMenu(ch);
          }, 600);
        }}
        onTouchMove={(e) => {
          // Cancel long press if scrolled more than 8px vertically
          if (rowTouchStartY.current !== null && Math.abs(e.touches[0].clientY - rowTouchStartY.current) > 8) {
            clearTimeout(longPressTimer.current);
            longPressTimer.current = null;
          }
        }}
        onTouchEnd={(e) => {
          if (longPressTimer.current) {
            clearTimeout(longPressTimer.current);
            longPressTimer.current = null;
            // Short tap: select channel
            const dy = rowTouchStartY.current !== null ? Math.abs(e.changedTouches[0].clientY - rowTouchStartY.current) : 0;
            if (dy < 8) setSelectedChannel(ch);
          }
          rowTouchStartY.current = null;
        }}
        onClick={() => { if (touchDragIdx.current === null) setSelectedChannel(ch); }}
      >
        {/* Number */}
        <div className="w-9 flex-shrink-0 flex items-center justify-center">
          {isActive
            ? <span className="flex items-center gap-0.5"><span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse mr-0.5" /><Play className="w-3 h-3 fill-white text-white" /></span>
            : <span className="text-sm font-mono" style={{ color: 'rgba(160,160,160,0.9)' }}>{num}</span>
          }
        </div>
        {/* Logo — rounded-full like in the image */}
        <div className="w-10 h-10 flex-shrink-0 rounded-full overflow-hidden flex items-center justify-center mr-3" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.1)' }}>
          {ch.logo_url
            ? <img src={ch.logo_url} alt="" loading="lazy" className="w-full h-full object-cover" onError={(e) => { e.target.style.display = 'none'; }} />
            : <Tv className="w-4 h-4" style={{ color: 'rgba(255,255,255,0.2)' }} />}
        </div>
        {/* Name */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate leading-tight" style={{ color: '#fff' }}>
            {ch.name}
          </p>
          {ch.category && (
            <p className="text-[10px] truncate leading-tight mt-0.5 capitalize" style={{ color: 'rgba(160,160,160,0.6)' }}>{ch.category}</p>
          )}
        </div>
        {/* Favorite button */}
        <button
          data-remote
          className="min-w-[44px] min-h-[44px] flex-shrink-0 flex items-center justify-center rounded-full transition-colors ml-1"
          style={{ background: 'transparent' }}
          onClick={(e) => { e.stopPropagation(); toggleFavorite(ch.id); }}
          onTouchEnd={(e) => { e.stopPropagation(); toggleFavorite(ch.id); }}
        >
          <Star className="w-4 h-4" style={{ color: favorites.includes(ch.id) ? 'rgb(250,204,21)' : 'rgba(255,255,255,0.18)', fill: favorites.includes(ch.id) ? 'rgb(250,204,21)' : 'none', strokeWidth: favorites.includes(ch.id) ? 1.5 : 1.5 }} />
        </button>
      </div>
    );
  }, [filteredChannels, selectedChannel, dragIdx, dragOverIdx, channelIndexMap]);

  // Detect mobile (narrow screen) — reactive to resize
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // Re-fetch channels from the server (used by mobile pull-to-refresh)
  const reloadChannels = useCallback(async () => {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const all = [];
    let page = 0;
    const PAGE_SIZE = 200;
    while (true) {
      let batch;
      let retries = 0;
      while (retries < 3) {
        try {
          batch = await base44.entities.Channel.list("-created_date", PAGE_SIZE, page * PAGE_SIZE);
          break;
        } catch (e) {
          if (e?.message?.includes("Rate limit")) { retries++; await sleep(2000 * retries); }
          else break;
        }
      }
      if (!batch?.length) break;
      all.push(...batch);
      setChannels([...all]);
      if (batch.length < PAGE_SIZE) break;
      page++;
      await sleep(150);
    }
    if (all.length > 0) {
      await idbSet("channels", "all", all);
      await idbSet("meta", "channels_updated_at", Date.now());
    }
  }, []);

  const { pull: chPull, refreshing: chRefreshing } = usePullToRefresh({
    onRefresh: reloadChannels,
    containerRef: channelScrollRef,
    disabled: !isMobile,
  });

  return (
    <div className={`flex overflow-hidden relative ${uiSettings.channelListRight === true && !isMobile ? "flex-row-reverse" : ""}`} style={{ background: '#0d1117', fontFamily: 'Inter, sans-serif', width: '100vw', height: '100dvh' }}>

      <div className="absolute top-0 left-0 right-0 h-1 pointer-events-none z-50" style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(140,60,240,0.55) 30%, rgba(180,80,255,0.7) 50%, rgba(140,60,240,0.55) 70%, transparent 100%)', filter: 'blur(2px)' }} />
      <div className="absolute bottom-0 left-0 right-0 h-1 pointer-events-none z-50" style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(140,60,240,0.45) 30%, rgba(180,80,255,0.6) 50%, rgba(140,60,240,0.45) 70%, transparent 100%)', filter: 'blur(2px)' }} />
      <div className="absolute top-0 left-0 bottom-0 w-1 pointer-events-none z-50" style={{ background: 'linear-gradient(180deg, transparent 0%, rgba(140,60,240,0.45) 30%, rgba(180,80,255,0.6) 50%, rgba(140,60,240,0.45) 70%, transparent 100%)', filter: 'blur(2px)' }} />
      <div className="absolute top-0 right-0 bottom-0 w-1 pointer-events-none z-50" style={{ background: 'linear-gradient(180deg, transparent 0%, rgba(140,60,240,0.45) 30%, rgba(180,80,255,0.6) 50%, rgba(140,60,240,0.45) 70%, transparent 100%)', filter: 'blur(2px)' }} />

      {/* ── LEFT PANEL — floating overlay (dark, semi-transparent) on all devices ── */}
      <div
        className="flex flex-col h-full flex-shrink-0 transition-all duration-300 relative"
        style={{
          width: showList ? (isMobile ? '100vw' : '360px') : '0',
          position: showList ? 'absolute' : 'relative',
          top: 0,
          left: uiSettings.channelListRight === true ? 'auto' : 0,
          right: uiSettings.channelListRight === true ? 0 : 'auto',
          overflow: 'hidden',
          background: 'rgba(8,6,14,0.72)',
          backdropFilter: showList ? 'blur(12px)' : 'none',
          borderRight: showList && !isMobile && uiSettings.channelListRight !== true ? '1px solid rgba(255,255,255,0.08)' : 'none',
          borderLeft: showList && !isMobile && uiSettings.channelListRight === true ? '1px solid rgba(255,255,255,0.08)' : 'none',
          boxShadow: showList && !isMobile ? '0 0 40px rgba(0,0,0,0.6)' : 'none',
          borderRadius: showList && !isMobile ? '0 16px 16px 0' : '0',
          zIndex: 30,
          height: '100%',
        }}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        {/* Decorative glow arc — right side (like the image) */}
        <div className="absolute right-0 top-1/4 pointer-events-none" style={{
          width: '180px', height: '400px',
          background: 'radial-gradient(ellipse at right center, rgba(100,80,220,0.18) 0%, rgba(60,100,200,0.10) 40%, transparent 70%)',
          filter: 'blur(8px)',
        }} />

        {/* Panel Top Bar — thin dark strip like the reference image */}
        <div className="flex items-center gap-3 px-4 py-3 flex-shrink-0 relative z-10" style={{ background: 'rgba(0,0,0,0.4)', borderBottom: '1px solid rgba(255,255,255,0.06)', paddingLeft: 'calc(1rem + env(safe-area-inset-left))', paddingRight: 'calc(1rem + env(safe-area-inset-right))', paddingTop: 'calc(0.75rem + env(safe-area-inset-top))' }}>
          <button onClick={() => setShowSidebar(true)} data-remote className="p-3 md:p-1.5 rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center">
            <Menu className="w-5 h-5 text-white/60" />
          </button>
          {/* Logo */}
          <div className="flex items-center gap-2.5 flex-1">
            <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 ring-2 ring-cyan-500/30" style={{ boxShadow: "0 0 12px rgba(0,242,255,0.2)" }}>
              <img src="https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png" alt="Asemanak TV" className="w-full h-full object-cover" />
            </div>
            <div className="leading-tight">
              <p className="text-white text-base font-bold leading-none">آسمانک</p>
              <p className="text-cyan-400/60 text-[10px] leading-none mt-0.5 tracking-wide">TV</p>
            </div>
          </div>
          <button onClick={() => setShowSearch(v => !v)} data-remote className="p-3 md:p-1.5 rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center">
            {showSearch ? <X className="w-5 h-5 text-white/60" /> : <Search className="w-5 h-5 text-white/60" />}
          </button>
          <Link to="/Favorites" data-remote className="p-3 md:p-1.5 rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center">
            <Bookmark className="w-5 h-5 text-white/60" />
          </Link>
        </div>

        {/* Search */}
        {showSearch && (
          <div className="px-3 py-2 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
            <input
              autoFocus data-remote
              value={panel === "channels" ? search : countrySearch}
              onChange={(e) => panel === "channels" ? setSearch(e.target.value) : setCountrySearch(e.target.value)}
              placeholder={panel === "channels" ? "Filter channels..." : "Filter groups..."}
              className="w-full text-white text-xs px-3 py-2 rounded-lg outline-none"
              style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.1)' }}
            />
          </div>
        )}

        {/* Channel List header — highlighted like the reference image's "All channels" bar */}
        <div className="mx-3 mb-2 px-4 py-2.5 flex items-center justify-between flex-shrink-0 relative z-10 rounded-xl"
          style={{ background: 'rgba(56,42,77,0.8)', border: '1px solid rgba(168,85,247,0.2)' }}>
          <span className="text-white text-sm font-bold">Channel List</span>
          <button
            onClick={() => setPanel(p => p === "countries" ? "channels" : "countries")} data-remote
            className="flex items-center gap-1 text-white/60 hover:text-white text-xs transition-colors"
          >
            <ChevronDown className="w-3.5 h-3.5" />
            {selectedCountry === "__favorites__" ? "Favorites" : selectedCountry || "All"}
          </button>
        </div>

        {/* Active channel highlight bar — blue pill like the reference image */}
        {selectedChannel && (
          <div className="mx-3 mb-1 flex-shrink-0 rounded-xl flex items-center gap-3 px-4 py-3 relative z-10"
            style={{ background: 'rgba(59,77,141,0.7)', border: '1px solid rgba(80,120,255,0.3)' }}>
            <div className="w-7 h-7 rounded-full bg-white/15 flex items-center justify-center flex-shrink-0">
              <Play className="w-3.5 h-3.5 fill-white text-white" />
            </div>
            <span className="text-white text-sm font-semibold truncate flex-1">{selectedChannel.name}</span>
            <button onClick={() => setSelectedChannel(null)} data-remote className="text-white/40 hover:text-white flex-shrink-0">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Category filter chips */}
        {panel === "channels" && availableCategories.length > 0 && (
          <div className="flex gap-2 px-3 pb-2.5 overflow-x-auto flex-shrink-0 relative z-10" style={{ scrollbarWidth: 'none' }}>
            <button
              onClick={() => setSelectedCategory(null)} data-remote
              className="flex-shrink-0 text-xs px-4 py-1.5 rounded-full transition-colors font-medium"
              style={{
                background: selectedCategory === null ? 'rgba(50,120,220,0.35)' : 'rgba(255,255,255,0.07)',
                border: selectedCategory === null ? '1px solid rgba(80,150,255,0.6)' : '1px solid rgba(255,255,255,0.1)',
                color: selectedCategory === null ? '#fff' : 'rgba(255,255,255,0.45)',
              }}
            >All</button>
            {availableCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat === selectedCategory ? null : cat)} data-remote
                className="flex-shrink-0 text-xs px-4 py-1.5 rounded-full transition-colors capitalize font-medium"
                style={{
                  background: selectedCategory === cat ? 'rgba(50,120,220,0.35)' : 'rgba(255,255,255,0.07)',
                  border: selectedCategory === cat ? '1px solid rgba(80,150,255,0.6)' : '1px solid rgba(255,255,255,0.1)',
                  color: selectedCategory === cat ? '#fff' : 'rgba(255,255,255,0.45)',
                }}
              >{cat}</button>
            ))}
          </div>
        )}

        {/* CHANNEL LIST — virtualized */}
        {panel === "channels" && (
          <div className="flex-1 overflow-hidden relative pb-[calc(4.5rem_+_env(safe-area-inset-bottom))] md:pb-0" id="channel-list-inner">
            {/* Pull-to-refresh indicator (mobile) */}
            {(chPull > 0 || chRefreshing) && (
              <div className="absolute left-1/2 top-0 z-30 flex flex-col items-center pointer-events-none"
                style={{ transform: `translateX(-50%) translateY(${chPull}px)` }}>
                <RefreshCw className={`w-5 h-5 text-cyan-300 ${chRefreshing ? "animate-spin" : ""}`} style={{ opacity: Math.min(1, chPull / 70) }} />
              </div>
            )}
            {loading && channels.length === 0 ? (
              <div className="overflow-y-auto h-full">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-3 px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', height: ITEM_H }}>
                    <div className="w-5 h-2 rounded animate-pulse" style={{ background: 'rgba(255,255,255,0.08)' }} />
                    <div className="flex-1 h-2 rounded animate-pulse" style={{ background: 'rgba(255,255,255,0.08)' }} />
                    <div className="w-8 h-8 rounded-lg animate-pulse flex-shrink-0" style={{ background: 'rgba(255,255,255,0.08)' }} />
                  </div>
                ))}
              </div>
            ) : (
              <AutoSizedList
                listRef={listRef}
                outerRef={channelScrollRef}
                itemCount={filteredChannels.length}
                itemSize={ITEM_H}
                ChannelRow={ChannelRow}
              />
            )}
          </div>
        )}

        {/* COUNTRIES LIST */}
        {panel === "countries" && (
          <div className="flex-1 overflow-y-auto" onTouchStart={(e) => e.stopPropagation()} onTouchEnd={(e) => e.stopPropagation()}>
            <button key="__favorites__" onClick={() => { setSelectedCountry("__favorites__"); setPanel("channels"); }} data-remote
              className="w-full flex items-center gap-3 px-5 py-4 text-left transition-colors"
              style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', background: selectedCountry === "__favorites__" ? 'rgba(168,85,247,0.15)' : 'transparent', color: selectedCountry === "__favorites__" ? 'rgb(216,180,254)' : 'rgba(255,255,255,0.85)' }}>
              <Star className="w-4 h-4 flex-shrink-0" style={{ color: 'rgb(250,204,21)', fill: 'rgb(250,204,21)' }} />
              <span className="text-base font-medium">{`Favorites (${favorites.length})`}</span>
            </button>
            <button key="__all__" onClick={() => { setSelectedCountry(null); setPanel("channels"); }} data-remote
              className="w-full flex items-center gap-3 px-5 py-4 text-left transition-colors"
              style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', background: selectedCountry === null ? 'rgba(168,85,247,0.15)' : 'transparent', color: selectedCountry === null ? 'rgb(216,180,254)' : 'rgba(255,255,255,0.85)' }}>
              <span className="text-base font-medium">{`All channels (${channels.length})`}</span>
            </button>
            {filteredCountries.map((country) => (
              <button key={country} onClick={() => { setSelectedCountry(country); setPanel("channels"); }} data-remote
                className="w-full flex items-center gap-3 px-5 py-4 text-left transition-colors"
                style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', background: selectedCountry === country ? 'rgba(168,85,247,0.15)' : 'transparent', color: selectedCountry === country ? 'rgb(216,180,254)' : 'rgba(255,255,255,0.85)' }}>
                <span className="text-base font-medium">{country}</span>
                <span className="text-sm text-white/40 ml-auto">({countryMap[country].length})</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── RIGHT AREA ── */}
      <div className="flex-1 relative overflow-hidden min-w-0">

        {/* TOP TOOLBAR — floating overlay on top of the video */}
        <div className="absolute top-0 left-0 right-0 flex items-center px-4 z-20" style={{ height: 'calc(56px + env(safe-area-inset-top))', paddingTop: 'env(safe-area-inset-top)', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
          {/* Back to main menu */}
          <button
            onClick={() => { if (window.history.length > 1) navigate(-1); else navigate("/", { replace: true }); }} data-remote
            className="p-2 rounded-lg hover:bg-white/10 transition-colors mr-1 flex-shrink-0 min-w-[44px] min-h-[44px] flex items-center justify-center"
            title="بازگشت"
          >
            <ArrowLeft className="w-5 h-5 text-white/60" />
          </button>
          <div className="flex-1" />


        </div>

        {/* VIDEO AREA — fills the entire right area, behind the toolbar */}
        <div className="absolute inset-0 overflow-hidden" style={{ background: '#000' }}>
          <div className="absolute inset-0 overflow-hidden z-0">

            {selectedChannel?.stream_url && !showMediaSplash ? (
              isYoutube(selectedChannel.stream_url) ? (
                <iframe
                  key={selectedChannel.id}
                  src={getYoutubeEmbed(selectedChannel.stream_url)}
                  className="absolute inset-0 w-full h-full"
                  style={{ transform: 'scale(1.15)', transformOrigin: 'center center' }}
                  allowFullScreen
                  allow="autoplay; encrypted-media; picture-in-picture"
                  title={selectedChannel.name}
                />
              ) : (
                <video
                  ref={videoRef}
                  className="absolute inset-0 w-full h-full object-cover"
                  autoPlay playsInline controls={false}
                  onCanPlay={() => { setVideoLoading(false); setVideoLoadingSlow(false); clearTimeout(slowTimer.current); }}
                  onPlaying={() => { setVideoLoading(false); setVideoLoadingSlow(false); clearTimeout(slowTimer.current); }}
                  onError={() => { setVideoLoading(false); setVideoLoadingSlow(false); setVideoError(true); }}
                />
              )
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4"
                style={{ background: 'linear-gradient(135deg, #0d1117 0%, #1a2035 100%)' }}>
                <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center">
                  <Tv className="w-10 h-10 text-white/20" />
                </div>
                <p className="text-white/30 text-sm">Select a channel to watch</p>
              </div>
            )}

            {/* Loading overlay */}
            {videoLoading && selectedChannel && !isYoutube(selectedChannel.stream_url) && (
              <div className="absolute inset-0 flex items-center justify-center z-10" style={{ background: 'rgba(0,0,0,0.6)' }}>
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
                  <p className="text-white text-sm font-semibold">{selectedChannel.name}</p>
                  {videoLoadingSlow && <p className="text-white/60 text-xs text-center">لطفاً منتظر باشید...</p>}
                </div>
              </div>
            )}

            {/* Error overlay */}
            {videoError && selectedChannel && !isYoutube(selectedChannel.stream_url) && (
              <div className="absolute inset-0 flex items-center justify-center z-10" style={{ background: 'rgba(0,0,0,0.7)' }}>
                <div className="flex flex-col items-center gap-3 border border-red-500/30 rounded-2xl px-8 py-6 bg-red-900/20">
                  <X className="w-8 h-8 text-red-400" />
                  <p className="text-white text-sm font-semibold">{selectedChannel.name}</p>
                  <p className="text-red-300 text-xs">کانال در دسترس نیست</p>
                </div>
              </div>
            )}

            {/* Subtitle/Dubbing overlay */}
            <SubtitleOverlay videoRef={videoRef} />
          </div>

          {/* Channel logo overlay — visible on the video */}
          {selectedChannel?.logo_url && (
            <img src={selectedChannel.logo_url} alt={selectedChannel.name}
              className="absolute z-[15] w-12 h-12 object-contain pointer-events-none"
              style={{ top: 'calc(4rem + env(safe-area-inset-top))', right: 'calc(1rem + env(safe-area-inset-right))', filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.6))' }}
              onError={(e) => { e.target.style.display = 'none'; }}
            />
          )}

          {/* Gesture control: right=volume, left=brightness (only for HLS video, not youtube iframe) */}
          {selectedChannel && !isYoutube(selectedChannel.stream_url) ? (
            <GestureControl videoRef={videoRef} onTap={() => setShowList(v => !v)} />
          ) : (
            /* Video tap/click area (youtube / empty) */
            <div className="absolute inset-0 z-5"
              onTouchStart={onVideoTouchStart} onTouchMove={onVideoTouchMove}
              onTouchEnd={onVideoTouchEnd} onClick={onVideoClick} />
          )}

          {/* Video Overlay Controls */}
          {showVideoControls && selectedChannel && (
            <VideoOverlayControls
              channel={selectedChannel}
              isMuted={isMuted}
              isFavorite={favorites.includes(selectedChannel.id)}
              isLocked={lockedChannels.includes(selectedChannel.id)}
              onToggleMute={() => setIsMuted(v => !v)}
              onToggleList={() => setShowList(v => !v)}
              onPrevChannel={() => navChannel(-1)}
              onNextChannel={() => navChannel(1)}
              onToggleFavorite={() => toggleFavorite(selectedChannel.id)}
              onReport={() => { setShowReport(true); setShowVideoControls(false); }}
              onToggleLock={() => toggleLock(selectedChannel.id)}
            />
          )}
        </div>
      </div>

      {/* SIDEBAR MENU */}
      {showSidebar && (
        <div className="fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowSidebar(false)} />
          <div className="relative z-10 w-72 max-w-[85vw] h-full flex flex-col border-r border-white/10" style={{ background: 'rgba(13,17,23,0.98)' }}>
            <div className="px-5 pt-10 pb-4">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl overflow-hidden flex-shrink-0" style={{ boxShadow: "0 0 12px rgba(0,242,255,0.2)" }}>
                  <img src="https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png" alt="Asemanak TV" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="text-white font-bold text-base">ASEMANAK TV</p>
                  <p className="text-cyan-400/60 text-xs">آسمانک تی وی</p>
                </div>
              </div>
              <div className="rounded-xl px-4 py-3 flex items-center justify-between" style={{ background: 'linear-gradient(90deg, rgba(6,182,212,0.3), rgba(168,85,247,0.3))', border: '1px solid rgba(6,182,212,0.3)' }}>
                <span className="text-white text-sm font-semibold">Asemanak TV ({channels.length})</span>
                <ChevronDown className="w-4 h-4 text-white" />
              </div>
            </div>
            <div className="mx-5 border-t border-white/10 mb-2" />
            <div className="flex-1 px-2 overflow-y-auto">
              <button onClick={() => { setShowSearch(true); setShowSidebar(false); }} data-remote
                className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                <Search className="w-5 h-5" /><span className="text-base">Search</span>
              </button>
              <Link to="/Favorites" onClick={() => setShowSidebar(false)} data-remote
                className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                <Star className="w-5 h-5 text-yellow-400" /><span className="text-base">علاقه‌مندی‌ها</span>
                <span className="text-xs text-white/30 ml-auto">{favorites.length}</span>
              </Link>
              <button onClick={() => { if (selectedChannel) { openEpg(selectedChannel); setShowSidebar(false); } }} data-remote
                className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                <List className="w-5 h-5" /><span className="text-base">EPG</span>
                {!selectedChannel && <span className="text-xs text-white/30 ml-auto">Select a channel first</span>}
              </button>
              <Link to="/Settings" onClick={() => setShowSidebar(false)} data-remote
                className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                <Settings className="w-5 h-5" /><span className="text-base">Settings</span>
                <ChevronRight className="w-4 h-4 ml-auto text-white/30" />
              </Link>
              <Link to="/" onClick={() => setShowSidebar(false)} data-remote
                className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                <Tv className="w-5 h-5 text-purple-400" /><span className="text-base">منوی اصلی</span>
                <ChevronRight className="w-4 h-4 ml-auto text-white/30" />
              </Link>
              {selectedChannel && (
                <>
                  <div className="mx-4 my-1 border-t border-white/10" />
                  <p className="px-4 py-2 text-xs text-white/30 font-semibold uppercase tracking-widest">{selectedChannel.name}</p>
                  <button onClick={() => { toggleFavorite(selectedChannel.id); setShowSidebar(false); }} data-remote
                    className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                    <Star className={`w-5 h-5 ${favorites.includes(selectedChannel.id) ? "fill-yellow-400 text-yellow-400" : ""}`} />
                    <span className="text-base">{favorites.includes(selectedChannel.id) ? "Remove from Favorites" : "Add to Favorites"}</span>
                  </button>
                  <button onClick={() => { openEpg(selectedChannel); setShowSidebar(false); }} data-remote
                    className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                    <List className="w-5 h-5" /><span className="text-base">EPG</span>
                  </button>
                  <button onClick={() => { toggleLock(selectedChannel.id); setShowSidebar(false); }} data-remote
                    className="w-full flex items-center gap-4 px-4 py-4 text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
                    <Lock className={`w-5 h-5 ${lockedChannels.includes(selectedChannel.id) ? "text-red-400" : ""}`} />
                    <span className="text-base">{lockedChannels.includes(selectedChannel.id) ? "Unlock Channel" : "Lock Channel"}</span>
                  </button>
                </>
              )}
            </div>
            <div className="px-5 py-4 border-t border-white/10">
              <button onClick={() => { setPanel("countries"); setShowSidebar(false); }} data-remote
                className="w-full flex items-center justify-between text-white/60 hover:text-white text-sm transition-colors">
                <span>Groups</span><ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Options Panel */}
      {showOptions && (
        <OptionsPanel
          channel={selectedChannel}
          isFavorite={selectedChannel ? favorites.includes(selectedChannel.id) : false}
          onFavorite={() => selectedChannel && toggleFavorite(selectedChannel.id)}
          onEPG={() => openEpg(selectedChannel)}
          onClose={closeOverlays}
        />
      )}

      {/* EPG Panel */}
      {epgChannel && <EPGPanel channel={epgChannel} onClose={closeOverlays} />}

      {/* Channel Options Menu (long-press) */}
      {channelOptionsMenu && (
        <ChannelOptionsMenu
          channel={channelOptionsMenu}
          isFavorite={favorites.includes(channelOptionsMenu.id)}
          onFavorite={() => toggleFavorite(channelOptionsMenu.id)}
          onSearch={() => { setShowSearch(true); setShowList(true); }}
          onChangeNumber={(newNum) => {
            // Reorder: move channelOptionsMenu to position newNum (1-based)
            setChannels(prev => {
              const arr = [...prev];
              const fromI = arr.findIndex(c => c.id === channelOptionsMenu.id);
              if (fromI < 0) return prev;
              const toI = Math.min(newNum - 1, arr.length - 1);
              const [removed] = arr.splice(fromI, 1);
              arr.splice(toI, 0, removed);
              idbSet("channels", "all", arr);
              return arr;
            });
          }}
          onClose={closeOverlays}
        />
      )}

      {/* Report Problem Modal */}
      {showReport && selectedChannel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/70" onClick={() => { setShowReport(false); setReportSent(false); }} />
          <div className="relative z-10 w-80 rounded-2xl p-6 border border-white/10" style={{ background: 'rgba(13,17,23,0.98)' }}>
            <h3 className="text-white font-bold text-base mb-1">گزارش مشکل</h3>
            <p className="text-white/50 text-xs mb-4">{selectedChannel.name}</p>
            {reportSent ? (
              <div className="flex flex-col items-center gap-3 py-4">
                <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Flag className="w-6 h-6 text-green-400" />
                </div>
                <p className="text-green-400 text-sm font-semibold">گزارش ارسال شد</p>
                <button onClick={() => { setShowReport(false); setReportSent(false); }} className="text-white/50 text-xs">بستن</button>
              </div>
            ) : (
              <>
                <div className="space-y-2 mb-4">
                  {['کانال پخش نمی‌شود', 'کیفیت پایین است', 'صدا ندارد', 'کانال اشتباه است', 'مشکل دیگر'].map(reason => (
                    <button key={reason} onClick={() => setReportSent(true)}
                      className="w-full text-left text-sm text-white/70 hover:text-white px-4 py-2.5 rounded-xl hover:bg-white/5 transition-colors border border-white/5 hover:border-white/10">
                      {reason}
                    </button>
                  ))}
                </div>
                <button onClick={() => { setShowReport(false); }} className="w-full text-center text-white/30 text-xs py-2">انصراف</button>
              </>
            )}
          </div>
        </div>
      )}

      {/* MEDIA SPLASH TRANSITION */}
      {showMediaSplash && <MediaSplash onDone={() => { setShowMediaSplash(false); navigate('/Media'); }} />}

      {/* CHANNEL NUMBER INPUT OVERLAY */}
      {showChannelInput && (
        <div className="fixed bottom-12 right-8 z-50 pointer-events-none">
          <div className="flex flex-col items-center gap-1 rounded-2xl px-8 py-5 shadow-2xl"
            style={{ background: 'rgba(13,17,23,0.92)', border: '1px solid rgba(255,255,255,0.15)' }}>
            <span className="text-white/50 text-xs font-semibold uppercase tracking-widest mb-1">Channel</span>
            <span className="text-white font-black text-5xl font-mono leading-none">{channelInput}</span>
            {(() => {
              const num = parseInt(channelInput, 10);
              const ch = filteredChannelsRef.current[num - 1];
              return ch ? <span className="text-cyan-300 text-sm font-medium mt-2 truncate max-w-[180px]">{ch.name}</span> : null;
            })()}
          </div>
        </div>
      )}
    </div>
  );
}

// Helper: auto-sized virtual list
function AutoSizedList({ listRef, itemCount, itemSize, ChannelRow, outerRef }) {
  const containerRef = useRef(null);
  const [height, setHeight] = useState(500);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([entry]) => setHeight(entry.contentRect.height));
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  return (
    <div ref={containerRef} style={{ height: '100%', width: '100%' }}>
      <FixedSizeList
        ref={listRef}
        outerRef={outerRef}
        height={height}
        width="100%"
        itemCount={itemCount}
        itemSize={itemSize}
        overscanCount={10}
      >
        {ChannelRow}
      </FixedSizeList>
    </div>
  );
}