import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { ArrowLeft, Plus, Play, Tv2, Clapperboard, ChevronLeft, ChevronRight, Sparkles, List, X, Clock, Calendar, Languages, RefreshCw, Smile, Heart, Gift } from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { usePullToRefresh } from "@/lib/usePullToRefresh";
import YouTubePlayer from "@/components/media/YouTubePlayer";
import HlsVideoPlayer from "@/components/media/HlsVideoPlayer";
import SeriesDetail from "@/components/media/SeriesDetail";
import AddPlaylistForm, { fetchPlaylistEpisodes } from "@/components/media/AddPlaylistForm";
import SeriesReorderModal from "@/components/media/SeriesReorderModal";
import AddEpisodeForm from "@/components/media/AddEpisodeForm";
import HeroVideo from "@/components/media/HeroVideo";
import SeriesCard from "@/components/media/SeriesCard";
import SeriesContextMenu from "@/components/media/SeriesContextMenu";
import MediaSplash from "@/components/media/MediaSplash";
import TrailerHero from "@/components/media/TrailerHero";
import { useIsMobile } from "@/lib/useIsMobile";
import { useIsTV } from "@/lib/useIsTV";
import { killAllMedia } from "@/lib/killAllMedia";
import { playBrandSound } from "@/lib/brandSound";
import { idbGet, idbSet } from "@/lib/idb";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import NavHeader from "@/components/layout/NavHeader";

const STORAGE_KEY = "ayeneh_media_series";
const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";
// No built-in series — all series are user-added and persisted server-side.
const DEFAULT_SERIES = [];

// Series are persisted server-side (Series entity) so they sync across devices/installs.
// IndexedDB is kept as an offline cache; DEFAULT_SERIES (Hercai) is always merged in.
let seriesCache = null;

function mergeDefaults(remote) {
  const keys = new Set((remote || []).map(s => s.playlistId).filter(Boolean));
  return [...(remote || []), ...DEFAULT_SERIES.filter(d => d.playlistId && !keys.has(d.playlistId))];
}

// Remove duplicate series (same playlistId or title) — keeps the first (most recent).
function dedupeSeries(list) {
  const seen = new Set();
  const out = [];
  for (const s of (list || [])) {
    const key = s.playlistId || s.title;
    if (key && seen.has(key)) continue;
    if (key) seen.add(key);
    out.push(s);
  }
  return out;
}

let lastLoadFailed = false;

function sortSeriesByOrder(list) {
  return [...list].sort((a, b) => {
    const aOrder = Number(a.sortOrder) || 0;
    const bOrder = Number(b.sortOrder) || 0;
    if (aOrder !== bOrder) return aOrder - bOrder;
    return new Date(b.created_date || 0) - new Date(a.created_date || 0);
  });
}

async function loadSeries() {
  // Retry once to ride through transient network blips.
  let remote = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      remote = await base44.entities.Series.list("-created_date", 500) || [];
      break;
    } catch (e) {
      // Session expired — re-authenticate instead of silently showing stale data.
      const code = e?.status || e?.response?.status || e?.statusCode;
      const msg = (e?.message || '') + '';
      if (code === 401 || code === 403 || /logged in|forbidden|unauthor/i.test(msg)) {
        lastLoadFailed = true;
        try { base44.auth.redirectToLogin(window.location.href); } catch {}
        return [];
      }
      if (attempt === 0) await new Promise(r => setTimeout(r, 800));
    }
  }
  if (remote) {
    lastLoadFailed = false;
    try { await idbSet("series", "all", remote); } catch {}
    seriesCache = sortSeriesByOrder(mergeDefaults(dedupeSeries(remote)));
    return seriesCache;
  }
  // Network failed — fall back to IndexedDB cache for offline support
  // so users can still browse and watch previously-loaded series without internet.
  try {
    const cached = await idbGet("series", "all");
    if (cached && cached.length > 0) {
      lastLoadFailed = false;
      seriesCache = sortSeriesByOrder(mergeDefaults(dedupeSeries(cached)));
      return seriesCache;
    }
  } catch {}
  lastLoadFailed = true;
  return [];
}

async function persistSeries(data) {
  seriesCache = data;
  try { await idbSet("series", "all", data); } catch {}
}

const SECTIONS = [
  { id: "series", label: "سریال‌ها", labelEn: "Series", icon: <Tv2 className="w-4 h-4" /> },
  { id: "movies", label: "فیلم‌ها", labelEn: "Movies", icon: <Tv2 className="w-4 h-4" /> },
  { id: "animation", label: "انیمیشن‌ها", labelEn: "Animations", icon: <Clapperboard className="w-4 h-4" /> },
  { id: "comedy", label: "سریال‌های کمدی", labelEn: "Comedy", icon: <Smile className="w-4 h-4" /> },
  { id: "drama", label: "سریال‌های داستانی", labelEn: "Drama", icon: <Heart className="w-4 h-4" /> },
  { id: "occasional", label: "برنامه‌های مناسبتی", labelEn: "Occasional", icon: <Gift className="w-4 h-4" /> },
];

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

export default function Media() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const isMobile = useIsMobile();
  const isSmallMobile = useIsMobile(480);
  const isTV = useIsTV();
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryFilter = searchParams.get("cat");
  const [allSeries, setAllSeries] = useState([]);
  const [loadFailed, setLoadFailed] = useState(false);
  const loadedRef = useRef(false);
  useEffect(() => {
    // One-time clear of stale IndexedDB cache so old series never reappear.
    const CACHE_VER = "v4_2026_08_01";
    if (localStorage.getItem("ayeneh_series_cache_ver") !== CACHE_VER) {
      localStorage.setItem("ayeneh_series_cache_ver", CACHE_VER);
      try { idbSet("series", "all", []); } catch {}
      seriesCache = null;
    }
    loadSeries().then(data => {
      setAllSeries(data);
      loadedRef.current = true;
      setLoadFailed(lastLoadFailed);
      if (lastLoadFailed) {
        const fa = readSettings().language !== "en";
        toast({
          title: fa ? "خطا در بارگذاری سریال‌ها" : "Failed to load series",
          description: fa ? "لطفاً وارد حساب شوید یا اتصال اینترنت را بررسی کنید" : "Please log in or check your connection",
          variant: "destructive",
        });
      }
    });
  }, []);

  // Auto-update the list when series change on the server (added/edited/deleted anywhere).
  useEffect(() => {
    let timer = null;
    const unsubscribe = base44.entities.Series.subscribe(() => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        seriesCache = null;
        loadSeries().then(setAllSeries);
      }, 400);
    });
    return () => { if (timer) clearTimeout(timer); unsubscribe(); };
  }, []);

  // Reload series when the app regains focus (picks up changes made elsewhere / on the website).
  useEffect(() => {
    const onFocus = () => { seriesCache = null; loadSeries().then(setAllSeries); };
    const onVis = () => { if (!document.hidden) onFocus(); };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);
  useEffect(() => { if (loadedRef.current) persistSeries(allSeries); }, [allSeries]);
  const seriesIdParam = searchParams.get("series");
  const episodeParam = searchParams.get("episode");
  // Selected series is derived from the `?series=` URL param — the URL is the
  // source of truth so back/forward navigation and deep links work correctly.
  const selectedSeries = useMemo(
    () => allSeries.find(s => s.id === seriesIdParam) || null,
    [allSeries, seriesIdParam]
  );
  // _playId forces the player to remount whenever the episode changes.
  const [playId, setPlayId] = useState(Date.now());
  useEffect(() => { if (episodeParam) setPlayId(Date.now()); }, [episodeParam]);
  const playingEpisode = useMemo(() => {
    if (!selectedSeries || !episodeParam) return null;
    const eps = (selectedSeries.episodes || []).slice().sort((a, b) => a.number - b.number);
    const ep = eps.find(e => String(e.number) === String(episodeParam));
    return ep ? { ...ep, _playId: playId } : null;
  }, [selectedSeries, episodeParam, playId]);

  // Push series/episode state to the URL search params (creates history entries).
  const updateMediaParams = useCallback((updates, { replace = false } = {}) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(updates)) {
      if (value === null || value === undefined) next.delete(key);
      else next.set(key, String(value));
    }
    setSearchParams(next, { replace });
  }, [searchParams, setSearchParams]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showReorderModal, setShowReorderModal] = useState(false);
  const [heroPlaying, setHeroPlaying] = useState(null);
  const [trailerSeries, setTrailerSeries] = useState(null);
  const [contextMenuSeries, setContextMenuSeries] = useState(null);
  const [addEpisodeTarget, setAddEpisodeTarget] = useState(null);
  const [focusIndex, setFocusIndex] = useState(-1);
  const trailerDebounceRef = useRef(null);
  const [showSplash, setShowSplash] = useState(true);
  const [isFa, setIsFa] = useState(() => readSettings().language !== "en");
  const [, setOfflineVersion] = useState(0);

  // Stop ALL YouTube iframes when leaving Media — no lingering audio after exit.
  useEffect(() => {
    return () => {
      setTrailerSeries(null);
      document.querySelectorAll("iframe").forEach(f => {
        try { f.contentWindow.postMessage(JSON.stringify({ event: "command", func: "stopVideo", args: "" }), "*"); } catch {}
        try { f.src = "about:blank"; } catch {}
      });
      document.querySelectorAll("video").forEach(v => {
        try { v.pause(); } catch {}
        try { v.src = ""; } catch {}
      });
      document.querySelectorAll("audio").forEach(a => {
        try { a.pause(); } catch {}
        try { a.src = ""; } catch {}
      });
    };
  }, []);

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    window.addEventListener("ayeneh-settings-changed", syncLang);
    window.addEventListener("storage", syncLang);
    return () => {
      window.removeEventListener("ayeneh-settings-changed", syncLang);
      window.removeEventListener("storage", syncLang);
    };
  }, []);

  const toggleLang = () => {
    const s = readSettings();
    const newLang = s.language === "en" ? "fa" : "en";
    const updated = { ...s, language: newLang };
    localStorage.setItem("ayeneh_settings", JSON.stringify(updated));
    setIsFa(newLang === "fa");
    window.dispatchEvent(new Event("ayeneh-settings-changed"));
  };

  // Brand sound removed — silent loading only

  // Re-render when offline download status changes (download/remove from context menu)
  useEffect(() => {
    const update = () => setOfflineVersion(v => v + 1);
    window.addEventListener("ayeneh-offline-changed", update);
    return () => window.removeEventListener("ayeneh-offline-changed", update);
  }, []);

  // Mobile tab re-select → reset to the root Media grid (closes any open series/episode view).
  useEffect(() => {
    const onReset = (e) => {
      if (e.detail?.tabId !== "media" && e.detail?.to !== "/Media") return;
      updateMediaParams({ series: null, episode: null }, { replace: true });
      setHeroPlaying(null);
      setShowAddForm(false);
      setContextMenuSeries(null);
      setAddEpisodeTarget(null);
      setTrailerSeries(null);
      // Re-show the splash animation every time the Media tab is re-opened.
      setShowSplash(true);
    };
    window.addEventListener("mobile-tab-reset", onReset);
    return () => window.removeEventListener("mobile-tab-reset", onReset);
  }, []);

  const tr = (fa, en) => isFa ? fa : en;

  // Section label reflects the active category filter (series / movies / animation).
  const newLabel = categoryFilter === "animation" ? tr("انیمیشن‌های جدید", "New Animations")
    : categoryFilter === "movies" ? tr("فیلم‌های جدید", "New Movies")
    : tr("سریال‌های جدید", "New Series");

  // Pull-to-refresh on mobile — reloads series from storage
  const refreshMedia = useCallback(async () => {
    seriesCache = null;
    const data = await loadSeries();
    setAllSeries(data);
    setLoadFailed(lastLoadFailed);
  }, []);
  const { ref: mediaScrollRef, pull: mediaPull, refreshing: mediaRefreshing } = usePullToRefresh({ onRefresh: refreshMedia });

  const addSeries = (newSeries) => {
    base44.entities.Series.create({
      title: newSeries.title,
      description: newSeries.description || "",
      playlistId: newSeries.playlistId || "",
      playlistUrl: newSeries.playlistUrl || "",
      category: newSeries.category || "series",
      type: newSeries.type || "youtube",
      poster: newSeries.poster || "",
      episodes: newSeries.episodes || [],
    }).then(async (created) => {
      setAllSeries(prev => [created, ...prev.filter(s => s.id !== created.id)]);
      // Bust cache + reload from server so the new series persists across reloads.
      seriesCache = null;
      const fresh = await loadSeries();
      setAllSeries(fresh);
    }).catch(() => {
      // Create failed (offline or not authenticated) — don't keep a local-only
      // phantom that vanishes on refresh; surface the error instead.
      const fa = readSettings().language !== "en";
      toast({
        title: fa ? "خطا در ذخیره سریال" : "Failed to save series",
        description: fa ? "لطفاً وارد حساب شوید یا اتصال اینترنت را بررسی کنید" : "Please log in or check your connection",
        variant: "destructive",
      });
    });
    base44.entities.Notification.create({
      title: "سریال جدید اضافه شد",
      body: newSeries?.title || "سریال جدید",
      type: "new_series",
      is_active: true,
    }).catch(() => {});
  };

  const deleteSeries = (id) => {
    const snapshot = allSeries;
    setAllSeries(prev => {
      const next = prev.filter(s => s.id !== id);
      // Update caches so deleted series don't reappear on offline reload.
      seriesCache = next;
      try { idbSet("series", "all", next); } catch {}
      return next;
    });
    try { localStorage.removeItem(`ayeneh_last_ep_${id}`); } catch {}
    base44.entities.Series.delete(id).catch(() => {
      // Rollback: restore the deleted series
      setAllSeries(snapshot);
      seriesCache = snapshot;
      try { idbSet("series", "all", snapshot); } catch {}
      const fa = readSettings().language !== "en";
      toast({
        title: fa ? "خطا در حذف سریال" : "Failed to delete series",
        description: fa ? "لطفاً وارد حساب شوید یا اتصال اینترنت را بررسی کنید" : "Please log in or check your connection",
        variant: "destructive",
      });
    });
  };
  const renameSeries = (id, newName) => {
    const snapshot = allSeries.find(s => s.id === id);
    setAllSeries(prev => prev.map(s => s.id === id ? { ...s, title: newName } : s));
    base44.entities.Series.update(id, { title: newName }).catch(() => {
      // Rollback: restore the old title
      setAllSeries(prev => prev.map(s => s.id === id ? { ...s, title: snapshot?.title || s.title } : s));
      const fa = readSettings().language !== "en";
      toast({
        title: fa ? "خطا در تغییر نام سریال" : "Failed to rename series",
        description: fa ? "لطفاً وارد حساب شوید یا اتصال اینترنت را بررسی کنید" : "Please log in or check your connection",
        variant: "destructive",
      });
    });
  };
  const changeSeriesPhoto = (id, newPhoto, position, scale) => {
    const snapshot = allSeries.find(s => s.id === id);
    setAllSeries(prev => prev.map(s => s.id === id ? { ...s, poster: newPhoto, posterPosition: position, posterScale: scale } : s));
    base44.entities.Series.update(id, { poster: newPhoto, posterPosition: position, posterScale: scale }).catch(() => {
      // Rollback: restore the old photo
      setAllSeries(prev => prev.map(s => s.id === id ? { ...s, poster: snapshot?.poster || s.poster, posterPosition: snapshot?.posterPosition, posterScale: snapshot?.posterScale } : s));
      const fa = readSettings().language !== "en";
      toast({
        title: fa ? "خطا در تغییر عکس سریال" : "Failed to change series photo",
        description: fa ? "لطفاً وارد حساب شوید یا اتصال اینترنت را بررسی کنید" : "Please log in or check your connection",
        variant: "destructive",
      });
    });
  };

  const addEpisodeToSeries = (seriesId, episode) => {
    const build = (s) => {
      if (s.id !== seriesId) return s;
      const eps = [...(s.episodes || [])];
      const nextNumber = eps.length > 0 ? Math.max(...eps.map(e => Number(e.number) || 0)) + 1 : 1;
      eps.push({ ...episode, number: episode.number || nextNumber });
      return { ...s, episodes: eps };
    };
    setAllSeries(prev => {
      const next = prev.map(build);
      const updated = next.find(s => s.id === seriesId);
      if (updated) base44.entities.Series.update(seriesId, { episodes: updated.episodes }).catch(() => {});
      return next;
    });
  };

  const reorderEpisodes = (seriesId, fromIndex, toIndex) => {
    const build = (s) => {
      if (s.id !== seriesId) return s;
      const eps = [...(s.episodes || [])].sort((a, b) => a.number - b.number);
      if (toIndex < 0 || toIndex >= eps.length || fromIndex === toIndex) return s;
      [eps[fromIndex], eps[toIndex]] = [eps[toIndex], eps[fromIndex]];
      // Keep original episode numbers — don't renumber after reorder
      return { ...s, episodes: eps };
    };
    setAllSeries(prev => {
      const next = prev.map(build);
      const updated = next.find(s => s.id === seriesId);
      if (updated) base44.entities.Series.update(seriesId, { episodes: updated.episodes }).catch(() => {});
      return next;
    });
  };

  const deleteEpisode = (seriesId, epIdx) => {
    const build = (s) => {
      if (s.id !== seriesId) return s;
      const eps = [...(s.episodes || [])].sort((a, b) => a.number - b.number);
      if (epIdx < 0 || epIdx >= eps.length) return s;
      eps.splice(epIdx, 1);
      // Keep original episode numbers — don't renumber after delete
      return { ...s, episodes: eps };
    };
    setAllSeries(prev => {
      const next = prev.map(build);
      const updated = next.find(s => s.id === seriesId);
      if (updated) base44.entities.Series.update(seriesId, { episodes: updated.episodes }).catch(() => {});
      return next;
    });
  };

  const catFiltered = allSeries.filter(s => !categoryFilter || s.category === categoryFilter);

  // ── Section data for Darya.net-style layout ──
  // 1. Continue Watching — series with a saved last episode
  const continueWatching = catFiltered.filter(s => {
    try { return !!localStorage.getItem(`ayeneh_last_ep_${s.id}`); } catch { return false; }
  });

  // 2. New Series — most recently added (first 12)
  const newSeries = [...catFiltered].sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0)).slice(0, 12);

  // 3. Coming Soon — placeholder (empty for now, shows a teaser card)
  const comingSoon = [];

  const activeSections = categoryFilter ? SECTIONS.filter(s => s.id === categoryFilter) : SECTIONS;
  const heroSeries = catFiltered[0];

  // Flat list for TV remote navigation
  const flatSeries = [
    ...continueWatching,
    ...newSeries.filter(s => !continueWatching.includes(s)),
    ...activeSections.flatMap(section => allSeries.filter(s => s.category === section.id)),
  ];

  // ── TV Remote: only handle BACK — arrow keys + OK are handled by the global
  // useTVRemote hook (spatial navigation) and native click on focused SeriesCard.
  // On TV: focus on a card plays its trailer (with sound); OK opens the series detail.
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        killAllMedia();
        navigate("/");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  // Clean up trailer debounce timer on unmount
  useEffect(() => {
    return () => { if (trailerDebounceRef.current) clearTimeout(trailerDebounceRef.current); };
  }, []);

  // ── Netflix-style: on TV, when a card receives focus, auto-play its trailer
  // at the top (TrailerHero) after a short debounce. OK opens the series detail.
  const handleCardFocus = (globalIdx) => {
    setFocusIndex(globalIdx);
    if (!isTV) return;
    const item = flatSeries[globalIdx];
    if (!item) return;
    if (trailerDebounceRef.current) clearTimeout(trailerDebounceRef.current);
    trailerDebounceRef.current = setTimeout(() => {
      setTrailerSeries(prev => {
        if (prev?.id === item.id) return prev; // already playing this trailer
        return { ...item, _trailerPlayId: Date.now() };
      });
    }, 800);
  };

  useEffect(() => {
    if (focusIndex < 0) return;
    const item = flatSeries[focusIndex];
    if (item) {
      const el = document.getElementById(`series-card-${item.id}`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
    }
  }, [focusIndex]);

  const handleSeriesSelect = (series) => {
    // Direct navigation to series detail — no trailer preview.
    openSeriesDetail(series);
  };

  const openSeriesDetail = (series) => {
    const episodes = (series.episodes || []).slice().sort((a, b) => a.number - b.number);
    // No episodes — just open the detail overlay without starting a player.
    if (episodes.length === 0) {
      updateMediaParams({ series: series.id, episode: null });
      return;
    }
    const lastEpId = localStorage.getItem(`ayeneh_last_ep_${series.id}`);
    const lastEp = episodes.find(ep => (ep.videoId || ep.fileUrl) === lastEpId) || episodes[0];
    // Track for the "Continue Watching" section so the series resumes next time.
    const epKey = lastEp?.videoId || lastEp?.fileUrl;
    if (epKey) {
      try { localStorage.setItem(`ayeneh_last_ep_${series.id}`, epKey); } catch {}
    }
    // Push series + episode to the URL (creates a new history entry).
    setPlayId(Date.now());
    updateMediaParams({ series: series.id, episode: lastEp.number });

    // Auto-sync: re-fetch playlist in background to pick up new episodes
    if (series.playlistId) {
      fetchPlaylistEpisodes(series.playlistId).then(({ episodes: freshEps }) => {
        if (!freshEps || freshEps.length === 0) return;
        const currentEps = series.episodes || [];
        const needsUpdate = freshEps.length !== currentEps.length ||
          (currentEps.length > 0 && freshEps[0].videoId !== currentEps[0].videoId);
        if (!needsUpdate) return;
        const updated = { ...series, episodes: freshEps };
        setAllSeries(prev => prev.map(s => s.id === series.id ? updated : s));
        base44.entities.Series.update(series.id, { episodes: freshEps }).catch(() => {});
      }).catch(() => {});
    }
  };

  const handlePlayEpisode = (ep) => {
    // Push the episode to the URL (creates a new history entry).
    setPlayId(Date.now());
    updateMediaParams({ episode: ep.number });
    if (selectedSeries) {
      const epKey = ep.videoId || ep.fileUrl;
      if (epKey) localStorage.setItem(`ayeneh_last_ep_${selectedSeries.id}`, epKey);
    }
  };

  if (showSplash) return <MediaSplash onDone={() => setShowSplash(false)} />;

  if (selectedSeries) {
    return (
      <SeriesDetail
        series={selectedSeries}
        onPlayEpisode={handlePlayEpisode}
        playingEpisode={playingEpisode}
        onBack={() => updateMediaParams({ series: null, episode: null })}
        onExitPlayer={() => updateMediaParams({ episode: null }, { replace: true })}
        onDelete={isAdmin ? () => { deleteSeries(selectedSeries.id); updateMediaParams({ series: null, episode: null }, { replace: true }); } : undefined}
        onAddEpisode={isAdmin ? (ep) => addEpisodeToSeries(selectedSeries.id, ep) : undefined}
        onReorderEpisodes={isAdmin ? (fromIdx, toIdx) => reorderEpisodes(selectedSeries.id, fromIdx, toIdx) : undefined}
        onDeleteEpisode={isAdmin ? (epIdx) => deleteEpisode(selectedSeries.id, epIdx) : undefined}
        onEditEpisodeNumber={isAdmin ? (epIdx, newNum) => {
          const build = (s) => {
            if (s.id !== selectedSeries.id) return s;
            const eps = [...(s.episodes || [])].sort((a, b) => a.number - b.number);
            if (epIdx < 0 || epIdx >= eps.length) return s;
            const oldEp = eps[epIdx];
            // Update title if it's a generic "قسمت X" or "Episode X" pattern
            const isGenericTitle = /^(قسمت|Episode)\s+\d+$/i.test((oldEp.title || '').trim());
            eps[epIdx] = {
              ...oldEp,
              number: newNum,
              title: isGenericTitle ? `قسمت ${newNum}` : oldEp.title,
            };
            return { ...s, episodes: eps };
          };
          setAllSeries(prev => {
            const next = prev.map(build);
            const updated = next.find(s => s.id === selectedSeries.id);
            if (updated) base44.entities.Series.update(selectedSeries.id, { episodes: updated.episodes }).catch(() => {});
            return next;
          });
        } : undefined}
        isFa={isFa} isTV={isTV}
        isAdmin={isAdmin}
      />
    );
  }

  // Compute flat index offsets for each section
  let runningOffset = 0;
  const sectionOffsets = {};
  const sectionsData = [
    { id: "continue", data: continueWatching, offset: runningOffset },
  ];
  runningOffset += continueWatching.length;
  sectionsData.push({ id: "new", data: newSeries, offset: runningOffset });
  runningOffset += newSeries.length;

  return (
    <div className="fixed inset-0 flex flex-col text-white overflow-hidden" style={{ background: '#0a0d16', WebkitTouchCallout: 'none', WebkitUserSelect: 'none', userSelect: 'none' }} onContextMenu={(e) => e.preventDefault()}>
      <style>{`@keyframes shimmerText{0%{background-position:-200% 0}100%{background-position:200% 0}} .shimmer-text{background:linear-gradient(90deg,#c77dff,#5ad8ff,#fff,#c77dff);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;animation:shimmerText 3s linear infinite;-webkit-transform:translateZ(0);transform:translateZ(0);-webkit-backface-visibility:hidden;backface-visibility:hidden}`}</style>
      {/* Top nav bar */}
      <NavHeader title={tr("سریال‌ها", "Series")} rtl={isFa}>
        <button onClick={toggleLang} data-remote
          className="flex items-center gap-1.5 px-3 py-3 md:py-2 rounded-xl text-xs font-bold text-white transition-all hover:scale-105"
          style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}>
          <Languages className="w-3.5 h-3.5" />
          {isFa ? "EN" : "فا"}
        </button>
        {isAdmin && (
          <>
            <button onClick={() => setShowReorderModal(true)} data-remote
              className="flex items-center gap-1.5 px-3 py-3 md:py-2 rounded-xl text-xs font-bold text-white transition-all hover:scale-105"
              style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}>
              <List className="w-3.5 h-3.5" /> {tr("مدیریت", "Manage")}
            </button>
            <button onClick={() => setShowAddForm(true)} data-remote
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)', boxShadow: '0 4px 15px rgba(123,44,191,0.35)' }}>
              <Plus className="w-4 h-4" /> {tr("افزودن", "Add")}
            </button>
          </>
        )}
      </NavHeader>

      {loadFailed && (
        <div className="flex items-center justify-between gap-3 px-4 py-2.5 flex-shrink-0 z-20"
          style={{ background: 'rgba(239,68,68,0.12)', borderBottom: '1px solid rgba(239,68,68,0.3)' }}>
          <p className="text-red-300 text-xs font-medium flex-1">
            {isFa ? "بارگذاری سریال‌ها ناموفق بود — وارد حساب شوید یا اتصال اینترنت را بررسی کنید" : "Failed to load series — please log in or check connection"}
          </p>
          <button onClick={refreshMedia} data-remote
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-white flex-shrink-0">
            <RefreshCw className="w-3 h-3" /> {isFa ? "تلاش مجدد" : "Retry"}
          </button>
        </div>
      )}

      <div className="flex-1 overflow-y-auto pb-[calc(5rem_+_env(safe-area-inset-bottom))] md:pb-0" ref={mediaScrollRef}>
        {!selectedSeries && (
          trailerSeries ? (
            <TrailerHero
              key={trailerSeries._trailerPlayId}
              series={trailerSeries}
              onEnter={(s) => { setTrailerSeries(null); openSeriesDetail(s); }}
              onStop={() => setTrailerSeries(null)}
              isTV={isTV}
              allSeries={catFiltered}
            />
          ) : (
            <HeroVideo series={catFiltered} onPlay={setHeroPlaying} onShowEpisodes={openSeriesDetail} />
          )
        )}

        {/* 1. Continue Watching — first section at the top */}
        {continueWatching.length > 0 && (
          <CategoryRow
            section={{ id: "continue", label: tr("ادامه تماشا", "Continue Watching"), labelEn: "Continue Watching", icon: <Clock className="w-4 h-4" /> }}
            items={continueWatching}
            onSelect={handleSeriesSelect}
            onDoubleSelect={openSeriesDetail}
            onLongPress={setContextMenuSeries}
            onAdd={isAdmin ? () => setShowAddForm(true) : null}
            focusIndex={focusIndex}
            sectionStartIndex={sectionsData[0].offset}
            onFocusCard={handleCardFocus}
            accentColor="#00d4ff"
            isFa={isFa} isTV={isTV}
          />
        )}

        {/* 2. New Series */}
        {newSeries.length > 0 && (
          <CategoryRow
            section={{ id: "new", label: newLabel, labelEn: "New Series", icon: <Sparkles className="w-4 h-4" /> }}
            items={newSeries}
            onSelect={handleSeriesSelect}
            onDoubleSelect={openSeriesDetail}
            onLongPress={setContextMenuSeries}
            onAdd={isAdmin ? () => setShowAddForm(true) : null}
            focusIndex={focusIndex}
            sectionStartIndex={sectionsData[1].offset}
            onFocusCard={handleCardFocus}
            accentColor="#a855f7"
            isFa={isFa} isTV={isTV}
          />
        )}

        {/* 3. Coming Soon */}
        <CategoryRow
          section={{ id: "coming", label: tr("به زودی", "Coming Soon"), labelEn: "Coming Soon", icon: <Calendar className="w-4 h-4" /> }}
          items={comingSoon}
          onSelect={handleSeriesSelect}
          onDoubleSelect={openSeriesDetail}
          onLongPress={setContextMenuSeries}
          onAdd={isAdmin ? () => setShowAddForm(true) : null}
          focusIndex={focusIndex}
          sectionStartIndex={runningOffset}
          onFocusCard={handleCardFocus}
          accentColor="#fbbf24"
          isComingSoon
          isFa={isFa} isTV={isTV}
        />

        {/* Category sections */}
        {activeSections.map((section, sIdx) => {
          const items = allSeries.filter(s => s.category === section.id);
          const sectionStartIndex = runningOffset + comingSoon.length + activeSections.slice(0, sIdx).reduce((acc, s) => acc + allSeries.filter(x => x.category === s.id).length, 0);
          if (items.length === 0 && !["animation", "movies", "comedy", "drama", "occasional"].includes(section.id)) return null;
          const resolvedSection = { ...section, label: isFa ? section.label : (section.labelEn || section.label) };
          return (
            <CategoryRow key={section.id} section={resolvedSection} items={items} onSelect={handleSeriesSelect} onDoubleSelect={openSeriesDetail} onLongPress={setContextMenuSeries} onAdd={isAdmin ? () => setShowAddForm(true) : null} focusIndex={focusIndex} sectionStartIndex={sectionStartIndex} onFocusCard={handleCardFocus} isFa={isFa} isTV={isTV} />
          );
        })}

        {/* Empty state */}
        {catFiltered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: 'rgba(123,44,191,0.15)', border: '1px solid rgba(123,44,191,0.3)' }}>
              <Clapperboard className="w-8 h-8 text-purple-400" />
            </div>
            <p className="text-white/40 text-sm">
              {categoryFilter === "animation" ? tr("هنوز انیمیشنی اضافه نشده", "No animations yet") : categoryFilter === "movies" ? tr("هنوز فیلمی اضافه نشده", "No movies yet") : tr("هنوز سریال یا انیمیشنی اضافه نشده", "No series or animations yet")}
            </p>
            {isAdmin && (
              <button onClick={() => setShowAddForm(true)} data-remote
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)' }}>
                <Plus className="w-4 h-4" />
                {categoryFilter === "animation" ? tr("افزودن اولین انیمیشن", "Add first animation") : categoryFilter === "movies" ? tr("افزودن اولین فیلم", "Add first movie") : tr("افزودن اولین سریال", "Add first series")}
              </button>
            )}
          </div>
        )}

        <div className="h-8" />
      </div>

      {/* Pull-to-refresh indicator (mobile) */}
      {(mediaPull > 0 || mediaRefreshing) && (
        <div className="absolute left-1/2 z-30 flex flex-col items-center pointer-events-none"
          style={{ top: 72, transform: `translateX(-50%) translateY(${mediaPull}px)` }}>
          <RefreshCw className={`w-5 h-5 text-cyan-300 ${mediaRefreshing ? "animate-spin" : ""}`} style={{ opacity: Math.min(1, mediaPull / 70) }} />
        </div>
      )}

      {showAddForm && (
        <AddPlaylistForm onAdd={addSeries} onClose={() => setShowAddForm(false)} />
      )}
      {addEpisodeTarget && (
        <AddEpisodeForm
          nextNumber={(addEpisodeTarget.episodes && addEpisodeTarget.episodes.length) ? Math.max(...addEpisodeTarget.episodes.map(e => Number(e.number) || 0)) + 1 : 1}
          isFa={isFa} isTV={isTV}
          onAdd={(ep) => { addEpisodeToSeries(addEpisodeTarget.id, ep); setAddEpisodeTarget(null); }}
          onClose={() => setAddEpisodeTarget(null)}
        />
      )}
      {heroPlaying && (
        <div className="fixed inset-0 z-[80] bg-black" onClick={() => setHeroPlaying(null)}>
          <div className="relative w-full h-full" onClick={e => e.stopPropagation()}>
            <button onClick={() => setHeroPlaying(null)} data-remote className="absolute top-4 right-4 z-20 text-white/50 hover:text-white p-2 bg-black/40 rounded-xl backdrop-blur-md">
              <X className="w-5 h-5" />
            </button>
            {heroPlaying.fileUrl ? (
              <HlsVideoPlayer src={heroPlaying.fileUrl} />
            ) : (
              <YouTubePlayer videoId={heroPlaying.videoId} muted={true} />
            )}
          </div>
        </div>
      )}
      {contextMenuSeries && (
        <SeriesContextMenu
          series={contextMenuSeries}
          isAdmin={isAdmin}
          onDelete={isAdmin ? () => { deleteSeries(contextMenuSeries.id); setContextMenuSeries(null); } : undefined}
          onRename={isAdmin ? (newName) => renameSeries(contextMenuSeries.id, newName) : undefined}
          onChangePhoto={isAdmin ? (newPhoto, position, scale) => changeSeriesPhoto(contextMenuSeries.id, newPhoto, position, scale) : undefined}
          onAddEpisode={isAdmin ? () => { setAddEpisodeTarget(contextMenuSeries); setContextMenuSeries(null); } : undefined}
          onClose={() => setContextMenuSeries(null)}
        />
      )}
      {showReorderModal && (
        <SeriesReorderModal
          series={allSeries}
          onClose={() => setShowReorderModal(false)}
          onSaved={() => {
            seriesCache = null;
            loadSeries().then(setAllSeries);
          }}
          isFa={isFa} isTV={isTV}
        />
      )}
    </div>
  );
}

// ── Category Row (horizontal scroll — darya.net style) ──
function CategoryRow({ section, items, onSelect, onDoubleSelect, onLongPress, onAdd, focusIndex, sectionStartIndex, onFocusCard, accentColor, isComingSoon, isFa, isTV }) {
  const rowRef = useRef(null);
  const isEmpty = ["animation", "movies", "comedy", "drama", "occasional"].includes(section.id);
  const emptyLabel = section.id === "animation"
    ? (isFa ? "هنوز انیمیشنی اضافه نشده" : "No animations yet")
    : section.id === "movies"
    ? (isFa ? "هنوز فیلمی اضافه نشده" : "No movies yet")
    : section.id === "comedy"
    ? (isFa ? "هنوز سریال کمدی اضافه نشده" : "No comedy series yet")
    : section.id === "drama"
    ? (isFa ? "هنوز سریال داستانی اضافه نشده" : "No drama series yet")
    : section.id === "occasional"
    ? (isFa ? "هنوز برنامه مناسبتی اضافه نشده" : "No occasional programs yet")
    : (isFa ? "هنوز محتوایی اضافه نشده" : "No content yet");
  const emptyBtn = section.id === "animation"
    ? (isFa ? "افزودن انیمیشن" : "Add Animation")
    : section.id === "movies"
    ? (isFa ? "افزودن فیلم" : "Add Movie")
    : section.id === "comedy"
    ? (isFa ? "افزودن سریال کمدی" : "Add Comedy")
    : section.id === "drama"
    ? (isFa ? "افزودن سریال داستانی" : "Add Drama")
    : section.id === "occasional"
    ? (isFa ? "افزودن برنامه مناسبتی" : "Add Occasional")
    : (isFa ? "افزودن" : "Add");

  return (
    <div className="px-4 py-5">
      {/* Section header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <span style={{ color: accentColor || '#a855f7' }}>{section.icon}</span>
          <h3 className="font-bold text-lg shimmer-text">{section.label}</h3>
          <span className="text-white/30 text-sm">({items.length})</span>
        </div>
        {items.length > 0 && (
          <div className="flex gap-1">
            <button onClick={() => rowRef.current?.scrollBy({ left: -300, behavior: 'smooth' })} data-remote aria-label="Scroll left"
              className="w-11 h-11 rounded-full flex items-center justify-center bg-white/5 hover:bg-white/10 transition-colors">
              <ChevronLeft className="w-4 h-4 text-white/60" />
            </button>
            <button onClick={() => rowRef.current?.scrollBy({ left: 300, behavior: 'smooth' })} data-remote aria-label="Scroll right"
              className="w-11 h-11 rounded-full flex items-center justify-center bg-white/5 hover:bg-white/10 transition-colors">
              <ChevronRight className="w-4 h-4 text-white/60" />
            </button>
          </div>
        )}
      </div>

      {/* Coming Soon placeholder */}
      {isComingSoon ? (
        <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none', touchAction: 'pan-x' }}>
          {[1, 2, 3].map(i => (
            <div key={i} className="flex-shrink-0 w-40 h-56 rounded-2xl flex flex-col items-center justify-center gap-3"
              style={{ background: 'rgba(255,255,255,0.03)', border: '2px dashed rgba(251,191,36,0.25)' }}>
              <Calendar className="w-8 h-8 text-yellow-400/40" />
              <p className="text-yellow-400/50 text-xs font-medium text-center px-3">{isFa ? "به زودی" : "Coming Soon"}</p>
              <p className="text-white/20 text-[10px]">{isFa ? "Coming Soon" : "به زودی"}</p>
            </div>
          ))}
        </div>
      ) : items.length > 0 ? (
        <div ref={rowRef} className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none', touchAction: 'pan-x' }}>
          {items.map((item, i) => {
            const globalIdx = sectionStartIndex + i;
            return (
              <SeriesCard key={item.id} item={item} onSelect={onSelect} onDoubleSelect={onDoubleSelect} onLongPress={onLongPress}
                isFocused={focusIndex === globalIdx} index={i}
                onFocus={() => onFocusCard && onFocusCard(globalIdx)} isTV={isTV} />
            );
          })}
        </div>
      ) : isEmpty ? (
        <div className="text-center py-10">
          <Clapperboard className="w-10 h-10 text-purple-400/40 mx-auto mb-3" />
          <p className="text-white/50 text-sm mb-3">{emptyLabel}</p>
          {onAdd && (
            <button onClick={onAdd}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-white"
              style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)' }}>
              <Plus className="w-4 h-4" /> {emptyBtn}
            </button>
          )}
        </div>
      ) : null}
    </div>
  );
}