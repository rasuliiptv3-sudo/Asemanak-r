import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useRemoteNav } from "@/lib/useRemoteNav";
import { base44 } from "@/api/base44Client";
import { Search, Radio, RefreshCw } from "lucide-react";
import ChannelCard from "@/components/channels/ChannelCard";
import CategoryFilter from "@/components/channels/CategoryFilter";
import NavHeader from "@/components/layout/NavHeader";
import { usePullToRefresh } from "@/lib/usePullToRefresh";

export default function Channels() {
  const navigate = useNavigate();
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState(() => {
    const saved = localStorage.getItem("ayeneh_favorites");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cat = params.get("category");
    if (cat) setCategory(cat);
    // Paginated fetch — loads ALL channels (10,000+)
    const loadAll = async () => {
      const all = [];
      let page = 0;
      const PAGE_SIZE = 500;
      while (page < 100) {
        let batch;
        try { batch = await base44.entities.Channel.list("-created_date", PAGE_SIZE, page * PAGE_SIZE); } catch { break; }
        if (!batch?.length) break;
        all.push(...batch);
        setChannels([...all]);
        if (batch.length < PAGE_SIZE) break;
        page++;
      }
      setLoading(false);
    };
    loadAll();
  }, []);

  const reloadChannels = useCallback(async () => {
    try {
      const all = [];
      let page = 0;
      const PAGE_SIZE = 500;
      while (page < 100) {
        const batch = await base44.entities.Channel.list("-created_date", PAGE_SIZE, page * PAGE_SIZE);
        if (!batch?.length) break;
        all.push(...batch);
        if (batch.length < PAGE_SIZE) break;
        page++;
      }
      if (all.length) setChannels(all);
    } catch {}
  }, []);
  const { ref, pull, refreshing } = usePullToRefresh({ onRefresh: reloadChannels });
  const navRef = useRef(null);
  const setOuterRef = useCallback((el) => { ref.current = el; navRef.current = el; }, [ref]);
  useRemoteNav(navRef);

  // TV remote: Back key returns to main menu
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        navigate("/");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const toggleFavorite = (id) => {
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id];
      try { localStorage.setItem("ayeneh_favorites", JSON.stringify(next)); }
      catch { return prev; }
      return next;
    });
  };

  const filtered = channels.filter((ch) => {
    const matchCat = category === "all" || ch.category === category;
    const matchSearch =
      !search ||
      ch.name.toLowerCase().includes(search.toLowerCase()) ||
      (ch.name_fa && ch.name_fa.includes(search));
    return matchCat && matchSearch;
  });

  return (
    <div ref={setOuterRef} className="relative h-full overflow-y-auto" style={{ paddingTop: 0 }}>
      <NavHeader title="All Channels" fallbackTo="/" />
      <div className="max-w-7xl mx-auto px-4 py-8 pb-[calc(5.5rem_+_env(safe-area-inset-bottom))] md:pb-8" style={{ paddingLeft: "calc(1rem + env(safe-area-inset-left))", paddingRight: "calc(1rem + env(safe-area-inset-right))", paddingTop: "calc(2rem + env(safe-area-inset-top))" }}>
      {/* Pull-to-refresh indicator (mobile) */}
      {(pull > 0 || refreshing) && (
        <div className="absolute left-1/2 top-0 z-30 flex flex-col items-center pointer-events-none"
          style={{ transform: `translateX(-50%) translateY(${pull}px)` }}>
          <RefreshCw className={`w-5 h-5 text-cyan-300 ${refreshing ? "animate-spin" : ""}`} style={{ opacity: Math.min(1, pull / 70) }} />
        </div>
      )}
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-black text-foreground mb-1">All Channels</h1>
        <p className="text-muted-foreground font-vazir">تمام کانال‌های موجود</p>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          data-remote
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search channels..."
          className="w-full bg-secondary border border-border rounded-xl pl-12 pr-4 py-3 text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 transition-colors"
        />
      </div>

      {/* Filter */}
      <div className="mb-8">
        <CategoryFilter selected={category} onChange={setCategory} />
      </div>

      {/* Count */}
      {!loading && (
        <p className="text-sm text-muted-foreground mb-4">
          {filtered.length} channel{filtered.length !== 1 ? "s" : ""} found
        </p>
      )}

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="bg-card border border-border rounded-xl overflow-hidden animate-pulse">
              <div className="h-40 bg-secondary" />
              <div className="p-3 space-y-2">
                <div className="h-3 bg-secondary rounded w-3/4" />
                <div className="h-3 bg-secondary rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {filtered.map((ch) => (
            <ChannelCard
              key={ch.id}
              channel={ch}
              isFavorite={favorites.includes(ch.id)}
              onToggleFavorite={toggleFavorite}
              onPlay={() => navigate(`/Player/${ch.id}`)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-24">
          <Radio className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-lg font-semibold">No channels found</p>
          <p className="text-muted-foreground mt-1">Try a different search or category</p>
        </div>
      )}
      </div>
    </div>
  );
}