import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Upload, Link, CheckCircle, AlertCircle, Loader2, ArrowLeft, Tv, ShieldAlert } from "lucide-react";
import { Link as RouterLink } from "react-router-dom";

function parseM3U(text) {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  const channels = [];
  let current = {};
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith("#EXTINF:")) {
      current = {};
      const nameMatch = line.match(/tvg-name="([^"]*)"/);
      const logoMatch = line.match(/tvg-logo="([^"]*)"/);
      const groupMatch = line.match(/group-title="([^"]*)"/);
      const countryMatch = line.match(/tvg-country="([^"]*)"/);
      const langMatch = line.match(/tvg-language="([^"]*)"/);
      const commaIdx = line.lastIndexOf(",");
      const displayName = commaIdx >= 0 ? line.slice(commaIdx + 1).trim() : "";
      current.name = (nameMatch ? nameMatch[1] : displayName) || "Unknown";
      current.logo_url = logoMatch ? logoMatch[1] : "";
      current.country = countryMatch ? countryMatch[1] : (groupMatch ? groupMatch[1] : "");
      current.language = langMatch ? langMatch[1] : "";
      current.category = "general";
      current.is_active = true;
    } else if (!line.startsWith("#") && (line.startsWith("http") || line.startsWith("rtmp")) && current.name) {
      current.stream_url = line;
      channels.push({ ...current });
      current = {};
    }
  }
  return channels;
}

export default function ImportPlaylist() {
  const [url, setUrl] = useState("https://iptv-org.github.io/iptv/index.country.m3u");
  const [status, setStatus] = useState(null);
  const [message, setMessage] = useState("");
  const [count, setCount] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isAdmin, setIsAdmin] = useState(null); // null = loading

  useEffect(() => {
    base44.auth.me().then((user) => {
      setIsAdmin(user?.role === "admin");
    }).catch(() => setIsAdmin(false));
  }, []);

  const handleImportUrl = async () => {
    if (!url.trim()) return;
    setStatus("loading");
    setMessage("Fetching playlist...");
    setProgress(10);
    let text = "";
    try {
      const res = await fetch(url);
      text = await res.text();
    } catch {
      setStatus("error");
      setMessage("Could not fetch playlist. Please paste the M3U content directly below.");
      return;
    }
    await processM3U(text);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setStatus("loading");
    setMessage("Reading file...");
    setProgress(10);
    const text = await file.text();
    await processM3U(text);
  };

  const handlePaste = async (e) => {
    const text = e.target.value;
    if (text.includes("#EXTM3U") && text.length > 100) {
      setStatus("loading");
      setMessage("Parsing playlist...");
      setProgress(10);
      await processM3U(text);
    }
  };

  const processM3U = async (text) => {
    setProgress(30);
    const parsed = parseM3U(text);
    if (parsed.length === 0) {
      setStatus("error");
      setMessage("No valid channels found in this M3U file.");
      return;
    }
    setMessage(`Parsed ${parsed.length} channels. Importing...`);
    setProgress(50);
    const batchSize = 100;
    let imported = 0;
    for (let i = 0; i < parsed.length; i += batchSize) {
      await base44.entities.Channel.bulkCreate(parsed.slice(i, i + batchSize));
      imported += Math.min(batchSize, parsed.length - i);
      setProgress(50 + Math.floor((imported / parsed.length) * 50));
      setMessage(`Importing... ${imported}/${parsed.length}`);
    }
    setCount(parsed.length);
    setStatus("success");
    setMessage(`Successfully imported ${parsed.length} channels!`);
    setProgress(100);
  };

  // Loading admin check
  if (isAdmin === null) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
      </div>
    );
  }

  // Not admin
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center gap-4 px-4">
        <ShieldAlert className="w-12 h-12 text-red-400" />
        <h2 className="text-xl font-bold">Access Denied</h2>
        <p className="text-white/50 text-sm text-center">Only admins can import playlists.</p>
        <RouterLink to="/Home" className="mt-4 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-6 py-3 rounded-xl transition-colors">
          ← Back to Home
        </RouterLink>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="flex items-center gap-3 px-4 py-4 border-b border-white/10">
        <RouterLink to="/Home" className="text-white/60 hover:text-white">
          <ArrowLeft className="w-5 h-5" />
        </RouterLink>
        <Tv className="w-5 h-5 text-cyan-400" />
        <h1 className="text-lg font-bold">Import M3U Playlist</h1>
      </div>

      <div className="max-w-lg mx-auto px-4 py-8 space-y-6">
        <div className="space-y-2">
          <label className="text-sm text-white/60 font-medium uppercase tracking-wider">Playlist URL</label>
          <div className="flex gap-2">
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="http://example.com/playlist.m3u"
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-cyan-500/50"
            />
            <button
              onClick={handleImportUrl}
              disabled={status === "loading" || !url.trim()}
              className="bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 px-4 py-3 rounded-xl font-semibold text-sm flex items-center gap-2 transition-colors"
            >
              <Link className="w-4 h-4" />
              Load
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm text-white/60 font-medium uppercase tracking-wider">Upload .m3u File</label>
          <label className="flex flex-col items-center justify-center gap-3 border-2 border-dashed border-white/20 rounded-xl py-8 cursor-pointer hover:border-cyan-500/50 transition-colors bg-white/5">
            <Upload className="w-8 h-8 text-white/40" />
            <span className="text-sm text-white/50">Click to upload .m3u or .m3u8 file</span>
            <input type="file" accept=".m3u,.m3u8,.txt" className="hidden" onChange={handleFileUpload} />
          </label>
        </div>

        <div className="space-y-2">
          <label className="text-sm text-white/60 font-medium uppercase tracking-wider">Or Paste M3U Content</label>
          <textarea
            onChange={handlePaste}
            placeholder={"#EXTM3U\n#EXTINF:-1 tvg-name=\"Channel Name\" group-title=\"Country\",Channel Name\nhttp://stream.url/..."}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50 h-32 font-mono resize-none"
          />
        </div>

        {status && (
          <div className={`rounded-xl p-4 flex items-start gap-3 ${
            status === "success" ? "bg-green-900/30 border border-green-500/30" :
            status === "error" ? "bg-red-900/30 border border-red-500/30" :
            "bg-cyan-900/30 border border-cyan-500/30"
          }`}>
            {status === "loading" && <Loader2 className="w-5 h-5 text-cyan-400 animate-spin flex-shrink-0 mt-0.5" />}
            {status === "success" && <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />}
            {status === "error" && <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />}
            <div className="flex-1">
              <p className="text-sm">{message}</p>
              {status === "loading" && (
                <div className="mt-2 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500 rounded-full transition-all duration-300" style={{ width: `${progress}%` }} />
                </div>
              )}
            </div>
          </div>
        )}

        {status === "success" && (
          <RouterLink to="/Home" className="block w-full text-center bg-cyan-600 hover:bg-cyan-500 text-white font-semibold py-3 rounded-xl transition-colors">
            ← Back to Watch ({count} channels imported)
          </RouterLink>
        )}
      </div>
    </div>
  );
}