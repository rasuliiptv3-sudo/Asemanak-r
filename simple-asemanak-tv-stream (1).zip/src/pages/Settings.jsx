import { useState, useEffect, useRef } from "react";
import { useRemoteNav } from "@/lib/useRemoteNav";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { playStartupSound } from "@/lib/startupSound";
import {
  ArrowLeft, Plus, Trash2, List, Globe, Tv, Monitor, Download, Loader2,
  CheckCircle, AlertCircle, Edit2, Check, X, User, LogOut, Shield,
  Wifi, Zap, Info, RefreshCw, Lock, Eye, EyeOff, KeyRound,
  Users, Palette, Subtitles, Languages, Cloud, Bell, Image as ImageIcon,
  ChevronDown, ArrowUp, ArrowDown
} from "lucide-react";
import { Link as RouterLink, useParams, useNavigate } from "react-router-dom";
import AuthPlaylistSection from "@/components/settings/AuthPlaylistSection";
import UserStatsSection from "@/components/settings/UserStatsSection";
import DateTimeWeatherSection from "@/components/settings/DateTimeWeatherSection";
import SendNotificationSection from "@/components/settings/SendNotificationSection";
import SecurityLogsView from "@/components/settings/SecurityLogsView";
import BackgroundPicker from "@/components/entry/BackgroundPicker";
import OfflineManagerSection from "@/components/settings/OfflineManagerSection";
import PlaylistsSection from "@/components/settings/PlaylistsSection";
import AddChannelTab from "@/components/settings/AddChannelTab";
import { TIMEZONES } from "@/components/DigitalClock";
import { idbSet } from "@/lib/idb";
import { useIsMobile } from "@/lib/useIsMobile";
import MobileSelectSheet from "@/components/settings/MobileSelectSheet";
import DeleteAccountModal from "@/components/settings/DeleteAccountModal";
import NavHeader from "@/components/layout/NavHeader";
import FeedbackSection from "@/components/settings/FeedbackSection";

// ─── Translations ──────────────────────────────────────────────────────────
const T = {
  en: {
    settings: "Settings", general: "General", player: "Player",
    language: "Language", channelNumbers: "Ch. Numbers", playlists: "Playlists",
    account: "Account", performance: "Performance", about: "About",
    loadLastChannel: "Load last channel on startup", loadLastChannelDesc: "Auto-resume last watched channel",
    pip: "Picture-in-Picture", pipDesc: "Watch in floating mini window",
    smartControls: "Smart Controls", smartControlsDesc: "Show controls on hover/tap",
    bgBlur: "Background blur", bgBlurDesc: "Blur channel list over live video",
    showNumbers: "Show channel numbers", showNumbersDesc: "Display index numbers in list",
    autoHideList: "Auto-hide channel list", autoHideListDesc: "Hide list when video starts",
    darkTheme: "Dark theme", darkThemeDesc: "Use dark interface",
    bufferSize: "Buffer Size", bufferSizeDesc: "How much to buffer before playback",
    skipStep: "Skip Step", skipStepDesc: "Amount to skip forward/backward",
    videoQuality: "Video Quality", videoQualityDesc: "Default stream quality",
    aspectRatio: "Aspect Ratio", aspectRatioDesc: "Video aspect ratio",
    autoPlay: "Auto-play on select", autoPlayDesc: "Start playing immediately on tap",
    hwAccel: "Hardware acceleration", hwAccelDesc: "Use GPU for video decoding",
    autoReconnect: "Reconnect on error", autoReconnectDesc: "Auto-reconnect when stream fails",
    appLanguage: "App Language", epgLanguage: "EPG Language",
    showFarsiNames: "Show Persian names", showFarsiNamesDesc: "Show Farsi names when available",
    rtl: "RTL layout", rtlDesc: "Right-to-left interface",
    chNumbersTitle: "Channel Numbers", chNumbersDesc: "Edit icon to change order.",
    noChannels: "No channels loaded yet.", searchChannel: "Search channel...",
    m3uPlaylists: "M3U Playlists", playlistName: "Playlist name (optional)",
    playlistUrl: "http://example.com/playlist.m3u", addBtn: "Add",
    savedPlaylists: "Saved Playlists", load: "Load", noPlaylists: "No playlists yet.",
    deleting: "Deleting channels...", deleted: "channels deleted.",
    errorDelete: "Error deleting.", noChannelsFound: "No valid channels found.",
    loadedChannels: "channels loaded!", couldNotFetch: "Could not fetch playlist.",
    // Account
    signedInAs: "Signed in as", notSignedIn: "Not signed in",
    signInGoogle: "Sign in with Google", signOut: "Sign Out",
    deleteAccount: "Delete Account", deleteAccountDesc: "Permanently delete your account and all data",
    deleteConfirm: "Type DELETE to confirm", deleteConfirmBtn: "Permanently Delete",
    deleteSuccess: "Account deleted.", deleteFail: "Could not delete account.",
    profile: "Profile", email: "Email", role: "Role",
    // Performance
    lowBandwidth: "Low Bandwidth Mode", lowBandwidthDesc: "Reduce quality for weak connections",
    preloadNext: "Preload next channel", preloadNextDesc: "Buffer next channel in background",
    maxRetries: "Max Retries on Error", maxRetriesDesc: "How many times to retry failed stream",
    hlsLowLatency: "Low Latency Mode", hlsLowLatencyDesc: "Reduce stream delay (uses more data)",
    cacheChannels: "Cache channel list", cacheChannelsDesc: "Store channels offline for faster load",
    clearCache: "Clear Cache", clearCacheSuccess: "Cache cleared!",
    // About
    appName: "Asemanak TV", version: "Version", build: "Build",
    contact: "Contact", website: "Website",
    colorTheme: "Color Theme", colorThemeDesc: "Choose accent color scheme",
    fontSize: "Font Size", fontSizeDesc: "Adjust overall text size",
    minimalInfo: "Minimal info on switch", minimalInfoDesc: "Brief channel info overlay when switching",
    reverseChannelNav: "Reverse channel up/down", reverseChannelNavDesc: "Swap channel up/down navigation direction",
    channelListRight: "Channel list on right", channelListRightDesc: "Show channel list on the right side",
    startOnBoot: "Start app automatically after booting", startOnBootDesc: "Launch app when device starts",
    extendCutout: "Extend display into camera cutout", extendCutoutDesc: "Use full screen including notch area",
    landscape: "Landscape orientation", landscapeDesc: "Lock app to landscape mode",
    userAgent: "User-Agent", userAgentDesc: "Custom User-Agent header for stream requests",
    oldVersion: "Switch to old app version 2", oldVersionDesc: "Use the previous app version",
    subtitleEnabled: "Enable Subtitles", subtitleEnabledDesc: "Show translated subtitles on video",
    subtitleLang: "Subtitle Language",
    dubbingEnabled: "Enable Dubbing", dubbingEnabledDesc: "Translate audio to Farsi",
    dubbingLang: "Dubbing Language",
    subDubNote: "Works when the stream supports subtitle/dubbing tracks",
    userStats: "User Stats",
    navSound: "Navigation Sounds", navSoundDesc: "Play gentle sounds on focus and selection",
    startupSound: "Startup Sound", startupSoundDesc: "Play a sound when the app launches",
    startupSoundSelect: "Select Startup Sound", startupSoundSelectDesc: "Choose the launch sound (admin only)",
    soundDefault: "Default", soundCinematic: "Cinematic", soundSoft: "Soft Bell", soundEpic: "Epic",
    coverDuration: "Cover Image Duration", coverDurationDesc: "How long the series cover shows before playback",
  },
  fa: {
    settings: "تنظیمات", general: "عمومی", player: "پخش‌کننده",
    language: "زبان", channelNumbers: "شماره کانال", playlists: "پلی‌لیست‌ها",
    account: "حساب کاربری", performance: "عملکرد", about: "درباره",
    loadLastChannel: "بارگذاری آخرین کانال", loadLastChannelDesc: "ادامه پخش آخرین کانال",
    pip: "تصویر در تصویر", pipDesc: "تماشا در پنجره شناور",
    smartControls: "کنترل‌های هوشمند", smartControlsDesc: "نمایش کنترل‌ها هنگام هاور",
    bgBlur: "تار کردن پس‌زمینه", bgBlurDesc: "تار کردن لیست روی ویدیو",
    showNumbers: "نمایش شماره کانال", showNumbersDesc: "نمایش اعداد در لیست",
    autoHideList: "پنهان‌سازی خودکار لیست", autoHideListDesc: "پنهان کردن لیست پس از پخش",
    darkTheme: "تم تاریک", darkThemeDesc: "استفاده از رابط تاریک",
    bufferSize: "اندازه بافر", bufferSizeDesc: "میزان بافر قبل از پخش",
    skipStep: "مقدار جهش", skipStepDesc: "جهش به جلو/عقب",
    videoQuality: "کیفیت ویدیو", videoQualityDesc: "کیفیت پیش‌فرض",
    aspectRatio: "نسبت تصویر", aspectRatioDesc: "نسبت ابعاد ویدیو",
    autoPlay: "پخش خودکار", autoPlayDesc: "شروع پخش فوری",
    hwAccel: "شتاب سخت‌افزاری", hwAccelDesc: "استفاده از GPU",
    autoReconnect: "اتصال مجدد", autoReconnectDesc: "اتصال خودکار هنگام قطع",
    appLanguage: "زبان برنامه", epgLanguage: "زبان EPG",
    showFarsiNames: "نمایش نام فارسی", showFarsiNamesDesc: "نمایش نام فارسی در صورت وجود",
    rtl: "چیدمان راست به چپ", rtlDesc: "جهت رابط از راست به چپ",
    chNumbersTitle: "شماره کانال‌ها", chNumbersDesc: "روی آیکون ویرایش کلیک کنید.",
    noChannels: "هنوز کانالی نیست.", searchChannel: "جستجو...",
    m3uPlaylists: "پلی‌لیست‌های M3U", playlistName: "نام (اختیاری)",
    playlistUrl: "http://example.com/playlist.m3u", addBtn: "افزودن",
    savedPlaylists: "پلی‌لیست‌های ذخیره‌شده", load: "بارگذاری", noPlaylists: "پلی‌لیستی نیست.",
    deleting: "در حال حذف...", deleted: "کانال حذف شد.",
    errorDelete: "خطا در حذف.", noChannelsFound: "کانالی یافت نشد.",
    loadedChannels: "کانال بارگذاری شد!", couldNotFetch: "پلی‌لیست واکشی نشد.",
    signedInAs: "وارد شده با", notSignedIn: "وارد نشده‌اید",
    signInGoogle: "ورود با گوگل", signOut: "خروج",
    deleteAccount: "حذف حساب", deleteAccountDesc: "حذف دائمی حساب و تمام داده‌ها",
    deleteConfirm: "DELETE را تایپ کنید", deleteConfirmBtn: "حذف دائمی",
    deleteSuccess: "حساب حذف شد.", deleteFail: "حذف انجام نشد.",
    profile: "پروفایل", email: "ایمیل", role: "نقش",
    lowBandwidth: "حالت پهنای باند کم", lowBandwidthDesc: "کاهش کیفیت برای اتصال ضعیف",
    preloadNext: "پیش‌بارگذاری کانال بعدی", preloadNextDesc: "بافر کانال بعدی در پس‌زمینه",
    maxRetries: "حداکثر تلاش مجدد", maxRetriesDesc: "تعداد تلاش مجدد",
    hlsLowLatency: "حالت تأخیر کم", hlsLowLatencyDesc: "کاهش تأخیر پخش",
    cacheChannels: "ذخیره لیست کانال‌ها", cacheChannelsDesc: "ذخیره آفلاین برای بارگذاری سریع‌تر",
    clearCache: "پاک کردن حافظه", clearCacheSuccess: "حافظه پاک شد!",
    appName: "آسمانک تی وی", version: "نسخه", build: "بیلد",
    contact: "تماس", website: "وب‌سایت",
    colorTheme: "رنگ تم", colorThemeDesc: "انتخاب رنگ accent برنامه",
    fontSize: "اندازه فونت", fontSizeDesc: "تنظیم اندازه متن برنامه",
    minimalInfo: "اطلاعات مختصر هنگام تغییر کانال", minimalInfoDesc: "نمایش اطلاعات کوتاه کانال هنگام تغییر",
    reverseChannelNav: "معکوس کردن کانال بالا/پایین", reverseChannelNavDesc: "معکوس جهت navigation با دکمه کانال بالا/پایین",
    channelListRight: "لیست کانال در راست", channelListRightDesc: "نمایش لیست کانال در سمت راست",
    startOnBoot: "اجرای خودکار پس از بوت", startOnBootDesc: "اجرای برنامه هنگام روشن شدن دستگاه",
    extendCutout: "گسترش نمایش در ناحیه دوربین", extendCutoutDesc: "استفاده از تمام صفحه شامل ناحیه دوربین",
    landscape: "حالت افقی", landscapeDesc: "قفل کردن برنامه در حالت افقی",
    userAgent: "User-Agent", userAgentDesc: "هدر User-Agent سفارشی برای درخواست‌ها",
    oldVersion: "انتقال به نسخه قدیمی ۲", oldVersionDesc: "استفاده از نسخه قبلی برنامه",
    subtitleEnabled: "فعال‌سازی زیرنویس", subtitleEnabledDesc: "نمایش زیرنویس ترجمه‌شده روی ویدیو",
    subtitleLang: "زبان زیرنویس",
    dubbingEnabled: "فعال‌سازی دوبله", dubbingEnabledDesc: "ترجمه صدا به فارسی",
    dubbingLang: "زبان دوبله",
    subDubNote: "هنگامی که استریم از زیرنویس/دوبله پشتیبانی کند کار می‌کند",
    userStats: "آمار کاربران",
    navSound: "صدای ناوبری", navSoundDesc: "پخش صدای ملایم هنگام انتخاب گزینه‌ها",
    startupSound: "صدای استارتاپ", startupSoundDesc: "پخش صدا هنگام باز شدن برنامه",
    startupSoundSelect: "انتخاب صدای استارتاپ", startupSoundSelectDesc: "انتخاب صدای راه‌اندازی (فقط ادمین)",
    soundDefault: "پیش‌فرض", soundCinematic: "سینمایی", soundSoft: "زنگ نرم", soundEpic: "حماسی",
    startupSound: "صدای استارتاپ", startupSoundDesc: "پخش صدا هنگام باز شدن برنامه",
    startupSoundSelect: "انتخاب صدای استارتاپ", startupSoundSelectDesc: "انتخاب صدای راه‌اندازی (فقط ادمین)",
    soundDefault: "پیش‌فرض", soundCinematic: "سینمایی", soundSoft: "زنگ نرم", soundEpic: "حماسی",
    coverDuration: "مدت کاور سریال", coverDurationDesc: "مدت زمان نمایش عکس کاور قبل از پخش",
  },
};

// ─── Helpers ──────────────────────────────────────────────────────────────
function Toggle({ value, onChange }) {
  return (
    <button data-remote onClick={() => onChange(!value)}
      className={`relative w-12 h-6 rounded-full transition-all flex-shrink-0 ${value ? "bg-cyan-500" : "bg-white/15"}`}
      style={value ? { boxShadow: "0 0 12px rgba(34,211,238,0.5)" } : {}}>
      <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform ${value ? "translate-x-6" : "translate-x-0.5"}`} />
    </button>
  );
}

function Row({ label, description, children, rtl }) {
  return (
    <div className={`settings-row flex items-center justify-between px-4 py-3.5 rounded-xl mb-2 transition-colors hover:bg-white/[0.04] ${rtl ? "flex-row-reverse" : ""}`}
      style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
        <p className="text-[15px] text-white font-medium leading-tight">{label}</p>
        {description && <p className="text-sm text-white/60 mt-1 leading-snug">{description}</p>}
      </div>
      {children}
    </div>
  );
}

function SelectRow({ label, description, value, options, onChange, rtl }) {
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);
  const current = options.find((o) => (o.value !== undefined ? o.value : o) === value);
  const currentLabel = current ? (current.label || current) : value;

  // Mobile: touch-friendly bottom sheet instead of the native dropdown
  if (isMobile) {
    return (
      <>
        <div className={`settings-row flex items-center justify-between px-4 py-3.5 rounded-xl mb-2 transition-colors hover:bg-white/[0.04] ${rtl ? "flex-row-reverse" : ""}`}
          style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.06)" }}>
          <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
            <p className="text-[15px] text-white font-medium leading-tight">{label}</p>
            {description && <p className="text-sm text-white/60 mt-1 leading-snug">{description}</p>}
          </div>
          <button
            data-remote
            onClick={() => setOpen(true)}
            className="bg-white/10 border border-white/15 text-white text-sm rounded-lg px-3 py-2 flex items-center justify-between gap-1.5 flex-shrink-0 min-w-[120px] active:scale-95 transition-transform"
          >
            <span className="truncate">{currentLabel}</span>
            <ChevronDown className="w-3.5 h-3.5 text-white/50 flex-shrink-0" />
          </button>
        </div>
        {open && (
          <MobileSelectSheet
            label={label}
            options={options}
            value={value}
            rtl={rtl}
            onSelect={(v) => { onChange(v); setOpen(false); }}
            onClose={() => setOpen(false)}
          />
        )}
      </>
    );
  }

  return (
    <div className={`settings-row flex items-center justify-between px-4 py-3.5 rounded-xl mb-2 transition-colors hover:bg-white/[0.04] ${rtl ? "flex-row-reverse" : ""}`}
      style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
        <p className="text-[15px] text-white font-medium leading-tight">{label}</p>
        {description && <p className="text-sm text-white/60 mt-1 leading-snug">{description}</p>}
      </div>
      <select value={value} onChange={(e) => onChange(e.target.value)} data-remote
        className="bg-white/10 border border-white/15 text-white text-sm rounded-lg px-3 py-2 outline-none cursor-pointer flex-shrink-0 min-w-[120px]">
        {options.map((o) => <option key={o.value || o} value={o.value || o} className="bg-gray-900">{o.label || o}</option>)}
      </select>
    </div>
  );
}

function ChannelNumberEditor({ channels, onSave, t, isFA }) {
  const [editId, setEditId] = useState(null);
  const [editVal, setEditVal] = useState("");
  const [search, setSearch] = useState("");
  const [list, setList] = useState(channels);
  useEffect(() => { setList(channels); }, [channels]);
  const filtered = list.filter(ch => !search || ch.name.toLowerCase().includes(search.toLowerCase()));
  const startEdit = (ch, idx) => { setEditId(ch.id); setEditVal(String(idx + 1)); };
  const confirmEdit = (ch) => {
    const newNum = parseInt(editVal, 10);
    if (isNaN(newNum) || newNum < 1 || newNum > list.length) { setEditId(null); return; }
    const newList = [...list];
    const fromIdx = newList.findIndex(c => c.id === ch.id);
    const toIdx = Math.min(newNum - 1, newList.length - 1);
    const [removed] = newList.splice(fromIdx, 1);
    newList.splice(toIdx, 0, removed);
    setList(newList); onSave(newList); setEditId(null);
  };
  const moveUp = (ch) => {
    const idx = list.findIndex(c => c.id === ch.id);
    if (idx <= 0) return;
    const newList = [...list];
    [newList[idx - 1], newList[idx]] = [newList[idx], newList[idx - 1]];
    setList(newList); onSave(newList);
  };
  const moveDown = (ch) => {
    const idx = list.findIndex(c => c.id === ch.id);
    if (idx >= list.length - 1) return;
    const newList = [...list];
    [newList[idx + 1], newList[idx]] = [newList[idx], newList[idx + 1]];
    setList(newList); onSave(newList);
  };
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-white/60">{isFA ? `تعداد کانال‌ها: ${list.length}` : `Total channels: ${list.length}`}</span>
      </div>
      <input value={search} onChange={e => setSearch(e.target.value)} placeholder={t.searchChannel}
        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/30 outline-none focus:border-cyan-500/50 mb-3" />
      <div className="max-h-80 overflow-y-auto rounded-xl border border-white/10 divide-y divide-white/5">
        {filtered.map((ch) => {
          const globalIdx = list.findIndex(c => c.id === ch.id);
          return (
            <div key={ch.id} className="flex items-center gap-3 px-3 py-2.5 hover:bg-white/5">
              {editId === ch.id ? (
                <>
                  <input autoFocus value={editVal} onChange={e => setEditVal(e.target.value)}
                    onKeyDown={e => { if (e.key === "Enter") confirmEdit(ch); if (e.key === "Escape") setEditId(null); }}
                    className="w-14 bg-white/10 border border-cyan-500/50 rounded-lg px-2 py-1 text-xs text-white outline-none text-center" />
                  <span className="flex-1 text-sm text-white/80 truncate">{ch.name}</span>
                  <button onClick={() => confirmEdit(ch)} className="text-green-400 p-3 md:p-1"><Check className="w-4 h-4" /></button>
                  <button onClick={() => setEditId(null)} className="text-white/60 p-3 md:p-1"><X className="w-4 h-4" /></button>
                </>
              ) : (
                <>
                  <span className="text-xs font-mono text-white/40 w-8 text-right">{globalIdx + 1}</span>
                  <div className="flex-1 min-w-0">
                    <span className="text-sm text-white/80 truncate block">{ch.name}</span>
                    {ch.country && <span className="text-[10px] text-white/60">{ch.country}</span>}
                  </div>
                  <button onClick={() => moveUp(ch)} data-remote disabled={globalIdx === 0} className="text-white/30 hover:text-cyan-400 p-4 md:p-1 flex items-center justify-center disabled:opacity-20"><ArrowUp className="w-3.5 h-3.5" /></button>
                  <button onClick={() => moveDown(ch)} data-remote disabled={globalIdx === list.length - 1} className="text-white/30 hover:text-cyan-400 p-4 md:p-1 flex items-center justify-center disabled:opacity-20"><ArrowDown className="w-3.5 h-3.5" /></button>
                  <button onClick={() => startEdit(ch, globalIdx)} data-remote className="text-white/30 hover:text-cyan-400 p-4 md:p-1 flex items-center justify-center"><Edit2 className="w-3.5 h-3.5" /></button>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Password Gate ─────────────────────────────────────────────────────────
function PasswordGate({ onUnlock }) {
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [err, setErr] = useState(false);
  const check = () => {
    const saved = localStorage.getItem("ayeneh_settings_pw") || "";
    if (pw === saved) { onUnlock(); }
    else { setErr(true); setTimeout(() => setErr(false), 1500); }
  };
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-80 rounded-2xl border border-white/15 p-8 flex flex-col items-center gap-5"
        style={{ background: "rgba(10,14,24,0.98)" }}>
        <div className="w-16 h-16 rounded-full bg-cyan-500/15 flex items-center justify-center">
          <Lock className="w-8 h-8 text-cyan-400" />
        </div>
        <div className="text-center">
          <p className="text-white font-bold text-lg">تنظیمات قفل است</p>
          <p className="text-white/40 text-sm mt-1">Settings is Locked</p>
        </div>
        <div className="w-full relative">
          <input
            autoFocus
            data-remote
            type={show ? "text" : "password"}
            value={pw}
            onChange={e => setPw(e.target.value)}
            onKeyDown={e => e.key === "Enter" && check()}
            placeholder="پسورد را وارد کنید..."
            className={`w-full bg-white/5 border rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/25 outline-none pr-10 transition-colors ${err ? "border-red-500" : "border-white/15 focus:border-cyan-500/50"}`}
          />
          <button onClick={() => setShow(v => !v)} data-remote className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60">
            {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        {err && <p className="text-red-400 text-xs -mt-2">پسورد اشتباه است / Wrong password</p>}
        <button onClick={check} data-remote
          className="w-full bg-cyan-600 hover:bg-cyan-500 py-3 rounded-xl font-semibold text-sm text-white transition-colors">
          ورود / Unlock
        </button>
      </div>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────
export default function Settings() {
  const navRef = useRef(null);
  useRemoteNav(navRef, "button, a, select, [data-remote], [tabindex]:not([tabindex='-1'])");
  const { user, logout } = useAuth();
  const { tab: routeTab } = useParams();
  const navigate = useNavigate();
  const fromTV = new URLSearchParams(window.location.search).get("from") === "tv";
  const activeTab = routeTab || (fromTV ? "playlists" : "account");
  const [isAdmin, setIsAdmin] = useState(() => user?.role === "admin");
  const [currentUser, setCurrentUser] = useState(null);
  const [unlocked, setUnlocked] = useState(() => !localStorage.getItem("ayeneh_settings_pw"));

  const [settings, setSettings] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
  });
  const get = (key, def) => settings[key] !== undefined ? settings[key] : def;
  const set = (key, value) => {
    // Optimistic: update the UI state immediately from the latest state (avoids
    // stale-closure races on rapid toggles), then persist — the UI reflects the
    // change before any storage/DB write confirmation.
    setSettings((prev) => {
      const updated = { ...prev, [key]: value };
      localStorage.setItem("ayeneh_settings", JSON.stringify(updated));
      window.dispatchEvent(new Event("ayeneh-settings-changed"));
      return updated;
    });
  };

  // Listen for settings changes from other components (e.g., language toggle in other pages)
  useEffect(() => {
    const onSettingsChanged = () => {
      try { setSettings(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}")); } catch {}
    };
    window.addEventListener("ayeneh-settings-changed", onSettingsChanged);
    return () => window.removeEventListener("ayeneh-settings-changed", onSettingsChanged);
  }, []);

  const lang = get("language", "fa");
  const isFA = lang === "fa";
  const t = T[isFA ? "fa" : "en"];
  const rtl = isFA || get("rtl", false);

  // Channel number editor (admin)
  const [channelsForEdit, setChannelsForEdit] = useState([]);

  // Account
  const [deleteConfirmText, setDeleteConfirmText] = useState("");
  const [deleteStatus, setDeleteStatus] = useState(null); // null | "loading" | "success" | "error"
  const [deleteErrorMsg, setDeleteErrorMsg] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Cache
  const [cacheCleared, setCacheCleared] = useState(false);
  const [showBgPicker, setShowBgPicker] = useState(false);

  // Security
  const [secPwInput, setSecPwInput] = useState("");
  const [secNewPw, setSecNewPw] = useState("");
  const [secConfirmPw, setSecConfirmPw] = useState("");
  const [secShowPw, setSecShowPw] = useState(false);
  const [secMsg, setSecMsg] = useState(null); // {type, text}
  const [savedPw, setSavedPw] = useState(() => localStorage.getItem("ayeneh_settings_pw") || "");
  const [removePwInput, setRemovePwInput] = useState("");
  const [removeMsg, setRemoveMsg] = useState(null);
  const [secTab, setSecTab] = useState("add");

  // When password is removed, auto-unlock
  useEffect(() => {
    if (!savedPw) setUnlocked(true);
  }, [savedPw]);

  useEffect(() => {
    base44.auth.me()
      .then((u) => { setCurrentUser(u); if (u?.role === "admin") setIsAdmin(true); })
      .catch(() => {});
  }, []);

  // TV remote: Back key returns to main menu
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        navigate("/");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  // Apply color theme + font size globally
  useEffect(() => {
    const theme = get("colorTheme", "default");
    const fontScale = get("fontSize", "medium");
    const root = document.documentElement;
    const themes = {
      default: { primary: "272 70% 55%", accent: "196 90% 50%", ring: "272 70% 55%" },
      green:   { primary: "142 71% 45%", accent: "142 71% 45%", ring: "142 71% 45%" },
      orange:  { primary: "25 95% 55%",  accent: "25 95% 55%",  ring: "25 95% 55%" },
      pink:    { primary: "330 81% 60%", accent: "330 81% 60%", ring: "330 81% 60%" },
      blue:    { primary: "217 91% 60%", accent: "217 91% 60%", ring: "217 91% 60%" },
    };
    const th = themes[theme] || themes.default;
    root.style.setProperty("--primary", th.primary);
    root.style.setProperty("--accent", th.accent);
    root.style.setProperty("--ring", th.ring);
    // On TV (large screen), use larger font defaults for 10-foot viewing distance
    const isTVScreen = window.innerWidth >= 1200;
    const sizes = isTVScreen
      ? { small: "16px", medium: "20px", large: "22px", xlarge: "24px" }
      : { small: "14px", medium: "16px", large: "18px", xlarge: "20px" };
    root.style.fontSize = sizes[fontScale] || (isTVScreen ? "20px" : "16px");
  }, [settings.colorTheme, settings.fontSize]);

  // Extend display into camera cutout — apply viewport-fit=cover
  useEffect(() => {
    const meta = document.querySelector('meta[name="viewport"]');
    if (!meta) return;
    const base = meta.getAttribute("content") || "";
    if (get("extendCutout", true)) {
      if (!base.includes("viewport-fit=cover")) meta.setAttribute("content", base + ", viewport-fit=cover");
    } else {
      meta.setAttribute("content", base.replace(/,?\s*viewport-fit=cover/g, ""));
    }
  }, [settings.extendCutout]);

  // Landscape orientation lock (best-effort; may require fullscreen)
  // Disabled on small mobile screens — they are always portrait.
  useEffect(() => {
    try {
      const isSmallScreen = window.innerWidth < 768;
      if (isSmallScreen) {
        // Small mobiles: always portrait, never landscape
        if (screen.orientation && screen.orientation.lock) screen.orientation.lock("portrait").catch(() => {});
        return;
      }
      if (get("landscape", false)) {
        if (screen.orientation && screen.orientation.lock) screen.orientation.lock("landscape").catch(() => {});
      } else {
        if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
      }
    } catch {}
  }, [settings.landscape]);

  useEffect(() => {
    if (activeTab === "manage_channels") {
      try {
        const cached = JSON.parse(localStorage.getItem("ayeneh_channels_cache") || "[]");
        setChannelsForEdit(cached);
      } catch { setChannelsForEdit([]); }
    }
  }, [activeTab]);

  const handleSignInGoogle = () => {
    base44.auth.redirectToLogin(window.location.href);
  };

  const handleSignOut = () => {
    logout(true);
  };

  const handleDeleteAccount = async () => {
    setDeleteStatus("loading");
    setDeleteErrorMsg(null);
    try {
      await base44.functions.invoke("deleteAccount", {});
      ["ayeneh_favorites", "ayeneh_locked", "ayeneh_channels_cache",
       "ayeneh_last_channel", "ayeneh_settings", "ayeneh_playlists"].forEach(k => localStorage.removeItem(k));
      setDeleteStatus("success");
      setTimeout(() => { logout(true); }, 2000);
    } catch (e) {
      setDeleteStatus("error");
      setDeleteErrorMsg(e?.message || t.deleteFail);
    }
  };

  const handleClearCache = () => {
    ["ayeneh_channels_cache", "ayeneh_last_channel"].forEach(k => localStorage.removeItem(k));
    idbSet("channels", "all", []);
    idbSet("meta", "channels_updated_at", 0);
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 2000);
  };

  const handleSaveChannelOrder = (newList) => {
    try { localStorage.setItem("ayeneh_channels_cache", JSON.stringify(newList)); } catch {}
    setChannelsForEdit(newList);
  };

  const tabs = [
    { id: "account",  label: t.account,  icon: <User className="w-4 h-4" /> },
    { id: "general",  label: t.general,  icon: <Monitor className="w-4 h-4" /> },
    { id: "datetime", label: isFA ? "تاریخ و آب‌وهوا" : "Date & Weather", icon: <Cloud className="w-4 h-4" /> },
    { id: "player",   label: t.player,   icon: <Tv className="w-4 h-4" /> },
    { id: "offline",   label: isFA ? "آفلاین" : "Offline", icon: <Download className="w-4 h-4" /> },
    { id: "performance", label: t.performance, icon: <Zap className="w-4 h-4" /> },
    { id: "language", label: t.language, icon: <Globe className="w-4 h-4" /> },
    ...(isAdmin ? [
      { id: "wallpaper", label: isFA ? "پس‌زمینه" : "Wallpaper", icon: <ImageIcon className="w-4 h-4" /> },
      { id: "playlists", label: t.playlists, icon: <Plus className="w-4 h-4" /> },
      { id: "manage_channels", label: isFA ? "مدیریت کانال‌ها" : "Channels", icon: <List className="w-4 h-4" /> },
      { id: "auth_playlists", label: isFA ? "اشتراکی" : "Subscriptions", icon: <KeyRound className="w-4 h-4" /> },
      { id: "user_stats", label: t.userStats, icon: <Users className="w-4 h-4" /> },
      { id: "send_notification", label: isFA ? "پیام همگانی" : "Broadcast", icon: <Bell className="w-4 h-4" /> },
      { id: "security_logs", label: isFA ? "لاگ امنیتی" : "Security Logs", icon: <Shield className="w-4 h-4" /> },
    ] : []),
    { id: "security", label: isFA ? "امنیت" : "Security", icon: <Shield className="w-4 h-4" /> },
    { id: "about",    label: t.about,    icon: <Info className="w-4 h-4" /> },
  ];

  const visibleTabs = fromTV ? tabs.filter(t => ["playlists", "auth_playlists"].includes(t.id)) : tabs;

  if (!unlocked) return <PasswordGate onUnlock={() => setUnlocked(true)} />;

  return (
    <div ref={navRef} className="h-[100dvh] text-white flex flex-col overflow-hidden" dir={rtl ? "rtl" : "ltr"}
      style={{ background: "radial-gradient(ellipse 80% 60% at 30% 0%, rgba(168,85,247,0.08) 0%, transparent 50%), radial-gradient(ellipse 60% 50% at 80% 100%, rgba(0,204,255,0.06) 0%, transparent 50%), #0a0d16" }}>
      <style>{`
        .settings-page button:focus,
        .settings-page select:focus,
        .settings-page input:focus,
        .settings-page a:focus,
        .settings-page [data-remote]:focus {
          outline: 3px solid rgb(34,211,238) !important;
          outline-offset: 3px !important;
          box-shadow: 0 0 22px rgba(34,211,238,0.6) !important;
          z-index: 5;
          position: relative;
        }
        .settings-page .settings-row:focus-within {
          background: rgba(34,211,238,0.06) !important;
          border-color: rgba(34,211,238,0.25) !important;
        }
      `}</style>
      {/* Header — glassmorphism with Asemanak branding */}
      <NavHeader title={t.settings} rtl={rtl} />

      <div className={`settings-page flex flex-1 overflow-hidden ${rtl ? "flex-row-reverse" : ""}`}>
        {/* Sidebar — professional glassmorphism with refined active states */}
        <div className={`hidden md:flex w-52 flex-col pt-4 flex-shrink-0 ${rtl ? "border-l" : "border-r"}`}
          style={{ background: "rgba(0,0,0,0.3)", backdropFilter: "blur(12px)", borderColor: "rgba(255,255,255,0.06)" }}>
          {visibleTabs.map((tab) => {
            const selected = activeTab === tab.id;
            return (
              <button key={tab.id} data-remote onClick={() => navigate(`/Settings/${tab.id}`)}
                className={`flex items-center gap-3 mx-2 px-3 py-3 rounded-xl text-sm font-semibold transition-all outline-none mb-1 ${rtl ? "flex-row-reverse text-right" : "text-left"} ${
                  selected ? "text-white" : "text-white/45 hover:text-white/80 hover:bg-white/5"}`}
                style={selected ? {
                  background: "linear-gradient(135deg, rgba(224,56,246,0.15), rgba(107,84,255,0.15))",
                  border: "1px solid rgba(107,84,255,0.3)",
                  boxShadow: "0 4px 16px rgba(107,84,255,0.15), inset 0 1px 0 rgba(255,255,255,0.06)",
                } : { border: "1px solid transparent" }}>
                <span className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all flex-shrink-0 ${selected ? "text-white" : "text-white/40"}`}
                  style={selected ? { background: 'linear-gradient(135deg, #E038F6, #6B54FF)', boxShadow: '0 2px 10px rgba(107,84,255,0.4)' } : { background: 'rgba(255,255,255,0.05)' }}>
                  {tab.icon}
                </span>
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
          <div className="flex-1" />
          <div className="px-4 py-3 text-center">
            <span className="text-white/60 text-sm font-bold tracking-widest">ASEMANAK TV</span>
          </div>
        </div>

        {/* Mobile tab strip — horizontally scrollable icon+label tabs (replaces sidebar on phones) */}
        <div className="md:hidden flex items-center gap-1 overflow-x-auto px-2 py-2 flex-shrink-0"
          style={{ background: "rgba(0,0,0,0.3)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          {visibleTabs.map((tab) => {
            const selected = activeTab === tab.id;
            return (
              <button key={tab.id} data-remote onClick={() => navigate(`/Settings/${tab.id}`)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all flex-shrink-0 ${
                  selected ? "text-white" : "text-white/45"}`}
                style={selected ? {
                  background: "linear-gradient(135deg, rgba(224,56,246,0.15), rgba(107,84,255,0.15))",
                  border: "1px solid rgba(107,84,255,0.3)",
                } : { border: "1px solid transparent" }}>
                {tab.icon}
                <span className="whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 min-h-0 overflow-y-auto px-6 py-5 pb-[calc(2rem_+_env(safe-area-inset-bottom))]">

          {/* ── ACCOUNT ── */}
          {activeTab === "account" && (
            <div className="max-w-lg space-y-6">
              <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>{t.account}</h2>

              {currentUser ? (
                <div className="rounded-2xl overflow-hidden" style={{ background: "linear-gradient(160deg, rgba(20,14,35,0.6), rgba(10,8,20,0.7))", border: "1px solid rgba(255,255,255,0.08)", boxShadow: "0 8px 32px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.04)" }}>
                  {/* Profile card — gradient avatar */}
                  <div className="flex items-center gap-4 px-5 py-5">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #E038F6, #6B54FF)", boxShadow: "0 4px 16px rgba(107,84,255,0.35)", border: "1px solid rgba(255,255,255,0.15)" }}>
                      <User className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-bold text-base truncate">{currentUser.full_name || "User"}</p>
                      <p className="text-white/50 text-xs truncate mt-0.5">{currentUser.email}</p>
                      <span className="inline-block mt-1.5 text-sm font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider" style={{ background: "rgba(107,84,255,0.2)", color: "#c4b5fd", border: "1px solid rgba(107,84,255,0.3)" }}>
                        {currentUser.role || "user"}
                      </span>
                    </div>
                  </div>
                  <div className="border-t border-white/10" />
                  {/* Sign out */}
                  <button data-remote onClick={handleSignOut}
                    className="w-full flex items-center gap-3 px-5 py-4 text-white/70 hover:text-white hover:bg-white/5 transition-colors">
                    <LogOut className="w-4 h-4 text-white/50" />
                    <span className="text-sm">{t.signOut}</span>
                  </button>
                  <div className="border-t border-white/10" />
                  {/* Delete account */}
                  <button data-remote onClick={() => { setDeleteConfirmText(""); setDeleteStatus(null); setShowDeleteConfirm(true); }}
                    className="w-full flex items-center gap-3 px-5 py-4 text-red-400/80 hover:text-red-400 hover:bg-red-500/5 transition-colors">
                    <Trash2 className="w-4 h-4" />
                    <div className={rtl ? "text-right" : ""}>
                      <p className="text-sm font-medium">{t.deleteAccount}</p>
                      <p className="text-xs text-red-400/50">{t.deleteAccountDesc}</p>
                    </div>
                  </button>
                </div>
              ) : (
                <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
                  <div className="px-5 py-8 flex flex-col items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-white/5 border-2 border-white/10 flex items-center justify-center">
                      <User className="w-8 h-8 text-white/30" />
                    </div>
                    <p className="text-white/50 text-sm">{t.notSignedIn}</p>
                    <button data-remote onClick={handleSignInGoogle}
                      className="flex items-center gap-3 bg-white text-gray-900 font-semibold px-6 py-3 rounded-xl hover:bg-gray-100 transition-colors shadow-lg">
                      <svg viewBox="0 0 24 24" width="20" height="20">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                      {t.signInGoogle}
                    </button>
                  </div>
                </div>
              )}

              <DeleteAccountModal
                open={showDeleteConfirm}
                loading={deleteStatus === "loading"}
                error={deleteStatus === "error" ? (deleteErrorMsg || t.deleteFail) : null}
                success={deleteStatus === "success" ? t.deleteSuccess : null}
                requireText="DELETE"
                onClose={() => { setShowDeleteConfirm(false); setDeleteConfirmText(""); setDeleteStatus(null); }}
                onConfirm={handleDeleteAccount}
              />

              {/* Feedback & Comments */}
              <FeedbackSection isFA={isFA} rtl={rtl} />
            </div>
          )}

          {/* ── GENERAL ── */}
          {activeTab === "general" && (
            <div className="max-w-lg">
              <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest mb-5 ${rtl ? "text-right" : ""}`}>{t.general}</h2>
              <Row label={t.loadLastChannel} description={t.loadLastChannelDesc} rtl={rtl}><Toggle value={get("loadLastChannel", true)} onChange={v => set("loadLastChannel", v)} /></Row>
              <Row label={t.startOnBoot} description={t.startOnBootDesc} rtl={rtl}><Toggle value={get("startOnBoot", false)} onChange={v => set("startOnBoot", v)} /></Row>
              <Row label={t.extendCutout} description={t.extendCutoutDesc} rtl={rtl}><Toggle value={get("extendCutout", false)} onChange={v => set("extendCutout", v)} /></Row>
              <Row label={t.landscape} description={t.landscapeDesc} rtl={rtl}><Toggle value={get("landscape", false)} onChange={v => set("landscape", v)} /></Row>
              <Row label={t.pip} description={t.pipDesc} rtl={rtl}><Toggle value={get("pip", false)} onChange={v => set("pip", v)} /></Row>
              <Row label={t.smartControls} description={t.smartControlsDesc} rtl={rtl}><Toggle value={get("smartControls", true)} onChange={v => set("smartControls", v)} /></Row>
              <Row label={t.bgBlur} description={t.bgBlurDesc} rtl={rtl}><Toggle value={get("bgBlur", true)} onChange={v => set("bgBlur", v)} /></Row>
              <Row label={t.showNumbers} description={t.showNumbersDesc} rtl={rtl}><Toggle value={get("showNumbers", false)} onChange={v => set("showNumbers", v)} /></Row>
              <Row label={t.autoHideList} description={t.autoHideListDesc} rtl={rtl}><Toggle value={get("autoHideList", false)} onChange={v => set("autoHideList", v)} /></Row>
              <Row label={t.darkTheme} description={t.darkThemeDesc} rtl={rtl}><Toggle value={get("darkTheme", true)} onChange={v => set("darkTheme", v)} /></Row>
              <Row label={t.navSound} description={t.navSoundDesc} rtl={rtl}><Toggle value={get("navSound", true)} onChange={v => set("navSound", v)} /></Row>

              {/* Refresh app — clears caches and reloads */}
              <div className="py-4 border-b border-white/10">
                <button data-remote onClick={() => { try { localStorage.removeItem("ayeneh_channels_cache"); } catch {} window.location.reload(); }}
                  className={`w-full flex items-center gap-3 text-cyan-300 hover:text-cyan-200 transition-colors ${rtl ? "flex-row-reverse" : ""}`}>
                  <RefreshCw className="w-4 h-4 flex-shrink-0" />
                  <div className={rtl ? "text-right" : ""}>
                    <p className="text-sm font-medium">{rtl ? "بازنشانی برنامه" : "Refresh App"}</p>
                    <p className="text-xs text-white/40 mt-0.5">{rtl ? "پاک کردن کش و بارگذاری مجدد" : "Clear cache and reload"}</p>
                  </div>
                </button>
              </div>

              {/* Color Theme */}
              <div className="py-4 border-b border-white/10">
                <div className={`flex items-center justify-between mb-3 ${rtl ? "flex-row-reverse" : ""}`}>
                  <div className={rtl ? "pl-4 text-right" : "pr-4"}>
                    <p className="text-sm text-white font-medium flex items-center gap-1.5"><Palette className="w-3.5 h-3.5" />{t.colorTheme}</p>
                    <p className="text-xs text-white/40 mt-0.5">{t.colorThemeDesc}</p>
                  </div>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { id: "default", label: isFA ? "پیش‌فرض" : "Default", color: "rgb(168,85,247)" },
                    { id: "green", label: isFA ? "سبز" : "Green", color: "rgb(34,197,94)" },
                    { id: "orange", label: isFA ? "نارنجی" : "Orange", color: "rgb(249,115,22)" },
                    { id: "pink", label: isFA ? "صورتی" : "Pink", color: "rgb(236,72,153)" },
                    { id: "blue", label: isFA ? "آبی" : "Blue", color: "rgb(59,130,246)" },
                  ].map(opt => (
                    <button key={opt.id} data-remote onClick={() => set("colorTheme", opt.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition-all ${get("colorTheme", "default") === opt.id ? "border-white/40 bg-white/10" : "border-white/10 hover:border-white/20"}`}>
                      <span className="w-4 h-4 rounded-full flex-shrink-0" style={{ background: opt.color }} />
                      <span className="text-xs text-white/80">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Size */}
              <SelectRow label={t.fontSize} description={t.fontSizeDesc} value={get("fontSize", "medium")}
                options={[{ value: "small", label: isFA ? "کوچک" : "Small" }, { value: "medium", label: isFA ? "متوسط" : "Medium" }, { value: "large", label: isFA ? "بزرگ" : "Large" }, { value: "xlarge", label: isFA ? "خیلی بزرگ" : "X-Large" }]}
                onChange={v => set("fontSize", v)} rtl={rtl} />

              {/* Minimal info on switch */}
              <Row label={t.minimalInfo} description={t.minimalInfoDesc} rtl={rtl}><Toggle value={get("minimalInfo", false)} onChange={v => set("minimalInfo", v)} /></Row>
              <Row label={t.reverseChannelNav} description={t.reverseChannelNavDesc} rtl={rtl}><Toggle value={get("reverseChannelNav", false)} onChange={v => set("reverseChannelNav", v)} /></Row>
              <Row label={t.channelListRight} description={t.channelListRightDesc} rtl={rtl}><Toggle value={get("channelListRight", false)} onChange={v => set("channelListRight", v)} /></Row>

              {/* Startup sound toggle + admin-only sound selector */}
              <Row label={t.startupSound} description={t.startupSoundDesc} rtl={rtl}><Toggle value={get("startupSound", true)} onChange={v => set("startupSound", v)} /></Row>
              {isAdmin && (
                <SelectRow label={t.startupSoundSelect} description={t.startupSoundSelectDesc} value={get("startupSoundType", "default")}
                  options={[
                    { value: "default", label: t.soundDefault },
                    { value: "cinematic", label: t.soundCinematic },
                    { value: "soft", label: t.soundSoft },
                    { value: "epic", label: t.soundEpic },
                  ]}
                  onChange={v => set("startupSoundType", v)} rtl={rtl} />
              )}

              {/* Clock settings */}
              <SelectRow label={isFA ? "منطقه زمانی ساعت" : "Clock Timezone"} description={isFA ? "انتخاب منطقه زمانی ساعت دیجیتال" : "Digital clock timezone"} value={get("clockTimezone", "Asia/Tehran")}
                options={TIMEZONES.map(tz => ({ value: tz.value, label: isFA ? tz.labelFa : tz.labelEn }))}
                onChange={v => set("clockTimezone", v)} rtl={rtl} />
              <SelectRow label={isFA ? "فرمت ساعت" : "Clock Format"} description={isFA ? "۱۲ یا ۲۴ ساعته" : "12 or 24 hour"} value={get("clockFormat", "24")}
                options={[{ value: "24", label: isFA ? "۲۴ ساعته" : "24-hour" }, { value: "12", label: isFA ? "۱۲ ساعته" : "12-hour" }]}
                onChange={v => set("clockFormat", v)} rtl={rtl} />
              <SelectRow label={isFA ? "تنظیم ساعت (اختلاف ساعت)" : "Clock Offset (hours)"} description={isFA ? "اختلاف ساعت برای تنظیم دستی شماره ساعت" : "Manual hour offset to adjust the clock"} value={String(get("clockOffset", 0))}
                options={Array.from({ length: 25 }, (_, i) => { const v = i - 12; return { value: String(v), label: (v > 0 ? "+" : "") + v }; })}
                onChange={v => set("clockOffset", Number(v))} rtl={rtl} />
              <SelectRow label={isFA ? "تنظیم دقیقه (اختلاف دقیقه)" : "Clock Offset (minutes)"} description={isFA ? "اختلاف دقیقه برای تنظیم دقیقه ساعت" : "Manual minute offset to adjust the clock"} value={String(get("clockOffsetMinutes", 0))}
                options={Array.from({ length: 60 }, (_, i) => { const v = i; return { value: String(v), label: (v > 0 ? "+" : "") + v }; })}
                onChange={v => set("clockOffsetMinutes", Number(v))} rtl={rtl} />
              <SelectRow label={isFA ? "تنظیم ثانیه (اختلاف ثانیه)" : "Clock Offset (seconds)"} description={isFA ? "اختلاف ثانیه برای تنظیم دقیق ثانیه ساعت" : "Manual second offset to adjust the clock"} value={String(get("clockOffsetSeconds", 0))}
                options={Array.from({ length: 60 }, (_, i) => { const v = i; return { value: String(v), label: (v > 0 ? "+" : "") + v }; })}
                onChange={v => set("clockOffsetSeconds", Number(v))} rtl={rtl} />
            </div>
          )}

          {/* ── DATE / TIME / WEATHER ── */}
          {activeTab === "datetime" && (
            <DateTimeWeatherSection get={get} set={set} isFA={isFA} rtl={rtl} />
          )}

          {/* ── WALLPAPER (admin only) ── */}
          {activeTab === "wallpaper" && (
            <div className="max-w-lg space-y-5">
              <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest mb-4 ${rtl ? "text-right" : ""}`}>
                {isFA ? "پس‌زمینه و اسلایدشو" : "Wallpaper & Slideshow"}
              </h2>
              <div className="rounded-2xl border border-white/10 p-5" style={{ background: "rgba(255,255,255,0.04)" }}>
                <div className="flex items-center gap-3 mb-2">
                  <ImageIcon className="w-5 h-5 text-purple-400" />
                  <p className="text-white font-semibold text-sm">{isFA ? "انتخاب پس‌زمینه‌های منوی اصلی" : "Choose home menu wallpapers"}</p>
                </div>
                <p className="text-white/40 text-xs mb-4">
                  {isFA ? "پس‌زمینه‌های انتخاب‌شده به‌صورت چرخشی در صفحه اصلی نمایش داده می‌شوند." : "Selected wallpapers rotate on the home screen."}
                </p>
                <button onClick={() => setShowBgPicker(true)}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
                  style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 15px rgba(123,44,191,0.35)" }}>
                  <ImageIcon className="w-4 h-4" /> {isFA ? "انتخاب پس‌زمینه‌ها" : "Choose wallpapers"}
                </button>
              </div>
              {showBgPicker && <BackgroundPicker isFa={isFA} onClose={() => setShowBgPicker(false)} />}
            </div>
          )}

          {/* ── PLAYER ── */}
          {activeTab === "player" && (
            <div className="max-w-lg">
              <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest mb-5 ${rtl ? "text-right" : ""}`}>{t.player}</h2>
              <SelectRow label={t.bufferSize} description={t.bufferSizeDesc} value={get("buffer", "15 s")} options={["5 s","10 s","15 s","30 s","60 s"]} onChange={v => set("buffer", v)} rtl={rtl} />
              <SelectRow label={t.skipStep} description={t.skipStepDesc} value={get("skipStep", "30 s")} options={["10 s","15 s","30 s","60 s","120 s"]} onChange={v => set("skipStep", v)} rtl={rtl} />
              <Row label={t.userAgent} description={t.userAgentDesc} rtl={rtl}>
                <input value={get("userAgent", "")} onChange={e => set("userAgent", e.target.value)} placeholder="Mozilla/5.0 ..." className="bg-white/10 border border-white/10 text-white text-xs rounded-lg px-3 py-1.5 outline-none w-52" />
              </Row>
              <SelectRow label={t.videoQuality} description={t.videoQualityDesc} value={get("quality", "Auto")} options={["Auto","1080p","720p","480p","360p"]} onChange={v => set("quality", v)} rtl={rtl} />
              <SelectRow label={t.aspectRatio} description={t.aspectRatioDesc} value={get("aspectRatio", "16:9")} options={["16:9","4:3","21:9","Fill","Auto"]} onChange={v => set("aspectRatio", v)} rtl={rtl} />
              <SelectRow label={isFA ? "اندازه نمایش" : "Display Size"} description={isFA ? "حالت نمایش پیش‌فرض ویدیو" : "Default video display mode"} value={get("displaySize", "full")}
                options={[{ value: "full", label: isFA ? "تمام صفحه" : "Full Screen" }, { value: "large", label: isFA ? "بزرگ" : "Large" }, { value: "medium", label: isFA ? "متوسط" : "Medium" }, { value: "small", label: isFA ? "کوچک" : "Small" }]}
                onChange={v => set("displaySize", v)} rtl={rtl} />
              {isAdmin && (
                <SelectRow label={t.coverDuration} description={t.coverDurationDesc} value={get("coverDuration", "3")} options={[{value:"2",label:"2s"},{value:"3",label:"3s"},{value:"5",label:"5s"},{value:"8",label:"8s"},{value:"10",label:"10s"},{value:"15",label:"15s"}]} onChange={v => set("coverDuration", v)} rtl={rtl} />
              )}
              <Row label={t.autoPlay} description={t.autoPlayDesc} rtl={rtl}><Toggle value={get("autoPlay", true)} onChange={v => set("autoPlay", v)} /></Row>
              <Row label={t.hwAccel} description={t.hwAccelDesc} rtl={rtl}><Toggle value={get("hwAccel", true)} onChange={v => set("hwAccel", v)} /></Row>
              <Row label={t.autoReconnect} description={t.autoReconnectDesc} rtl={rtl}><Toggle value={get("autoReconnect", true)} onChange={v => set("autoReconnect", v)} /></Row>
            </div>
          )}

          {/* ── OFFLINE MANAGER ── */}
          {activeTab === "offline" && (
            <OfflineManagerSection isFA={isFA} rtl={rtl} />
          )}

          {/* ── PERFORMANCE ── */}
          {activeTab === "performance" && (
            <div className="max-w-lg">
              <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest mb-5 ${rtl ? "text-right" : ""}`}>{t.performance}</h2>

              <Row label={t.lowBandwidth} description={t.lowBandwidthDesc} rtl={rtl}>
                <Toggle value={get("lowBandwidth", false)} onChange={v => set("lowBandwidth", v)} />
              </Row>
              <Row label={t.hlsLowLatency} description={t.hlsLowLatencyDesc} rtl={rtl}>
                <Toggle value={get("hlsLowLatency", true)} onChange={v => set("hlsLowLatency", v)} />
              </Row>
              <Row label={t.cacheChannels} description={t.cacheChannelsDesc} rtl={rtl}>
                <Toggle value={get("cacheChannels", true)} onChange={v => set("cacheChannels", v)} />
              </Row>
              <SelectRow label={t.maxRetries} description={t.maxRetriesDesc}
                value={get("maxRetries", "3")} options={["1","2","3","5","10"]}
                onChange={v => set("maxRetries", v)} rtl={rtl} />

              {/* Clear Cache button */}
              <div className={`flex items-center justify-between py-4 border-b border-white/10 ${rtl ? "flex-row-reverse" : ""}`}>
                <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
                  <p className="text-sm text-white font-medium">{t.clearCache}</p>
                  <p className="text-xs text-white/40 mt-0.5">ayeneh_channels_cache</p>
                </div>
                <button data-remote onClick={handleClearCache}
                  className={`flex items-center gap-2 text-xs px-4 py-2 rounded-lg border transition-colors ${
                    cacheCleared ? "border-green-500/40 text-green-400 bg-green-500/10" : "border-white/20 text-white/70 hover:text-white hover:border-white/40"
                  }`}>
                  {cacheCleared ? <CheckCircle className="w-3.5 h-3.5" /> : <RefreshCw className="w-3.5 h-3.5" />}
                  {cacheCleared ? t.clearCacheSuccess : t.clearCache}
                </button>
              </div>

              {/* Info box for weak internet */}
              <div className="mt-6 rounded-xl p-4 border border-cyan-500/20" style={{ background: "rgba(6,182,212,0.08)" }}>
                <div className="flex items-center gap-2 mb-2">
                  <Wifi className="w-4 h-4 text-cyan-400" />
                  <p className="text-cyan-400 text-xs font-bold uppercase tracking-wide">Weak Internet Tips</p>
                </div>
                <ul className="text-white/60 text-xs space-y-1.5">
                  <li>• Enable <strong className="text-white/80">Low Bandwidth Mode</strong> for compressed streams</li>
                  <li>• Enable <strong className="text-white/80">Cache channel list</strong> for offline access</li>
                  <li>• Set <strong className="text-white/80">Max Retries</strong> to 5+ for unstable connections</li>
                  <li>• Disable <strong className="text-white/80">Low Latency</strong> to improve buffering</li>
                  <li>• Set <strong className="text-white/80">Buffer Size</strong> to 30s or 60s in Player settings</li>
                </ul>
              </div>
            </div>
          )}

          {/* ── SEND NOTIFICATION ── */}
          {activeTab === "send_notification" && (
            <SendNotificationSection isFA={isFA} rtl={rtl} />
          )}

          {/* ── SECURITY LOGS ── */}
          {activeTab === "security_logs" && (
            <SecurityLogsView isFA={isFA} rtl={rtl} />
          )}

          {/* ── LANGUAGE ── */}
          {activeTab === "language" && (
            <div className="max-w-lg">
              <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest mb-5 ${rtl ? "text-right" : ""}`}>{t.language}</h2>
              <SelectRow label={t.appLanguage} value={get("language", "en")}
                options={[{ value: "en", label: "English" }, { value: "fa", label: "فارسی" }]}
                onChange={v => set("language", v)} rtl={rtl} />
              <SelectRow label={t.epgLanguage} value={get("epgLanguage", "en")}
                options={[{ value: "en", label: "English" }, { value: "fa", label: "فارسی" }]}
                onChange={v => set("epgLanguage", v)} rtl={rtl} />
              <Row label={t.showFarsiNames} description={t.showFarsiNamesDesc} rtl={rtl}><Toggle value={get("showFarsiNames", true)} onChange={v => set("showFarsiNames", v)} /></Row>
              <Row label={t.rtl} description={t.rtlDesc} rtl={rtl}><Toggle value={get("rtl", false)} onChange={v => set("rtl", v)} /></Row>

              {/* Subtitles & Dubbing */}
              <div className="mt-6">
                <h3 className={`text-xs font-bold text-cyan-400/60 uppercase tracking-widest mb-3 flex items-center gap-1.5 ${rtl ? "text-right" : ""}`}>
                  <Subtitles className="w-3.5 h-3.5" />{isFA ? "زیرنویس" : "Subtitles"}
                </h3>

                {/* Subtitle toggle */}
                <Row label={t.subtitleEnabled} description={t.subtitleEnabledDesc} rtl={rtl}>
                  <Toggle value={get("subtitleEnabled", false)} onChange={v => set("subtitleEnabled", v)} />
                </Row>
                {get("subtitleEnabled", false) && (
                  <SelectRow label={t.subtitleLang} value={get("subtitleLang", "en")}
                    options={[
                      { value: "en", label: isFA ? "انگلیسی → فارسی" : "English → Farsi" },
                      { value: "hi", label: isFA ? "هندی → فارسی" : "Hindi → Farsi" },
                      { value: "tr", label: isFA ? "ترکی → فارسی" : "Turkish → Farsi" },
                    ]}
                    onChange={v => set("subtitleLang", v)} rtl={rtl} />
                )}

                <p className="text-[11px] text-white/60 mt-3 flex items-start gap-1">
                  ⓘ {t.subDubNote}
                </p>
              </div>
            </div>
          )}

          {/* ── PLAYLISTS ── */}
          {activeTab === "playlists" && (
            <PlaylistsSection isFA={isFA} rtl={rtl} />
          )}

          {/* ── MANAGE CHANNELS ── */}
          {activeTab === "manage_channels" && (
            <div className="max-w-2xl space-y-6">
              <AddChannelTab isFA={isFA} rtl={rtl} />
              <div className="border-t border-white/10 pt-5">
                <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest mb-3 ${rtl ? "text-right" : ""}`}>
                  {isFA ? "ترتیب کانال‌ها (ریموت)" : "Reorder Channels (Remote)"}
                </h2>
                <ChannelNumberEditor channels={channelsForEdit} onSave={handleSaveChannelOrder} t={t} isFA={isFA} />
              </div>
            </div>
          )}

          {/* ── AUTH PLAYLISTS (subscription with credentials) ── */}
          {activeTab === "auth_playlists" && (
            <div className="max-w-lg space-y-5">
              <AuthPlaylistSection isFA={isFA} rtl={rtl} />
            </div>
          )}

          {/* ── USER STATS ── */}
          {activeTab === "user_stats" && (
            <div className="max-w-2xl">
              <UserStatsSection isFA={isFA} />
            </div>
          )}

          {/* ── SECURITY ── */}
          {activeTab === "security" && (
            <div className="max-w-lg space-y-5">
              <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>
                {isFA ? "امنیت تنظیمات" : "Settings Security"}
              </h2>

                {/* Status */}
                <div className="rounded-2xl border overflow-hidden"
                  style={{ background: "rgba(255,255,255,0.04)", borderColor: savedPw ? "rgba(6,182,212,0.3)" : "rgba(255,255,255,0.1)" }}>
                  <div className="flex items-center gap-4 px-5 py-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${savedPw ? "bg-cyan-500/20" : "bg-white/5"}`}>
                      <Lock className={`w-5 h-5 ${savedPw ? "text-cyan-400" : "text-white/30"}`} />
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-semibold text-sm">
                        {savedPw ? (isFA ? "پسورد فعال است" : "Password Active") : (isFA ? "بدون پسورد" : "No Password Set")}
                      </p>
                      <p className="text-white/40 text-xs mt-0.5">
                        {savedPw ? (isFA ? "تنظیمات قفل است" : "Settings are locked") : (isFA ? "تنظیمات باز است" : "Settings are open")}
                      </p>
                    </div>
                    {savedPw && <span className="text-[10px] px-2 py-1 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">ON</span>}
                  </div>
                </div>

                {/* Sub-tabs */}
                <div className="flex rounded-xl overflow-hidden border border-white/10" style={{ background: "rgba(255,255,255,0.03)" }}>
                  {(!savedPw
                    ? [{ id: "add", label: isFA ? "افزودن پسورد" : "Add Password" }]
                    : [
                        { id: "change", label: isFA ? "تغییر پسورد" : "Change Password" },
                        { id: "delete", label: isFA ? "حذف پسورد" : "Delete Password" },
                      ]
                  ).map(st => (
                    <button key={st.id} data-remote onClick={() => setSecTab(st.id)}
                      className={`flex-1 py-2.5 text-xs font-semibold transition-colors ${secTab === st.id ? "bg-cyan-600/30 text-cyan-400" : "text-white/50 hover:text-white"}`}>
                      {st.label}
                    </button>
                  ))}
                </div>

                {/* Add password */}
                {(secTab === "add" && !savedPw) && (
                  <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <div className="px-5 py-4 border-b border-white/10 flex items-center gap-3">
                      <KeyRound className="w-4 h-4 text-cyan-400" />
                      <p className="text-white font-semibold text-sm">{isFA ? "تنظیم پسورد جدید" : "Set New Password"}</p>
                    </div>
                    <div className="px-5 py-4 space-y-3">
                      <div>
                        <label className="text-xs text-white/40 mb-1 block">{isFA ? "پسورد جدید" : "New Password"}</label>
                        <input type={secShowPw ? "text" : "password"} value={secNewPw} onChange={e => setSecNewPw(e.target.value)} placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
                      </div>
                      <div>
                        <label className="text-xs text-white/40 mb-1 block">{isFA ? "تکرار پسورد" : "Confirm Password"}</label>
                        <input type={secShowPw ? "text" : "password"} value={secConfirmPw} onChange={e => setSecConfirmPw(e.target.value)} placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
                      </div>
                      <button onClick={() => setSecShowPw(v => !v)} className="text-xs text-white/30 hover:text-white/60 flex items-center gap-1">
                        {secShowPw ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        {secShowPw ? (isFA ? "پنهان کردن" : "Hide") : (isFA ? "نمایش" : "Show")}
                      </button>
                      {secMsg && <p className={`text-xs ${secMsg.type === "success" ? "text-green-400" : "text-red-400"}`}>{secMsg.text}</p>}
                      <button onClick={() => {
                        if (!secNewPw) { setSecMsg({ type: "error", text: isFA ? "پسورد خالی است" : "Password is empty" }); return; }
                        if (secNewPw !== secConfirmPw) { setSecMsg({ type: "error", text: isFA ? "پسوردها مطابقت ندارند" : "Passwords do not match" }); return; }
                        localStorage.setItem("ayeneh_settings_pw", secNewPw);
                        setSavedPw(secNewPw); setSecNewPw(""); setSecConfirmPw("");
                        setSecMsg({ type: "success", text: isFA ? "پسورد ذخیره شد ✓" : "Password saved ✓" });
                        setTimeout(() => setSecMsg(null), 3000);
                      }} data-remote className="w-full bg-cyan-600 hover:bg-cyan-500 py-3 rounded-xl text-sm font-semibold text-white transition-colors">
                        {isFA ? "ذخیره پسورد" : "Save Password"}
                      </button>
                    </div>
                  </div>
                )}

                {/* Change password */}
                {(secTab === "change" && savedPw) && (
                  <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <div className="px-5 py-4 border-b border-white/10 flex items-center gap-3">
                      <KeyRound className="w-4 h-4 text-cyan-400" />
                      <p className="text-white font-semibold text-sm">{isFA ? "تغییر پسورد" : "Change Password"}</p>
                    </div>
                    <div className="px-5 py-4 space-y-3">
                      <div>
                        <label className="text-xs text-white/40 mb-1 block">{isFA ? "پسورد فعلی" : "Current Password"}</label>
                        <input type={secShowPw ? "text" : "password"} value={secPwInput} onChange={e => setSecPwInput(e.target.value)} placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
                      </div>
                      <div>
                        <label className="text-xs text-white/40 mb-1 block">{isFA ? "پسورد جدید" : "New Password"}</label>
                        <input type={secShowPw ? "text" : "password"} value={secNewPw} onChange={e => setSecNewPw(e.target.value)} placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
                      </div>
                      <div>
                        <label className="text-xs text-white/40 mb-1 block">{isFA ? "تکرار پسورد جدید" : "Confirm New Password"}</label>
                        <input type={secShowPw ? "text" : "password"} value={secConfirmPw} onChange={e => setSecConfirmPw(e.target.value)} placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
                      </div>
                      <button onClick={() => setSecShowPw(v => !v)} className="text-xs text-white/30 hover:text-white/60 flex items-center gap-1">
                        {secShowPw ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        {secShowPw ? (isFA ? "پنهان" : "Hide") : (isFA ? "نمایش" : "Show")}
                      </button>
                      {secMsg && <p className={`text-xs ${secMsg.type === "success" ? "text-green-400" : "text-red-400"}`}>{secMsg.text}</p>}
                      <button onClick={() => {
                        if (secPwInput !== savedPw) { setSecMsg({ type: "error", text: isFA ? "پسورد فعلی اشتباه است" : "Current password is wrong" }); return; }
                        if (!secNewPw) { setSecMsg({ type: "error", text: isFA ? "پسورد جدید خالی است" : "New password empty" }); return; }
                        if (secNewPw !== secConfirmPw) { setSecMsg({ type: "error", text: isFA ? "پسوردها مطابقت ندارند" : "Passwords do not match" }); return; }
                        localStorage.setItem("ayeneh_settings_pw", secNewPw);
                        setSavedPw(secNewPw); setSecPwInput(""); setSecNewPw(""); setSecConfirmPw("");
                        setSecMsg({ type: "success", text: isFA ? "پسورد تغییر کرد ✓" : "Password changed ✓" });
                        setTimeout(() => setSecMsg(null), 3000);
                      }} className="w-full bg-cyan-600 hover:bg-cyan-500 py-3 rounded-xl text-sm font-semibold text-white transition-colors">
                        {isFA ? "تغییر پسورد" : "Change Password"}
                      </button>
                    </div>
                  </div>
                )}

                {/* Delete password */}
                {(secTab === "delete" && savedPw) && (
                  <div className="rounded-2xl border border-red-500/20 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <div className="px-5 py-4 border-b border-red-500/20 flex items-center gap-3">
                      <Trash2 className="w-4 h-4 text-red-400" />
                      <p className="text-white font-semibold text-sm">{isFA ? "حذف پسورد" : "Delete Password"}</p>
                    </div>
                    <div className="px-5 py-4 space-y-3">
                      <p className="text-white/40 text-xs">{isFA ? "با حذف پسورد، تنظیمات بدون محافظت می‌شود." : "Removing password means anyone can access Settings."}</p>
                      <div>
                        <label className="text-xs text-white/40 mb-1 block">{isFA ? "پسورد فعلی را وارد کنید" : "Enter current password to confirm"}</label>
                        <input type="password" value={removePwInput} onChange={e => setRemovePwInput(e.target.value)}
                          placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-red-500/50" />
                      </div>
                      {removeMsg && <p className={`text-xs ${removeMsg.type === "success" ? "text-green-400" : "text-red-400"}`}>{removeMsg.text}</p>}
                      <button onClick={() => {
                        if (removePwInput !== savedPw) {
                          setRemoveMsg({ type: "error", text: isFA ? "پسورد اشتباه است" : "Wrong password" });
                          setTimeout(() => setRemoveMsg(null), 3000); return;
                        }
                        localStorage.removeItem("ayeneh_settings_pw");
                        setSavedPw(""); setRemovePwInput(""); setUnlocked(true);
                        setRemoveMsg({ type: "success", text: isFA ? "پسورد حذف شد ✓" : "Password removed ✓" });
                      }} className="w-full bg-red-600/80 hover:bg-red-600 py-3 rounded-xl text-sm font-semibold text-white transition-colors">
                        {isFA ? "حذف پسورد" : "Delete Password"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
          )}

          {/* ── ABOUT ── */}
          {activeTab === "about" && (
            <div className="max-w-lg space-y-5">
              <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>{t.about}</h2>
              <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.03)" }}>
                <div className="flex items-center gap-4 px-5 py-5 border-b border-white/10">
                  <img src="https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png"
                    alt="Asemanak TV" className="w-14 h-14 rounded-2xl object-cover" />
                  <div>
                    <p className="text-white font-bold text-lg">{t.appName}</p>
                    <p className="text-white/40 text-sm">آسمانک تی وی</p>
                  </div>
                </div>
                <div className="divide-y divide-white/5">
                  {[
                    { label: t.version, value: "2.0.0" },
                    { label: t.build, value: "2026.06" },
                    { label: t.website, value: "darya.net" },
                    { label: t.contact, value: "rasuliiptv3@gmail.com" },
                  ].map(({ label, value }) => (
                    <div key={label} className={`flex items-center justify-between px-5 py-3.5 ${rtl ? "flex-row-reverse" : ""}`}>
                      <span className="text-sm text-white/50">{label}</span>
                      <span className="text-sm text-white font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <button onClick={() => alert(isFA ? "نسخه قدیمی در دسترس نیست" : "Old version not available")} className="w-full flex items-center justify-between px-5 py-4 rounded-2xl border border-white/10 hover:bg-white/5 transition-colors" style={{ background: "rgba(255,255,255,0.03)" }}>
                <div className={rtl ? "text-right" : ""}>
                  <p className="text-sm text-white font-medium">{t.oldVersion}</p>
                  <p className="text-xs text-white/40 mt-0.5">{t.oldVersionDesc}</p>
                </div>
                <span className="text-white/30 text-lg">›</span>
              </button>
              <div className="rounded-xl p-4 border border-white/10 text-center" style={{ background: "rgba(255,255,255,0.03)" }}>
                <p className="text-white/30 text-xs">© 2026 Asemanak TV. All rights reserved.</p>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}