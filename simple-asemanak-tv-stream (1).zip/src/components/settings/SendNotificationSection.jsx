import { useState } from "react";
import { Bell, Send, Loader2, CheckCircle, Mail } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function SendNotificationSection({ isFA, rtl }) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [type, setType] = useState("general");
  const [sendEmail, setSendEmail] = useState(false);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState(null);

  const handleSend = async () => {
    if (!title.trim()) return;
    setSending(true);
    setSent(false);
    setError(null);
    try {
      await base44.functions.invoke("sendBroadcastNotification", {
        title: title.trim(),
        body: body.trim(),
        type,
        send_email: sendEmail,
      });
      setSent(true);
      setTitle("");
      setBody("");
      setSendEmail(false);
      setTimeout(() => setSent(false), 4000);
    } catch (e) {
      setError(e.message || (isFA ? "خطا در ارسال" : "Failed to send"));
    } finally {
      setSending(false);
    }
  };

  const typeOptions = [
    { value: "general", label: isFA ? "عمومی" : "General" },
    { value: "update", label: isFA ? "بروزرسانی" : "Update" },
    { value: "new_series", label: isFA ? "سریال/کانال جدید" : "New Content" },
  ];

  return (
    <div className="max-w-lg space-y-4" dir={rtl ? "rtl" : "ltr"}>
      <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>
        {isFA ? "ارسال پیام همگانی" : "Broadcast Notification"}
      </h2>

      {sent && (
        <div className="flex items-center gap-2 rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-3">
          <CheckCircle className="w-4 h-4 text-green-400" />
          <p className="text-green-400 text-sm">{isFA ? "اعلان ارسال شد ✓" : "Notification sent ✓"}</p>
        </div>
      )}
      {error && (
        <div className="flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      <div>
        <label className={`text-xs text-white/40 mb-1 block ${rtl ? "text-right" : ""}`}>
          {isFA ? "عنوان" : "Title"}
        </label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder={isFA ? "مثال: قطعی موقت سرور" : "e.g. Server maintenance"}
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50"
          dir="auto"
        />
      </div>

      <div>
        <label className={`text-xs text-white/40 mb-1 block ${rtl ? "text-right" : ""}`}>
          {isFA ? "متن پیام" : "Message body"}
        </label>
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={isFA ? "توضیحات اعلان..." : "Notification details..."}
          rows={3}
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50 resize-none"
          dir="auto"
        />
      </div>

      <div>
        <label className={`text-xs text-white/40 mb-1 block ${rtl ? "text-right" : ""}`}>
          {isFA ? "نوع اعلان" : "Notification type"}
        </label>
        <div className="flex gap-2">
          {typeOptions.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setType(opt.value)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${type === opt.value ? "bg-cyan-600/30 text-cyan-300 border border-cyan-500/40" : "bg-white/5 text-white/60 border border-white/10"}`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div className={`flex items-center gap-3 py-2 ${rtl ? "flex-row-reverse" : ""}`}>
        <button
          onClick={() => setSendEmail(!sendEmail)}
          className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${sendEmail ? "bg-cyan-500" : "bg-white/20"}`}
        >
          <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${sendEmail ? "translate-x-6" : "translate-x-0.5"}`} />
        </button>
        <div className={rtl ? "pl-4 text-right" : "pr-4"}>
          <p className="text-sm text-white font-medium flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5" />
            {isFA ? "ارسال ایمیل به همه کاربران" : "Email all users"}
          </p>
          <p className="text-xs text-white/40 mt-0.5">{isFA ? "علاوه بر اعلان درون‌برنامه‌ای" : "In addition to in-app notification"}</p>
        </div>
      </div>

      <button
        onClick={handleSend}
        disabled={sending || !title.trim()}
        className="w-full flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 py-3 rounded-xl text-sm font-semibold text-white transition-colors"
      >
        {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        {isFA ? "ارسال اعلان" : "Send Notification"}
      </button>
    </div>
  );
}