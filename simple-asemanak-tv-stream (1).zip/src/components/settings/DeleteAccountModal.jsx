import { useState, useEffect } from "react";
import { AlertTriangle, Trash2, X, Loader2, CheckCircle } from "lucide-react";

function readLangFA() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"; } catch { return true; }
}

// Stylish, native-like warning modal for permanent account deletion.
// Optional `requireText` (e.g. "DELETE") forces the user to type the exact
// phrase before the confirm button is enabled — matches the previous
// Settings flow's safety while replacing window.confirm dialogs.
export default function DeleteAccountModal({ open, onClose, onConfirm, loading, error, success, successText, requireText }) {
  const [text, setText] = useState("");
  const isFA = readLangFA();
  const dir = isFA ? "rtl" : "ltr";

  useEffect(() => { if (!open) setText(""); }, [open]);
  if (!open) return null;

  const t = {
    title: isFA ? "حذف حساب کاربری" : "Delete Account",
    subtitle: isFA ? "هشدار غیرقابل بازگشت" : "Irreversible Action",
    warning: isFA
      ? "این عملیات غیرقابل بازگشت است. تمام اطلاعات پروفایل شما شامل علاقه‌مندی‌ها، تنظیمات، قفل‌ها و داده‌های ذخیره‌شده برای همیشه حذف خواهد شد و قابل بازیابی نیست."
      : "This action is irreversible. All your profile data — including favorites, settings, locks and saved data — will be permanently removed and cannot be recovered.",
    typeHint: isFA ? "برای تایید، عبارت زیر را تایپ کنید:" : "Type the following to confirm:",
    cancel: isFA ? "انصراف" : "Cancel",
    confirm: isFA ? "حذف دائمی حساب" : "Permanently Delete",
    successMsg: successText || (isFA ? "حساب حذف شد" : "Account deleted"),
  };

  const canConfirm = !loading && (!requireText || text === requireText);

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center" style={{ direction: dir }}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={loading ? undefined : onClose} />
      <div className="relative w-[90%] max-w-md rounded-3xl overflow-hidden border border-red-500/25"
        style={{ background: "rgba(18,12,22,0.98)", boxShadow: "0 24px 80px rgba(0,0,0,0.6), 0 0 60px rgba(239,68,68,0.15)", animation: "delAccPop 0.22s ease-out" }}>
        <style>{`@keyframes delAccPop{from{transform:scale(0.92);opacity:0}to{transform:scale(1);opacity:1}}@keyframes delAccPulse{0%,100%{opacity:.85}50%{opacity:1}}`}</style>

        <button onClick={loading ? undefined : onClose} className="absolute top-3 right-3 text-white/60 hover:text-white p-1.5 rounded-lg transition-colors z-10 min-w-[44px] min-h-[44px] flex items-center justify-center">
          <X className="w-5 h-5" />
        </button>

        <div className="px-6 pt-8 pb-6 flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4 flex-shrink-0"
            style={{ background: "radial-gradient(circle, rgba(239,68,68,0.25), rgba(239,68,68,0.05))", border: "2px solid rgba(239,68,68,0.4)", boxShadow: "0 0 30px rgba(239,68,68,0.25)", animation: "delAccPulse 1.8s ease-in-out infinite" }}>
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>

          <h2 className="text-white font-bold text-lg mb-1">{t.title}</h2>
          <p className="text-red-300/70 text-sm font-semibold uppercase tracking-widest mb-3">{t.subtitle}</p>
          <p className="text-white/60 text-sm leading-relaxed mb-5">{t.warning}</p>

          {requireText && (
            <div className="w-full mb-4">
              <p className="text-white/50 text-sm mb-2">{t.typeHint}</p>
              <p className="text-red-400 font-mono text-sm font-bold mb-2 select-none">{requireText}</p>
              <input
                value={text}
                onChange={e => setText(e.target.value)}
                autoFocus
                placeholder={requireText}
                className="w-full bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-2.5 text-sm text-white text-center font-mono outline-none focus:border-red-500 transition-colors"
              />
            </div>
          )}

          {error && (
            <div className="w-full flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 mb-3">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-red-300 text-sm text-right flex-1">{error}</p>
            </div>
          )}
          {success && (
            <div className="w-full flex items-center gap-2 rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-2.5 mb-3">
              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
              <p className="text-green-300 text-sm text-right flex-1">{t.successMsg}</p>
            </div>
          )}

          <div className="w-full flex gap-3">
            <button onClick={onClose} disabled={loading}
              className="flex-1 py-3 rounded-xl text-sm font-semibold text-white/80 bg-white/10 hover:bg-white/15 disabled:opacity-40 transition-colors">
              {t.cancel}
            </button>
            <button onClick={onConfirm} disabled={!canConfirm}
              className="flex-1 py-3 rounded-xl text-sm font-bold text-white flex items-center justify-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ background: "linear-gradient(135deg, #dc2626, #b91c1c)", boxShadow: canConfirm ? "0 6px 20px rgba(239,68,68,0.35)" : "none" }}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              {t.confirm}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}