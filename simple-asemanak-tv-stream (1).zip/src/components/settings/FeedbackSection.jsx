import { useState, useEffect, useCallback } from "react";
import { MessageSquare, Send, Loader2, CheckCircle, RefreshCw } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

export default function FeedbackSection({ isFA = true, rtl = false }) {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [category, setCategory] = useState("other");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [feedbackList, setFeedbackList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const tr = (fa, en) => (isFA ? fa : en);

  const categories = [
    { value: "bug", label: tr("مشکل / باگ", "Bug") },
    { value: "suggestion", label: tr("پیشنهاد", "Suggestion") },
    { value: "question", label: tr("سؤال", "Question") },
    { value: "praise", label: tr("تشکر", "Praise") },
    { value: "other", label: tr("سایر", "Other") },
  ];

  const loadFeedback = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const items = await base44.entities.Feedback.list("-created_date", 50);
      // Show only the current user's feedback
      const mine = (items || []).filter(f => !f.user_email || f.user_email === user?.email);
      setFeedbackList(mine);
    } catch (e) {
      setError(tr("بارگذاری ناموفق", "Failed to load"));
    } finally {
      setLoading(false);
    }
  }, [user?.email, isFA]);

  useEffect(() => {
    loadFeedback();
  }, [loadFeedback]);

  const generateAutoReply = (cat, msg) => {
    const name = user?.full_name || user?.email || tr("کاربر گرامی", "Dear user");
    if (cat === "bug") {
      return isFA
        ? `${name}، از گزارش مشکل شما سپاسگزاریم. تیم فنی ما در اسرع وقت آن را بررسی و رفع خواهد کرد. در صورت نیاز اطلاعات بیشتری ارسال کنید.`
        : `Thank you for reporting this issue, ${name}. Our technical team will investigate and fix it as soon as possible. Please send more details if needed.`;
    }
    if (cat === "suggestion") {
      return isFA
        ? `${name}، پیشنهاد شما ارزشمند است و حتماً توسط تیم ما بررسی می‌شود. از همراهی شما سپاسگزاریم.`
        : `Your suggestion is valuable, ${name}, and will be reviewed by our team. Thank you for your support.`;
    }
    if (cat === "question") {
      return isFA
        ? `${name}، سؤال شما دریافت شد. تیم پشتیبانی در کوتاه‌ترین زمان پاسخ خواهد داد.`
        : `Your question has been received, ${name}. Our support team will respond shortly.`;
    }
    if (cat === "praise") {
      return isFA
        ? `${name}، از لطف و حمایت شما بی‌نهایت سپاسگزاریم! نظر شما انگیزه ماست.`
        : `Thank you so much for your kind words, ${name}! Your feedback motivates us.`;
    }
    return isFA
      ? `${name}، پیام شما دریافت شد. در صورت نیاز تیم ما با شما تماس خواهد گرفت. سپاس از همراهی شما.`
      : `Your message has been received, ${name}. Our team will contact you if needed. Thank you.`;
  };

  const handleSubmit = async () => {
    if (!message.trim()) return;
    setSubmitting(true);
    setError(null);
    try {
      const autoReply = generateAutoReply(category, message);
      const created = await base44.entities.Feedback.create({
        message: message.trim(),
        category,
        user_email: user?.email || "",
        user_name: user?.full_name || "",
        auto_reply: autoReply,
        status: "replied",
      });
      setFeedbackList(prev => [created, ...prev]);
      setMessage("");
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 4000);
    } catch (e) {
      setError(tr("ارسال ناموفق بود — دوباره تلاش کنید", "Failed to send — try again"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
      {/* Header */}
      <div className="px-5 py-4 border-b border-white/10 flex items-center gap-3">
        <MessageSquare className="w-5 h-5 text-cyan-400 flex-shrink-0" />
        <div className={`flex-1 ${rtl ? "text-right" : ""}`}>
          <p className="text-white font-semibold text-sm">{tr("نظرات و بازخورد", "Feedback & Comments")}</p>
          <p className="text-white/40 text-xs mt-0.5">{tr("نظر، پیشنهاد یا مشکل خود را با ما در میان بگذارید", "Share your opinions, suggestions, or issues")}</p>
        </div>
        <button onClick={loadFeedback} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors flex-shrink-0" title={tr("بازخوانی", "Refresh")}>
          <RefreshCw className={`w-3.5 h-3.5 text-white/50 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Form */}
      <div className="px-5 py-4 space-y-3">
        {/* Category pills */}
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button key={cat.value} onClick={() => setCategory(cat.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                category === cat.value
                  ? "bg-cyan-600/30 text-cyan-400 border border-cyan-500/40"
                  : "bg-white/5 text-white/50 border border-white/10 hover:bg-white/10"
              }`}>
              {cat.label}
            </button>
          ))}
        </div>

        {/* Text area */}
        <textarea
          value={message}
          onChange={e => setMessage(e.target.value)}
          rows={4}
          placeholder={tr("پیام خود را اینجا بنویسید...", "Write your message here...")}
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50 resize-none"
          style={{ direction: rtl ? "rtl" : "ltr" }}
        />

        {/* Submit */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleSubmit}
            disabled={submitting || !message.trim()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100"
            style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)" }}
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : submitted ? <CheckCircle className="w-4 h-4" /> : <Send className="w-4 h-4" />}
            {submitting ? tr("در حال ارسال...", "Sending...") : submitted ? tr("ارسال شد ✓", "Sent ✓") : tr("ارسال", "Send")}
          </button>
          {error && <p className="text-red-400 text-xs">{error}</p>}
        </div>

        {/* Auto-reply note */}
        {submitted && (
          <div className="rounded-xl p-3 border border-cyan-500/20" style={{ background: "rgba(6,182,212,0.08)" }}>
            <p className="text-cyan-400 text-xs font-medium">
              {tr("✓ پیام شما دریافت شد! پاسخ خودکار برای شما ارسال گردید.", "✓ Your message has been received! An auto-reply has been sent to you.")}
            </p>
          </div>
        )}
      </div>

      {/* Previous feedback list */}
      {feedbackList.length > 0 && (
        <div className="border-t border-white/10 px-5 py-4 space-y-3 max-h-80 overflow-y-auto">
          <p className="text-white/40 text-xs font-bold uppercase tracking-wider">{tr("پیام‌های قبلی شما", "Your Previous Messages")}</p>
          {feedbackList.map((fb) => (
            <div key={fb.id} className="rounded-xl p-3 border border-white/8" style={{ background: "rgba(255,255,255,0.03)" }}>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/60">
                  {categories.find(c => c.value === fb.category)?.label || fb.category}
                </span>
                <span className="text-[10px] text-white/30">
                  {fb.created_date ? new Date(fb.created_date).toLocaleDateString(isFA ? "fa-IR" : "en-US") : ""}
                </span>
              </div>
              <p className="text-white/80 text-xs mb-2 whitespace-pre-wrap" style={{ direction: rtl ? "rtl" : "ltr" }}>{fb.message}</p>
              {fb.auto_reply && (
                <div className="rounded-lg p-2.5 mt-1.5" style={{ background: "rgba(6,182,212,0.06)", border: "1px solid rgba(6,182,212,0.15)" }}>
                  <div className="flex items-center gap-1.5 mb-1">
                    <CheckCircle className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                    <span className="text-[10px] text-cyan-400/70 font-bold uppercase">{tr("پاسخ خودکار", "Auto Reply")}</span>
                  </div>
                  <p className="text-cyan-200/70 text-xs whitespace-pre-wrap" style={{ direction: rtl ? "rtl" : "ltr" }}>{fb.auto_reply}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {loading && feedbackList.length === 0 && (
        <div className="px-5 py-4 flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 text-white/30 animate-spin" />
          <span className="text-white/30 text-xs">{tr("بارگذاری...", "Loading...")}</span>
        </div>
      )}
    </div>
  );
}