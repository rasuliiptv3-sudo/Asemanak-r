import { useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Link2, Plus, Loader2, CheckCircle, AlertCircle, Trash2, Download, User, Server, KeyRound, Monitor, ChevronDown
} from "lucide-react";
import { useIsMobile } from "@/lib/useIsMobile";
import MobileSelectSheet from "@/components/settings/MobileSelectSheet";

const STORAGE_KEY = "ayeneh_auth_playlists";

const OUTPUT_OPTIONS = [
  { value: "m3u8", label: "m3u8 (Windows/LG/Browser)" },
  { value: "mpegts", label: "mpegts (STB/Enigma2)" },
  { value: "ts", label: "ts (Legacy)" },
  { value: "hls", label: "hls (HLS/Apple)" },
];

function loadAuthPlaylists() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}

export default function AuthPlaylistSection({ isFA, rtl }) {
  const [authPlaylists, setAuthPlaylists] = useState(loadAuthPlaylists);
  // Form state - Xtream style
  const [name, setName] = useState("");
  const [serverUrl, setServerUrl] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [output, setOutput] = useState("m3u8");
  const [includeVod, setIncludeVod] = useState(false);
  const [includeSeries, setIncludeSeries] = useState(false);
  const [fullUrl, setFullUrl] = useState("");

  const [loadingIdx, setLoadingIdx] = useState(null);
  const [deletingIdx, setDeletingIdx] = useState(null);
  const [result, setResult] = useState(null);
  const [adding, setAdding] = useState(false);
  const isMobile = useIsMobile();
  const [outputOpen, setOutputOpen] = useState(false);

  // Auto-parse a full Xtream get.php URL and fill all fields
  const parseFullUrl = (raw) => {
    if (!raw) return;
    try {
      const url = new URL(raw.trim());
      const params = url.searchParams;
      const u = params.get("username");
      const p = params.get("password");
      const out = params.get("output");
      if (!u || !p) {
        setResult({ idx: -1, status: "error", message: isFA ? "یوزرنیم/پسورد در لینک یافت نشد" : "Username/password not found in URL" });
        return;
      }
      const server = `${url.protocol}//${url.host}/`;
      setServerUrl(server);
      setUsername(u);
      setPassword(p);
      if (out) setOutput(out);
      setFullUrl("");
      setResult({ idx: -1, status: "success", message: isFA ? "لینک تجزیه شد ✓ فیلدها پر شدند" : "URL parsed ✓ fields filled" });
      setTimeout(() => setResult(null), 3000);
    } catch {
      setResult({ idx: -1, status: "error", message: isFA ? "لینک نامعتبر است" : "Invalid URL" });
    }
  };

  const save = (list) => {
    setAuthPlaylists(list);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  };

  const buildM3uUrl = (pl) => {
    // Construct Xtream get.php URL from components
    const base = pl.serverUrl.replace(/\/+$/, "");
    const params = new URLSearchParams({
      username: pl.username,
      password: pl.password,
      type: "m3u_plus",
      output: pl.output || "m3u8",
    });
    return `${base}/get.php?${params.toString()}`;
  };

  const buildApiUrl = (pl) => {
    const base = pl.serverUrl.replace(/\/+$/, "");
    const params = new URLSearchParams({
      username: pl.username,
      password: pl.password,
    });
    return `${base}/player_api.php?${params.toString()}`;
  };

  const parseM3U = (text) => {
    const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
    const channels = []; let current = {};
    for (const line of lines) {
      if (line.startsWith("#EXTINF:")) {
        current = {};
        const nm = line.match(/tvg-name="([^"]*)"/);
        const logo = line.match(/tvg-logo="([^"]*)"/);
        const group = line.match(/group-title="([^"]*)"/);
        const country = line.match(/tvg-country="([^"]*)"/);
        const lang = line.match(/tvg-language="([^"]*)"/);
        const ci = line.lastIndexOf(",");
        const dn = ci >= 0 ? line.slice(ci + 1).trim() : "";
        current.name = (nm ? nm[1] : dn) || "Unknown";
        current.logo_url = logo ? logo[1] : "";
        current.country = country ? country[1] : (group ? group[1] : "");
        current.language = lang ? lang[1] : "";
        current.category = "general"; current.is_active = true;
      } else if (!line.startsWith("#") && (line.startsWith("http") || line.startsWith("rtmp")) && current.name) {
        current.stream_url = line;
        channels.push({ ...current }); current = {};
      }
    }
    return channels;
  };

  const handleAdd = () => {
    if (!serverUrl.trim() || !username.trim() || !password.trim()) return;
    setAdding(true);
    const entry = {
      name: name.trim() || serverUrl.trim(),
      serverUrl: serverUrl.trim(),
      username: username.trim(),
      password: password.trim(),
      output,
      includeVod,
      includeSeries,
      addedAt: Date.now(),
    };
    save([...authPlaylists, entry]);
    // Reset form
    setName(""); setServerUrl(""); setUsername(""); setPassword("");
    setOutput("m3u8"); setIncludeVod(false); setIncludeSeries(false);
    setResult({ idx: -1, status: "success", message: isFA ? "اشتراک اضافه شد — روی بارگذاری کلیک کنید" : "Added — click Load to fetch channels" });
    setTimeout(() => setResult(null), 4000);
    setAdding(false);
  };

  const loadAuth = async (pl, idx) => {
    setLoadingIdx(idx); setResult(null);
    const m3uUrl = buildM3uUrl(pl);
    let text = "";

    const proxies = [
      (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
      (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
      (u) => `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(u)}`,
      (u) => `https://proxy.cors.sh/${u}`,
      (u) => `https://thingproxy.freeboard.io/fetch/${u}`,
    ];

    const tryFetch = async (urlStr) => {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000);
      try {
        const res = await fetch(urlStr, { signal: controller.signal });
        clearTimeout(timeout);
        if (!res.ok) throw new Error("bad status");
        return await res.text();
      } catch (e) {
        clearTimeout(timeout);
        throw e;
      }
    };

    try {
      // Try direct fetch first
      try {
        text = await tryFetch(m3uUrl);
      } catch {
        // If direct fails (CORS), try all proxies in sequence
        for (const p of proxies) {
          try {
            text = await tryFetch(p(m3uUrl));
            if (text && text.length > 10) break;
          } catch {}
        }
        if (!text || text.length < 10) throw new Error("all failed");
      }
    } catch {
      setResult({ idx, status: "error", message: isFA ? "واکشی ناموفق — سرور پاسخ نمی‌دهد" : "Fetch failed — server not responding" });
      setLoadingIdx(null); return;
    }

    const parsed = parseM3U(text);
    if (!parsed.length) {
      setResult({ idx, status: "error", message: isFA ? "کانالی یافت نشد — اطلاعات را بررسی کنید" : "No channels found — check credentials" });
      setLoadingIdx(null); return;
    }

    setResult({ idx, status: "running", message: `0 / ${parsed.length} ...` });

    if (pl.channelIds?.length) {
      for (let i = 0; i < pl.channelIds.length; i += 50) {
        const batch = pl.channelIds.slice(i, i + 50);
        await Promise.all(batch.map(id => base44.entities.Channel.delete(id).catch(() => {})));
      }
    }

    const BATCH = 40;
    const allCreated = [];
    for (let i = 0; i < parsed.length; i += BATCH) {
      const batch = parsed.slice(i, i + BATCH);
      let created;
      let retries = 0;
      while (retries < 3) {
        try {
          created = await base44.entities.Channel.bulkCreate(batch);
          break;
        } catch (e) {
          retries++;
          if (retries >= 3) break;
          await new Promise(r => setTimeout(r, 2000 * retries));
        }
      }
      if (Array.isArray(created)) allCreated.push(...created.map(c => c.id));
      setResult({ idx, status: "running", message: `${Math.min(i + BATCH, parsed.length)} / ${parsed.length} ...` });
      await new Promise(r => setTimeout(r, 300));
    }

    const updated = authPlaylists.map((p, i) =>
      i === idx ? { ...p, channelIds: allCreated, loadedAt: Date.now() } : p
    );
    save(updated);
    localStorage.removeItem("ayeneh_channels_cache");
    setResult({ idx, status: "success", message: isFA ? `${allCreated.length} کانال بارگذاری شد!` : `${allCreated.length} channels loaded!` });
    setLoadingIdx(null);
  };

  const removeAuth = async (pl, idx) => {
    setDeletingIdx(idx);
    setResult({ idx, status: "running", message: isFA ? "در حال حذف..." : "Deleting channels..." });
    const channelIds = pl.channelIds || [];
    try {
      for (let i = 0; i < channelIds.length; i += 50) {
        const batch = channelIds.slice(i, i + 50);
        await Promise.all(batch.map(id => base44.entities.Channel.delete(id).catch(() => {})));
      }
    } catch {}
    save(authPlaylists.filter((_, i) => i !== idx));
    localStorage.removeItem("ayeneh_channels_cache");
    setResult({ idx, status: "success", message: isFA ? `${channelIds.length} کانال حذف شد` : `${channelIds.length} channels deleted` });
    setDeletingIdx(null);
  };

  // Toggle switch
  const Toggle = ({ value, onChange }) => (
    <button onClick={() => onChange(!value)}
      className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${value ? "bg-cyan-500" : "bg-white/20"}`}>
      <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${value ? "translate-x-5" : "translate-x-0.5"}`} />
    </button>
  );

  return (
    <div className="space-y-4">
      {/* Section title */}
      <div className={`flex items-center gap-2 ${rtl ? "flex-row-reverse" : ""}`}>
        <Server className="w-4 h-4 text-cyan-400" />
        <p className="text-xs font-bold text-white/40 uppercase tracking-widest">
          {isFA ? "اشتراک Xtream (سرور + یوزرنیم + پسورد)" : "Xtream Subscription (Server + User + Pass)"}
        </p>
      </div>

      {/* Add form - Xtream style */}
      <div className="rounded-2xl border border-cyan-500/20 overflow-hidden" style={{ background: "rgba(6,182,212,0.05)" }}>
        <div className="px-4 py-3 border-b border-cyan-500/20 flex items-center gap-2">
          <Plus className="w-4 h-4 text-cyan-400" />
          <p className="text-white font-semibold text-sm">{isFA ? "افزودن اشتراک Xtream" : "Add Xtream Subscription"}</p>
        </div>
        <div className="p-4 space-y-3">
          {/* Full URL auto-parser */}
          <div className="rounded-xl border border-cyan-500/30 p-3" style={{ background: "rgba(6,182,212,0.08)" }}>
            <label className="text-xs text-cyan-400 mb-1.5 flex items-center gap-1.5 font-semibold">
              <Link2 className="w-3 h-3" />
              {isFA ? "جای‌گذاری لینک کامل (خودکار تجزیه می‌شود)" : "Paste Full URL (auto-parse)"}
            </label>
            <div className="flex gap-2">
              <input
                value={fullUrl}
                onChange={e => setFullUrl(e.target.value)}
                onKeyDown={e => e.key === "Enter" && parseFullUrl(fullUrl)}
                placeholder="http://example.com/get.php?username=...&password=..."
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50 font-mono"
              />
              <button
                onClick={() => parseFullUrl(fullUrl)}
                disabled={!fullUrl.trim()}
                className="flex-shrink-0 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 px-3 py-2 rounded-lg text-xs font-bold text-white transition-colors"
              >
                {isFA ? "تجزیه" : "Parse"}
              </button>
            </div>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 py-1">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-[10px] text-white/30 uppercase">{isFA ? "یا دستی وارد کنید" : "or enter manually"}</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Name */}
          <div>
            <label className="text-xs text-white/40 mb-1 block">{isFA ? "نام (اختیاری)" : "Name (optional)"}</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder={isFA ? "مثلاً: اشتراک من" : "e.g. My Subscription"}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
          </div>

          {/* Server URL */}
          <div>
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Server className="w-3 h-3" /> {isFA ? "آدرس سرور *" : "Server URL *"}</label>
            <input value={serverUrl} onChange={e => setServerUrl(e.target.value)}
              placeholder="http://example.com:8080/"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50 font-mono text-xs" />
          </div>

          {/* Username + Password */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><User className="w-3 h-3" /> {isFA ? "نام کاربری *" : "Username *"}</label>
              <input value={username} onChange={e => setUsername(e.target.value)}
                placeholder="username"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><KeyRound className="w-3 h-3" /> {isFA ? "رمز عبور *" : "Password *"}</label>
              <input value={password} onChange={e => setPassword(e.target.value)}
                placeholder="password"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
            </div>
          </div>

          {/* Output format */}
          <div>
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Monitor className="w-3 h-3" /> {isFA ? "فرمت خروجی" : "Output"}</label>
            {isMobile ? (
              <button type="button" onClick={() => setOutputOpen(true)}
                className="w-full bg-white/10 border border-white/10 text-white text-sm rounded-xl px-3 py-2.5 flex items-center justify-between gap-2 outline-none cursor-pointer active:scale-[0.99] transition-transform">
                <span className="truncate">{OUTPUT_OPTIONS.find(o => o.value === output)?.label || output}</span>
                <ChevronDown className="w-4 h-4 text-white/50 flex-shrink-0" />
              </button>
            ) : (
              <select value={output} onChange={e => setOutput(e.target.value)}
                className="w-full bg-white/10 border border-white/10 text-white text-sm rounded-xl px-3 py-2.5 outline-none cursor-pointer">
                {OUTPUT_OPTIONS.map(o => <option key={o.value} value={o.value} className="bg-gray-900">{o.label}</option>)}
              </select>
            )}
            {isMobile && outputOpen && (
              <MobileSelectSheet
                label={isFA ? "فرمت خروجی" : "Output"}
                options={OUTPUT_OPTIONS}
                value={output}
                rtl={rtl}
                onSelect={(v) => { setOutput(v); setOutputOpen(false); }}
                onClose={() => setOutputOpen(false)}
              />
            )}
          </div>

          {/* Toggles */}
          <div className="space-y-1">
            <div className={`flex items-center justify-between py-2 ${rtl ? "flex-row-reverse" : ""}`}>
              <span className="text-sm text-white/70">{isFA ? "شامل فیلم‌ها (VOD)" : "Include movies (VOD)"}</span>
              <Toggle value={includeVod} onChange={setIncludeVod} />
            </div>
            <div className={`flex items-center justify-between py-2 ${rtl ? "flex-row-reverse" : ""}`}>
              <span className="text-sm text-white/70">{isFA ? "شامل سریال‌ها" : "Include series"}</span>
              <Toggle value={includeSeries} onChange={setIncludeSeries} />
            </div>
          </div>

          {/* Hint */}
          <p className="text-[11px] text-cyan-400/70 flex items-start gap-1">
            ⓘ {isFA ? "فرمت m3u8 برای مرورگر و TV بهترین پخش را دارد" : "m3u8 output works best for browser/TV playback"}
          </p>

          {/* Result for add */}
          {result?.idx === -1 && (
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs ${
              result.status === "success" ? "bg-green-500/10 text-green-400"
              : result.status === "running" ? "bg-cyan-500/10 text-cyan-400"
              : "bg-red-500/10 text-red-400"}`}>
              {result.status === "success" ? <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" />
                : result.status === "running" ? <Loader2 className="w-3.5 h-3.5 flex-shrink-0 animate-spin" />
                : <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />}
              {result.message}
            </div>
          )}

          {/* Add button */}
          <button onClick={handleAdd} disabled={!serverUrl.trim() || !username.trim() || !password.trim() || adding}
            className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 py-3 rounded-xl text-sm font-bold text-white transition-colors flex items-center justify-center gap-2">
            {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {isFA ? "افزودن" : "Add Subscription"}
          </button>
        </div>
      </div>

      {/* Saved auth playlists */}
      {authPlaylists.length > 0 && (
        <div className="space-y-3">
          <p className="text-xs text-white/30 font-bold uppercase tracking-widest">{isFA ? "اشتراک‌های ذخیره‌شده" : "Saved Subscriptions"}</p>
          {authPlaylists.map((pl, idx) => (
            <div key={idx} className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
              {/* Header */}
              <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/10" style={{ background: "rgba(255,255,255,0.03)" }}>
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                  style={{ background: "rgba(6,182,212,0.25)", color: "rgb(34,211,238)" }}>
                  <Server className="w-3 h-3" />
                </div>
                <span className="text-xs font-semibold text-cyan-400 truncate flex-1">{pl.name}</span>
                {pl.channelIds?.length > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-green-500/20 text-green-400 border border-green-500/30">
                    {pl.channelIds.length} ch
                  </span>
                )}
              </div>
              {/* Body */}
              <div className="px-4 py-3">
                {/* Details */}
                <div className="mb-2 space-y-1 text-xs">
                  <div className="flex gap-2">
                    <span className="text-white/30 w-16">Server:</span>
                    <span className="text-white/50 truncate font-mono">{pl.serverUrl}</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-white/30 w-16">User:</span>
                    <span className="text-white/50 font-mono">{pl.username}</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-white/30 w-16">Output:</span>
                    <span className="text-white/50 font-mono">{pl.output}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    {pl.loadedAt && <p className="text-[10px] text-white/25">{new Date(pl.loadedAt).toLocaleDateString()}</p>}
                  </div>
                  <button onClick={() => loadAuth(pl, idx)} disabled={loadingIdx !== null || deletingIdx !== null}
                    className="flex items-center gap-1.5 text-xs text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded-lg hover:bg-cyan-500/10 disabled:opacity-40 transition-colors flex-shrink-0">
                    {loadingIdx === idx ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                    {pl.channelIds?.length ? (isFA ? "بارگذاری مجدد" : "Reload") : (isFA ? "بارگذاری" : "Load")}
                  </button>
                  <button onClick={() => removeAuth(pl, idx)} disabled={deletingIdx !== null || loadingIdx !== null}
                    className="text-white/30 hover:text-red-400 transition-colors flex-shrink-0 disabled:opacity-40 p-1">
                    {deletingIdx === idx ? <Loader2 className="w-4 h-4 animate-spin text-red-400" /> : <Trash2 className="w-4 h-4" />}
                  </button>
                </div>
                {result?.idx === idx && (
                  <div className={`flex items-center gap-2 px-3 py-2 mt-2 rounded-lg text-xs ${
                    result.status === "success" ? "bg-green-500/10 text-green-400"
                    : result.status === "running" ? "bg-cyan-500/10 text-cyan-400"
                    : "bg-red-500/10 text-red-400"}`}>
                    {result.status === "success" ? <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" />
                      : result.status === "running" ? <Loader2 className="w-3.5 h-3.5 flex-shrink-0 animate-spin" />
                      : <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />}
                    {result.message}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}