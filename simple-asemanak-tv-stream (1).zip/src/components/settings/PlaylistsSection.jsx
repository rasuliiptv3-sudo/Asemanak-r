import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Download, Trash2, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { idbSet } from "@/lib/idb";

const T = {
  en: {
    title: "M3U Playlists",
    addBtn: "Add", load: "Load", reload: "Reload",
    deleted: "channels deleted.", noChannelsFound: "No valid channels found.",
    loadedChannels: "channels loaded!", couldNotFetch: "Could not fetch playlist.",
    deleteAll: "Delete all channels",
    confirmDeleteAll: "Delete ALL channels and playlists from the database?",
    done: "All channels deleted",
    namePh: "Playlist name (optional)", urlPh: "http://example.com/playlist.m3u",
    ch: "ch", empty: "No playlists yet. Add one below.",
  },
  fa: {
    title: "پلی‌لیست‌های M3U",
    addBtn: "افزودن", load: "بارگذاری", reload: "بارگذاری مجدد",
    deleted: "کانال حذف شد.", noChannelsFound: "کانالی یافت نشد.",
    loadedChannels: "کانال بارگذاری شد!", couldNotFetch: "پلی‌لیست واکشی نشد.",
    deleteAll: "حذف همه کانال‌ها",
    confirmDeleteAll: "همه کانال‌ها و پلی‌لیست‌ها از دیتابیس پاک شوند؟",
    done: "همه کانال‌ها حذف شدند",
    namePh: "نام (اختیاری)", urlPh: "http://example.com/playlist.m3u",
    ch: "کانال", empty: "هنوز پلی‌لیستی نیست. یکی اضافه کنید.",
  }
};

const COUNTRY_PLAYLISTS = [
  { code: "af", flag: "🇦🇫", nameFa: "افغانستان", nameEn: "Afghanistan", url: "https://iptv-org.github.io/iptv/countries/af.m3u" },
  { code: "ir", flag: "🇮🇷", nameFa: "ایران", nameEn: "Iran", url: "https://iptv-org.github.io/iptv/countries/ir.m3u" },
  { code: "uz", flag: "🇺🇿", nameFa: "ازبکستان", nameEn: "Uzbekistan", url: "https://iptv-org.github.io/iptv/countries/uz.m3u" },
  { code: "tj", flag: "🇹🇯", nameFa: "تاجیکستان", nameEn: "Tajikistan", url: "https://iptv-org.github.io/iptv/countries/tj.m3u" },
  { code: "in", flag: "🇮🇳", nameFa: "هند (بالیوود)", nameEn: "India (Bollywood)", url: "https://iptv-org.github.io/iptv/countries/in.m3u" },
  { code: "us", flag: "🇺🇸", nameFa: "آمریکا", nameEn: "USA", url: "https://iptv-org.github.io/iptv/countries/us.m3u" },
  { code: "uk", flag: "🇬🇧", nameFa: "انگلستان", nameEn: "UK", url: "https://iptv-org.github.io/iptv/countries/uk.m3u" },
  { code: "de", flag: "🇩🇪", nameFa: "آلمان", nameEn: "Germany", url: "https://iptv-org.github.io/iptv/countries/de.m3u" },
  { code: "tr", flag: "🇹🇷", nameFa: "ترکیه", nameEn: "Turkey", url: "https://iptv-org.github.io/iptv/countries/tr.m3u" },
  { code: "ae", flag: "🇦🇪", nameFa: "امارات", nameEn: "UAE", url: "https://iptv-org.github.io/iptv/countries/ae.m3u" },
  { code: "sa", flag: "🇸🇦", nameFa: "عربستان", nameEn: "Saudi Arabia", url: "https://iptv-org.github.io/iptv/countries/sa.m3u" },
  { code: "ru", flag: "🇷🇺", nameFa: "روسیه", nameEn: "Russia", url: "https://iptv-org.github.io/iptv/countries/ru.m3u" },
];

function parseM3U(text) {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  const channels = []; let current = {};
  for (const line of lines) {
    if (line.startsWith("#EXTINF:")) {
      current = {};
      const nm = line.match(/tvg-name="([^"]*)"/);
      const logo = line.match(/tvg-logo="([^"]*)"/);
      const group = line.match(/group-title="([^"]*)"/);
      const country = line.match(/tvg-country="([^"]*)"/);
      const lang = line.match(/tvg-language="([^"]*)"/);
      const ci = line.lastIndexOf(",");
      const dn = ci >= 0 ? line.slice(ci + 1).trim() : "";
      current.name = (nm ? nm[1] : dn) || "Unknown";
      current.logo_url = logo ? logo[1] : "";
      current.country = country ? country[1] : (group ? group[1] : "");
      current.language = lang ? lang[1] : "";
      current.category = "general"; current.is_active = true;
    } else if (!line.startsWith("#") && (line.startsWith("http") || line.startsWith("rtmp")) && current.name) {
      current.stream_url = line;
      channels.push({ ...current }); current = {};
    }
  }
  return channels;
}

function clearChannelCache() {
  localStorage.removeItem("ayeneh_channels_cache");
  localStorage.removeItem("ayeneh_last_channel");
  idbSet("channels", "all", []);
  idbSet("meta", "channels_updated_at", 0);
}

export default function PlaylistsSection({ isFA, rtl }) {
  const t = isFA ? T.fa : T.en;
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyIdx, setBusyIdx] = useState(null);
  const [loadResult, setLoadResult] = useState(null);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [adding, setAdding] = useState(false);
  const [addingCountry, setAddingCountry] = useState(null);

  const handleAddCountry = async (cp) => {
    setAddingCountry(cp.code);
    try {
      const created = await base44.entities.Playlist.create({ name: isFA ? cp.nameFa : cp.nameEn, url: cp.url, channelIds: [] });
      setPlaylists(prev => [created, ...prev]);
    } catch {}
    setAddingCountry(null);
  };

  useEffect(() => {
    (async () => {
      // One-time migration of localStorage playlists to the server.
      if (!localStorage.getItem("ayeneh_playlists_migrated_v2")) {
        try {
          const local = JSON.parse(localStorage.getItem("ayeneh_playlists") || "[]");
          const valid = (local || []).filter(p => p && p.url);
          if (valid.length) {
            await base44.entities.Playlist.bulkCreate(valid.map(p => ({
              name: p.name || p.url,
              url: p.url,
              channelIds: p.channelIds || [],
              loadedAt: p.loadedAt ? new Date(p.loadedAt).toISOString() : undefined,
            })));
          }
        } catch {}
        localStorage.setItem("ayeneh_playlists_migrated_v2", "1");
      }
      try {
        const remote = await base44.entities.Playlist.list("-created_date", 50);
        setPlaylists(remote || []);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const handleAdd = async () => {
    const u = url.trim();
    if (!u) return;
    setAdding(true);
    try {
      const created = await base44.entities.Playlist.create({ name: name.trim() || u, url: u, channelIds: [] });
      setPlaylists(prev => [created, ...prev]);
      setName(""); setUrl("");
    } catch {}
    setAdding(false);
  };

  const loadPlaylist = async (pl, idx) => {
    setBusyIdx(idx); setLoadResult(null);
    let text = "";
    try {
      const res = await fetch(pl.url);
      if (!res.ok) throw new Error();
      text = await res.text();
    } catch {
      setLoadResult({ idx, status: "error", message: t.couldNotFetch });
      setBusyIdx(null); return;
    }
    const parsed = parseM3U(text);
    if (!parsed.length) { setLoadResult({ idx, status: "error", message: t.noChannelsFound }); setBusyIdx(null); return; }

    setLoadResult({ idx, status: "running", message: `0 / ${parsed.length} ...` });

    // Delete old channels for this playlist first
    if (pl.channelIds?.length) {
      for (let i = 0; i < pl.channelIds.length; i += 50) {
        const batch = pl.channelIds.slice(i, i + 50);
        await Promise.all(batch.map(id => base44.entities.Channel.delete(id).catch(() => {})));
      }
    }

    const BATCH = 100;
    const allCreated = [];
    for (let i = 0; i < parsed.length; i += BATCH) {
      const batch = parsed.slice(i, i + BATCH);
      let created;
      let retries = 0;
      while (retries < 4) {
        try { created = await base44.entities.Channel.bulkCreate(batch); break; }
        catch { retries++; if (retries >= 4) break; await new Promise(r => setTimeout(r, 1500 * retries)); }
      }
      if (Array.isArray(created)) allCreated.push(...created.map(c => c.id));
      setLoadResult({ idx, status: "running", message: `${Math.min(i + BATCH, parsed.length)} / ${parsed.length} ...` });
      await new Promise(r => setTimeout(r, 120));
    }

    await base44.entities.Playlist.update(pl.id, { channelIds: allCreated, loadedAt: new Date().toISOString() }).catch(() => {});
    setPlaylists(prev => prev.map((p, i) => i === idx ? { ...p, channelIds: allCreated, loadedAt: new Date().toISOString() } : p));
    clearChannelCache();

    setLoadResult({ idx, status: "success", message: `${allCreated.length} ${t.loadedChannels}` });
    setBusyIdx(null);
  };

  const removePlaylist = async (idx) => {
    const pl = playlists[idx];
    if (!pl) return;
    setBusyIdx(idx);
    const ids = pl.channelIds || [];
    for (let i = 0; i < ids.length; i += 50) {
      const batch = ids.slice(i, i + 50);
      await Promise.all(batch.map(id => base44.entities.Channel.delete(id).catch(() => {})));
    }
    await base44.entities.Playlist.delete(pl.id).catch(() => {});
    setPlaylists(prev => prev.filter((_, i) => i !== idx));
    clearChannelCache();
    setBusyIdx(null);
  };

  const deleteAll = async () => {
    if (!window.confirm(t.confirmDeleteAll)) return;
    setBusyIdx("all");
    try {
      // deleteMany has a per-call limit; loop until ALL channels are gone (10,000+)
      for (let i = 0; i < 200; i++) {
        await base44.entities.Channel.deleteMany({}).catch(() => {});
        const remaining = await base44.entities.Channel.list("-created_date", 1).catch(() => []);
        if (!remaining?.length) break;
      }
    } catch {}
    try {
      const all = await base44.entities.Playlist.list("-created_date", 100);
      await Promise.all(all.map(p => base44.entities.Playlist.delete(p.id).catch(() => {})));
    } catch {}
    setPlaylists([]);
    clearChannelCache();
    setBusyIdx(null);
    alert(t.done);
  };

  return (
    <div className="max-w-lg space-y-5">
      <div className="flex items-center justify-between">
        <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>{t.title}</h2>
        <button onClick={deleteAll} disabled={busyIdx !== null}
          className="text-xs text-red-400 border border-red-500/30 px-3 py-1.5 rounded-lg hover:bg-red-500/10 disabled:opacity-40 transition-colors flex items-center gap-1.5">
          {busyIdx === "all" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null} {t.deleteAll}
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8"><Loader2 className="w-5 h-5 text-white/40 animate-spin" /></div>
      ) : playlists.length === 0 ? (
        <p className="text-white/30 text-sm">{t.empty}</p>
      ) : (
        playlists.map((pl, idx) => (
          <div key={pl.id} className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
            <div className="flex items-center gap-2 px-4 py-2.5 border-b border-white/10" style={{ background: "rgba(255,255,255,0.03)" }}>
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                style={{ background: "rgba(6,182,212,0.25)", color: "rgb(34,211,238)" }}>
                {idx + 1}
              </div>
              <span className="text-xs font-semibold text-cyan-300 truncate flex-1">{pl.name}</span>
              {pl.channelIds?.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-green-500/20 text-green-400 border border-green-500/30">
                  {pl.channelIds.length} {t.ch}
                </span>
              )}
            </div>
            <div className="px-4 py-3 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="text-xs text-white/40 truncate">{pl.url}</p>
                {pl.loadedAt && <p className="text-[10px] text-white/25 mt-0.5">{new Date(pl.loadedAt).toLocaleDateString()}</p>}
              </div>
              <button onClick={() => loadPlaylist(pl, idx)} disabled={busyIdx !== null}
                className="flex items-center gap-1.5 text-xs text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded-lg hover:bg-cyan-500/10 disabled:opacity-40 transition-colors flex-shrink-0">
                {busyIdx === idx ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                {pl.channelIds?.length ? t.reload : t.load}
              </button>
              <button onClick={() => removePlaylist(idx)} disabled={busyIdx !== null}
                className="text-white/30 hover:text-red-400 transition-colors flex-shrink-0 disabled:opacity-40 p-1">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            {loadResult?.idx === idx && (
              <div className={`flex items-center gap-2 px-4 py-2 text-xs border-t ${
                loadResult.status === "success" ? "border-green-500/20 bg-green-900/20 text-green-400"
                : loadResult.status === "running" ? "border-cyan-500/20 bg-cyan-900/20 text-cyan-400"
                : "border-red-500/20 bg-red-900/20 text-red-400"}`}>
                {loadResult.status === "success" ? <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" />
                  : loadResult.status === "running" ? <Loader2 className="w-3.5 h-3.5 flex-shrink-0 animate-spin" />
                  : <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />}
                {loadResult.message}
              </div>
            )}
          </div>
        ))
      )}

      {/* Quick add — country playlists */}
      <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
        <div className="px-4 py-3 border-b border-white/10">
          <p className="text-xs font-bold text-white/50 uppercase tracking-widest">{isFA ? "پلی‌لیست‌های کشورها — اضافه کردن سریع" : "Country Playlists — Quick Add"}</p>
        </div>
        <div className="p-3 flex flex-wrap gap-2">
          {COUNTRY_PLAYLISTS.map(cp => (
            <button key={cp.code} onClick={() => handleAddCountry(cp)} disabled={!!addingCountry}
              className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-white transition-all hover:scale-105 disabled:opacity-40"
              style={{ background: "linear-gradient(135deg, rgba(6,182,212,0.2), rgba(123,44,191,0.2))", border: "1px solid rgba(255,255,255,0.15)" }}>
              <span className="text-base">{cp.flag}</span>
              <span>{isFA ? cp.nameFa : cp.nameEn}</span>
              {addingCountry === cp.code && <Loader2 className="w-3 h-3 animate-spin" />}
            </button>
          ))}
        </div>
      </div>

      {/* Add form */}
      <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
        <div className="p-4 space-y-2">
          <input value={name} onChange={e => setName(e.target.value)} placeholder={t.namePh}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
          <div className="flex gap-2">
            <input value={url} onChange={e => setUrl(e.target.value)} placeholder={t.urlPh}
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
            <button onClick={handleAdd} disabled={adding || !url.trim()}
              className="bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 px-4 py-2.5 rounded-xl font-semibold text-sm flex items-center gap-1.5 transition-colors flex-shrink-0">
              {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}{t.addBtn}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}