import { useState, useEffect } from "react";
import { Download, Trash2, Loader2, HardDrive } from "lucide-react";
import { getOfflineIndex, removeOfflineVideo, clearAllOffline } from "@/lib/offlineVideo";

function fmtSize(b) {
  if (!b) return "—";
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + " KB";
  if (b < 1024 * 1024 * 1024) return (b / (1024 * 1024)).toFixed(1) + " MB";
  return (b / (1024 * 1024 * 1024)).toFixed(2) + " GB";
}

export default function OfflineManagerSection({ isFA, rtl }) {
  const isFa = isFA;
  const [items, setItems] = useState([]);
  const [busy, setBusy] = useState(null);
  const tr = (f, e) => (isFA ? f : e);

  const refresh = () => setItems(getOfflineIndex());
  useEffect(() => {
    refresh();
    window.addEventListener("ayeneh-offline-changed", refresh);
    return () => window.removeEventListener("ayeneh-offline-changed", refresh);
  }, []);

  const total = items.reduce((s, e) => s + (e.size || 0), 0);

  const delOne = async (fileUrl) => {
    setBusy(fileUrl);
    try { await removeOfflineVideo(fileUrl); } catch {}
    setBusy(null);
  };
  const delAll = async () => {
    if (!window.confirm(tr("همه ویدیوهای آفلاین حذف شوند؟", "Delete all offline videos?"))) return;
    setBusy("all");
    try { await clearAllOffline(); } catch {}
    setBusy(null);
  };

  return (
    <div className="max-w-lg space-y-5">
      <h2 className={`text-sm font-bold text-white/50 uppercase tracking-widest mb-4 ${rtl ? "text-right" : ""}`}>
        {tr("مدیریت ویدیوهای آفلاین", "Offline Videos Manager")}
      </h2>

      <div className="rounded-2xl border border-white/10 p-5 flex items-center gap-4" style={{ background: "rgba(255,255,255,0.04)" }}>
        <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(34,211,238,0.15)" }}>
          <HardDrive className="w-6 h-6 text-cyan-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white font-semibold text-sm">{tr("فضای اشغال‌شده", "Used space")}</p>
          <p className="text-white/50 text-xs mt-0.5">
            {isFA ? `${toFa(items.length)} ویدیو • ${toFa(fmtSize(total))}` : `${items.length} videos • ${fmtSize(total)}`}
          </p>
        </div>
        {items.length > 0 && (
          <button onClick={delAll} disabled={busy === "all"}
            className="flex items-center gap-1.5 text-xs text-red-400 border border-red-500/30 px-3 py-2 rounded-lg hover:bg-red-500/10 transition-colors disabled:opacity-40 flex-shrink-0">
            {busy === "all" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            {tr("حذف همه", "Clear all")}
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/15 p-10 text-center">
          <Download className="w-8 h-8 text-white/20 mx-auto mb-3" />
          <p className="text-white/40 text-sm leading-relaxed">
            {tr(
              "هنوز ویدیویی برای افلاین ذخیره نشده است. هنگام تماشای یک قسمت، دکمه‌ی «دانلود افلاین» را بزنید تا اینجا ذخیره شود.",
              "No offline videos yet. While watching an episode, tap \"Download offline\" to save it here."
            )}
          </p>
        </div>
      ) : (
        <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.03)" }}>
          {items.map((it, i) => (
            <div key={it.fileUrl} className={`flex items-center gap-3 px-4 py-3 ${i > 0 ? "border-t border-white/5" : ""}`}>
              <Download className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm truncate">{it.label || it.fileUrl}</p>
                <p className="text-white/40 text-xs mt-0.5">
                  {isFa ? toFa(fmtSize(it.size)) : fmtSize(it.size)}{it.cachedAt ? ` • ${new Date(it.cachedAt).toLocaleDateString(isFA ? "fa-IR" : "en-US")}` : ""}
                </p>
              </div>
              <button onClick={() => delOne(it.fileUrl)} disabled={busy === it.fileUrl}
                className="text-white/30 hover:text-red-400 transition-colors disabled:opacity-40 p-1 flex-shrink-0">
                {busy === it.fileUrl ? <Loader2 className="w-4 h-4 animate-spin text-red-400" /> : <Trash2 className="w-4 h-4" />}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function toFa(s) {
  return String(s).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
}