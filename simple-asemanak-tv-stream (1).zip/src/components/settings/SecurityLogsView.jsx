import { useState, useEffect } from "react";
import { Shield, RefreshCw, AlertTriangle, Info, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

const SEVERITY_META = {
  info: { Icon: Info, color: "#22d3ee", labelFa: "اطلاعات", labelEn: "Info" },
  warning: { Icon: AlertTriangle, color: "#fbbf24", labelFa: "هشدار", labelEn: "Warning" },
  critical: { Icon: AlertCircle, color: "#ef4444", labelFa: "بحرانی", labelEn: "Critical" },
};

const EVENT_LABELS = {
  login_attempt: { fa: "تلاش ورود", en: "Login Attempt" },
  login_success: { fa: "ورود موفق", en: "Login Success" },
  login_failed: { fa: "ورود ناموفق", en: "Login Failed" },
  concurrent_login: { fa: "ورود همزمان", en: "Concurrent Login" },
  device_mismatch: { fa: "تغییر دستگاه", en: "Device Mismatch" },
  suspicious_activity: { fa: "فعالیت مشکوک", en: "Suspicious Activity" },
  rate_limit_hit: { fa: "محدودیت درخواست", en: "Rate Limit Hit" },
  token_expired: { fa: "انقضای توکن", en: "Token Expired" },
};

export default function SecurityLogsView({ isFA, rtl }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  const load = async () => {
    setLoading(true);
    try {
      const res = await base44.entities.SecurityLog.filter({}, "-created_date", 100);
      setLogs(res || []);
    } catch (e) {
      // SecurityLog might not be accessible to non-admins
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = filter === "all" ? logs : logs.filter(l => l.severity === filter);

  const fmt = (iso) => {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toLocaleString(isFA ? "fa-IR" : "en-US");
  };

  return (
    <div className="max-w-2xl space-y-4" dir={rtl ? "rtl" : "ltr"}>
      <div className="flex items-center justify-between">
        <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>
          {isFA ? "لاگ‌های امنیتی" : "Security Logs"}
        </h2>
        <button onClick={load} disabled={loading}
          className="flex items-center gap-1.5 text-xs text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded-lg hover:bg-cyan-500/10 disabled:opacity-40 transition-colors">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          {isFA ? "بروزرسانی" : "Refresh"}
        </button>
      </div>

      {/* Filter buttons */}
      <div className="flex gap-2">
        {["all", "info", "warning", "critical"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === f ? "bg-cyan-600/30 text-cyan-300 border border-cyan-500/40" : "bg-white/5 text-white/60 border border-white/10"}`}>
            {f === "all" ? (isFA ? "همه" : "All") : (isFA ? SEVERITY_META[f]?.labelFa : SEVERITY_META[f]?.labelEn)}
          </button>
        ))}
      </div>

      {/* Logs list */}
      <div className="rounded-2xl border border-white/10 overflow-hidden divide-y divide-white/5" style={{ background: "rgba(255,255,255,0.02)" }}>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <RefreshCw className="w-6 h-6 text-white/30 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12">
            <Shield className="w-8 h-8 text-white/15 mb-2" />
            <p className="text-white/40 text-sm">{isFA ? "لاگی وجود ندارد" : "No logs found"}</p>
          </div>
        ) : (
          filtered.map(log => {
            const meta = SEVERITY_META[log.severity] || SEVERITY_META.info;
            const eventLabel = EVENT_LABELS[log.event_type] || { fa: log.event_type, en: log.event_type };
            const Icon = meta.Icon;
            return (
              <div key={log.id} className="flex gap-3 px-4 py-3 hover:bg-white/3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: `${meta.color}1a`, border: `1px solid ${meta.color}33` }}>
                  <Icon className="w-4 h-4" style={{ color: meta.color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-white text-sm font-medium">{isFA ? eventLabel.fa : eventLabel.en}</p>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full"
                      style={{ background: `${meta.color}1a`, color: meta.color }}>
                      {isFA ? meta.labelFa : meta.labelEn}
                    </span>
                  </div>
                  {log.user_email && <p className="text-white/50 text-xs mt-0.5">{log.user_email}</p>}
                  {log.details && <p className="text-white/40 text-xs mt-1">{log.details}</p>}
                  <div className="flex items-center gap-3 mt-1">
                    <p className="text-white/25 text-[10px]">{fmt(log.created_date)}</p>
                    {log.ip_address && log.ip_address !== "unknown" && <p className="text-white/25 text-[10px]">IP: {log.ip_address}</p>}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}