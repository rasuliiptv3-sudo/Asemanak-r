import { useState } from "react";
import { X } from "lucide-react";
import FeedbackSection from "@/components/settings/FeedbackSection";

/**
 * Full-screen modal wrapper around FeedbackSection — used by the profile dropdown.
 */
export default function FeedbackModal({ onClose }) {
  const [isFA] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"; } catch { return true; }
  });

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative z-10 w-full max-w-lg max-h-[85vh] overflow-y-auto rounded-2xl"
        style={{ background: "rgba(20,14,30,0.98)", border: "1px solid rgba(168,85,247,0.3)", boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4"
          style={{ background: "rgba(20,14,30,0.98)", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <h2 className="text-white font-bold text-base">
            {isFA ? "نظریات کاربران" : "User Comments"}
          </h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors">
            <X className="w-4 h-4 text-white/60" />
          </button>
        </div>

        {/* Feedback content */}
        <div className="p-4">
          <FeedbackSection isFA={isFA} rtl={isFA} />
        </div>
      </div>
    </div>
  );
}