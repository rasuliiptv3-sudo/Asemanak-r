import { Check, X } from "lucide-react";

// Touch-friendly bottom sheet for selecting an option on mobile.
// Replaces native <select> dropdowns inside Settings on narrow screens.
export default function MobileSelectSheet({ label, options, value, rtl, onSelect, onClose }) {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-end"
      style={{ direction: rtl ? "rtl" : "ltr" }}
    >
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div
        className="relative w-full rounded-t-3xl max-h-[70vh] flex flex-col"
        style={{
          background: "rgb(var(--chrome-bg-rgb) / 0.98)",
          borderTop: "1px solid rgb(var(--chrome-border-rgb) / 0.15)",
          paddingBottom: "calc(env(safe-area-inset-bottom) + 12px)",
          animation: "sheetUp 0.22s ease-out",
        }}
      >
        <style>{`@keyframes sheetUp{from{transform:translateY(100%)}to{transform:translateY(0)}}`}</style>
        {/* Grabber */}
        <div className="flex justify-center pt-2 pb-1">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>
        <div className="flex items-center justify-between px-5 pt-1 pb-3 border-b border-white/10">
          <span className="text-white font-bold text-sm truncate">{label}</span>
          <button onClick={onClose} className="text-white/50 hover:text-white p-1 flex-shrink-0 min-w-[44px] min-h-[44px] flex items-center justify-center">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="overflow-y-auto px-3 py-2" style={{ overscrollBehavior: "none" }}>
          {options.map((o) => {
            const val = o.value !== undefined ? o.value : o;
            const lbl = o.label || o;
            const selected = String(val) === String(value);
            return (
              <button
                key={val}
                onClick={() => onSelect(val)}
                className={`w-full flex items-center justify-between px-4 py-3.5 rounded-xl text-sm transition-colors my-0.5 ${
                  selected
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                    : "text-white/80 border border-transparent hover:bg-white/5"
                }`}
              >
                <span className="truncate text-right" style={{ direction: rtl ? "rtl" : "ltr" }}>{lbl}</span>
                {selected && <Check className="w-4 h-4 flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}