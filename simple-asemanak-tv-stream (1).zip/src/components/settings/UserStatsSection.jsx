import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { RefreshCw, Users, Shield, Calendar, Mail } from "lucide-react";

export default function UserStatsSection({ isFA }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const all = await base44.entities.User.list("-created_date", 200);
      setUsers(all || []);
    } catch {}
    setLoading(false);
  };

  const adminCount = users.filter(u => u.role === "admin").length;
  const userCount = users.filter(u => u.role !== "admin").length;

  const t = isFA
    ? { title: "آمار کاربران", total: "کل کاربران", admins: "ادمین", regular: "کاربر عادی", list: "لیست کاربران", people: "نفر", none: "هیچ کاربری یافت نشد" }
    : { title: "User Stats", total: "Total Users", admins: "Admins", regular: "Regular", list: "User List", people: "users", none: "No users found" };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${isFA ? "text-right" : ""}`}>{t.title}</h2>
        <button onClick={loadUsers} className="p-2 rounded-lg hover:bg-white/10 transition-colors">
          <RefreshCw className={`w-4 h-4 text-white/50 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl p-4 text-center border border-cyan-500/20" style={{ background: "rgba(6,182,212,0.08)" }}>
          <p className="text-3xl font-black text-cyan-400">{users.length}</p>
          <p className="text-white/50 text-xs mt-1">{t.total}</p>
        </div>
        <div className="rounded-2xl p-4 text-center border border-purple-500/20" style={{ background: "rgba(168,85,247,0.08)" }}>
          <p className="text-3xl font-black text-purple-400">{adminCount}</p>
          <p className="text-white/50 text-xs mt-1">{t.admins}</p>
        </div>
        <div className="rounded-2xl p-4 text-center border border-white/10" style={{ background: "rgba(255,255,255,0.04)" }}>
          <p className="text-3xl font-black text-white">{userCount}</p>
          <p className="text-white/50 text-xs mt-1">{t.regular}</p>
        </div>
      </div>

      {/* User list */}
      <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.03)" }}>
        <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
          <p className="text-sm font-bold text-white/60 uppercase tracking-wider">{t.list}</p>
          <span className="text-xs text-white/30">{users.length} {t.people}</span>
        </div>
        {loading ? (
          <div className="p-8 flex justify-center">
            <div className="w-8 h-8 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          </div>
        ) : users.length === 0 ? (
          <div className="p-8 text-center text-white/30 text-sm">{t.none}</div>
        ) : (
          <div className="divide-y divide-white/5 max-h-96 overflow-y-auto">
            {users.map((u) => (
              <div key={u.id} className="flex items-center gap-3 px-4 py-3">
                <div className="w-8 h-8 rounded-full bg-cyan-600/20 border border-cyan-500/20 flex items-center justify-center flex-shrink-0 text-xs font-bold text-cyan-400">
                  {(u.full_name || u.email || "?")[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium truncate">{u.full_name || "—"}</p>
                  <p className="text-xs text-white/40 truncate flex items-center gap-1">
                    <Mail className="w-3 h-3 flex-shrink-0" />{u.email}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                    u.role === "admin"
                      ? "bg-purple-500/20 text-purple-400 border-purple-500/30"
                      : "bg-white/5 text-white/40 border-white/10"
                  }`}>
                    {u.role || "user"}
                  </span>
                  {u.created_date && (
                    <span className="text-[10px] text-white/25 flex items-center gap-1">
                      <Calendar className="w-2.5 h-2.5" />
                      {new Date(u.created_date).toLocaleDateString("fa-IR")}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}