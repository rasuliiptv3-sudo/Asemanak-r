import { useState, useEffect } from "react";
import { LocateFixed, Cloud, Sun, CloudRain, CloudSnow, Wind, CloudSun, CloudFog, Clock, MapPin, ChevronDown } from "lucide-react";
import { CITIES, getSelectedCity, setSelectedCity, detectCityByGeo } from "@/lib/cities";
import { TIMEZONES } from "@/components/DigitalClock";
import { useIsMobile } from "@/lib/useIsMobile";
import MobileSelectSheet from "@/components/settings/MobileSelectSheet";

const WEATHER = {
  0: { Icon: Sun, fa: "آفتابی" }, 1: { Icon: Sun, fa: "نیمه‌آفتابی" }, 2: { Icon: CloudSun, fa: "نیمه‌ابری" },
  3: { Icon: Cloud, fa: "ابری" }, 45: { Icon: CloudFog, fa: "مه‌آلود" }, 48: { Icon: CloudFog, fa: "مه یخی" },
  51: { Icon: CloudRain, fa: "نم‌نم" }, 53: { Icon: CloudRain, fa: "نم‌نم" }, 55: { Icon: CloudRain, fa: "نم‌نم" },
  61: { Icon: CloudRain, fa: "باران" }, 63: { Icon: CloudRain, fa: "باران" }, 65: { Icon: CloudRain, fa: "باران سنگین" },
  71: { Icon: CloudSnow, fa: "برف" }, 73: { Icon: CloudSnow, fa: "برف" }, 75: { Icon: CloudSnow, fa: "برف سنگین" },
  80: { Icon: CloudRain, fa: "رگبار" }, 81: { Icon: CloudRain, fa: "رگبار" }, 82: { Icon: CloudRain, fa: "رگبار سنگین" },
  95: { Icon: Wind, fa: "رعد و برق" }, 96: { Icon: Wind, fa: "رعد و برق" }, 99: { Icon: Wind, fa: "رعد و برق" },
};

function Toggle({ value, onChange }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${value ? "bg-cyan-500" : "bg-white/20"}`}>
      <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${value ? "translate-x-6" : "translate-x-0.5"}`} />
    </button>
  );
}
function Row({ label, description, children, rtl }) {
  return (
    <div className={`flex items-center justify-between py-4 border-b border-white/10 ${rtl ? "flex-row-reverse" : ""}`}>
      <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
        <p className="text-sm text-white font-medium">{label}</p>
        {description && <p className="text-xs text-white/40 mt-0.5">{description}</p>}
      </div>
      {children}
    </div>
  );
}
function SelectRow({ label, description, value, options, onChange, rtl }) {
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);
  const current = options.find((o) => (o.value !== undefined ? o.value : o) === value);
  const currentLabel = current ? (current.label || current) : value;

  if (isMobile) {
    return (
      <>
        <div className={`flex items-center justify-between py-4 border-b border-white/10 ${rtl ? "flex-row-reverse" : ""}`}>
          <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
            <p className="text-sm text-white font-medium">{label}</p>
            {description && <p className="text-xs text-white/40 mt-0.5">{description}</p>}
          </div>
          <button onClick={() => setOpen(true)}
            className="bg-white/10 border border-white/15 text-white text-xs rounded-lg px-3 py-2 flex items-center justify-between gap-1.5 flex-shrink-0 min-w-[120px] active:scale-95 transition-transform">
            <span className="truncate">{currentLabel}</span>
            <ChevronDown className="w-3.5 h-3.5 text-white/50 flex-shrink-0" />
          </button>
        </div>
        {open && (
          <MobileSelectSheet label={label} options={options} value={value} rtl={rtl}
            onSelect={(v) => { onChange(v); setOpen(false); }} onClose={() => setOpen(false)} />
        )}
      </>
    );
  }

  return (
    <div className={`flex items-center justify-between py-4 border-b border-white/10 ${rtl ? "flex-row-reverse" : ""}`}>
      <div className={`flex-1 min-w-0 ${rtl ? "pl-4 text-right" : "pr-4"}`}>
        <p className="text-sm text-white font-medium">{label}</p>
        {description && <p className="text-xs text-white/40 mt-0.5">{description}</p>}
      </div>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="bg-white/10 border border-white/10 text-white text-xs rounded-lg px-3 py-1.5 outline-none cursor-pointer flex-shrink-0">
        {options.map((o) => <option key={o.value || o} value={o.value || o} className="bg-gray-900">{o.label || o}</option>)}
      </select>
    </div>
  );
}

export default function DateTimeWeatherSection({ get, set, isFA, rtl }) {
  const [city, setCity] = useState(getSelectedCity());
  const [weather, setWeather] = useState(null);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const cache = JSON.parse(localStorage.getItem("ayeneh_weather_cache") || "null");
        if (cache && cache.id === city.id && Date.now() - cache.t < 30 * 60 * 1000) { setWeather(cache.data); return; }
        const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.long}&current=temperature_2m,weather_code&timezone=${city.tz}`);
        const d = await res.json();
        if (cancelled) return;
        const data = { temp: Math.round(d.current?.temperature_2m), code: d.current?.weather_code };
        setWeather(data);
        localStorage.setItem("ayeneh_weather_cache", JSON.stringify({ t: Date.now(), id: city.id, data }));
      } catch {}
    };
    load();
    return () => { cancelled = true; };
  }, [city.id]);

  const pick = (id) => { const c = setSelectedCity(id); setCity(c); };
  const detect = async () => { setLocating(true); const c = await detectCityByGeo(); setLocating(false); if (c) setCity(c); };

  const W = (weather && WEATHER[weather.code]) || { Icon: Cloud, fa: "—" };
  const WIcon = W.Icon;

  return (
    <div className="max-w-lg">
      <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest mb-4 ${rtl ? "text-right" : ""}`}>
        {isFA ? "تاریخ، ساعت و آب‌وهوا" : "Date, Time & Weather"}
      </h2>

      {/* Weather card */}
      <div className="rounded-2xl border border-white/10 p-5 mb-5 flex items-center gap-4"
        style={{ background: "linear-gradient(135deg, rgba(6,182,212,0.10), rgba(168,85,247,0.08))" }}>
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
          style={{ background: "rgba(6,182,212,0.15)", border: "1px solid rgba(6,182,212,0.3)" }}>
          <WIcon className="w-7 h-7 text-cyan-400" />
        </div>
        <div className="flex-1">
          <p className="text-white font-bold text-lg" style={{ fontFamily: "Vazirmatn, sans-serif" }}>{city.nameFa}</p>
          <p className="text-white/60 text-xs" style={{ fontFamily: "Vazirmatn, sans-serif" }}>
            {weather ? `${weather.temp}°C · ${W.fa}` : (isFA ? "در حال دریافت..." : "Loading...")}
          </p>
        </div>
        <button onClick={detect} disabled={locating}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-bold text-white transition-all hover:scale-[1.03] disabled:opacity-60 flex-shrink-0"
          style={{ background: "linear-gradient(135deg, #7b2cbf, #00d4ff)" }}>
          <LocateFixed className="w-3.5 h-3.5" /> {locating ? "..." : (isFA ? "موقعیت من" : "My Location")}
        </button>
      </div>

      {/* City / country selection */}
      <div className="mb-5">
        <p className={`text-xs text-white/40 mb-2 flex items-center gap-1.5 ${rtl ? "text-right" : ""}`}>
          <MapPin className="w-3 h-3" /> {isFA ? "انتخاب شهر / کشور" : "Select City / Country"}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {CITIES.map(c => (
            <button key={c.id} onClick={() => pick(c.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${city.id === c.id ? "bg-cyan-600/30 text-cyan-300 border border-cyan-500/40" : "bg-white/5 text-white/60 border border-white/10 hover:border-white/20"}`}
              style={{ fontFamily: "Vazirmatn, sans-serif" }}>
              {c.nameFa}
            </button>
          ))}
        </div>
      </div>

      {/* Clock settings */}
      <p className={`text-xs text-white/40 mb-2 mt-2 flex items-center gap-1.5 ${rtl ? "text-right" : ""}`}>
        <Clock className="w-3 h-3" /> {isFA ? "تنظیمات ساعت" : "Clock Settings"}
      </p>

      <Row label={isFA ? "ساعت ۲۴ ساعته" : "24-hour clock"} rtl={rtl}>
        <Toggle value={get("clockFormat", "24") === "24"} onChange={v => set("clockFormat", v ? "24" : "12")} />
      </Row>
      <Row label={isFA ? "نمایش همیشگی ساعت" : "Clock always visible"} rtl={rtl}>
        <Toggle value={get("clockAlwaysVisible", true)} onChange={v => set("clockAlwaysVisible", v)} />
      </Row>
      <SelectRow label={isFA ? "موقعیت ساعت" : "Clock position"} value={get("clockPosition", "center")}
        options={[
          { value: "center", label: isFA ? "مرکز" : "Center" },
          { value: "top-right", label: isFA ? "بالا راست" : "Top right" },
          { value: "top-left", label: isFA ? "بالا چپ" : "Top left" },
          { value: "bottom-right", label: isFA ? "پایین راست" : "Bottom right" },
          { value: "bottom-left", label: isFA ? "پایین چپ" : "Bottom left" },
        ]}
        onChange={v => set("clockPosition", v)} rtl={rtl} />
      <SelectRow label={isFA ? "اندازه ساعت" : "Clock size"} value={get("clockSize", "100")}
        options={[{ value: "100", label: "100%" }, { value: "125", label: "125%" }, { value: "150", label: "150%" }, { value: "200", label: "200%" }]}
        onChange={v => set("clockSize", v)} rtl={rtl} />
      <SelectRow label={isFA ? "منطقه زمانی" : "Timezone"} value={get("clockTimezone", "Asia/Tehran")}
        options={TIMEZONES.map(tz => ({ value: tz.value, label: isFA ? tz.labelFa : tz.labelEn }))}
        onChange={v => set("clockTimezone", v)} rtl={rtl} />

      {/* Clock time adjustment — grouped in a highlighted card for easy access */}
      <div className="mt-4 rounded-2xl border border-cyan-500/20 p-4" style={{ background: "rgba(6,182,212,0.06)" }}>
        <p className={`text-xs font-bold text-cyan-400 mb-1 flex items-center gap-1.5 ${rtl ? "text-right" : ""}`}>
          <Clock className="w-3 h-3" /> {isFA ? "تنظیم دقیق ساعت" : "Fine Clock Adjustment"}
        </p>
        <p className={`text-[11px] text-white/40 mb-3 ${rtl ? "text-right" : ""}`}>
          {isFA ? "اختلاف ساعت، دقیقه و ثانیه برای تنظیم دستی" : "Hour, minute and second offsets for manual adjustment"}
        </p>
        <SelectRow label={isFA ? "اختلاف ساعت" : "Hour offset"} value={String(get("clockOffset", 0))}
          options={Array.from({ length: 25 }, (_, i) => { const v = i - 12; return { value: String(v), label: (v > 0 ? "+" : "") + v }; })}
          onChange={v => set("clockOffset", Number(v))} rtl={rtl} />
        <SelectRow label={isFA ? "اختلاف دقیقه" : "Minute offset"} value={String(get("clockOffsetMinutes", 0))}
          options={Array.from({ length: 60 }, (_, i) => { const v = i; return { value: String(v), label: (v > 0 ? "+" : "") + v }; })}
          onChange={v => set("clockOffsetMinutes", Number(v))} rtl={rtl} />
        <SelectRow label={isFA ? "اختلاف ثانیه" : "Second offset"} value={String(get("clockOffsetSeconds", 0))}
          options={Array.from({ length: 60 }, (_, i) => { const v = i; return { value: String(v), label: (v > 0 ? "+" : "") + v }; })}
          onChange={v => set("clockOffsetSeconds", Number(v))} rtl={rtl} />
      </div>
    </div>
  );
}