import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Loader2, CheckCircle, AlertCircle, Trash2, Tv, ChevronDown } from "lucide-react";
import { useIsMobile } from "@/lib/useIsMobile";
import MobileSelectSheet from "@/components/settings/MobileSelectSheet";

// Preset channels - popular Afghan channels with verified working streams (iptv-org)
const PRESET_CHANNELS = [
  {
    name: "Tolo TV",
    name_fa: "طلوع",
    stream_url: "https://tgn.bozztv.com/eshgtv-dvrfl05/gin-tolohd/tracks-v1a1/mono.m3u8",
    logo_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Tolou_TV_Logo.png/200px-Tolou_TV_Logo.png",
    category: "entertainment",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: true,
  },
  {
    name: "TOLOnews",
    name_fa: "طلوع نیوز",
    stream_url: "https://tgn.bozztv.com/eshgtv-dvrfl05/gin-tolonews/index.m3u8",
    logo_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Tolou_TV_Logo.png/200px-Tolou_TV_Logo.png",
    category: "news",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Lemar TV",
    name_fa: "لمر",
    stream_url: "https://tgn.bozztv.com/eshgtv-dvrfl05/gin-lemar/index.m3u8",
    logo_url: "",
    category: "entertainment",
    country: "Afghanistan",
    language: "Pashto",
    is_active: true,
    is_featured: false,
  },
  {
    name: "RTA TV",
    name_fa: "آرتی‌آی",
    stream_url: "https://rta-tv.akamaized.net/live/SD/RTA-1/RTA/RTA-1.m3u8",
    logo_url: "",
    category: "general",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Kayhan TV",
    name_fa: "کیهان",
    stream_url: "https://playout395.livestreamingcdn.com/live/Stream1/playlist.m3u8",
    logo_url: "",
    category: "entertainment",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Tamadon TV",
    name_fa: "تمدن",
    stream_url: "https://hls.tamadon.live/hls/stream.m3u8",
    logo_url: "",
    category: "religious",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Shamshad TV",
    name_fa: "شمشاد",
    stream_url: "https://5a1178b42cc03.streamlock.net/shamshadtelevision/shamshadtelevision/playlist.m3u8",
    logo_url: "",
    category: "entertainment",
    country: "Afghanistan",
    language: "Pashto",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Bahar TV",
    name_fa: "بهار",
    stream_url: "https://59d39900ebfb8.streamlock.net/bahartv/bahartv/playlist.m3u8",
    logo_url: "",
    category: "entertainment",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Dunya Naw TV",
    name_fa: "دنیا نو",
    stream_url: "https://dunyanhls.wns.live/hls/stream.m3u8",
    logo_url: "",
    category: "news",
    country: "Afghanistan",
    language: "Pashto",
    is_active: true,
    is_featured: false,
  },
  {
    name: "Faza TV",
    name_fa: "فضا تی‌وی",
    stream_url: "https://live20.bozztv.com/gin-36bay4/gin-fazatv/tracks-v1a1/mono.m3u8",
    logo_url: "https://i.imgur.com/GpxjzNm.png",
    category: "entertainment",
    country: "Afghanistan",
    language: "Dari",
    is_active: true,
    is_featured: false,
  },
];

export default function AddChannelTab({ isFA, rtl }) {
  const isMobile = useIsMobile();
  const [name, setName] = useState("");
  const [nameFa, setNameFa] = useState("");
  const [streamUrl, setStreamUrl] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [category, setCategory] = useState("general");
  const [country, setCountry] = useState("");
  const [language, setLanguage] = useState("");
  const [status, setStatus] = useState(null); // null | "loading" | "success" | "error"
  const [statusMsg, setStatusMsg] = useState("");
  const [addingPreset, setAddingPreset] = useState(null);
  const [catSheetOpen, setCatSheetOpen] = useState(false);
  const [countrySheetOpen, setCountrySheetOpen] = useState(false);

  const categories = ["general","news","sports","entertainment","movies","music","kids","documentary","religious","lifestyle"];
  const countries = ["Afghanistan","Iran","India","Pakistan","Turkey","UAE","Saudi Arabia","USA","UK","Germany","France"];
  const categoryOptions = categories.map(c => ({ value: c, label: c.charAt(0).toUpperCase() + c.slice(1) }));
  const countryOptions = [{ value: "", label: isFA ? "— انتخاب —" : "— Select —" }, ...countries.map(c => ({ value: c, label: c }))];

  const handleAdd = async () => {
    if (!name.trim() || !streamUrl.trim()) return;
    setStatus("loading");
    try {
      await base44.entities.Channel.create({
        name: name.trim(),
        name_fa: nameFa.trim() || undefined,
        stream_url: streamUrl.trim(),
        logo_url: logoUrl.trim() || undefined,
        category,
        country: country.trim() || undefined,
        language: language.trim() || undefined,
        is_active: true,
        is_featured: false,
      });
      setStatus("success");
      setStatusMsg(isFA ? "کانال اضافه شد ✓" : "Channel added ✓");
      setName(""); setNameFa(""); setStreamUrl(""); setLogoUrl(""); setCountry(""); setLanguage("");
      setTimeout(() => setStatus(null), 3000);
    } catch {
      setStatus("error");
      setStatusMsg(isFA ? "خطا در افزودن" : "Error adding channel");
    }
  };

  const handleAddPreset = async (preset, idx) => {
    setAddingPreset(idx);
    try {
      await base44.entities.Channel.create({ ...preset });
    } catch {}
    setAddingPreset(null);
  };

  return (
    <div className="max-w-lg space-y-6">
      <h2 className={`text-xs font-bold text-white/40 uppercase tracking-widest ${rtl ? "text-right" : ""}`}>
        {isFA ? "افزودن کانال دستی" : "Add Channel Manually"}
      </h2>

      {/* Preset channels */}
      <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
        <div className="px-4 py-3 border-b border-white/10">
          <p className="text-white/60 text-xs font-bold uppercase tracking-wide">{isFA ? "کانال‌های آماده" : "Quick Add Presets"}</p>
        </div>
        <div className="divide-y divide-white/5">
          {PRESET_CHANNELS.map((ch, idx) => (
            <div key={idx} className="flex items-center gap-3 px-4 py-3">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                {ch.logo_url ? (
                  <img src={ch.logo_url} alt={ch.name} className="w-full h-full rounded-full object-cover" onError={e => { e.target.style.display='none'; }} />
                ) : (
                  <Tv className="w-4 h-4 text-white/30" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium">{ch.name_fa || ch.name}</p>
                <p className="text-white/30 text-[10px] truncate">{ch.stream_url}</p>
              </div>
              <button
                onClick={() => handleAddPreset(ch, idx)}
                disabled={addingPreset === idx}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 disabled:opacity-40 transition-colors flex-shrink-0"
              >
                {addingPreset === idx ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                {isFA ? "افزودن" : "Add"}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Manual form */}
      <div className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
        <div className="px-4 py-3 border-b border-white/10">
          <p className="text-white/60 text-xs font-bold uppercase tracking-wide">{isFA ? "افزودن دستی" : "Custom Channel"}</p>
        </div>
        <div className="px-4 py-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-white/40 mb-1 block">{isFA ? "نام انگلیسی *" : "Name (EN) *"}</label>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="Channel Name"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 block">{isFA ? "نام فارسی" : "Name (FA)"}</label>
              <input value={nameFa} onChange={e => setNameFa(e.target.value)} placeholder="نام کانال"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
            </div>
          </div>

          <div>
            <label className="text-xs text-white/40 mb-1 block">{isFA ? "لینک پخش *" : "Stream URL *"}</label>
            <input value={streamUrl} onChange={e => setStreamUrl(e.target.value)}
              placeholder="https://... (m3u8 / mp4 / ts)"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
          </div>

          <div>
            <label className="text-xs text-white/40 mb-1 block">{isFA ? "لینک لوگو" : "Logo URL"}</label>
            <input value={logoUrl} onChange={e => setLogoUrl(e.target.value)} placeholder="https://..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-white/40 mb-1 block">{isFA ? "دسته‌بندی" : "Category"}</label>
              {isMobile ? (
                <>
                  <button type="button" data-remote onClick={() => setCatSheetOpen(true)}
                    className="w-full bg-white/10 border border-white/10 text-white text-xs rounded-xl px-2 py-2.5 outline-none flex items-center justify-between gap-1 capitalize active:scale-95 transition-transform">
                    <span className="truncate">{category}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-white/50 flex-shrink-0" />
                  </button>
                  {catSheetOpen && (
                    <MobileSelectSheet label={isFA ? "دسته‌بندی" : "Category"} options={categoryOptions} value={category} rtl={rtl}
                      onSelect={(v) => { setCategory(v); setCatSheetOpen(false); }} onClose={() => setCatSheetOpen(false)} />
                  )}
                </>
              ) : (
                <select value={category} onChange={e => setCategory(e.target.value)} data-remote
                  className="w-full bg-white/10 border border-white/10 text-white text-xs rounded-xl px-2 py-2.5 outline-none">
                  {categories.map(c => <option key={c} value={c} className="bg-gray-900 capitalize">{c}</option>)}
                </select>
              )}
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 block">{isFA ? "کشور" : "Country"}</label>
              {isMobile ? (
                <>
                  <button type="button" data-remote onClick={() => setCountrySheetOpen(true)}
                    className="w-full bg-white/10 border border-white/10 text-white text-xs rounded-xl px-2 py-2.5 outline-none flex items-center justify-between gap-1 active:scale-95 transition-transform">
                    <span className="truncate">{country || (isFA ? "— انتخاب —" : "— Select —")}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-white/50 flex-shrink-0" />
                  </button>
                  {countrySheetOpen && (
                    <MobileSelectSheet label={isFA ? "کشور" : "Country"} options={countryOptions} value={country} rtl={rtl}
                      onSelect={(v) => { setCountry(v); setCountrySheetOpen(false); }} onClose={() => setCountrySheetOpen(false)} />
                  )}
                </>
              ) : (
                <select value={country} onChange={e => setCountry(e.target.value)} data-remote
                  className="w-full bg-white/10 border border-white/10 text-white text-xs rounded-xl px-2 py-2.5 outline-none">
                  <option value="" className="bg-gray-900">{isFA ? "— انتخاب —" : "— Select —"}</option>
                  {countries.map(c => <option key={c} value={c} className="bg-gray-900">{c}</option>)}
                </select>
              )}
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1 block">{isFA ? "زبان" : "Language"}</label>
              <input value={language} onChange={e => setLanguage(e.target.value)} placeholder="Farsi"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-500/50" />
            </div>
          </div>

          {status && (
            <div className={`flex items-center gap-2 text-xs px-3 py-2 rounded-lg ${status === "success" ? "bg-green-500/10 text-green-400" : status === "error" ? "bg-red-500/10 text-red-400" : "bg-cyan-500/10 text-cyan-400"}`}>
              {status === "loading" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : status === "success" ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
              {statusMsg}
            </div>
          )}

          <button onClick={handleAdd} disabled={!name.trim() || !streamUrl.trim() || status === "loading"}
            className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 py-3 rounded-xl text-sm font-bold text-white transition-colors flex items-center justify-center gap-2">
            {status === "loading" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {isFA ? "افزودن کانال" : "Add Channel"}
          </button>
        </div>
      </div>
    </div>
  );
}