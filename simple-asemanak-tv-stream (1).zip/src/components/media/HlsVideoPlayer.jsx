import { useEffect, useRef, useState } from "react";
import { Play, Pause, Rewind, FastForward, Volume2, VolumeX, Sun, Settings2, Loader2, Maximize, Shrink, Gauge, EyeOff, Eye } from "lucide-react";
import Hls from "hls.js";
import SeriesCoverOverlay from "@/components/media/SeriesCoverOverlay";
import { useIsTV } from "@/lib/useIsTV";

const SCREEN_SIZES = [
  { value: "full", label: "کامل", labelEn: "Full", scale: 1.0 },
  { value: "large", label: "بزرگ", labelEn: "Large", scale: 0.85 },
  { value: "medium", label: "متوسط", labelEn: "Medium", scale: 0.65 },
  { value: "small", label: "کوچک", labelEn: "Small", scale: 0.45 },
];

export default function HlsVideoPlayer({ src, onVideoClick, seriesTitle, seriesPoster, isAdmin = false, posterPosition }) {
  const videoRef = useRef(null);
  const hlsRef = useRef(null);
  const isTV = useIsTV();
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(100);
  const [muted, setMuted] = useState(true);
  const [brightness, setBrightness] = useState(1);
  const [levels, setLevels] = useState([]);
  const [currentLevel, setCurrentLevel] = useState(-1);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [screenSize, setScreenSize] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").displaySize || "full"; } catch { return "full"; }
  });
  const [showScreenMenu, setShowScreenMenu] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [buffering, setBuffering] = useState(false);
  // Hide-logo: -1 = off, 0 = top-right, 1 = top-left, 2 = bottom-left, 3 = bottom-right
  const [hideLogoPos, setHideLogoPos] = useState(-1);
  const controlsTimer = useRef(null);

  const isHls = src && /\.m3u8(\?|#|$)/i.test(src);
  // Start overlay ONLY for HLS streams — gallery videos start instantly, no dark cover.
  const [showStartOverlay, setShowStartOverlay] = useState(isHls);
  const currentSize = SCREEN_SIZES.find(s => s.value === screenSize) || SCREEN_SIZES[0];
  // Configurable cover duration from settings (default 3s)
  const coverMs = (() => { try { return (parseInt(JSON.parse(localStorage.getItem('ayeneh_settings') || '{}').coverDuration) || 3) * 1000; } catch { return 3000; } })();

  // Initialize HLS or native playback
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !src) return;

    setLoading(true);
    let hls = null;

    if (isHls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, lowLatencyMode: false, maxBufferLength: 30, maxMaxBufferLength: 60 });
      hlsRef.current = hls;
      hls.loadSource(src);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        setLoading(false);
        video.muted = true;
        video.play().then(() => { setMuted(true); }).catch(() => { setMuted(true); });
        const lvls = hls.levels.map((l, i) => ({
          index: i, height: l.height, bitrate: l.bitrate,
          label: l.height ? `${l.height}p` : `${Math.round(l.bitrate / 1000)}kbps`,
        }));
        setLevels(lvls);
      });

      hls.on(Hls.Events.LEVEL_SWITCHED, (_, data) => setCurrentLevel(data.level));

      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR: try { hls.startLoad(); } catch {} break;
            case Hls.ErrorTypes.MEDIA_ERROR: try { hls.recoverMediaError(); } catch {} break;
            default: try { hls.destroy(); } catch {} break;
          }
        }
      });
    } else {
      // Fallback: either non-HLS gallery video (src set via JSX prop) or HLS URL
      // on a browser without hls.js support — try native HTML5 video source binding
      // (Safari/iOS play HLS natively; other browsers will fail gracefully via onError).
      video.muted = true;
      setMuted(true);
      if (isHls) video.src = src;
      const clearLoading = () => setLoading(false);
      video.addEventListener('loadeddata', clearLoading, { once: true });
      video.addEventListener('canplay', clearLoading, { once: true });
      // If autoPlay failed (browser policy), try play() once data is ready
      const tryPlay = () => {
        if (video.paused) { video.play().then(() => setMuted(true)).catch(() => {}); }
      };
      video.addEventListener('canplay', tryPlay, { once: true });
      const fallbackTimer = setTimeout(() => { setLoading(false); tryPlay(); }, 2000);
      video._fallbackTimer = fallbackTimer;
    }

    return () => {
      if (hls) { try { hls.destroy(); } catch {} hlsRef.current = null; }
      if (video) {
        if (video._fallbackTimer) clearTimeout(video._fallbackTimer);
        try { video.pause(); video.removeAttribute("src"); video.load(); } catch {}
      }
    };
  }, [src, isHls]);

  // NOTE: No polling interval — native events (onTimeUpdate/onPlay/onPause/onLoadedMetadata)
  // drive state updates. Polling causes re-renders every 500ms which stutter gallery playback.

  useEffect(() => {
    const v = videoRef.current;
    if (v) v.playbackRate = playbackRate;
  }, [playbackRate]);

  // Controls start hidden — shown on tap via handleVideoClick or flashControls

  // ── TV remote control ──
  // OK/Enter/Space → play/pause · ←/→ → seek ±10s · ↑/↓ → volume · Back → exit
  const flashControls = () => {
    setShowControls(true);
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    controlsTimer.current = setTimeout(() => setShowControls(false), 4000);
  };

  useEffect(() => {
    const onKey = (e) => {
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.target?.isContentEditable) return;
      const v = videoRef.current;
      if (!v) return;
      switch (e.key) {
        case "Enter":
        case " ":
        case "XF86OK":
        case "Accept":
          e.preventDefault();
          e.stopPropagation();
          togglePlay();
          flashControls();
          break;
        case "ArrowLeft":
          e.preventDefault();
          e.stopPropagation();
          seekBy(-10);
          flashControls();
          break;
        case "ArrowRight":
          e.preventDefault();
          e.stopPropagation();
          seekBy(10);
          flashControls();
          break;
        case "ArrowUp":
          e.preventDefault();
          e.stopPropagation();
          { const nv = Math.min(100, (muted ? 0 : volume) + 10); handleVolume(nv); flashControls(); }
          break;
        case "ArrowDown":
          e.preventDefault();
          e.stopPropagation();
          { const nv = Math.max(0, (muted ? 0 : volume) - 10); handleVolume(nv); flashControls(); }
          break;
        case "MediaPlay":
        case "MediaPause":
        case "MediaPlayPause":
          e.preventDefault();
          e.stopPropagation();
          togglePlay();
          flashControls();
          break;
        case "MediaRewind":
        case "MediaTrackPrevious":
          e.preventDefault();
          e.stopPropagation();
          seekBy(-10);
          flashControls();
          break;
        case "MediaFastForward":
        case "MediaTrackNext":
          e.preventDefault();
          e.stopPropagation();
          seekBy(10);
          flashControls();
          break;
        case "0":
        case "h":
          e.preventDefault();
          e.stopPropagation();
          setHideLogoPos(p => (p + 1) % 5);
          flashControls();
          break;
        default:
          break;
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [currentTime, duration, muted, volume]);

  // Start overlay hides the instant the video begins playing (onPlaying).
  // Fallback timer removed — overlay is cleared by the play() handler + onPlaying.

  const handleVideoClick = () => {
    // First tap on gallery video unmutes it (fresh user gesture)
    const v = videoRef.current;
    if (v && !isHls && v.muted) {
      try { v.muted = false; setMuted(false); setVolume(100); } catch {}
    }
    setShowControls(v => {
      const next = !v;
      if (controlsTimer.current) clearTimeout(controlsTimer.current);
      if (next) controlsTimer.current = setTimeout(() => setShowControls(false), 4000);
      return next;
    });
    if (onVideoClick) onVideoClick();
  };

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
  };

  const seekTo = (t) => {
    const v = videoRef.current;
    if (v) {
      v.currentTime = t;
      setCurrentTime(t);
      // Ensure playback resumes after seeking (seek can leave video paused)
      if (v.paused) v.play().catch(() => {});
    }
  };
  const seekBy = (delta) => seekTo(Math.max(0, Math.min(duration, currentTime + delta)));

  const handleVolume = (val) => {
    setVolume(val); setMuted(val === 0);
    const v = videoRef.current;
    if (v) { v.volume = val / 100; v.muted = val === 0; }
  };

  const toggleMute = () => {
    if (muted || volume === 0) {
      setMuted(false); setVolume(50);
      const v = videoRef.current;
      if (v) { v.muted = false; v.volume = 0.5; }
    } else {
      setMuted(true);
      const v = videoRef.current; if (v) v.muted = true;
    }
  };

  const changeSpeed = (rate) => { setPlaybackRate(rate); setShowSpeedMenu(false); const v = videoRef.current; if (v) v.playbackRate = rate; };
  const changeLevel = (levelIndex) => { setShowQualityMenu(false); setCurrentLevel(levelIndex); if (hlsRef.current) hlsRef.current.currentLevel = levelIndex; };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="absolute inset-0 w-full h-full bg-black overflow-hidden flex items-center justify-center">
      <video
        ref={(el) => {
          videoRef.current = el;
          // React doesn't reliably set `muted` as a DOM property — set it here
          // so the browser allows autoplay (autoplay policy requires muted=true).
          if (el) el.muted = true;
        }}
        src={!isHls ? src : undefined}
        autoPlay
        muted
        playsInline
        preload="auto"
        className="bg-black"
        style={{
          filter: `brightness(${brightness})`,
          ...(screenSize === "full"
            ? { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.08)' }
            : { width: `${currentSize.scale * 100}%`, height: `${currentSize.scale * 100}%`, objectFit: 'cover', borderRadius: '12px', boxShadow: '0 0 40px rgba(0,0,0,0.8)' }
          ),
        }}
        onClick={handleVideoClick}
        onPlaying={() => { setLoading(false); setIsPlaying(true); setBuffering(false); setTimeout(() => setShowStartOverlay(false), coverMs); }}
        onPause={() => setIsPlaying(false)}
        onWaiting={() => setBuffering(true)}
        onLoadedMetadata={(e) => setDuration(e.target.duration || 0)}
        onTimeUpdate={(e) => {
          // Throttle: only update when integer second changes (reduces re-renders)
          const t = e.target.currentTime || 0;
          if (Math.floor(t) !== Math.floor(currentTime)) setCurrentTime(t);
        }}
        onSeeked={() => { const v = videoRef.current; if (v && v.paused) v.play().catch(() => {}); }}
        onError={() => { setLoading(false); setVideoError(true); }}
      />

      {/* Click overlay */}
      <div className="absolute inset-0 z-10" onClick={handleVideoClick} />

      {/* Hide-logo blur overlay — covers a corner to mask channel logos / watermarks */}
      {hideLogoPos >= 0 && (
        <div className="absolute z-[15] pointer-events-none" style={{
          ...(hideLogoPos === 0 ? { top: 0, right: 0 } : {}),
          ...(hideLogoPos === 1 ? { top: 0, left: 0 } : {}),
          ...(hideLogoPos === 2 ? { bottom: 0, left: 0 } : {}),
          ...(hideLogoPos === 3 ? { bottom: 0, right: 0 } : {}),
          width: '22%', height: '16%',
          background: 'rgba(5,5,12,0.25)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          border: '1px solid rgba(255,255,255,0.06)',
        }} />
      )}

      {/* Branding bar removed for clean fullscreen video — no logos or text overlays.
           hideInfo is always true for series playback (set by SeriesDetail). */}

      {/* Center controls — rewind 10s, play/pause, forward 10s (MOBILE ONLY — TV uses remote) */}
      {!isTV && showControls && !loading && (
        <div className="absolute z-[36] flex items-center gap-6"
          style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}>
          <button
            data-remote
            onClick={(e) => { e.stopPropagation(); seekBy(-10); }}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            <Rewind className="w-5 h-5 text-white" />
          </button>
          <button
            data-remote
            onClick={(e) => { e.stopPropagation(); togglePlay(); }}
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            {isPlaying ? <Pause className="w-7 h-7 text-white" /> : <Play className="w-7 h-7 text-white ml-0.5" />}
          </button>
          <button
            data-remote
            onClick={(e) => { e.stopPropagation(); seekBy(10); }}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            <FastForward className="w-5 h-5 text-white" />
          </button>
        </div>
      )}

      {/* Bottom controls — icons only (hidden on TV — remote controls playback) */}
      <div className="absolute bottom-0 left-0 right-0 z-[36] px-3 pb-2 pt-10 transition-opacity duration-300"
        style={{ background: "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.92) 35%)", opacity: isTV ? 0 : (showControls ? 1 : 0), pointerEvents: isTV ? 'none' : (showControls ? 'auto' : 'none') }}
        onClick={handleVideoClick}
      >
        {/* Seek bar */}
        <div data-remote tabIndex={0} role="slider" className="w-full h-1.5 rounded-full bg-white/20 cursor-pointer mb-2 relative group"
          onClick={(e) => { e.stopPropagation(); const rect = e.currentTarget.getBoundingClientRect(); const pct = (e.clientX - rect.left) / rect.width; seekTo(pct * duration); }}
          onKeyDown={(e) => { if (e.key === "ArrowLeft") { e.preventDefault(); seekBy(-10); } if (e.key === "ArrowRight") { e.preventDefault(); seekBy(10); } }}>
          <div className="h-full rounded-full" style={{ width: `${progress}%`, background: "linear-gradient(90deg, #7b2cbf, #c77dff)" }} />
          <div className="absolute top-1/2 w-3 h-3 rounded-full bg-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
            style={{ left: `${progress}%`, transform: "translate(-50%, -50%)" }} />
        </div>

        {/* Controls row — icons only */}
        <div className="flex items-center gap-2 flex-wrap" onClick={e => e.stopPropagation()}>
          {/* Transport buttons — visible on both TV and mobile */}
          <button onClick={() => seekBy(-10)} data-remote className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
            <Rewind className="w-4 h-4 text-white" />
          </button>
          <button onClick={togglePlay} data-remote className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
            {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
          </button>
          <button onClick={() => seekBy(10)} data-remote className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
            <FastForward className="w-4 h-4 text-white" />
          </button>

          {/* Volume + Brightness — mobile only (TV uses remote ↑/↓) */}
          {!isTV && (
            <>
              {/* Volume */}
              <div className="flex items-center gap-1.5 ml-1">
                <button onClick={toggleMute} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
                  {muted || volume === 0 ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
                </button>
                <input type="range" min={0} max={100} value={muted ? 0 : volume}
                  onChange={(e) => handleVolume(parseInt(e.target.value))}
                  className="w-14 h-1 cursor-pointer" style={{ accentColor: "#c77dff" }} />
              </div>

              {/* Brightness */}
              <div className="flex items-center gap-1.5">
                <Sun className="w-4 h-4 text-white/70 flex-shrink-0" />
                <input type="range" min={20} max={150} value={Math.round(brightness * 100)}
                  onChange={(e) => setBrightness(parseInt(e.target.value) / 100)}
                  className="w-14 h-1 cursor-pointer" style={{ accentColor: "#c77dff" }} />
              </div>
            </>
          )}

          {/* Quality — icon only */}
          {isHls && levels.length > 0 && (
            <div className="relative flex-shrink-0">
              <button onClick={() => setShowQualityMenu(v => !v)} data-remote
                className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors">
                <Settings2 className="w-4 h-4 text-white/70" />
              </button>
              {showQualityMenu && (
                <div className="absolute bottom-full right-0 mb-2 rounded-xl overflow-hidden backdrop-blur-md"
                  style={{ background: "rgba(10,13,22,0.95)", border: "1px solid rgba(255,255,255,0.15)", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", minWidth: "100px" }}>
                  <button onClick={() => changeLevel(-1)}
                    className={`flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors w-full text-right ${currentLevel === -1 ? "text-cyan-400" : "text-white/70"}`}>
                    <span className="text-sm">Auto</span>
                    {currentLevel === -1 && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                  </button>
                  {levels.slice().reverse().map(lvl => (
                    <button key={lvl.index} onClick={() => changeLevel(lvl.index)}
                      className={`flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors w-full text-right ${currentLevel === lvl.index ? "text-cyan-400" : "text-white/70"}`}>
                      <span className="text-sm">{lvl.label}</span>
                      {currentLevel === lvl.index && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Screen size — icon only */}
          <div className="relative flex-shrink-0">
            <button onClick={() => setShowScreenMenu(v => !v)} data-remote
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors">
              {screenSize === "full" ? <Maximize className="w-4 h-4 text-white/70" /> : <Shrink className="w-4 h-4 text-white/70" />}
            </button>
            {showScreenMenu && (
              <div className="absolute bottom-full right-0 mb-2 rounded-xl overflow-hidden backdrop-blur-md"
                style={{ background: "rgba(10,13,22,0.95)", border: "1px solid rgba(255,255,255,0.15)", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", minWidth: "110px" }}>
                {SCREEN_SIZES.map(opt => (
                  <button key={opt.value} onClick={() => { setScreenSize(opt.value); setShowScreenMenu(false); }}
                    className={`flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors w-full text-right ${screenSize === opt.value ? "text-cyan-400" : "text-white/70"}`}>
                    <span className="text-sm">{opt.label}</span>
                    {screenSize === opt.value && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Hide-logo — cycles through corners to mask channel logos / watermarks */}
          <div className="relative flex-shrink-0">
            <button onClick={() => setHideLogoPos(p => (p + 1) % 5)} data-remote
              className={`w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors ${hideLogoPos >= 0 ? "text-cyan-400" : "text-white/70"}`}
              title={hideLogoPos >= 0 ? "پنهان‌کردن لوگو" : "پنهان‌کردن لوگو"}>
              {hideLogoPos >= 0 ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {/* Speed — icon only (hidden on TV — remote controls playback) */}
          {!isTV && (
          <div className="relative flex-shrink-0">
            <button onClick={() => setShowSpeedMenu(v => !v)}
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors">
              <Gauge className="w-4 h-4 text-white/70" />
            </button>
            {showSpeedMenu && (
              <div className="absolute bottom-full right-0 mb-2 rounded-xl overflow-hidden backdrop-blur-md"
                style={{ background: "rgba(10,13,22,0.95)", border: "1px solid rgba(255,255,255,0.15)", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", minWidth: "100px" }}>
                {[0.5, 0.75, 1, 1.25, 1.5, 2].map(rate => (
                  <button key={rate} onClick={() => changeSpeed(rate)}
                    className={`flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors w-full text-right ${playbackRate === rate ? "text-cyan-400" : "text-white/70"}`}>
                    <span className="text-sm">{rate}x</span>
                    {playbackRate === rate && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>
          )}

          <span className="ml-auto" />
        </div>
      </div>

      {/* Start overlay — HLS only; gallery videos start instantly with no dark cover */}
      {showStartOverlay && (
        <SeriesCoverOverlay poster={seriesPoster} title={seriesTitle} phase="start" visible={true} posterPosition={posterPosition} />
      )}

      {/* Loading only — no seeking overlay (gallery videos seek instantly) */}
      {loading && !videoError && (
        <div className="absolute inset-0 flex items-center justify-center z-[20] bg-black/40">
          <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
        </div>
      )}

      {/* Buffering spinner — shows when video stalls during playback */}
      {buffering && !loading && !videoError && (
        <div className="absolute inset-0 flex items-center justify-center z-[20] bg-black/20 pointer-events-none">
          <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
        </div>
      )}

      {/* Error — video failed to load (unsupported format or bad URL) */}
      {videoError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-[30] bg-black/80 px-6 text-center">
          <p className="text-white/90 text-sm font-bold mb-1">⚠️ ویدیو پخش نمی‌شود</p>
          <p className="text-white/40 text-sm">فرمت ویدیو پشتیبانی نمی‌شود یا فایل خراب است</p>
        </div>
      )}
    </div>
  );
}