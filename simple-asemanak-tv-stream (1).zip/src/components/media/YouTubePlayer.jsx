import { useEffect, useRef, useState } from "react";
import { Loader2, Volume2, VolumeX, Play, Pause, Rewind, FastForward } from "lucide-react";
import VideoControls from "@/components/media/VideoControls";
import SeriesCoverOverlay from "@/components/media/SeriesCoverOverlay";
import { LOGO_URL } from "@/lib/brandAssets";
import { useIsTV } from "@/lib/useIsTV";

export default function YouTubePlayer({ videoId, muted = false, onVideoClick, langPref = "fa", controlsVisible = true, seriesTitle, seriesPoster, posterPosition, hideInfo = false, onLangChange }) {
  const isTV = useIsTV();
  const containerRef = useRef(null);
  const wrapperRef = useRef(null);
  const playerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [brightness, setBrightness] = useState(1);
  const [screenScale, setScreenScale] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [ytVolume, setYtVolume] = useState(100);
  const [videoEnded, setVideoEnded] = useState(false);
  const [showStartOverlay, setShowStartOverlay] = useState(true);
  const [videoError, setVideoError] = useState(false);
  const [showKeyControls, setShowKeyControls] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const keyControlsTimer = useRef(null);
  const controlsTimer = useRef(null);
  const hasStartedRef = useRef(false);

  useEffect(() => {
    if (!videoId) return;
    setLoading(true);
    setShowStartOverlay(true);
    setVideoError(false);
    hasStartedRef.current = false;
    setVideoEnded(false);

    let mounted = true;

    // Read configurable cover duration from settings (default 3s)
    const coverMs = (() => { try { return (parseInt(JSON.parse(localStorage.getItem('ayeneh_settings') || '{}').coverDuration) || 3) * 1000; } catch { return 3000; } })();

    // Safety net: hide start overlay after cover duration + 2s regardless of play state
    const overlaySafety = setTimeout(() => { if (mounted) setShowStartOverlay(false); }, coverMs + 2000);

    if (!window.YT) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      document.body.appendChild(tag);
    }

    const initPlayer = () => {
      if (!mounted || !containerRef.current) return;

      // Captions/subtitles DISABLED by default — user requested no Persian subtitles on series.
      const hlLang = langPref === "fa" ? "fa" : "en";

      playerRef.current = new window.YT.Player(containerRef.current, {
        videoId,
        width: "100%",
        height: "100%",
        playerVars: {
          autoplay: 1,
          mute: muted ? 1 : 0,
          controls: 0,
          modestbranding: 1,
          rel: 0,
          playsinline: 1,
          iv_load_policy: 3,
          cc_load_policy: 0,   // ← subtitles OFF
          cc_lang_pref: hlLang,
          hl: hlLang,
        },
        events: {
          onReady: (e) => {
            if (!mounted) return;
            setLoading(false);
            if (!muted) {
              e.target.unMute();
              e.target.setVolume(100);
            }
            e.target.playVideo();
            // Fallback: if autoplay with sound is blocked (iOS), retry muted after 3s
            setTimeout(() => {
              if (mounted && playerRef.current) {
                try {
                  if (playerRef.current.getPlayerState() !== 1) {
                    playerRef.current.mute();
                    setIsMuted(true);
                    playerRef.current.playVideo();
                  }
                } catch {}
              }
            }, 3000);
            // Captions module NOT loaded — subtitles disabled per user request.
          },
          onError: (e) => {
            if (!mounted) return;
            setLoading(false);
            setShowStartOverlay(false);
            setVideoError(true);
            // Error 101/150 = embedding disabled; 100 = video removed; 2 = invalid params
          },
          onStateChange: (e) => {
            if (!mounted) return;
            if (e.data === 1) {
              setLoading(false); setIsPlaying(true); setVideoEnded(false); setVideoError(false);
              // Hide start overlay on FIRST play only — not on seeks/replays
              if (!hasStartedRef.current) {
                hasStartedRef.current = true;
                setTimeout(() => { if (mounted) setShowStartOverlay(false); }, coverMs);
              }
            }
            if (e.data === 2) setIsPlaying(false);
            if (e.data === 0) { setIsPlaying(false); setVideoEnded(true); }
          },
        },
      });
    };

    if (window.YT && window.YT.Player) {
      initPlayer();
    } else {
      const prevCb = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prevCb) prevCb();
        initPlayer();
      };
      const check = setInterval(() => {
        if (window.YT && window.YT.Player) {
          clearInterval(check);
          initPlayer();
        }
      }, 200);
      setTimeout(() => clearInterval(check), 5000);
    }

    return () => {
      mounted = false;
      clearTimeout(overlaySafety);
      if (playerRef.current) {
        try { playerRef.current.stopVideo(); } catch {}
        try { playerRef.current.destroy(); } catch {}
        playerRef.current = null;
      }
      // Forcibly remove any lingering iframe so audio can't keep playing after exit.
      if (containerRef.current) containerRef.current.innerHTML = "";
    };
  }, [videoId]);

  // Captions permanently disabled — no language preference toggle.

  // React to muted prop changes
  useEffect(() => {
    if (!playerRef.current) return;
    try {
      if (muted) playerRef.current.mute();
      else { playerRef.current.unMute(); playerRef.current.setVolume(100); }
    } catch {}
  }, [muted]);

  // ── TV remote control — OK=play/pause, ←/→=seek ±10s, ↑/↓=volume ──
  const flashKeyControls = () => {
    setShowKeyControls(true);
    if (keyControlsTimer.current) clearTimeout(keyControlsTimer.current);
    // Show controls longer on TV (4s) so user has time to see the feedback
    keyControlsTimer.current = setTimeout(() => setShowKeyControls(false), isTV ? 4000 : 2000);
  };

  useEffect(() => {
    const onKey = (e) => {
      const tag = e.target?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.target?.isContentEditable) return;
      if (e.defaultPrevented) return;
      if (!playerRef.current) return;
      switch (e.key) {
        case "Enter":
        case " ":
        case "XF86OK":
        case "Accept":
          e.preventDefault();
          e.stopPropagation();
          togglePlay();
          flashKeyControls();
          break;
        case "ArrowLeft":
          e.preventDefault();
          e.stopPropagation();
          seekBy(-10);
          flashKeyControls();
          break;
        case "ArrowRight":
          e.preventDefault();
          e.stopPropagation();
          seekBy(10);
          flashKeyControls();
          break;
        case "ArrowUp":
          e.preventDefault();
          e.stopPropagation();
          { const nv = Math.min(100, (isMuted ? 0 : ytVolume) + 10);
            setYtVolume(nv); setIsMuted(false);
            try { playerRef.current.unMute(); playerRef.current.setVolume(nv); } catch {} }
          flashKeyControls();
          break;
        case "ArrowDown":
          e.preventDefault();
          e.stopPropagation();
          { const nv = Math.max(0, (isMuted ? 0 : ytVolume) - 10);
            setYtVolume(nv); setIsMuted(nv === 0);
            try { if (nv === 0) playerRef.current.mute(); else { playerRef.current.unMute(); playerRef.current.setVolume(nv); } } catch {} }
          flashKeyControls();
          break;
        case "MediaPlay":
        case "MediaPause":
        case "MediaPlayPause":
          e.preventDefault();
          e.stopPropagation();
          togglePlay();
          flashKeyControls();
          break;
        case "MediaRewind":
        case "MediaTrackPrevious":
          e.preventDefault();
          e.stopPropagation();
          seekBy(-10);
          flashKeyControls();
          break;
        case "MediaFastForward":
        case "MediaTrackNext":
          e.preventDefault();
          e.stopPropagation();
          seekBy(10);
          flashKeyControls();
          break;
        default:
          break;
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [isMuted, ytVolume]);

  // Detect near-end — show cover overlay BEFORE YouTube's end-screen appears
  useEffect(() => {
    if (!videoId) return;
    const interval = setInterval(() => {
      if (!playerRef.current || videoEnded) return;
      try {
        const ct = playerRef.current.getCurrentTime() || 0;
        const dur = playerRef.current.getDuration() || 0;
        if (dur > 0 && ct >= dur - 20) {
          setVideoEnded(true);
          setIsPlaying(false);
        }
      } catch {}
    }, 300);
    return () => clearInterval(interval);
  }, [videoId, videoEnded]);

  // Scale iframe to cover container (crop black bars) — directly sets iframe style
  // via querySelector for reliability (YT API replaces the div, losing CSS variables).
  useEffect(() => {
    if (!videoId) return;

    let ro = null;
    let pollInterval = null;

    const applyCover = () => {
      const wrapper = wrapperRef.current;
      if (!wrapper) return;
      const w = wrapper.clientWidth;
      const h = wrapper.clientHeight;
      if (w === 0 || h === 0) return;
      const videoRatio = 16 / 9;
      const containerRatio = w / h;
      let iw, ih;
      if (containerRatio > videoRatio) {
        iw = w;
        ih = w / videoRatio;
      } else {
        ih = h;
        iw = h * videoRatio;
      }
      // Zoom factor — crops edges to eliminate black bars and fill the screen.
      // 1.0 = exact cover; 1.15 = 15% zoom to crop baked-in letterboxing.
      const zoom = 1.3;
      iw *= zoom;
      ih *= zoom;
      // Find the iframe (YouTube API replaces the div with an iframe)
      const iframe = wrapper.querySelector('iframe');
      if (iframe) {
        iframe.style.setProperty('position', 'absolute', 'important');
        iframe.style.setProperty('top', '50%', 'important');
        iframe.style.setProperty('left', '50%', 'important');
        iframe.style.setProperty('width', iw + 'px', 'important');
        iframe.style.setProperty('height', ih + 'px', 'important');
        iframe.style.setProperty('transform', 'translate(-50%, -50%)', 'important');
        // Stop polling once the iframe is located — ResizeObserver handles future updates
        if (pollInterval) { clearInterval(pollInterval); pollInterval = null; }
      }
      // Also set CSS variables as fallback
      wrapper.style.setProperty('--yt-iw', iw + 'px');
      wrapper.style.setProperty('--yt-ih', ih + 'px');
    };

    applyCover();
    // Poll for iframe appearance (YT API may not have created it yet)
    pollInterval = setInterval(applyCover, 200);
    ro = new ResizeObserver(applyCover);
    if (wrapperRef.current) ro.observe(wrapperRef.current);
    window.addEventListener('resize', applyCover);
    window.addEventListener('orientationchange', applyCover);

    return () => {
      if (pollInterval) clearInterval(pollInterval);
      if (ro) ro.disconnect();
      window.removeEventListener('resize', applyCover);
      window.removeEventListener('orientationchange', applyCover);
    };
  }, [videoId]);

  if (!videoId) return null;

  const togglePlay = () => {
    if (!playerRef.current) return;
    try {
      const state = playerRef.current.getPlayerState();
      if (state === 1) { playerRef.current.pauseVideo(); setIsPlaying(false); }
      else {
        // Unmute when playing — autoplay restrictions may have muted the video
        playerRef.current.unMute();
        playerRef.current.setVolume(ytVolume || 100);
        playerRef.current.playVideo();
        setIsPlaying(true);
        setIsMuted(false);
      }
    } catch {}
  };

  const seekBy = (delta) => {
    if (!playerRef.current) return;
    try {
      const ct = playerRef.current.getCurrentTime() || 0;
      const dur = playerRef.current.getDuration() || 0;
      const newTime = Math.max(0, Math.min(dur, ct + delta));
      playerRef.current.seekTo(newTime, true);
    } catch {}
  };

  const toggleMute = () => {
    if (!playerRef.current) return;
    try {
      if (isMuted) {
        playerRef.current.unMute();
        playerRef.current.setVolume(100);
        setIsMuted(false);
      } else {
        playerRef.current.mute();
        setIsMuted(true);
      }
    } catch {}
  };

  return (
    <div className="absolute inset-0 bg-black overflow-hidden">
      <div ref={wrapperRef} className="yt-brightness-wrapper absolute inset-0 w-full h-full" style={{ overflow: 'hidden', filter: `brightness(${brightness})`, transform: `scale(${screenScale})`, transition: 'transform 0.3s ease' }}>
        <style>{`.yt-brightness-wrapper iframe{position:absolute!important;top:50%!important;left:50%!important;width:var(--yt-iw,100%)!important;height:var(--yt-ih,100%)!important;transform:translate(-50%,-50%)!important;}`}</style>
        <div ref={containerRef} style={{ position: 'absolute', inset: 0, overflow: 'hidden' }} />
      </div>
      {/* Full-area click overlay — blocks ALL YouTube clicks/branding; toggles UI */}
      <div
        className="absolute inset-0 z-10"
        onClick={(e) => {
          setShowControls(prev => {
            const next = !prev;
            if (controlsTimer.current) clearTimeout(controlsTimer.current);
            if (next) controlsTimer.current = setTimeout(() => setShowControls(false), 4000);
            return next;
          });
          if (onVideoClick) onVideoClick();
        }}
      />

      {/* Center controls — rewind, play/pause, forward (MOBILE ONLY — TV uses remote) */}
      {!isTV && (showControls || showKeyControls) && !loading && !videoEnded && (
        <div className="absolute z-[36] flex items-center gap-6"
          style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}>
          <button
            data-remote
            onClick={(e) => { e.stopPropagation(); seekBy(-10); }}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            <Rewind className="w-5 h-5 text-white" />
          </button>
          <button
            data-remote
            onClick={(e) => { e.stopPropagation(); togglePlay(); }}
            className="w-16 h-16 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            {isPlaying ? <Pause className="w-7 h-7 text-white" /> : <Play className="w-7 h-7 text-white ml-0.5" />}
          </button>
          <button
            data-remote
            onClick={(e) => { e.stopPropagation(); seekBy(10); }}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
            style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}
          >
            <FastForward className="w-5 h-5 text-white" />
          </button>
        </div>
      )}

      {/* Top overlay — fully opaque band hides YouTube's title / "Watch on YouTube" / profile */}
      <style>{`
        .yt-top-band { height: 60px; }
        .yt-bottom-band { height: 60px; }
        @media (max-width: 480px) {
          .yt-top-band { height: 80px; }
          .yt-bottom-band { height: 80px; }
        }
      `}</style>
      <div className="yt-top-band absolute top-0 left-0 right-0 z-20 pointer-events-none"
        style={hideInfo ? { height: '50px', backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)' } : {}} />
      <div className="yt-bottom-band absolute bottom-0 left-0 right-0 z-20 pointer-events-none"
        style={hideInfo ? { height: '50px', backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)' } : {}} />

      {/* Start overlay — clean cover with series name + poster, covers video start for 10 seconds */}
      {!videoEnded && (
        <SeriesCoverOverlay poster={seriesPoster} title={seriesTitle} phase="start" visible={showStartOverlay} posterPosition={posterPosition} />
      )}
      {/* Video controls — seek, volume, brightness (MOBILE ONLY — TV uses remote) */}
      {!isTV && (showControls || showKeyControls) && (
        <div className="absolute bottom-0 left-0 right-0 z-[36]">
          <VideoControls
            playerRef={playerRef}
            onTogglePlay={togglePlay}
            isPlaying={isPlaying}
            brightness={brightness}
            onBrightnessChange={setBrightness}
            onScreenSizeChange={setScreenScale}
            isTV={isTV}
            langPref={langPref}
            onLangChange={onLangChange}
          />
        </div>
      )}
      {/* Loading */}
      {loading && !videoError && (
        <div className="absolute inset-0 flex items-center justify-center z-40 bg-black">
          <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
        </div>
      )}

      {/* Error — video failed to play (embedding disabled, removed, etc.) */}
      {videoError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-[45] bg-black/90 px-6 text-center">
          <p className="text-white/90 text-base font-bold mb-2">⚠️ پخش ویدیو ناموفق بود</p>
          <p className="text-white/40 text-sm mb-5">این ویدیو ممکن است اجازه embed نداشته باشد یا حذف شده باشد</p>
          <a href={`https://www.youtube.com/watch?v=${videoId}`} target="_blank" rel="noopener noreferrer" data-remote
            className="flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
            style={{ background: 'linear-gradient(135deg, #ff0000, #cc0000)', boxShadow: '0 4px 15px rgba(255,0,0,0.3)' }}>
            <Play className="w-4 h-4" /> تماشا در یوتیوب
          </a>
        </div>
      )}

      {/* End overlay — series cover image with replay button */}
      {videoEnded && (
        <SeriesCoverOverlay poster={seriesPoster} title={seriesTitle} phase="end" visible={true} posterPosition={posterPosition}
          onReplay={() => { if (playerRef.current) { playerRef.current.seekTo(0, true); playerRef.current.playVideo(); } setVideoEnded(false); }}
        />
      )}

      {/* App logo watermark — semi-transparent, blurred */}
      <img src={LOGO_URL} alt="" className="absolute z-[25] w-10 h-10 opacity-15 pointer-events-none"
        style={{ bottom: 'calc(1rem + env(safe-area-inset-bottom))', left: 'calc(1rem + env(safe-area-inset-left))', filter: 'blur(1px)' }} />

      {/* Floating mute/unmute — landscape on small mobiles only */}
      <style>{`@media(max-width:480px) and (orientation:landscape){.yt-mute-float{display:flex!important;}}`}</style>
      <button onClick={toggleMute} className="yt-mute-float absolute z-50 w-10 h-10 rounded-full items-center justify-center"
        style={{ display: 'none', top: 'calc(0.75rem + env(safe-area-inset-top))', right: 'calc(0.75rem + env(safe-area-inset-right))', background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}>
        {isMuted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-white" />}
      </button>
    </div>
  );
}