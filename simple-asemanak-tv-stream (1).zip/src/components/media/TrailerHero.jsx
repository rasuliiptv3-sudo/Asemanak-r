import { useRef, useEffect, useState } from "react";
import { Play, List, Volume2, VolumeX, Loader2 } from "lucide-react";
import CoverSlideshow from "./CoverSlideshow";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

/**
 * Trailer hero — plays a single series' first episode in the featured header.
 * Gallery videos use a callback ref + retry to ensure instant playback.
 * If the trailer fails to start within 6 seconds (common on TV), falls back
 * to a fullscreen horizontal cover slideshow of all series.
 */
export default function TrailerHero({ series, onEnter, onStop, isTV = false, allSeries = [] }) {
  const containerRef = useRef(null);
  const nativeVideoRef = useRef(null);
  const playerRef = useRef(null);
  const mountedRef = useRef(true);
  const [isPlaying, setIsPlaying] = useState(true);
  // On TV: start unmuted (autoplay with sound — user already interacted via D-pad).
  // Fallback to muted if the browser blocks autoplay with sound.
  // On mobile: start unmuted (user clicked to open trailer).
  const [muted, setMuted] = useState(false);
  const mutedRef = useRef(false);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const failTimerRef = useRef(null);
  const startedRef = useRef(false);

  const firstEp = (series?.episodes || [])[0];
  const videoId = firstEp?.videoId;
  const fileUrl = firstEp?.fileUrl;
  const epCount = (series?.episodes || []).length;

  // YouTube player init
  useEffect(() => {
    mountedRef.current = true;
    startedRef.current = false;
    setFailed(false);
    if (!videoId) { setReady(true); return; }
    setReady(false);

    // Failure detection: if playback doesn't start within 6s, show cover slideshow
    failTimerRef.current = setTimeout(() => {
      if (mountedRef.current && !startedRef.current) {
        setFailed(true);
      }
    }, 6000);

    const init = () => {
      if (!mountedRef.current || !containerRef.current) return;
      // Reset failure timer from when the player is actually created
      if (failTimerRef.current) { clearTimeout(failTimerRef.current); }
      failTimerRef.current = setTimeout(() => {
        if (mountedRef.current && !startedRef.current) setFailed(true);
      }, 6000);
      if (playerRef.current) { try { playerRef.current.destroy(); } catch {} }

      playerRef.current = new window.YT.Player(containerRef.current, {
        videoId,
        width: "100%",
        height: "100%",
        playerVars: {
          autoplay: 1, mute: 0, controls: 0, modestbranding: 1,
          rel: 0, iv_load_policy: 3, playsinline: 1, disablekb: 1, fs: 0,
          loop: 1, playlist: videoId,
        },
        events: {
          onReady: (e) => {
            if (!mountedRef.current) return;
            startedRef.current = true;
            if (failTimerRef.current) { clearTimeout(failTimerRef.current); failTimerRef.current = null; }
            try {
              // Seek to an attractive scene (random 10-60s) for trailer feel
              const seekTime = Math.floor(Math.random() * 50) + 10;
              e.target.seekTo(seekTime, true);
              e.target.unMute();
              e.target.setVolume(100);
              e.target.playVideo();
            } catch {}
            setReady(true);
            mutedRef.current = false;
            setMuted(false);
            // Fallback: if autoplay with sound is blocked, retry muted after 3s
            setTimeout(() => {
              if (mountedRef.current && playerRef.current) {
                try {
                  if (playerRef.current.getPlayerState() !== 1) {
                    playerRef.current.mute();
                    mutedRef.current = true;
                    setMuted(true);
                    playerRef.current.playVideo();
                  }
                } catch {}
              }
            }, 3000);
          },
          onStateChange: (e) => {
            if (!mountedRef.current) return;
            const st = e.data;
            if (st === 1) { setIsPlaying(true); startedRef.current = true; if (failTimerRef.current) { clearTimeout(failTimerRef.current); failTimerRef.current = null; } }
            else if (st === 2) setIsPlaying(false);
            // st === 5 = cued, st === 3 = buffering — not failures
            // Seamless loop: when video ends (state 0), jump to a new attractive scene
            // so it feels like a continuous trailer, not a replay with a visible stop.
            else if (st === 0) {
              try {
                const dur = playerRef.current?.getDuration?.() || 0;
                if (dur > 30) {
                  // Seek to a random attractive moment (10% to 70% of duration)
                  const newSeek = Math.floor(dur * (0.1 + Math.random() * 0.5));
                  playerRef.current.seekTo(newSeek, true);
                  playerRef.current.playVideo();
                }
              } catch {}
            }
          },
          onError: () => {
            if (!mountedRef.current) return;
            setFailed(true);
          },
        },
      });
    };

    if (window.YT && window.YT.Player) init();
    else {
      if (!window.ytApiLoading) {
        window.ytApiLoading = true;
        const tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(tag);
      }
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { if (prev) prev(); init(); };
      const check = setInterval(() => {
        if (window.YT && window.YT.Player) { clearInterval(check); init(); }
      }, 200);
      setTimeout(() => clearInterval(check), 8000);
    }

    return () => {
      mountedRef.current = false;
      if (failTimerRef.current) { clearTimeout(failTimerRef.current); failTimerRef.current = null; }
      if (playerRef.current) {
        try { playerRef.current.stopVideo(); } catch {}
        try { playerRef.current.destroy(); } catch {}
        playerRef.current = null;
      }
    };
  }, [videoId]);

  // Native video: cleanup + fallback timer (play is handled by callback ref)
  useEffect(() => {
    if (!fileUrl) return;
    setReady(false);
    startedRef.current = false;
    setFailed(false);
    // Start muted to bypass autoplay restrictions; unmute once playback starts.
    setMuted(true);
    const timer = setTimeout(() => setReady(true), 3000);
    // Failure detection: if playback doesn't start within 6s, show cover slideshow
    failTimerRef.current = setTimeout(() => {
      if (mountedRef.current && !startedRef.current) {
        setFailed(true);
      }
    }, 6000);
    return () => {
      clearTimeout(timer);
      if (failTimerRef.current) { clearTimeout(failTimerRef.current); failTimerRef.current = null; }
      const v = nativeVideoRef.current;
      if (v) {
        try { v.pause(); } catch {}
        try { v.removeAttribute('src'); } catch {}
        try { v.load(); } catch {}
      }
    };
  }, [fileUrl]);

  const togglePlay = () => {
    if (playerRef.current) {
      try {
        if (isPlaying) playerRef.current.pauseVideo();
        else playerRef.current.playVideo();
      } catch {}
    } else if (nativeVideoRef.current) {
      if (nativeVideoRef.current.paused) nativeVideoRef.current.play();
      else nativeVideoRef.current.pause();
    }
  };

  const toggleMute = () => {
    if (playerRef.current) {
      const next = !muted;
      mutedRef.current = next;
      try {
        if (next) playerRef.current.mute();
        else { playerRef.current.unMute(); playerRef.current.setVolume(100); }
      } catch {}
      setMuted(next);
    } else if (nativeVideoRef.current) {
      nativeVideoRef.current.muted = !nativeVideoRef.current.muted;
      setMuted(nativeVideoRef.current.muted);
    }
  };

  if (!videoId && !fileUrl) return null;

  // Fallback: if the trailer failed to start within 6s, show cover slideshow
  if (failed) {
    return (
      <CoverSlideshow
        allSeries={allSeries}
        activeSeries={series}
        onEnter={(s) => { onEnter(s); }}
        isTV={isTV}
      />
    );
  }

  return (
    <div className="relative w-full overflow-hidden flex-shrink-0" style={{ height: "45vh", minHeight: "280px", maxHeight: "420px" }}>
      {/* Video — YouTube or native */}
      <div className="absolute inset-0 overflow-hidden">
        {fileUrl ? (
          <video
            key={`${fileUrl}_${series?._trailerPlayId || ''}`}
            ref={(el) => {
              nativeVideoRef.current = el;
              if (el) {
                el.muted = true; // start muted to allow autoplay
                el.play().then(() => {
                  // Unmute once playback starts (user already interacted via D-pad)
                  el.muted = false;
                  el.volume = 1;
                  setMuted(false);
                }).catch(() => {
                  setMuted(true);
                  setTimeout(() => { try { el.play().catch(() => {}); } catch {} }, 500);
                });
              }
            }}
            autoPlay
            muted
            playsInline
            preload="auto"
            src={fileUrl}
            className="w-full h-full object-cover"
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onPlaying={() => { setReady(true); startedRef.current = true; if (failTimerRef.current) { clearTimeout(failTimerRef.current); failTimerRef.current = null; } }}
            onCanPlay={() => { setReady(true); try { nativeVideoRef.current?.play().catch(() => {}); } catch {} }}
            onLoadedMetadata={(e) => {
              // Seek to an attractive scene (random 10-70s, or 70% of duration for short clips)
              const v = e.target;
              if (v.duration > 20) {
                try { v.currentTime = Math.min(Math.floor(Math.random() * 60) + 10, v.duration * 0.7); } catch {}
              }
            }}
            onEnded={(e) => {
              // Seamless loop — jump to a new attractive scene instead of stopping,
              // so it feels like a continuous trailer, not a replay with a visible cut.
              const v = e.target;
              if (v.duration > 20) {
                try {
                  v.currentTime = Math.min(Math.floor(Math.random() * 60) + 10, v.duration * 0.7);
                  v.play().catch(() => {});
                } catch {}
              } else {
                // Short clip — just restart
                try { v.currentTime = 0; v.play().catch(() => {}); } catch {}
              }
            }}
            onLoadedData={() => { setReady(true); try { nativeVideoRef.current?.play().catch(() => {}); } catch {} }}
            onError={() => { setReady(true); setFailed(true); }}
          />
        ) : videoId ? (
          <div style={{
            position: "absolute", top: "50%", left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100vw", height: "56.25vw",
            minHeight: "100%", minWidth: "177.78vh",
            pointerEvents: "none",
          }}>
            <div ref={containerRef} className="w-full h-full" />
          </div>
        ) : null}
      </div>

      {/* Gradient overlays — YouTube gets full gradients; gallery gets minimal bottom gradient */}
      {videoId ? (
        <>
          <div className="absolute inset-0" style={{ background: "rgba(10,13,22,0.4)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(10,13,22,0.15) 0%, rgba(10,13,22,0.35) 50%, #0a0d16 100%)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(10,13,22,0.9) 0%, transparent 60%)" }} />
        </>
      ) : (
        <div className="absolute inset-0 pointer-events-none z-[5]"
          style={{ background: "linear-gradient(180deg, transparent 0%, transparent 50%, rgba(10,13,22,0.85) 100%)" }} />
      )}

      {/* Loading */}
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center z-[7]">
          <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
        </div>
      )}

      {/* Click-blocker — YouTube only */}
      {videoId && <div className="absolute inset-0 z-[6]" />}

      {/* Pause indicator */}
      {!isPlaying && ready && (
        <div className="absolute inset-0 z-10 flex items-center justify-center" onClick={(e) => { e.stopPropagation(); togglePlay(); }}>
          <div className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{ background: "rgba(123,44,191,0.6)", backdropFilter: "blur(8px)", border: "2px solid rgba(255,255,255,0.3)" }}>
            <Play className="w-8 h-8 fill-white text-white ml-1" />
          </div>
        </div>
      )}

      {/* Content overlay */}
      <div className="absolute bottom-0 left-0 p-5 md:p-8 z-[40] max-w-lg" style={{ pointerEvents: 'none' }}>
        <span className="text-xs font-bold uppercase tracking-widest mb-2 block shimmer-text">ویژه • Featured</span>
        <h2 className="text-white font-black text-2xl md:text-4xl mb-1 drop-shadow-lg">{series?.title}</h2>
        <p className="text-white/60 text-sm mb-4">قسمت — پخش از داخل برنامه {epCount}</p>
        <div className="flex items-center gap-3" style={{ pointerEvents: 'auto' }}>
          <button onClick={() => onEnter(series)} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
            style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 20px rgba(123,44,191,0.5)" }}>
            <Play className="w-4 h-4 fill-white" /> پخش
          </button>
          <button onClick={() => onEnter(series)} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white/80 transition-all hover:scale-105"
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)" }}>
            <List className="w-4 h-4" /> قسمت‌ها
          </button>
        </div>
      </div>

      {/* Asemanak Series logo — gradient squircle branding */}
      <div className="absolute top-4 left-4 z-[40] flex items-center gap-2.5 px-3 py-2 rounded-2xl"
        style={{ background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.1)' }}>
        <div style={{
          width: 36, height: 36, borderRadius: '28%',
          background: 'linear-gradient(135deg, #E038F6 0%, #6B54FF 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 4px 16px rgba(107,84,255,0.45), inset 0 1px 0 rgba(255,255,255,0.25)',
          flexShrink: 0,
        }}>
          <span style={{ color: '#fff', fontWeight: 900, fontSize: 19, fontFamily: 'Inter, sans-serif', lineHeight: 1 }}>A</span>
        </div>
        <div className="leading-tight" style={{ direction: 'ltr' }}>
          <p className="text-white font-black text-xs tracking-wide">ASEMANAK</p>
          <p className="text-white/50 text-[8px] font-bold uppercase tracking-[0.2em]">SERIES</p>
        </div>
      </div>

      {/* Sound toggle — visible for both YouTube and gallery */}
      <button onClick={toggleMute} data-remote className="absolute bottom-4 right-4 z-[40] w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
        style={{ background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.15)", backdropFilter: "blur(8px)" }}>
        {muted ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
      </button>

    </div>
  );
}