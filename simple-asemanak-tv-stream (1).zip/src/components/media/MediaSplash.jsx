import { useEffect, useState } from "react";
import AsemanakLogo from "@/components/brand/AsemanakLogo";

/**
 * Media page splash — professional cinematic loading.
 * Asemanak Series branding with gradient glow, elegant dual-ring loader.
 */
export default function MediaSplash({ onDone }) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setExiting(true), 1600);
    const t2 = setTimeout(() => onDone(), 2100);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onDone]);

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: 'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(107,84,255,0.08) 0%, transparent 60%), #0a0d16',
      opacity: exiting ? 0 : 1,
      transition: "opacity 0.5s ease-in-out",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "28px",
    }}>
      {/* Asemanak Series logo with glow */}
      <div style={{
        animation: 'media-splash-fadein 0.6s ease-out',
      }}>
        <AsemanakLogo size={56} showText={true} variant="SERIES" />
      </div>

      {/* Dual-ring loader */}
      <div className="relative" style={{ width: 48, height: 48 }}>
        <div className="absolute inset-0 rounded-full"
          style={{
            border: '2px solid transparent',
            borderTopColor: 'rgba(224,56,246,0.9)',
            borderRightColor: 'rgba(107,84,255,0.6)',
            animation: 'media-splash-spin 1.2s linear infinite',
            filter: 'drop-shadow(0 0 6px rgba(224,56,246,0.4))',
          }} />
        <div className="absolute rounded-full"
          style={{
            inset: 6,
            border: '2px solid transparent',
            borderBottomColor: 'rgba(34,211,238,0.6)',
            animation: 'media-splash-spin-rev 1.6s linear infinite',
          }} />
      </div>

      <style>{`
        @keyframes media-splash-fadein {
          0% { opacity: 0; transform: translateY(10px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes media-splash-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes media-splash-spin-rev {
          0% { transform: rotate(360deg); }
          100% { transform: rotate(0deg); }
        }
      `}</style>
    </div>
  );
}