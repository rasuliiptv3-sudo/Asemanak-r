import { useState, useEffect, useRef } from "react";
import { ArrowLeft, Play, Trash2, List, Clock, Check, Film, Plus, Download, Loader2, X, ChevronUp, ChevronDown, Music, EyeOff, Eye, Droplet } from "lucide-react";
import HlsVideoPlayer from "@/components/media/HlsVideoPlayer";
import YouTubePlayer from "@/components/media/YouTubePlayer";
import AddEpisodeForm from "@/components/media/AddEpisodeForm";
import { getOfflineVideoUrl, getOfflineVideoUrlSync, cacheVideoOffline, getOfflineIndex } from "@/lib/offlineVideo";
import { killAllMedia } from "@/lib/killAllMedia";
import { base44 } from "@/api/base44Client";
import { useIsTV } from "@/lib/useIsTV";

// Cover music removed — silent loading only

export default function SeriesDetail({ series, onPlayEpisode, playingEpisode, onBack, onExitPlayer, onDelete, onAddEpisode, onReorderEpisodes, onEditEpisodeNumber, onDeleteEpisode, isFa = true, isAdmin = false }) {
  const isTV = useIsTV();
  const [showSidebar, setShowSidebar] = useState(false);
  const [showAddEpisode, setShowAddEpisode] = useState(false);
  const [editingEpIdx, setEditingEpIdx] = useState(null);
  const [epNumValue, setEpNumValue] = useState("");
  const [selectedSeason, setSelectedSeason] = useState(1);
  // Hide-logo: -1 = off, 0 = top-right, 1 = top-left, 2 = bottom-left, 3 = bottom-right, 4 = all corners
  const [hideLogoPos, setHideLogoPos] = useState(() => {
    // Default from series.hideOverlays if set
    return -1;
  });
  // Manual blur mode — draggable blur box for hiding logos/text
  const [blurMode, setBlurMode] = useState(false);
  const [blurPos, setBlurPos] = useState({ x: 50, y: 50 });
  const [blurSize, setBlurSize] = useState({ w: 30, h: 18 });
  const blurDragRef = useRef(null);
  const blurResizeRef = useRef(null);
  const episodeListRef = useRef(null);
  const [offlineSrc, setOfflineSrc] = useState(null);
  const [offlineReady, setOfflineReady] = useState(false);
  const [downloading, setDownloading] = useState(false);
  // Default true — player renders immediately with direct URL (like YouTube).
  // Only set to false when a cached blob URL needs to be fetched from IndexedDB.
  const [offlineChecked, setOfflineChecked] = useState(true);
  // Subtitles disabled — no caption selector in the player.
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [dlProgress, setDlProgress] = useState({ current: 0, total: 0 });
  const [uiLang, setUiLang] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"; } catch { return true; }
  });
  // Branding/logos always hidden in the video player — no overlays shown.

  // Auto-hide overlay UI (top bar + controls + floating buttons) after inactivity.
  const [showUI, setShowUI] = useState(false);
  const uiTimer = useRef(null);
  const embedRef = useRef(null);
  const videoRef = useRef(null);
  const resetUI = () => {
    setShowUI(true);
    if (uiTimer.current) clearTimeout(uiTimer.current);
    uiTimer.current = setTimeout(() => setShowUI(false), 4000);
  };
  const toggleUI = () => {
    setShowUI(v => {
      const next = !v;
      if (uiTimer.current) clearTimeout(uiTimer.current);
      if (next) uiTimer.current = setTimeout(() => setShowUI(false), 4000);
      return next;
    });
  };
  // Top bar starts hidden — shown on tap via toggleUI

  // Stop ALL audio when leaving the player (full unmount) — YouTube, Aparat, HTML5 video.
  useEffect(() => {
    return () => {
      killAllMedia();
    };
  }, []);

  // ── Kill ALL media when exiting the player (playingEpisode → null) ──
  // This fires when the user presses Back to leave the episode and return to
  // the series detail list. Without this, HLS/YouTube audio leaks into the list.
  useEffect(() => {
    if (!playingEpisode) {
      killAllMedia();
    }
  }, [playingEpisode]);

  useEffect(() => {
    const syncLang = () => {
      try { setUiLang(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    window.addEventListener("ayeneh-settings-changed", syncLang);
    window.addEventListener("storage", syncLang);
    return () => {
      window.removeEventListener("ayeneh-settings-changed", syncLang);
      window.removeEventListener("storage", syncLang);
    };
  }, []);

  // ── TV remote: Back key exits player or goes back to series list ──
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        if (playingEpisode) (onExitPlayer || onBack)();
        else onBack();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [playingEpisode, onBack, onExitPlayer]);

  const fa = isFa && uiLang;
  const tr = (f, e) => fa ? f : e;

  // Offline playback: only for direct video files (fileUrl).
  // YouTube videos play via YouTubePlayer — no backend URL resolution needed.
  useEffect(() => {
    let active = true;
    setOfflineSrc(null);
    setOfflineReady(false);
    setOfflineChecked(true);

    const key = playingEpisode?.fileUrl;
    if (!key) return;

    // 1. Check memory cache (sync) — instant playback with offline blob
    const cachedUrl = getOfflineVideoUrlSync(key);
    if (cachedUrl) { setOfflineSrc(cachedUrl); setOfflineReady(true); return; }

    // 2. Check offline index (sync) — if cached, fetch blob URL (brief spinner)
    const idx = getOfflineIndex();
    const isCached = idx.some(e => e.fileUrl === key);
    if (isCached) {
      setOfflineChecked(false);
      getOfflineVideoUrl(key).then(url => {
        if (!active) return;
        if (url) { setOfflineSrc(url); setOfflineReady(true); }
        setOfflineChecked(true);
      }).catch(() => { if (active) setOfflineChecked(true); });
    }

    return () => { active = false; };
  }, [playingEpisode]);

  // When a playing episode is set (e.g. resume from Continue Watching), switch to its season
  useEffect(() => {
    if (playingEpisode?.season) {
      setSelectedSeason(Number(playingEpisode.season) || 1);
    }
  }, [playingEpisode]);

  // Auto-focus the first episode when the detail page opens (non-playing mode).
  // This lets TV users immediately navigate episodes with D-pad without first
  // having to focus something manually.
  useEffect(() => {
    if (playingEpisode) return; // skip in player mode
    const timer = setTimeout(() => {
      const firstEp = episodeListRef.current?.querySelector('[data-remote]');
      if (firstEp) firstEp.focus();
    }, 300);
    return () => clearTimeout(timer);
  }, [playingEpisode, series?.id, selectedSeason]);

  if (!series) return null;
  const allEpisodes = (series.episodes || []).slice().sort((a, b) => a.number - b.number);
  const seasons = [...new Set(allEpisodes.map(e => Number(e.season) || 1))].sort((a, b) => a - b);
  const currentSeason = seasons.includes(selectedSeason) ? selectedSeason : (seasons[0] || 1);
  const episodes = allEpisodes.filter(e => (Number(e.season) || 1) === currentSeason);
  const nextEpNumber = episodes.length > 0 ? Math.max(...episodes.map(e => Number(e.number) || 0)) + 1 : 1;

  // Download all episodes for offline viewing (stored in IndexedDB — app-private, not in gallery)
  // Works for both gallery uploads (fileUrl) AND YouTube videos (videoId → backend resolves direct URL)
  const downloadableEps = allEpisodes.filter(ep => ep.fileUrl || ep.videoId);
  const offlineIdx = getOfflineIndex();
  const allDownloaded = downloadableEps.length > 0 && downloadableEps.every(ep => {
    const key = ep.fileUrl || `yt_${ep.videoId}`;
    return offlineIdx.some(e => e.fileUrl === key);
  });

  const handleDownloadAll = async () => {
    if (downloadingAll || allDownloaded) return;
    const toDownload = downloadableEps.filter(ep => {
      const key = ep.fileUrl || `yt_${ep.videoId}`;
      return !offlineIdx.some(e => e.fileUrl === key);
    });
    if (toDownload.length === 0) return;
    setDownloadingAll(true);
    setDlProgress({ current: 0, total: toDownload.length });
    for (let i = 0; i < toDownload.length; i++) {
      try {
        const ep = toDownload[i];
        const key = ep.fileUrl || `yt_${ep.videoId}`;
        const label = `${series.title} — ${ep.title || tr("قسمت", "Episode")}`;
        if (ep.fileUrl) {
          // Gallery video — direct download
          await cacheVideoOffline(key, { label });
        } else if (ep.videoId) {
          // YouTube video — backend resolves direct URL, then download
          const res = await base44.functions.invoke('downloadYoutubeVideo', { videoId: ep.videoId });
          if (res?.data?.fileUrl) {
            await cacheVideoOffline(key, { label }, res.data.fileUrl);
          }
        }
      } catch {}
      setDlProgress({ current: i + 1, total: toDownload.length });
    }
    setDownloadingAll(false);
    setDlProgress({ current: 0, total: 0 });
  };

  // ── Playing mode: video fills the ENTIRE screen; overlays auto-hide ──
  if (playingEpisode) {
    return (
      <div className="fixed inset-0 text-white overflow-hidden"
        style={{ background: '#000', WebkitTouchCallout: 'none', WebkitUserSelect: 'none', userSelect: 'none' }}
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* Video — fills the whole screen, no black bars, no YouTube UI */}
        <div className="absolute inset-0 bg-black" onClick={toggleUI}>
          {playingEpisode.embedUrl ? (
            <iframe ref={embedRef} src={playingEpisode.embedUrl} allow="autoplay; fullscreen" allowFullScreen
              className="absolute inset-0 w-full h-full" frameBorder="0" />
          ) : playingEpisode.fileUrl ? (
            offlineChecked ? (
              offlineSrc ? (
                <HlsVideoPlayer key={playingEpisode._playId || offlineSrc} src={offlineSrc} onVideoClick={toggleUI} seriesTitle={series.title} seriesPoster={series.poster} isAdmin={isAdmin} posterPosition={series.posterPosition} />
              ) : (
                <HlsVideoPlayer key={playingEpisode._playId || playingEpisode.fileUrl} src={playingEpisode.fileUrl} onVideoClick={toggleUI} seriesTitle={series.title} seriesPoster={series.poster} isAdmin={isAdmin} posterPosition={series.posterPosition} />
              )
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-black z-[20]">
                <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
              </div>
            )
          ) : playingEpisode.videoId ? (
            <YouTubePlayer
              key={playingEpisode._playId || playingEpisode.videoId}
              videoId={playingEpisode.videoId}
              onVideoClick={toggleUI}
              seriesTitle={series.title}
              seriesPoster={series.poster}
              posterPosition={series.posterPosition}
              hideInfo
            />
          ) : null}
        </div>

        {/* Floating back + list buttons — mobile only (TV uses top bar which auto-hides) */}
        {!isTV && (
          <>
            <button onClick={() => (onExitPlayer || onBack)()} data-remote className="md:hidden absolute z-50 w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
              style={{ bottom: 'calc(5rem + env(safe-area-inset-bottom))', left: 'calc(1rem + env(safe-area-inset-left))', background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.25)' }}>
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <button onClick={() => setShowSidebar(v => !v)} data-remote className="md:hidden absolute z-50 w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
              style={{ bottom: 'calc(5rem + env(safe-area-inset-bottom))', right: 'calc(1rem + env(safe-area-inset-right))', background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.25)' }}>
              <List className="w-6 h-6 text-white" />
            </button>
          </>
        )}

        {/* Hide-logo cover overlays — masks channel logos / watermarks on the video */}
        {hideLogoPos >= 0 && (
          <>
            {/* Top-right corner */}
            {(hideLogoPos === 0 || hideLogoPos === 4) && (
              <div className="absolute z-[35] pointer-events-none" style={{ top: 0, right: 0, width: '24%', height: '14%', background: 'rgba(5,5,12,0.25)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)' }} />
            )}
            {/* Top-left corner */}
            {(hideLogoPos === 1 || hideLogoPos === 4) && (
              <div className="absolute z-[35] pointer-events-none" style={{ top: 0, left: 0, width: '24%', height: '14%', background: 'rgba(5,5,12,0.25)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)' }} />
            )}
            {/* Bottom-left corner */}
            {(hideLogoPos === 2 || hideLogoPos === 4) && (
              <div className="absolute z-[35] pointer-events-none" style={{ bottom: 0, left: 0, width: '24%', height: '14%', background: 'rgba(5,5,12,0.25)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)' }} />
            )}
            {/* Bottom-right corner */}
            {(hideLogoPos === 3 || hideLogoPos === 4) && (
              <div className="absolute z-[35] pointer-events-none" style={{ bottom: 0, right: 0, width: '24%', height: '14%', background: 'rgba(5,5,12,0.25)', backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)' }} />
            )}
          </>
        )}

        {/* Manual blur box — draggable, user positions it over logos/text */}
        {blurMode && (
          <div
            className="absolute z-[36] cursor-move touch-none"
            style={{
              top: `${blurPos.y}%`,
              left: `${blurPos.x}%`,
              width: `${blurSize.w}%`,
              height: `${blurSize.h}%`,
              transform: 'translate(-50%, -50%)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              background: 'rgba(5,5,12,0.15)',
              border: '2px solid rgba(34,211,238,0.5)',
              borderRadius: '12px',
              boxShadow: '0 0 20px rgba(34,211,238,0.2)',
            }}
            onPointerDown={(e) => {
              e.stopPropagation();
              e.currentTarget.setPointerCapture(e.pointerId);
              blurDragRef.current = { startX: e.clientX, startY: e.clientY, posX: blurPos.x, posY: blurPos.y };
            }}
            onPointerMove={(e) => {
              e.stopPropagation();
              if (!blurDragRef.current) return;
              const dx = (e.clientX - blurDragRef.current.startX) / window.innerWidth * 100;
              const dy = (e.clientY - blurDragRef.current.startY) / window.innerHeight * 100;
              setBlurPos({
                x: Math.max(5, Math.min(95, blurDragRef.current.posX + dx)),
                y: Math.max(5, Math.min(95, blurDragRef.current.posY + dy)),
              });
            }}
            onPointerUp={(e) => { e.stopPropagation(); blurDragRef.current = null; }}
            onPointerCancel={(e) => { e.stopPropagation(); blurDragRef.current = null; }}
          >
            {/* Close button — dismisses blur */}
            <button
              onClick={(e) => { e.stopPropagation(); setBlurMode(false); }}
              onPointerDown={(e) => e.stopPropagation()}
              className="absolute -top-3 -right-3 w-7 h-7 rounded-full flex items-center justify-center z-10"
              style={{ background: 'rgba(239,68,68,0.9)', border: '2px solid rgba(255,255,255,0.3)' }}
            >
              <X className="w-4 h-4 text-white" />
            </button>
            <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-cyan-400 text-sm font-bold whitespace-nowrap pointer-events-none">
              {tr("بکشید برای جابه‌جایی", "Drag to move")}
            </span>
            {/* Resize handle — bottom-right corner */}
            <div
              className="absolute -bottom-2 -right-2 w-6 h-6 rounded-full cursor-se-resize touch-none"
              style={{ background: 'rgba(34,211,238,0.8)', border: '2px solid rgba(255,255,255,0.3)' }}
              onPointerDown={(e) => {
                e.stopPropagation();
                e.currentTarget.setPointerCapture(e.pointerId);
                blurResizeRef.current = { startX: e.clientX, startY: e.clientY, w: blurSize.w, h: blurSize.h };
              }}
              onPointerMove={(e) => {
                e.stopPropagation();
                if (!blurResizeRef.current) return;
                const dx = (e.clientX - blurResizeRef.current.startX) / window.innerWidth * 100;
                const dy = (e.clientY - blurResizeRef.current.startY) / window.innerHeight * 100;
                setBlurSize({
                  w: Math.max(10, Math.min(80, blurResizeRef.current.w + dx)),
                  h: Math.max(8, Math.min(60, blurResizeRef.current.h + dy)),
                });
              }}
              onPointerUp={(e) => { e.stopPropagation(); blurResizeRef.current = null; }}
              onPointerCancel={(e) => { e.stopPropagation(); blurResizeRef.current = null; }}
            />
          </div>
        )}

        {/* Floating Blur button — always visible during playback */}
        <button
          onClick={() => setBlurMode(v => !v)}
          data-remote
          className="absolute z-[38] flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-semibold transition-colors"
          style={{
            bottom: 'calc(1rem + env(safe-area-inset-bottom))',
            right: 'calc(1rem + env(safe-area-inset-right))',
            background: blurMode ? 'rgba(34,211,238,0.3)' : 'rgba(0,0,0,0.7)',
            backdropFilter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
            border: blurMode ? '1px solid rgba(34,211,238,0.5)' : '1px solid rgba(255,255,255,0.15)',
            color: blurMode ? '#22d3ee' : 'rgba(255,255,255,0.8)',
          }}
        >
          <Droplet className="w-4 h-4" />
          {blurMode ? tr("بلور روشن", "Blur On") : tr("بلور", "Blur")}
        </button>

        {/* Top bar overlay (auto-hides) */}
        {showUI && (
          <div className="absolute top-0 left-0 right-0 z-30 flex items-center gap-3 px-4 py-3"
            style={{ background: 'linear-gradient(180deg, rgba(0,0,0,0.85) 0%, transparent 100%)', paddingTop: 'calc(0.75rem + env(safe-area-inset-top))' }}>
            <button onClick={() => (onExitPlayer || onBack)()} data-remote className="flex items-center gap-2 text-white/90 hover:text-white bg-white/10 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors flex-shrink-0">
              <ArrowLeft className="w-4 h-4" /> {tr("بازگشت", "Back")}
            </button>
            <span className="flex-1" />
            {/* Hide logo/name toggle — cycles through corners to mask channel logos */}
            <button onClick={() => setHideLogoPos(p => (p + 1) % 5)} data-remote
              className="flex items-center gap-1.5 bg-white/10 backdrop-blur-md hover:bg-white/15 rounded-xl px-3 py-2 text-sm font-semibold transition-colors flex-shrink-0"
              style={{ color: hideLogoPos >= 0 ? '#22d3ee' : 'rgba(255,255,255,0.7)' }}>
              {hideLogoPos >= 0 ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {hideLogoPos >= 0 ? tr("پنهان لوگو", "Hide Logo") : tr("پنهان لوگو", "Hide Logo")}
            </button>
            {playingEpisode.fileUrl && (
              <button onClick={async () => {
                if (offlineReady) return;
                try {
                  setDownloading(true);
                  await cacheVideoOffline(playingEpisode.fileUrl, { label: `${series?.title ? series.title + " — " : ""}${playingEpisode.title || tr("قسمت", "Episode")}` });
                  const u = await getOfflineVideoUrl(playingEpisode.fileUrl);
                  if (u) { setOfflineSrc(u); setOfflineReady(true); }
                } catch { window.alert(tr("دانلود ناموفق بود", "Download failed")); }
                finally { setDownloading(false); }
              }} disabled={downloading || offlineReady}
                className="flex items-center gap-1.5 text-cyan-300 bg-white/10 backdrop-blur-md hover:bg-white/15 rounded-xl px-3 py-2 text-sm font-semibold transition-colors disabled:opacity-60 flex-shrink-0">
                {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : offlineReady ? <Check className="w-4 h-4 text-green-400" /> : <Download className="w-4 h-4" />}
                {offlineReady ? (tr("افلاین ✓", "Offline ✓")) : ""}
              </button>
            )}
          </div>
        )}

        {/* Floating controls — sidebar toggle (auto-hide) */}
        {showUI && (
          <div className="absolute top-3 right-3 z-40 flex gap-2">
            <button
              onClick={() => setShowSidebar(v => !v)} data-remote
              className="w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-md transition-all hover:scale-105"
              style={{ background: 'rgba(0,0,0,0.6)', border: '1px solid rgba(255,255,255,0.15)' }}
            >
              <List className="w-5 h-5 text-white/80" />
            </button>
          </div>
        )}

        {/* Episode sidebar — overlay drawer on the right (toggle with the List button) */}
        {showSidebar && (
          <>
          <div className="absolute inset-0 z-30" onClick={() => setShowSidebar(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-72 z-40 flex flex-col overflow-hidden"
            style={{ background: 'rgba(10,13,22,0.96)', borderLeft: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="px-3 py-2.5 flex items-center gap-2 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
              <List className="w-3.5 h-3.5 text-purple-400" />
              <p className="text-white/60 text-sm font-bold uppercase tracking-widest">{tr("قسمت‌ها", "Episodes")}</p>
              <span className="text-white/30 text-sm mr-auto">{episodes.length}</span>
              <button onClick={() => setShowSidebar(false)} className="text-white/40 hover:text-white p-0.5"><X className="w-4 h-4" /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-2 py-2">
              {episodes.map((ep, i) => {
                const isActive = playingEpisode.videoId === ep.videoId;
                return (
                  <button key={`${ep.videoId}-${i}`} onClick={() => onPlayEpisode(ep)} data-remote
                    className={`tv-focusable group w-full flex items-center gap-2 rounded-lg p-1.5 mb-1 text-left transition-all ${isActive ? 'bg-purple-600/25 border border-purple-500/50' : 'hover:bg-white/5 border border-transparent'}`}>
                    <div className="relative w-20 h-12 flex-shrink-0 rounded overflow-hidden bg-black/40">
                      {ep.embedUrl ? (
                        <div className="w-full h-full flex items-center justify-center bg-black/40">
                          <Film className="w-4 h-4 text-white/40" />
                        </div>
                      ) : ep.fileUrl ? (
                        <video src={ep.fileUrl} className="w-full h-full object-cover" muted preload="metadata" />
                      ) : (
                        <img src={`https://img.youtube.com/vi/${ep.videoId}/mqdefault.jpg`} alt={ep.title}
                          className="w-full h-full object-cover" onError={e => { e.target.style.display = 'none'; }} />
                      )}
                      {isActive ? (
                        <div className="absolute inset-0 flex items-center justify-center" style={{ background: 'rgba(123,44,191,0.5)' }}>
                          <Play className="w-4 h-4 fill-white text-white" />
                        </div>
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: 'rgba(0,0,0,0.4)' }}>
                          <Play className="w-4 h-4 fill-white text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-semibold truncate ${isActive ? 'text-white' : 'text-white/70'}`}>
                        {/^(قسمت|Episode)\s+\d+$/i.test((ep.title || '').trim()) ? `${tr("قسمت", "Episode")} ${ep.number}` : (ep.title || `${tr("قسمت", "Episode")} ${ep.number}`)}
                      </p>
                      <p className="text-purple-400/60 text-sm mt-0.5">{tr("قسمت", "Episode")} {ep.number}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
          </>
        )}
      </div>
    );
  }

  // ── Default mode: hero header + episode list ──
  return (
    <div className="fixed inset-0 flex flex-col text-white overflow-hidden" style={{ background: '#0a0d16' }}>
      {/* Hero header with series poster */}
      <div className="relative flex-shrink-0" style={{ height: '200px' }}>
        {series.poster && (
          <img src={series.poster} alt={series.title} className="absolute inset-0 w-full h-full object-cover"
            style={{
              objectPosition: series.posterPosition || 'center 20%',
              transform: `scale(${series.posterScale || 1})`,
              transformOrigin: series.posterPosition || 'center 20%',
            }}
            onError={e => { e.target.style.display = 'none'; }} />
        )}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(10,13,22,0.4) 0%, rgba(10,13,22,0.85) 70%, #0a0d16 100%)' }} />

        <div className="absolute top-0 left-0 right-0 flex items-center justify-between px-4 py-3 z-10">
          <button onClick={onBack} data-remote className="flex items-center gap-2 text-white/80 hover:text-white bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors">
            <ArrowLeft className="w-4 h-4" /> {tr("بازگشت", "Back")}
          </button>
          <div className="flex items-center gap-2">
            {downloadableEps.length > 0 && (
              <button onClick={handleDownloadAll} disabled={downloadingAll || allDownloaded} data-remote
                className="flex items-center gap-1.5 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors disabled:opacity-60 hover:bg-cyan-500/20"
                style={{ color: allDownloaded ? '#34d399' : '#22d3ee' }}>
                {downloadingAll ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    {dlProgress.current}/{dlProgress.total}
                  </>
                ) : allDownloaded ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> {tr("دانلود شده", "Downloaded")}
                  </>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5" /> {tr("دانلود همه", "Download All")}
                  </>
                )}
              </button>
            )}
            {onAddEpisode && (
              <button onClick={() => setShowAddEpisode(true)} data-remote
                className="flex items-center gap-1.5 text-cyan-300 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors hover:bg-cyan-500/20">
                <Plus className="w-3.5 h-3.5" /> {tr("افزودن قسمت", "Add Episode")}
              </button>
            )}
            {isAdmin && (
              <label className="flex items-center gap-1.5 text-amber-300 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors hover:bg-amber-500/20 cursor-pointer">
                <Music className="w-3.5 h-3.5" />
                {series.coverMusic ? tr("موسیقی ✓", "Music ✓") : tr("موسیقی کاور", "Cover Music")}
                <input type="file" accept="audio/*" className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    try {
                      const { file_url } = await base44.integrations.Core.UploadFile({ file });
                      await base44.entities.Series.update(series.id, { coverMusic: file_url });
                      window.location.reload();
                    } catch { window.alert(tr("آپلود ناموفق", "Upload failed")); }
                  }} />
              </label>
            )}
            {onDelete && (
              <button onClick={() => { if (window.confirm(fa ? 'حذف این سریال؟' : 'Delete this series?')) onDelete(); }} data-remote
                className="flex items-center gap-1.5 text-red-400 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors hover:bg-red-500/20">
                <Trash2 className="w-3.5 h-3.5" /> {tr("حذف", "Delete")}
              </button>
            )}
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
          <h1 className="text-white font-black text-xl md:text-2xl mb-1 drop-shadow-lg">{series.title}</h1>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-purple-300 text-sm font-semibold bg-purple-600/20 border border-purple-500/30 rounded-full px-2.5 py-0.5">
              <List className="w-3 h-3" /> {allEpisodes.length} {tr("قسمت", "episodes")}
            </span>
            <span className="flex items-center gap-1 text-white/50 text-sm">
              <Clock className="w-3 h-3" /> {tr("پخش از داخل برنامه", "In-app playback")}
            </span>
          </div>
        </div>
      </div>

      {/* Episode list */}
      <div ref={episodeListRef} className="flex-1 overflow-y-auto px-4 py-4">
        {/* Season selector — horizontal tabs */}
        {seasons.length > 1 && (
          <div className="flex gap-2 mb-4 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
            {seasons.map(s => (
              <button key={s} onClick={() => setSelectedSeason(s)} data-remote
                className={`tv-focusable flex-shrink-0 px-4 py-2 rounded-xl text-sm font-bold transition-all ${currentSeason === s ? 'text-white' : 'text-white/50 hover:text-white/80'}`}
                style={currentSeason === s
                  ? { background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)', boxShadow: '0 2px 12px rgba(123,44,191,0.4)' }
                  : { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
                {tr(`فصل ${s}`, `Season ${s}`)}
              </button>
            ))}
          </div>
        )}
        <p className="text-white/40 text-sm font-bold uppercase tracking-widest mb-3">
          {seasons.length > 1 ? tr(`فصل ${currentSeason} — قسمت‌ها`, `Season ${currentSeason} — Episodes`) : tr("قسمت‌ها — از اول به آخر", "Episodes — first to last")}
        </p>
        <div className="flex flex-col gap-2 max-w-2xl mx-auto w-full">
          {episodes.map((ep, i) => (
            <div key={`${ep.videoId}-${i}`} onClick={() => onPlayEpisode(ep)} tabIndex={0} data-remote
              className="tv-focusable group flex items-center gap-3 rounded-xl overflow-hidden text-left transition-all hover:scale-[1.01] w-full cursor-pointer"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center m-1.5 rounded-lg"
                style={{ background: 'rgba(123,44,191,0.2)', border: '1px solid rgba(123,44,191,0.4)' }}>
                {editingEpIdx === i ? (
                  <input type="number" min="1" value={epNumValue}
                    onChange={e => setEpNumValue(e.target.value)}
                    onBlur={() => {
                      const newNum = Number(epNumValue);
                      if (newNum > 0 && newNum !== ep.number && onEditEpisodeNumber) {
                        onEditEpisodeNumber(i, newNum);
                      }
                      setEditingEpIdx(null);
                    }}
                    onKeyDown={e => { if (e.key === 'Enter') e.target.blur(); if (e.key === 'Escape') setEditingEpIdx(null); }}
                    className="w-8 bg-transparent text-center text-purple-300 font-bold text-sm outline-none"
                    autoFocus />
                ) : onEditEpisodeNumber ? (
                  <button onClick={(e) => { e.stopPropagation(); setEditingEpIdx(i); setEpNumValue(String(ep.number)); }}
                    className="text-purple-300 font-bold text-sm hover:text-cyan-400 transition-colors">
                    {ep.number}
                  </button>
                ) : (
                  <span className="text-purple-300 font-bold text-sm">{ep.number}</span>
                )}
              </div>
              <div className="relative w-28 h-16 flex-shrink-0 bg-black/40 rounded-lg overflow-hidden">
                {ep.embedUrl ? (
                  <div className="w-full h-full flex items-center justify-center bg-black/40">
                    <Film className="w-5 h-5 text-white/30" />
                  </div>
                ) : ep.fileUrl ? (
                  <video src={ep.fileUrl} className="w-full h-full object-cover" muted preload="metadata" />
                ) : (
                  <img src={`https://img.youtube.com/vi/${ep.videoId}/mqdefault.jpg`} alt={ep.title}
                    className="w-full h-full object-cover" onError={e => { e.target.style.display = 'none'; }} />
                )}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ background: 'rgba(123,44,191,0.5)' }}>
                  <Play className="w-5 h-5 fill-white text-white" />
                </div>
              </div>
              <div className="flex-1 min-w-0 py-2">
                <p className="text-white text-sm font-semibold truncate">
                  {/^(قسمت|Episode)\s+\d+$/i.test((ep.title || '').trim()) ? `${tr("قسمت", "Episode")} ${ep.number}` : (ep.title || `${tr("قسمت", "Episode")} ${ep.number}`)}
                </p>
                <p className="text-purple-400/60 text-sm mt-0.5">{tr("قسمت", "Episode")} {ep.number}</p>
              </div>
              {onReorderEpisodes && (
                <div className="flex flex-col gap-0.5 flex-shrink-0">
                  <button onClick={(e) => { e.stopPropagation(); if (i > 0) onReorderEpisodes(i, i - 1); }}
                    disabled={i === 0}
                    className="w-7 h-6 rounded flex items-center justify-center hover:bg-white/10 transition-colors disabled:opacity-20 disabled:hover:bg-transparent">
                    <ChevronUp className="w-4 h-4 text-cyan-400" />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); if (i < episodes.length - 1) onReorderEpisodes(i, i + 1); }}
                    disabled={i === episodes.length - 1}
                    className="w-7 h-6 rounded flex items-center justify-center hover:bg-white/10 transition-colors disabled:opacity-20 disabled:hover:bg-transparent">
                    <ChevronDown className="w-4 h-4 text-cyan-400" />
                  </button>
                </div>
              )}
              {onDeleteEpisode && (
                <button onClick={(e) => { e.stopPropagation(); if (window.confirm(fa ? 'حذف این قسمت؟' : 'Delete this episode?')) onDeleteEpisode(i); }} data-remote
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-colors hover:bg-red-500/20"
                  style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              )}
              <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mr-3 transition-colors"
                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
                <Play className="w-4 h-4 text-white/50 group-hover:text-purple-400 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddEpisode && (
        <AddEpisodeForm
          nextNumber={nextEpNumber}
          currentSeason={currentSeason}
          isFa={fa}
          onAdd={(ep) => { onAddEpisode(ep); setShowAddEpisode(false); }}
          onClose={() => setShowAddEpisode(false)}
        />
      )}
    </div>
  );
}