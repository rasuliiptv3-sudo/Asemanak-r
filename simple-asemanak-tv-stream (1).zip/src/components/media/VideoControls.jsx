import { useState, useEffect } from "react";
import { Play, Pause, Rewind, FastForward, Volume2, VolumeX, Sun, Settings2, Maximize, Shrink, ZoomIn } from "lucide-react";

const QUALITY_OPTIONS = [
  { value: "auto", label: "Auto", ytKey: null },
  { value: "1080p", label: "1080p", ytKey: "hd1080" },
  { value: "720p", label: "720p", ytKey: "hd720" },
  { value: "480p", label: "480p", ytKey: "large" },
  { value: "360p", label: "360p", ytKey: "medium" },
];

const SCREEN_SIZES = [
  { value: "full", label: "کامل", scale: 1.0 },
  { value: "large", label: "بزرگ", scale: 0.85 },
  { value: "medium", label: "متوسط", scale: 0.65 },
  { value: "small", label: "کوچک", scale: 0.45 },
];

export default function VideoControls({ playerRef, onTogglePlay, isPlaying, brightness, onBrightnessChange, onScreenSizeChange, isTV = false }) {
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(100);
  const [muted, setMuted] = useState(false);
  const [quality, setQuality] = useState("auto");
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [screenSize, setScreenSize] = useState("full");
  const [showScreenMenu, setShowScreenMenu] = useState(false);
  const [zoom, setZoom] = useState(1);
  const ZOOM_LEVELS = [1, 1.25, 1.5, 2];
  const cycleZoom = () => {
    setZoom(prev => {
      const idx = ZOOM_LEVELS.indexOf(prev);
      const next = ZOOM_LEVELS[(idx + 1) % ZOOM_LEVELS.length];
      if (onScreenSizeChange) onScreenSizeChange(next);
      return next;
    });
  };

  // Poll current time and duration
  useEffect(() => {
    const interval = setInterval(() => {
      if (!playerRef.current) return;
      try {
        setCurrentTime(playerRef.current.getCurrentTime() || 0);
        setDuration(playerRef.current.getDuration() || 0);
      } catch {}
    }, 500);
    return () => clearInterval(interval);
  }, [playerRef]);

  const seekTo = (time) => {
    if (!playerRef.current) return;
    try { playerRef.current.seekTo(time, true); setCurrentTime(time); } catch {}
  };

  const seekBy = (delta) => {
    seekTo(Math.max(0, Math.min(duration, currentTime + delta)));
  };

  const handleVolume = (v) => {
    setVolume(v);
    setMuted(v === 0);
    if (playerRef.current) {
      try {
        if (v === 0) playerRef.current.mute();
        else { playerRef.current.unMute(); playerRef.current.setVolume(v); }
      } catch {}
    }
  };

  const changeQuality = (q) => {
    setQuality(q);
    setShowQualityMenu(false);
    if (!playerRef.current) return;
    const opt = QUALITY_OPTIONS.find(o => o.value === q);
    if (opt && opt.ytKey) {
      // setPlaybackQualityRange is the modern API — locks both min and max to force the quality.
      try { playerRef.current.setPlaybackQualityRange(opt.ytKey, opt.ytKey); } catch {}
      // Fallback to deprecated setPlaybackQuality for older players.
      try { playerRef.current.setPlaybackQuality(opt.ytKey); } catch {}
    } else {
      // "auto" — reset range to default
      try { playerRef.current.setPlaybackQualityRange("small", "hd1080"); } catch {}
      try { playerRef.current.setPlaybackQuality("default"); } catch {}
    }
  };

  const toggleMute = () => {
    if (muted || volume === 0) {
      setMuted(false);
      setVolume(50);
      if (playerRef.current) { try { playerRef.current.unMute(); playerRef.current.setVolume(50); } catch {} }
    } else {
      setMuted(true);
      if (playerRef.current) { try { playerRef.current.mute(); } catch {} }
    }
  };

  const formatTime = (s) => {
    if (!s || isNaN(s)) return "0:00";
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="absolute bottom-0 left-0 right-0 z-30 px-3 pb-2 pt-10"
      style={{ background: 'linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.92) 35%)' }}
    >
      {/* Seek bar */}
      <div data-remote tabIndex={0} role="slider" className="w-full h-1.5 rounded-full bg-white/20 cursor-pointer mb-2 relative group"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const pct = (e.clientX - rect.left) / rect.width;
          seekTo(pct * duration);
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowLeft") { e.preventDefault(); seekBy(-10); }
          if (e.key === "ArrowRight") { e.preventDefault(); seekBy(10); }
        }}
      >
        <div className="h-full rounded-full" style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #7b2cbf, #c77dff)' }} />
        <div className="absolute top-1/2 w-3 h-3 rounded-full bg-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
          style={{ left: `${progress}%`, transform: 'translate(-50%, -50%)' }} />
      </div>

      {/* Controls row */}
      <div className="flex items-center gap-2 flex-wrap">
        {/* Transport buttons — visible on both TV and mobile (remote handles play/pause/seek too) */}
        <button onClick={() => seekBy(-10)} data-remote className="w-11 h-11 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
          <Rewind className="w-4 h-4 text-white" />
        </button>
        <button onClick={onTogglePlay} data-remote className="w-11 h-11 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
          {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
        </button>
        <button onClick={() => seekBy(10)} data-remote className="w-11 h-11 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
          <FastForward className="w-4 h-4 text-white" />
        </button>

        <span className="text-white/70 text-sm font-mono whitespace-nowrap mr-1">
          {formatTime(currentTime)} / {formatTime(duration)}
        </span>

        {/* Volume + Brightness — visible on mobile only (TV uses remote ↑/↓ for volume) */}
        {!isTV && (
          <>
            <div className="flex items-center gap-1.5 ml-1">
              <button onClick={toggleMute} data-remote className="w-11 h-11 rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors flex-shrink-0">
                {muted || volume === 0 ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
              </button>
              <input type="range" min={0} max={100} value={muted ? 0 : volume}
                onChange={(e) => handleVolume(parseInt(e.target.value))}
                className="w-14 h-1 cursor-pointer" style={{ accentColor: '#c77dff' }}
              />
            </div>

            <div className="flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-white/70 flex-shrink-0" />
              <input type="range" min={20} max={150} value={Math.round(brightness * 100)}
                onChange={(e) => onBrightnessChange(parseInt(e.target.value) / 100)}
                className="w-14 h-1 cursor-pointer" style={{ accentColor: '#c77dff' }}
              />
            </div>

            {/* Zoom */}
            <button onClick={cycleZoom} data-remote
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-white/15 transition-colors flex-shrink-0 min-h-[44px]"
              title="زوم">
              <ZoomIn className="w-4 h-4 text-white/70" />
              <span className="text-white/70 text-sm font-medium">{zoom === 1 ? "زوم" : `${zoom}x`}</span>
            </button>
          </>
        )}

        {/* Screen size selector — always visible (TV + mobile) */}
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setShowScreenMenu(v => !v)} data-remote
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-white/15 transition-colors min-h-[44px]"
            title="سایز صفحه"
          >
            {screenSize === "full" ? <Maximize className="w-4 h-4 text-white/70" /> : <Shrink className="w-4 h-4 text-white/70" />}
            <span className="text-white/70 text-sm font-medium">{SCREEN_SIZES.find(s => s.value === screenSize)?.label || "کامل"}</span>
          </button>
          {showScreenMenu && (
            <div className="absolute bottom-full right-0 mb-2 rounded-xl overflow-hidden backdrop-blur-md"
              style={{ background: "rgba(10,13,22,0.95)", border: "1px solid rgba(255,255,255,0.15)", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", minWidth: "110px" }}>
              <p className="px-4 py-1.5 text-sm text-white/60 uppercase tracking-wider border-b border-white/10">سایز صفحه</p>
              {SCREEN_SIZES.map(opt => (
                <button key={opt.value} data-remote onClick={() => { setScreenSize(opt.value); setShowScreenMenu(false); if (onScreenSizeChange) onScreenSizeChange(opt.scale); }}
                  className={`flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors w-full text-right ${screenSize === opt.value ? "text-cyan-400" : "text-white/70"}`}>
                  <span className="text-sm">{opt.label}</span>
                  {screenSize === opt.value && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Quality selector — always visible (TV + mobile) */}
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setShowQualityMenu(v => !v)} data-remote
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-white/15 transition-colors min-h-[44px]"
            title="کیفیت"
          >
            <Settings2 className="w-4 h-4 text-white/70" />
            <span className="text-white/70 text-sm font-medium">{quality === "auto" ? "Auto" : quality}</span>
          </button>
          {showQualityMenu && (
            <div className="absolute bottom-full right-0 mb-2 rounded-xl overflow-hidden backdrop-blur-md"
              style={{ background: "rgba(10,13,22,0.95)", border: "1px solid rgba(255,255,255,0.15)", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", minWidth: "100px" }}>
              <p className="px-4 py-1.5 text-sm text-white/60 uppercase tracking-wider border-b border-white/10">کیفیت</p>
              {QUALITY_OPTIONS.map(opt => (
                <button key={opt.value} data-remote onClick={() => changeQuality(opt.value)}
                  className={`flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors w-full text-right ${quality === opt.value ? "text-cyan-400" : "text-white/70"}`}>
                  <span className="text-sm">{opt.label}</span>
                  {quality === opt.value && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Branding */}
        <span className="ml-auto text-white/60 text-sm font-medium flex items-center gap-1.5 whitespace-nowrap">
          <div className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse" />
          پخش از آسمانک تی وی
        </span>
      </div>
    </div>
  );
}