import { Loader2 } from "lucide-react";
import AsemanakLogo from "@/components/brand/AsemanakLogo";

/**
 * Series cover overlay — professional cinematic loading experience.
 * Ken Burns zoom on the poster, Asemanak Series branding,
 * elegant dual-ring loader with glow, glassmorphism gradients.
 */
export default function SeriesCoverOverlay({ poster, title, phase, visible = true, onReplay, posterPosition }) {
  const isImage = poster && poster.match(/\.(jpg|jpeg|png|gif|webp|svg|avif)(\?|#|$)/i);
  const objPos = posterPosition || 'center 20%';

  return (
    <div className="absolute inset-0 z-[35] overflow-hidden transition-opacity duration-700"
      style={{ opacity: visible ? 1 : 0, pointerEvents: phase === "end" && visible ? "auto" : "none" }}>

      {/* Background — poster image OR solid dark */}
      {isImage ? (
        <img src={poster} alt={title}
          className="absolute inset-0 w-full h-full object-cover cover-kenburns"
          style={{ objectPosition: objPos }}
          onError={(e) => { e.target.style.display = 'none'; }} />
      ) : poster ? (
        <video src={`${poster}#t=0.1`} className="absolute inset-0 w-full h-full object-cover"
          style={{ objectPosition: objPos }}
          muted preload="metadata" playsInline />
      ) : (
        <div className="absolute inset-0" style={{ background: '#0a0d16' }} />
      )}

      {/* Cinematic gradient layers */}
      {poster && (
        <>
          <div className="absolute inset-0" style={{
            background: 'linear-gradient(180deg, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.15) 30%, rgba(0,0,0,0.2) 55%, rgba(0,0,0,0.9) 100%)'
          }} />
          <div className="absolute inset-0" style={{
            background: 'radial-gradient(ellipse at 50% 80%, rgba(107,84,255,0.15) 0%, transparent 55%)'
          }} />
          <div className="absolute inset-0" style={{
            boxShadow: 'inset 0 0 200px 50px rgba(0,0,0,0.75)'
          }} />
        </>
      )}
      {!poster && (
        <div className="absolute inset-0" style={{
          background: 'radial-gradient(ellipse 80% 60% at 50% 30%, rgba(224,56,246,0.08) 0%, transparent 60%), radial-gradient(ellipse 60% 50% at 50% 90%, rgba(107,84,255,0.1) 0%, transparent 50%), #0a0d16'
        }} />
      )}

      {/* Asemanak Series logo — top left, glassmorphism */}
      {phase === "start" && (
        <div className="absolute top-5 left-5 z-10 flex items-center gap-2 px-3 py-2 rounded-2xl"
          style={{ background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.1)' }}>
          <AsemanakLogo size={32} showText={true} variant="SERIES" />
        </div>
      )}

      {/* Professional loading indicator — dual ring with glow */}
      {phase === "start" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-6">
          <div className="relative" style={{ width: 64, height: 64 }}>
            {/* Outer ring — slow rotation */}
            <div className="absolute inset-0 rounded-full"
              style={{
                border: '2px solid transparent',
                borderTopColor: 'rgba(224,56,246,0.9)',
                borderRightColor: 'rgba(107,84,255,0.6)',
                animation: 'cover-spin 1.4s linear infinite',
                filter: 'drop-shadow(0 0 8px rgba(224,56,246,0.5))',
              }} />
            {/* Inner ring — counter rotation */}
            <div className="absolute rounded-full"
              style={{
                inset: 8,
                border: '2px solid transparent',
                borderBottomColor: 'rgba(34,211,238,0.7)',
                animation: 'cover-spin-rev 1.8s linear infinite',
                filter: 'drop-shadow(0 0 6px rgba(34,211,238,0.4))',
              }} />
            {/* Center dot */}
            <div className="absolute rounded-full"
              style={{
                top: '50%', left: '50%', width: 6, height: 6,
                transform: 'translate(-50%, -50%)',
                background: 'linear-gradient(135deg, #E038F6, #6B54FF)',
                boxShadow: '0 0 12px rgba(107,84,255,0.6)',
              }} />
          </div>
        </div>
      )}

      {/* Series title — elegant bottom placement */}
      {phase === "start" && title && (
        <div className="absolute bottom-0 left-0 right-0 px-6 pb-10 text-center">
          <div className="inline-block px-4 py-1.5 rounded-full mb-3"
            style={{ background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.12)' }}>
            <span className="text-white/60 text-[10px] font-bold uppercase tracking-[0.25em]">Now Loading</span>
          </div>
          <h2 className="text-white font-bold text-lg md:text-2xl tracking-wide"
            style={{ textShadow: '0 2px 24px rgba(0,0,0,0.9), 0 0 8px rgba(107,84,255,0.2)' }}>{title}</h2>
        </div>
      )}

      {/* Replay button (end phase) */}
      {phase === "end" && onReplay && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
          <AsemanakLogo size={48} showText={true} variant="SERIES" />
          <button onClick={onReplay} data-remote
            className="flex items-center gap-2 px-7 py-3.5 rounded-2xl text-white font-bold transition-all hover:scale-105"
            style={{
              background: 'linear-gradient(135deg, rgba(224,56,246,0.7), rgba(107,84,255,0.7))',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255,255,255,0.2)',
              boxShadow: '0 8px 32px rgba(107,84,255,0.4)',
            }}>
            <Loader2 className="w-5 h-5" />
            تماشای دوباره
          </button>
        </div>
      )}

      <style>{`
        @keyframes cover-kenburns {
          0% { transform: scale(1.0); }
          100% { transform: scale(1.1); }
        }
        .cover-kenburns {
          animation: cover-kenburns 5s ease-out forwards;
        }
        @keyframes cover-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes cover-spin-rev {
          0% { transform: rotate(360deg); }
          100% { transform: rotate(0deg); }
        }
      `}</style>
    </div>
  );
}