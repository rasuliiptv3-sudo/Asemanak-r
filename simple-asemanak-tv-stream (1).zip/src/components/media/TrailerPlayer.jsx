import { useRef, useEffect, useState } from "react";
import { X, Pause, Play, Volume2, VolumeX } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

/**
 * Fullscreen trailer player — plays the first episode of a series as a trailer.
 * Shows a "SKIP TRAILER" button (Darya.net style) that proceeds to the main series view.
 */
export default function TrailerPlayer({ series, onSkip, onClose }) {
  const playerRef = useRef(null);
  const containerRef = useRef(null);
  const mountedRef = useRef(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [muted, setMuted] = useState(false);
  const mutedRef = useRef(false);
  const [ready, setReady] = useState(false);

  const firstEp = (series?.episodes || [])[0];
  const videoId = firstEp?.videoId;
  const fileUrl = firstEp?.fileUrl;

  useEffect(() => {
    mountedRef.current = true;
    if (!videoId) { onSkip(); return; }

    const init = () => {
      if (!mountedRef.current || !containerRef.current) return;
      if (playerRef.current) { try { playerRef.current.destroy(); } catch {} }

      playerRef.current = new window.YT.Player(containerRef.current, {
        videoId,
        width: "100%",
        height: "100%",
        playerVars: {
          autoplay: 1, mute: 0, controls: 0, modestbranding: 1,
          rel: 0, iv_load_policy: 3, playsinline: 1, disablekb: 1, fs: 0,
        },
        events: {
          onReady: (e) => {
            if (!mountedRef.current) return;
            try {
              e.target.seekTo(15, true);
              e.target.unMute();
              e.target.setVolume(100);
              e.target.playVideo();
              e.target.setPlaybackQualityRange("hd720", "hd720");
            } catch {}
            setReady(true);
            // Fallback: if autoplay with sound is blocked, retry muted after 3s
            setTimeout(() => {
              if (mountedRef.current && playerRef.current) {
                try {
                  if (playerRef.current.getPlayerState() !== 1) {
                    playerRef.current.mute();
                    mutedRef.current = true;
                    setMuted(true);
                    playerRef.current.playVideo();
                  }
                } catch {}
              }
            }, 3000);
          },
          onStateChange: (e) => {
            if (!mountedRef.current) return;
            const st = e.data;
            if (st === window.YT.PlayerState.PLAYING) setIsPlaying(true);
            else if (st === window.YT.PlayerState.PAUSED) setIsPlaying(false);
            else if (st === window.YT.PlayerState.ENDED) onSkip();
          },
          onError: () => { if (mountedRef.current) onSkip(); },
        },
      });
    };

    if (window.YT && window.YT.Player) init();
    else {
      if (!window.ytApiLoading) {
        window.ytApiLoading = true;
        const tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(tag);
      }
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { if (prev) prev(); init(); };
      const check = setInterval(() => {
        if (window.YT && window.YT.Player) { clearInterval(check); init(); }
      }, 200);
      setTimeout(() => clearInterval(check), 8000);
    }

    return () => {
      mountedRef.current = false;
      if (playerRef.current) {
        try { playerRef.current.stopVideo(); } catch {}
        try { playerRef.current.destroy(); } catch {}
        playerRef.current = null;
      }
    };
  }, [videoId]);

  const togglePlay = () => {
    if (!playerRef.current) return;
    try {
      if (isPlaying) playerRef.current.pauseVideo();
      else playerRef.current.playVideo();
    } catch {}
  };

  const toggleMute = () => {
    if (!playerRef.current) return;
    const next = !muted;
    mutedRef.current = next;
    try {
      if (next) { playerRef.current.mute(); }
      else { playerRef.current.unMute(); playerRef.current.setVolume(100); }
    } catch {}
    setMuted(next);
  };

  if (!videoId && !fileUrl) return null;

  // Native video trailer for gallery-uploaded files
  if (!videoId && fileUrl) {
    return (
      <div className="fixed inset-0 z-[90] bg-black flex items-center justify-center">
        <video autoPlay muted playsInline src={fileUrl} className="w-full h-full object-cover"
          onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} onEnded={onSkip} />
        <div className="absolute inset-0" style={{ background: "rgba(0,0,0,0.35)" }} />
        <div className="absolute inset-0 z-[5]" />
        <button onClick={onClose} className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
          style={{ background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.2)", backdropFilter: "blur(8px)" }}>
          <X className="w-5 h-5 text-white" />
        </button>
        <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
          <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0" style={{ boxShadow: "0 0 10px rgba(123,44,191,0.4)", border: "1.5px solid rgba(123,44,191,0.35)" }}>
            <img src={LOGO_URL} alt="" className="w-full h-full object-cover" draggable={false} />
          </div>
          <div className="leading-tight">
            <p className="text-white font-bold text-sm">آسمانک</p>
            <p className="text-purple-300/70 text-[9px]">{series?.title}</p>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 z-20 px-4 pb-6 pt-20" style={{ background: "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.9) 50%)" }}>
          <div className="mb-4">
            <span className="text-xs font-bold uppercase tracking-widest text-purple-400 mb-1 block">تریلر • Trailer</span>
            <h2 className="text-white font-black text-xl md:text-2xl">{series?.title}</h2>
          </div>
          <div className="flex items-center justify-center gap-4">
            <button onClick={() => { const v = document.querySelector('video'); if (v) { if (v.paused) v.play(); else v.pause(); } }}
              className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110"
              style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", backdropFilter: "blur(8px)" }}>
              {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
            </button>
            <button onClick={() => { const v = document.querySelector('video'); if (v) { v.muted = !v.muted; setMuted(v.muted); } }}
              className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
              style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)", backdropFilter: "blur(8px)" }}>
              {muted ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
            </button>
            <button onClick={onSkip}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all hover:scale-105 active:scale-95"
              style={{ background: "transparent", border: "1.5px solid rgba(255,255,255,0.8)", boxShadow: "0 0 15px rgba(255,255,255,0.1)" }}>
              <span className="text-white font-bold text-xs uppercase tracking-wider whitespace-nowrap">Skip Trailer</span>
              <Play className="w-3.5 h-3.5 fill-white text-white" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[90] bg-black flex items-center justify-center">
      {/* YouTube player — scaled to cover, cropping overflow */}
      <div className="absolute inset-0 overflow-hidden">
        <div style={{
          position: "absolute", top: "50%", left: "50%",
          transform: "translate(-50%, -50%)",
          width: "100vw", height: "56.25vw",
          minHeight: "100%", minWidth: "177.78vh",
          pointerEvents: "none",
        }}>
          <div ref={containerRef} className="w-full h-full" />
        </div>
      </div>

      {/* Dark overlay for readability */}
      <div className="absolute inset-0" style={{ background: "rgba(0,0,0,0.35)" }} />

      {/* Transparent click-blocker */}
      <div className="absolute inset-0 z-[5]" />

      {/* Close button — top right */}
      <button onClick={onClose}
        className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
        style={{ background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.2)", backdropFilter: "blur(8px)" }}>
        <X className="w-5 h-5 text-white" />
      </button>

      {/* App logo — top left */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
        <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0"
          style={{ boxShadow: "0 0 10px rgba(123,44,191,0.4)", border: "1.5px solid rgba(123,44,191,0.35)" }}>
          <img src={LOGO_URL} alt="" className="w-full h-full object-cover" draggable={false} />
        </div>
        <div className="leading-tight">
          <p className="text-white font-bold text-sm">آسمانک</p>
          <p className="text-purple-300/70 text-[9px]">{series?.title}</p>
        </div>
      </div>

      {/* Loading */}
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center z-[15]">
          <div className="w-8 h-8 border-3 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
        </div>
      )}

      {/* Bottom controls */}
      <div className="absolute bottom-0 left-0 right-0 z-20 px-4 pb-6 pt-20"
        style={{ background: "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.9) 50%)" }}>

        {/* Title */}
        <div className="mb-4">
          <span className="text-xs font-bold uppercase tracking-widest text-purple-400 mb-1 block">تریلر • Trailer</span>
          <h2 className="text-white font-black text-xl md:text-2xl">{series?.title}</h2>
        </div>

        {/* Control buttons */}
        <div className="flex items-center justify-center gap-4">
          {/* Pause/Play */}
          <button onClick={togglePlay}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110"
            style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.2)", backdropFilter: "blur(8px)" }}>
            {isPlaying ? <Pause className="w-5 h-5 text-white" /> : <Play className="w-5 h-5 text-white" />}
          </button>

          {/* Mute toggle */}
          <button onClick={toggleMute}
            className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)", backdropFilter: "blur(8px)" }}>
            {muted ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
          </button>

          {/* SKIP TRAILER — Darya.net style */}
          <button onClick={onSkip}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg transition-all hover:scale-105 active:scale-95"
            style={{ background: "transparent", border: "1.5px solid rgba(255,255,255,0.8)", boxShadow: "0 0 15px rgba(255,255,255,0.1)" }}>
            <span className="text-white font-bold text-xs uppercase tracking-wider whitespace-nowrap">Skip Trailer</span>
            <Play className="w-3.5 h-3.5 fill-white text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}