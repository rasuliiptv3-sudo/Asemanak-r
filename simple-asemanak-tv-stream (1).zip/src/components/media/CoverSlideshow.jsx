import { useState, useEffect, useRef } from "react";
import { Play, List } from "lucide-react";

/**
 * Cover Slideshow — fullscreen horizontal cycling of all series cover images.
 * Used as a fallback when trailer auto-play fails on TV.
 * Each cover slides in from the right with a Ken Burns zoom effect,
 * holds for ~4s, then slides out to the left as the next one comes in.
 */
export default function CoverSlideshow({ allSeries, activeSeries, onEnter, isTV = false }) {
  const [index, setIndex] = useState(0);
  const [phase, setPhase] = useState("in"); // "in" | "hold" | "out"
  const timerRef = useRef(null);

  // Build list of covers — only series that have a poster image
  const covers = (allSeries || []).filter(s => {
    if (s.poster) return true;
    const vid = (s.episodes || []).find(ep => ep.videoId)?.videoId;
    return !!vid; // YouTube thumbnail as fallback cover
  });

  useEffect(() => {
    if (covers.length === 0) return;
    // Start with the active series if it has a cover
    if (activeSeries) {
      const activeIdx = covers.findIndex(s => s.id === activeSeries.id);
      if (activeIdx >= 0) setIndex(activeIdx);
    }
  }, []);

  // Cycle: in (1s) → hold (4s) → out (1s) → next
  useEffect(() => {
    if (covers.length <= 1) return;
    const durations = { in: 1000, hold: 4000, out: 1000 };
    timerRef.current = setTimeout(() => {
      setPhase(prev => {
        if (prev === "in") return "hold";
        if (prev === "hold") return "out";
        // out → next cover, back to "in"
        setIndex(i => (i + 1) % covers.length);
        return "in";
      });
    }, durations[phase]);
    return () => clearTimeout(timerRef.current);
  }, [phase, index, covers.length]);

  if (covers.length === 0) return null;

  const current = covers[index];
  if (!current) return null;

  const coverImage = current.poster
    || `https://img.youtube.com/vi/${(current.episodes || []).find(ep => ep.videoId)?.videoId}/maxresdefault.jpg`;

  // Slide animation: in = translateX(0) from right, out = translateX(-100%) to left
  const slideOffset = phase === "in" ? "0%" : phase === "out" ? "-100%" : "0%";
  const opacity = phase === "in" ? 1 : phase === "out" ? 0 : 1;

  return (
    <div className="relative w-full overflow-hidden flex-shrink-0" style={{ height: "45vh", minHeight: "280px", maxHeight: "420px" }}>
      {/* Cover image — slides horizontally with Ken Burns zoom */}
      <div
        className="absolute inset-0 transition-all duration-1000 ease-out"
        style={{
          transform: `translateX(${slideOffset}) scale(${phase === "hold" ? 1.08 : 1.0})`,
          opacity,
        }}
      >
        <img
          src={coverImage}
          alt={current.title}
          className="w-full h-full object-cover"
          style={{
            objectPosition: current.posterPosition || "center 20%",
            transform: `scale(${(current.posterScale || 1) * 1.02})`,
            transformOrigin: current.posterPosition || "center 20%",
          }}
          onError={e => {
            // Fallback to hq thumbnail if maxres fails
            const vid = (current.episodes || []).find(ep => ep.videoId)?.videoId;
            if (vid && e.target.src.includes("maxresdefault")) {
              e.target.src = `https://img.youtube.com/vi/${vid}/hqdefault.jpg`;
            } else {
              e.target.style.display = "none";
            }
          }}
        />
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 pointer-events-none" style={{ background: "rgba(10,13,22,0.35)" }} />
      <div className="absolute inset-0 pointer-events-none" style={{ background: "linear-gradient(180deg, rgba(10,13,22,0.15) 0%, rgba(10,13,22,0.35) 50%, #0a0d16 100%)" }} />
      <div className="absolute inset-0 pointer-events-none" style={{ background: "linear-gradient(90deg, rgba(10,13,22,0.85) 0%, transparent 60%)" }} />

      {/* Content overlay — show current series info */}
      <div className="absolute bottom-0 left-0 p-5 md:p-8 z-[40] max-w-lg" style={{ pointerEvents: 'none' }}>
        <span className="text-xs font-bold uppercase tracking-widest mb-2 block shimmer-text">ویژه • Featured</span>
        <h2 className="text-white font-black text-2xl md:text-4xl mb-1 drop-shadow-lg">{current.title}</h2>
        <p className="text-white/60 text-sm mb-4">{(current.episodes || []).length} قسمت</p>
        <div className="flex items-center gap-3" style={{ pointerEvents: 'auto' }}>
          <button
            onClick={() => onEnter(current)}
            data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
            style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 20px rgba(123,44,191,0.5)" }}
          >
            <Play className="w-4 h-4 fill-white" /> پخش
          </button>
          <button
            onClick={() => onEnter(current)}
            data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white/80 transition-all hover:scale-105"
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)" }}
          >
            <List className="w-4 h-4" /> قسمت‌ها
          </button>
        </div>
      </div>

      {/* Cover counter — bottom right */}
      <div className="absolute bottom-4 right-4 z-[40] flex items-center gap-1.5 px-3 py-1.5 rounded-full"
        style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)", border: "1px solid rgba(255,255,255,0.1)" }}>
        <span className="text-white/80 text-xs font-bold">{index + 1} / {covers.length}</span>
      </div>

      {/* Asemanak Series logo */}
      <div className="absolute top-4 left-4 z-[40] flex items-center gap-2.5 px-3 py-2 rounded-2xl"
        style={{ background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.1)' }}>
        <div style={{
          width: 36, height: 36, borderRadius: '28%',
          background: 'linear-gradient(135deg, #E038F6 0%, #6B54FF 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 4px 16px rgba(107,84,255,0.45), inset 0 1px 0 rgba(255,255,255,0.25)',
          flexShrink: 0,
        }}>
          <span style={{ color: '#fff', fontWeight: 900, fontSize: 19, fontFamily: 'Inter, sans-serif', lineHeight: 1 }}>A</span>
        </div>
        <div className="leading-tight" style={{ direction: 'ltr' }}>
          <p className="text-white font-black text-xs tracking-wide">ASEMANAK</p>
          <p className="text-white/50 text-[8px] font-bold uppercase tracking-[0.2em]">SERIES</p>
        </div>
      </div>
    </div>
  );
}