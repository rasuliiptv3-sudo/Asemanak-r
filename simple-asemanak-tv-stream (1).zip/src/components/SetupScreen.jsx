import { useState, useEffect } from "react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

/**
 * Setup screen — shown after language selection on TV devices.
 * Displays a "Setting up your Asemanak TV" message with a 0→100% progress
 * counter, then transitions into the main app.
 */
export default function SetupScreen({ onDone }) {
  const [progress, setProgress] = useState(0);

  const lang = (() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language || "fa"; } catch { return "fa"; }
  })();
  const isFa = lang !== "en";

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        const next = p + Math.random() * 5 + 2.5;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(onDone, 700);
          return 100;
        }
        return next;
      });
    }, 110);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-between px-6 md:px-16 overflow-hidden">

      {/* Subtle ambient glow */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(circle at 80% 50%, rgba(123,44,191,0.08) 0%, transparent 50%)',
      }} />

      {/* Left side — logo + text + progress */}
      <div className="relative flex flex-col" style={{ animation: 'setupFadeIn 0.8s ease-out' }}>
        {/* Logo */}
        <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl overflow-hidden mb-6"
          style={{ boxShadow: '0 0 24px rgba(123,44,191,0.3)' }}>
          <img src={LOGO_URL} alt="" className="w-full h-full object-cover" />
        </div>

        {/* Title */}
        <h1 className="text-white font-bold mb-8" style={{
          fontSize: 'clamp(22px, 4vw, 38px)',
          lineHeight: 1.3,
          fontFamily: isFa ? 'Vazirmatn, sans-serif' : 'Inter, sans-serif',
        }}>
          {isFa ? "در حال راه‌اندازی" : "Setting up your"}<br />
          {isFa ? "آسمانک تی‌وی" : "Asemanak TV"}
        </h1>

        {/* Progress */}
        <p className="text-white font-bold mb-3" style={{ fontSize: 'clamp(18px, 2.5vw, 24px)' }}>
          {Math.round(progress)}%
        </p>
        <div className="w-56 md:w-64 h-1 bg-white/15 rounded-full overflow-hidden">
          <div className="h-full bg-white rounded-full transition-all duration-100 ease-out"
            style={{ width: `${progress}%` }} />
        </div>
      </div>

      {/* Right side — decorative circles */}
      <div className="relative flex flex-col gap-4 md:gap-6" style={{ animation: 'setupFadeIn 1s ease-out 0.3s both' }}>
        <div className="w-14 h-14 md:w-20 md:h-20 rounded-full transition-all"
          style={{
            background: '#8888ff',
            boxShadow: '0 0 30px rgba(136,136,255,0.35)',
            animation: progress > 50 ? 'circlePulse 2s ease-in-out infinite' : 'none',
          }} />
        <div className="w-14 h-14 md:w-20 md:h-20 rounded-full"
          style={{ background: '#2a2a45' }} />
      </div>

      <style>{`
        @keyframes setupFadeIn {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes circlePulse {
          0%, 100% { opacity: 0.8; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.08); }
        }
      `}</style>
    </div>
  );
}