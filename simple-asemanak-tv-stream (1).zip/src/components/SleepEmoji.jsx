import { useState, useEffect, useRef } from "react";

const IDLE_MS = 120000; // 2 minutes

// Professional cartoon sleeping character (SVG). Shows after 2 min idle.
// On touch: wakes up, opens eyes, smiles at the user, then fades out.
export default function SleepEmoji() {
  const [state, setState] = useState("awake"); // awake | asleep | waking
  const timer = useRef(null);
  const wakeTimer = useRef(null);
  const stateRef = useRef("awake");

  useEffect(() => { stateRef.current = state; }, [state]);

  const resetIdle = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setState("asleep"), IDLE_MS);
  };

  const onActivity = () => {
    const cur = stateRef.current;
    if (cur === "asleep") {
      if (wakeTimer.current) clearTimeout(wakeTimer.current);
      wakeTimer.current = setTimeout(() => setState("awake"), 1800);
      setState("waking");
    }
    resetIdle();
  };

  useEffect(() => {
    resetIdle();
    const events = ["mousemove", "mousedown", "touchstart", "keydown", "click", "wheel", "pointerdown"];
    events.forEach(ev => window.addEventListener(ev, onActivity, { passive: true }));
    return () => {
      events.forEach(ev => window.removeEventListener(ev, onActivity));
      if (timer.current) clearTimeout(timer.current);
      if (wakeTimer.current) clearTimeout(wakeTimer.current);
    };
  }, []);

  if (state === "awake") return null;

  const asleep = state === "asleep";

  return (
    <div className="absolute pointer-events-none select-none"
      style={{ right: "-100px", top: "50%", transform: "translateY(-50%)" }}>
      <style>{`
        @keyframes sleep-breathe { 0%,100%{transform:translateY(0) scale(1);} 50%{transform:translateY(-4px) scale(1.04);} }
        @keyframes wake-pop { 0%{transform:scale(0.4) rotate(-8deg);opacity:0;} 55%{transform:scale(1.18) rotate(3deg);opacity:1;} 75%{transform:scale(0.95) rotate(0deg);} 100%{transform:scale(1) rotate(0deg);opacity:1;} }
        @keyframes wake-fade { 0%,55%{opacity:1;} 100%{opacity:0;transform:scale(0.82);} }
        @keyframes zzz-float { 0%{opacity:0;transform:translate(0,0) scale(0.5);} 25%{opacity:1;} 100%{opacity:0;transform:translate(22px,-40px) scale(1.25);} }
        @keyframes sparkle-pop { 0%,100%{opacity:0.2;transform:scale(0.7) rotate(0deg);} 50%{opacity:1;transform:scale(1.15) rotate(40deg);} }
      `}</style>
      <div style={{ position: "relative", width: 130, height: 130 }}>
        {/* Floating Z's while asleep */}
        {asleep && (
          <div className="absolute" style={{ right: 6, top: -16, width: 60, height: 60 }}>
            <span style={{ position: "absolute", left: 0, top: 28, fontSize: 18, fontWeight: 900, color: "#cfe9ff", animation: "zzz-float 2.8s ease-out infinite", textShadow: "0 0 8px rgba(34,211,238,0.8)" }}>z</span>
            <span style={{ position: "absolute", left: 14, top: 20, fontSize: 22, fontWeight: 900, color: "#bfe3ff", animation: "zzz-float 2.8s ease-out 0.9s infinite", textShadow: "0 0 8px rgba(34,211,238,0.8)" }}>z</span>
            <span style={{ position: "absolute", left: 28, top: 10, fontSize: 26, fontWeight: 900, color: "#a7d8ff", animation: "zzz-float 2.8s ease-out 1.8s infinite", textShadow: "0 0 8px rgba(34,211,238,0.8)" }}>Z</span>
          </div>
        )}
        {/* Sparkles when waking */}
        {!asleep && (
          <>
            <span style={{ position: "absolute", left: -6, top: 8, fontSize: 22, animation: "sparkle-pop 1.1s ease-in-out infinite" }}>✨</span>
            <span style={{ position: "absolute", right: -4, top: 30, fontSize: 18, animation: "sparkle-pop 1.1s ease-in-out 0.35s infinite" }}>✨</span>
            <span style={{ position: "absolute", left: 30, top: -8, fontSize: 16, animation: "sparkle-pop 1.1s ease-in-out 0.6s infinite" }}>⭐</span>
          </>
        )}
        {/* Character */}
        <svg width="130" height="130" viewBox="0 0 120 120"
          style={{
            animation: asleep
              ? "sleep-breathe 3.4s ease-in-out infinite"
              : "wake-pop 0.6s cubic-bezier(.34,1.56,.64,1) both, wake-fade 1.8s ease-in 0.6s forwards",
            filter: "drop-shadow(0 6px 18px rgba(123,44,191,0.4))",
          }}>
          <defs>
            <radialGradient id="bodyG" cx="38%" cy="34%" r="78%">
              <stop offset="0%" stopColor="#ede9fe" />
              <stop offset="55%" stopColor="#a78bfa" />
              <stop offset="100%" stopColor="#7c3aed" />
            </radialGradient>
            <linearGradient id="capG" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#67e8f9" />
              <stop offset="100%" stopColor="#0891b2" />
            </linearGradient>
          </defs>
          {/* Face */}
          <circle cx="60" cy="68" r="40" fill="url(#bodyG)" stroke="#fff" strokeOpacity="0.3" strokeWidth="1.5" />
          {/* Cheeks */}
          <ellipse cx="34" cy="78" rx="7.5" ry="5" fill="#fb7185" opacity="0.45" />
          <ellipse cx="86" cy="78" rx="7.5" ry="5" fill="#fb7185" opacity="0.45" />
          {/* Nightcap */}
          <path d="M40 36 Q46 6 76 18 Q72 32 56 37 Q47 38 40 36 Z" fill="url(#capG)" stroke="#fff" strokeOpacity="0.35" strokeWidth="1" />
          <circle cx="78" cy="15" r="6" fill="#e0f2fe" stroke="#0891b2" strokeWidth="1" />
          {asleep ? (
            <>
              {/* Closed sleepy eyes */}
              <path d="M40 68 Q48 61 55 68" fill="none" stroke="#3b0764" strokeWidth="3" strokeLinecap="round" />
              <path d="M65 68 Q73 61 80 68" fill="none" stroke="#3b0764" strokeWidth="3" strokeLinecap="round" />
              {/* Snore/breath mouth */}
              <ellipse cx="60" cy="84" rx="5.5" ry="4" fill="#3b0764" />
            </>
          ) : (
            <>
              {/* Open happy eyes */}
              <ellipse cx="47" cy="66" rx="8.5" ry="9.5" fill="#fff" />
              <ellipse cx="73" cy="66" rx="8.5" ry="9.5" fill="#fff" />
              <circle cx="48" cy="68" r="5" fill="#3b0764" />
              <circle cx="74" cy="68" r="5" fill="#3b0764" />
              <circle cx="46" cy="66" r="1.6" fill="#fff" />
              <circle cx="72" cy="66" r="1.6" fill="#fff" />
              {/* Big smile */}
              <path d="M43 80 Q60 98 77 80 Q60 88 43 80 Z" fill="#3b0764" />
              <path d="M50 84 Q60 90 70 84 Q60 88 50 84 Z" fill="#fb7185" opacity="0.7" />
            </>
          )}
        </svg>
      </div>
    </div>
  );
}