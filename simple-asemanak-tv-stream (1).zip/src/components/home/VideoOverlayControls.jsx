import { Play, ChevronUp, ChevronDown, Volume2, VolumeX, List, Star, Lock, Unlock, Flag } from "lucide-react";

export default function VideoOverlayControls({
  channel,
  isMuted,
  isFavorite,
  isLocked,
  onToggleMute,
  onToggleList,
  onPrevChannel,
  onNextChannel,
  onToggleFavorite,
  onReport,
  onToggleLock,
}) {
  return (
    <div className="absolute inset-3 rounded-2xl z-10 pointer-events-none flex flex-col justify-between p-4"
      style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.6) 0%, transparent 40%, transparent 60%, rgba(0,0,0,0.7) 100%)' }}>

      {/* Top bar — channel info */}
      <div className="flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-2">
          {channel.logo_url && (
            <div className="w-8 h-8 rounded-md overflow-hidden bg-white/10 flex items-center justify-center flex-shrink-0">
              <img src={channel.logo_url} alt="" className="w-full h-full object-contain"
                onError={e => { e.target.style.display = 'none'; }} />
            </div>
          )}
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-white font-bold text-sm">{channel.name}</span>
            </div>
            {channel.country && <span className="text-white/40 text-xs">{channel.country}</span>}
          </div>
        </div>
        {/* Right top actions */}
        <div className="flex items-center gap-2">
          <button onClick={onToggleFavorite} data-remote
            className="w-11 h-11 rounded-full flex items-center justify-center transition-colors"
            style={{ background: isFavorite ? 'rgba(250,204,21,0.2)' : 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,255,255,0.15)' }}>
            <Star className="w-4 h-4" style={{ color: isFavorite ? 'rgb(250,204,21)' : 'white', fill: isFavorite ? 'rgb(250,204,21)' : 'none' }} />
          </button>
          <button onClick={onReport} data-remote
            className="w-11 h-11 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(255,255,255,0.15)' }}>
            <Flag className="w-4 h-4 text-white/70" />
          </button>
        </div>
      </div>

      {/* Center — channel prev/next */}
      <div className="flex justify-end pointer-events-auto">
        <div className="flex flex-col gap-2">
          <button onClick={onPrevChannel} data-remote
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.2)' }}>
            <ChevronUp className="w-5 h-5 text-white" />
          </button>
          <button onClick={onNextChannel} data-remote
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.2)' }}>
            <ChevronDown className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-2">
          <button onClick={onToggleMute} data-remote
            className="w-11 h-11 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.2)' }}>
            {isMuted
              ? <VolumeX className="w-4 h-4 text-red-400" />
              : <Volume2 className="w-4 h-4 text-white" />}
          </button>
          <button onClick={onToggleLock} data-remote
            className="w-11 h-11 rounded-full flex items-center justify-center"
            style={{ background: isLocked ? 'rgba(239,68,68,0.25)' : 'rgba(0,0,0,0.5)', border: isLocked ? '1px solid rgba(239,68,68,0.5)' : '1px solid rgba(255,255,255,0.2)' }}>
            {isLocked ? <Lock className="w-4 h-4 text-red-400" /> : <Unlock className="w-4 h-4 text-white/70" />}
          </button>
        </div>
        <button onClick={onToggleList} data-remote
          className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full"
          style={{ background: 'rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.2)', color: 'rgba(255,255,255,0.8)' }}>
          <List className="w-3.5 h-3.5" />
          <span>لیست کانال‌ها</span>
        </button>
      </div>
    </div>
  );
}