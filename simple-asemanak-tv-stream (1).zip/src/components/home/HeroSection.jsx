import { Play, Globe, Zap } from "lucide-react";
import { Link } from "react-router-dom";

export default function HeroSection() {
  return (
    <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1a] via-[#0d0820] to-[#050510]" />
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-cyan-500/15 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl" />
      </div>

      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
          backgroundSize: "60px 60px"
        }}
      />

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        {/* Logo/Brand */}
        <div className="inline-flex items-center gap-3 mb-8">
          <div className="w-16 h-16 rounded-2xl overflow-hidden flex items-center justify-center shadow-2xl shadow-cyan-500/40" style={{ boxShadow: "0 0 24px rgba(0,242,255,0.35)" }}>
            <img src="https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png" alt="Asemanak TV" className="w-full h-full object-cover" />
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-white font-vazir">آسمانک تی وی</p>
            <p className="text-sm text-cyan-400/60 tracking-widest uppercase">ASEMANAK TV</p>
          </div>
        </div>

        <h1 className="text-4xl md:text-6xl font-black text-white mb-4 leading-tight">
          Watch the World,{" "}
          <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent">
            Live & Online
          </span>
        </h1>

        <p className="text-lg md:text-xl text-muted-foreground mb-4 font-vazir leading-relaxed">
          کانال‌های تلویزیونی جهانی و محلی را به صورت آنلاین تماشا کنید
        </p>
        <p className="text-base text-muted-foreground mb-10">
          World channels watch online — anytime, anywhere
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/Channels"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold px-8 py-4 rounded-xl shadow-xl shadow-purple-500/30 transition-all duration-300 hover:scale-105"
          >
            <Play className="w-5 h-5 fill-white" />
            Browse Channels
          </Link>
          <Link
            to="/Channels"
            className="inline-flex items-center gap-2 border border-border hover:border-primary/50 text-foreground font-semibold px-8 py-4 rounded-xl bg-card/50 backdrop-blur hover:bg-secondary transition-all duration-300"
          >
            <Globe className="w-5 h-5" />
            Explore All
          </Link>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-3 gap-6 max-w-lg mx-auto">
          {[
            { label: "Live Channels", value: "500+", icon: "📺" },
            { label: "Countries", value: "50+", icon: "🌍" },
            { label: "HD Quality", value: "Free", icon: "⚡" },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="text-xl font-bold text-white">{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}