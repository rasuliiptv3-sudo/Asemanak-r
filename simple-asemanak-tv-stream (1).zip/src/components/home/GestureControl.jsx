import { useRef, useState, useCallback } from "react";
import { Volume2, VolumeX, Sun } from "lucide-react";

/**
 * Vertical-swipe gesture control overlaid on the video.
 * Right half of the screen  → volume
 * Left half of the screen   → brightness (visual dimming overlay)
 *
 * Renders an invisible touch layer + a transient indicator.
 * Calls onTap() when the gesture was a tap (no vertical drag).
 */
export default function GestureControl({ videoRef, onTap }) {
  const [indicator, setIndicator] = useState(null); // { type: 'volume'|'brightness', value: 0..1 }
  const [brightness, setBrightness] = useState(1);   // 1 = full, 0.15 = dark
  const startY = useRef(null);
  const startX = useRef(null);
  const mode = useRef(null);       // 'volume' | 'brightness' | null
  const startVolume = useRef(1);
  const startBrightness = useRef(1);
  const moved = useRef(false);
  const hideTimer = useRef(null);

  const showIndicator = useCallback((type, value) => {
    setIndicator({ type, value });
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setIndicator(null), 800);
  }, []);

  const onTouchStart = (e) => {
    const t = e.touches[0];
    startY.current = t.clientY;
    startX.current = t.clientX;
    moved.current = false;
    mode.current = null;
    startVolume.current = videoRef.current ? videoRef.current.volume : 1;
    startBrightness.current = brightness;
  };

  const onTouchMove = (e) => {
    if (startY.current === null) return;
    const t = e.touches[0];
    const dy = startY.current - t.clientY; // up = positive
    const dx = t.clientX - startX.current;

    // Decide mode once vertical movement dominates
    if (!mode.current) {
      if (Math.abs(dy) > 12 && Math.abs(dy) > Math.abs(dx)) {
        const screenW = window.innerWidth;
        mode.current = startX.current > screenW / 2 ? "volume" : "brightness";
      } else {
        return;
      }
    }
    moved.current = true;
    e.preventDefault();

    const range = window.innerHeight * 0.6; // full swing over 60% of screen height
    const delta = dy / range;

    if (mode.current === "volume") {
      const v = Math.max(0, Math.min(1, startVolume.current + delta));
      if (videoRef.current) { videoRef.current.volume = v; videoRef.current.muted = v === 0; }
      showIndicator("volume", v);
    } else {
      const b = Math.max(0.15, Math.min(1, startBrightness.current + delta));
      setBrightness(b);
      showIndicator("brightness", (b - 0.15) / 0.85);
    }
  };

  const onTouchEnd = (e) => {
    if (!moved.current && startY.current !== null) {
      // it was a tap
      if (e.cancelable) e.preventDefault();
      onTap?.();
    }
    startY.current = null;
    startX.current = null;
    mode.current = null;
    moved.current = false;
  };

  return (
    <>
      {/* Brightness dimming overlay */}
      {brightness < 1 && (
        <div className="absolute inset-3 rounded-2xl pointer-events-none z-[6]"
          style={{ background: `rgba(0,0,0,${1 - brightness})` }} />
      )}

      {/* Touch capture layer */}
      <div
        className="absolute inset-3 rounded-2xl z-[7]"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      />

      {/* Indicator */}
      {indicator && (
        <div className="absolute inset-0 flex items-center justify-center z-[8] pointer-events-none">
          <div className="flex flex-col items-center gap-3 rounded-2xl px-7 py-6 shadow-2xl"
            style={{ background: "rgba(13,17,23,0.9)", border: "1px solid rgba(255,255,255,0.12)" }}>
            {indicator.type === "volume"
              ? (indicator.value === 0
                  ? <VolumeX className="w-8 h-8 text-cyan-400" />
                  : <Volume2 className="w-8 h-8 text-cyan-400" />)
              : <Sun className="w-8 h-8 text-yellow-400" />}
            <div className="w-1.5 h-32 rounded-full overflow-hidden flex flex-col-reverse" style={{ background: "rgba(255,255,255,0.12)" }}>
              <div className="w-full rounded-full transition-all"
                style={{
                  height: `${Math.round(indicator.value * 100)}%`,
                  background: indicator.type === "volume" ? "rgb(34,211,238)" : "rgb(250,204,21)",
                }} />
            </div>
            <span className="text-white text-sm font-bold font-mono">{Math.round(indicator.value * 100)}%</span>
          </div>
        </div>
      )}
    </>
  );
}