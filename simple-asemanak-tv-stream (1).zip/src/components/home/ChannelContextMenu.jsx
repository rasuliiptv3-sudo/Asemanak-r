import { ArrowUp, ArrowDown, X } from "lucide-react";

export default function ChannelContextMenu({ channel, onMoveUp, onMoveDown, onClose }) {
  if (!channel) return null;

  const options = [
    {
      label: "Move Up",
      icon: <ArrowUp className="w-5 h-5 text-white/70" />,
      action: onMoveUp,
    },
    {
      label: "Move Down",
      icon: <ArrowDown className="w-5 h-5 text-white/70" />,
      action: onMoveDown,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative w-full sm:max-w-sm rounded-t-2xl sm:rounded-2xl overflow-hidden"
        style={{ background: "rgba(10,14,26,0.97)", border: "1px solid rgba(255,255,255,0.1)" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Channel header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
          {channel.logo_url && (
            <img src={channel.logo_url} alt={channel.name}
              className="w-10 h-10 rounded-lg object-contain bg-white/5 flex-shrink-0"
              onError={(e) => { e.target.style.display = "none"; }} />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm truncate">{channel.name}</p>
            {channel.country && <p className="text-white/40 text-xs">{channel.country}</p>}
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Options */}
        <div className="py-2">
          {options.map((opt, i) => (
            <button
              key={i}
              onClick={() => { opt.action?.(); onClose(); }}
              className="w-full flex items-center gap-4 px-5 py-4 text-left transition-colors hover:bg-white/5 active:bg-white/10"
              style={{ borderBottom: i < options.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}
            >
              {opt.icon}
              <span className={`text-sm font-medium ${opt.highlight ? "text-yellow-400" : "text-white/85"}`}>
                {opt.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}