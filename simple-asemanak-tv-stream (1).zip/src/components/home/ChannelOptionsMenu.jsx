import { useState } from "react";
import { Star, Search, Hash, X, Check } from "lucide-react";

export default function ChannelOptionsMenu({ channel, isFavorite, onFavorite, onSearch, onChangeNumber, onClose }) {
  const [showNumberInput, setShowNumberInput] = useState(false);
  const [numVal, setNumVal] = useState("");

  const handleConfirmNumber = () => {
    const n = parseInt(numVal, 10);
    if (!isNaN(n) && n > 0) {
      onChangeNumber(n);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        className="relative z-10 w-72 rounded-2xl overflow-hidden border border-white/15 shadow-2xl"
        style={{ background: "rgba(10,14,24,0.97)" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Channel info header */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-white/10">
          {channel.logo_url && (
            <div className="w-10 h-10 rounded-lg overflow-hidden bg-white/10 flex items-center justify-center flex-shrink-0">
              <img src={channel.logo_url} alt="" className="w-full h-full object-contain"
                onError={e => { e.target.style.display = "none"; }} />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm truncate">{channel.name}</p>
            {channel.country && <p className="text-white/40 text-xs">{channel.country}</p>}
          </div>
          <button onClick={onClose} data-remote className="text-white/40 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Options */}
        <div className="py-2">
          <button
            onClick={() => { onFavorite(); onClose(); }} data-remote
            className="w-full flex items-center gap-4 px-5 py-4 hover:bg-white/5 transition-colors"
          >
            <Star className="w-5 h-5 flex-shrink-0" style={{ color: isFavorite ? "rgb(250,204,21)" : "rgba(255,255,255,0.5)", fill: isFavorite ? "rgb(250,204,21)" : "none" }} />
            <span className="text-white text-sm font-medium">{isFavorite ? "حذف از علاقه‌مندی‌ها" : "افزودن به علاقه‌مندی‌ها"}</span>
          </button>

          <button
            onClick={() => { onSearch(); onClose(); }} data-remote
            className="w-full flex items-center gap-4 px-5 py-4 hover:bg-white/5 transition-colors"
          >
            <Search className="w-5 h-5 text-white/50 flex-shrink-0" />
            <span className="text-white text-sm font-medium">جستجوی کانال</span>
          </button>

          <div className="mx-4 border-t border-white/10 my-1" />

          {/* Change channel number */}
          {!showNumberInput ? (
            <button
              onClick={() => setShowNumberInput(true)} data-remote
              className="w-full flex items-center gap-4 px-5 py-4 hover:bg-white/5 transition-colors"
            >
              <Hash className="w-5 h-5 text-cyan-400 flex-shrink-0" />
              <span className="text-white text-sm font-medium">تغییر شماره کانال</span>
            </button>
          ) : (
            <div className="px-5 py-3 flex items-center gap-3">
              <Hash className="w-5 h-5 text-cyan-400 flex-shrink-0" />
              <input
                autoFocus data-remote
                type="number"
                min="1"
                value={numVal}
                onChange={e => setNumVal(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") handleConfirmNumber(); if (e.key === "Escape") setShowNumberInput(false); }}
                placeholder="شماره جدید..."
                className="flex-1 bg-white/10 border border-cyan-500/50 rounded-lg px-3 py-1.5 text-sm text-white outline-none text-center"
              />
              <button onClick={handleConfirmNumber} data-remote className="text-green-400 p-1"><Check className="w-4 h-4" /></button>
              <button onClick={() => setShowNumberInput(false)} data-remote className="text-white/40 p-1"><X className="w-4 h-4" /></button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}