import { useState, useEffect } from "react";
import { Subtitles } from "lucide-react";

const LANG_LABELS = {
  en: { fa: "انگلیسی", en: "English" },
  hi: { fa: "هندی", en: "Hindi" },
  tr: { fa: "ترکی", en: "Turkish" },
};

export default function SubtitleOverlay({ videoRef }) {
  const [settings, setSettings] = useState({});
  const [subtitleText, setSubtitleText] = useState("");

  useEffect(() => {
    const update = () => {
      try { setSettings(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}")); } catch { setSettings({}); }
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  // Listen to video text tracks for actual subtitle text
  useEffect(() => {
    if (!settings.subtitleEnabled) { setSubtitleText(""); return; }

    let interval;
    const attachListeners = () => {
      const video = videoRef?.current;
      if (!video) return;
      const tracks = video.textTracks;
      for (let i = 0; i < tracks.length; i++) {
        if (tracks[i].mode === "showing" || tracks[i].mode === "hidden") {
          tracks[i].mode = "showing";
        }
        tracks[i].oncuechange = () => {
          if (tracks[i].activeCues && tracks[i].activeCues.length > 0) {
            const cue = tracks[i].activeCues[0];
            setSubtitleText(cue.text || "");
          } else {
            setSubtitleText("");
          }
        };
      }
    };

    attachListeners();
    interval = setInterval(attachListeners, 2000);

    return () => {
      clearInterval(interval);
      const video = videoRef?.current;
      if (video) {
        const tracks = video.textTracks;
        for (let i = 0; i < tracks.length; i++) {
          tracks[i].oncuechange = null;
        }
      }
    };
  }, [videoRef, settings.subtitleEnabled]);

  const subEnabled = settings.subtitleEnabled;
  const subLang = settings.subtitleLang || "en";
  const isFA = settings.language === "fa";

  if (!subEnabled) return null;

  return (
    <>
      {/* Actual subtitle text at bottom of video */}
      {subEnabled && subtitleText && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-30 max-w-[85%] pointer-events-none">
          <p className="text-white text-sm md:text-base font-medium text-center px-3 py-1.5 rounded-lg"
            style={{ background: "rgba(0,0,0,0.8)", textShadow: "0 1px 3px rgba(0,0,0,0.9)" }}>
            {subtitleText}
          </p>
        </div>
      )}

      {/* Badge indicator */}
      <div className="absolute bottom-3 right-3 z-30 flex flex-col items-end gap-1 pointer-events-none">
        {subEnabled && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg backdrop-blur-md"
            style={{ background: "rgba(0,0,0,0.65)", border: "1px solid rgba(34,211,238,0.3)" }}>
            <Subtitles className="w-3 h-3 text-cyan-400" />
            <span className="text-[10px] text-white font-medium">
              {isFA ? `زیرنویس: ${LANG_LABELS[subLang]?.fa || ""} → فارسی` : `Sub: ${LANG_LABELS[subLang]?.en || ""} → FA`}
            </span>
          </div>
        )}
      </div>
    </>
  );
}