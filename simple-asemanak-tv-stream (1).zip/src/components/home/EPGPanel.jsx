import { useState, useEffect } from "react";
import { X, Clock, Tv } from "lucide-react";

// Generate fake EPG schedule for a channel
function generateEPG(channel) {
  const programs = [
    { name: "Morning News", duration: 60, genre: "News" },
    { name: "Talk Show", duration: 90, genre: "Entertainment" },
    { name: "Documentary", duration: 60, genre: "Documentary" },
    { name: "Live Sports", duration: 120, genre: "Sports" },
    { name: "Evening News", duration: 30, genre: "News" },
    { name: "Drama Series", duration: 60, genre: "Drama" },
    { name: "Late Night Show", duration: 90, genre: "Entertainment" },
    { name: "Movie", duration: 120, genre: "Movies" },
    { name: "Night News", duration: 30, genre: "News" },
    { name: "Music Chart", duration: 60, genre: "Music" },
    { name: "Religious Program", duration: 45, genre: "Religious" },
    { name: "Kids Show", duration: 30, genre: "Kids" },
  ];

  // Use channel name hash to vary programs
  const seed = channel.name.charCodeAt(0) % programs.length;
  const rotated = [...programs.slice(seed), ...programs.slice(0, seed)];

  const now = new Date();
  now.setHours(0, 0, 0, 0);
  let current = new Date(now);

  return rotated.map((p, i) => {
    const start = new Date(current);
    const end = new Date(current.getTime() + p.duration * 60000);
    current = new Date(end);
    return {
      id: i,
      name: p.name,
      genre: p.genre,
      start,
      end,
      duration: p.duration,
    };
  });
}

function formatTime(date) {
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function isNow(program) {
  const now = new Date();
  return program.start <= now && program.end > now;
}

function getProgress(program) {
  const now = new Date();
  if (now < program.start) return 0;
  if (now > program.end) return 100;
  return Math.round(((now - program.start) / (program.end - program.start)) * 100);
}

export default function EPGPanel({ channel, onClose }) {
  const [programs, setPrograms] = useState([]);

  useEffect(() => {
    if (channel) {
      setPrograms(generateEPG(channel));
    }
  }, [channel?.id]);

  const nowProgram = programs.find(isNow);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />

      {/* Panel */}
      <div className="relative w-full sm:max-w-lg h-[70vh] sm:h-auto sm:max-h-[80vh] flex flex-col rounded-t-2xl sm:rounded-2xl border border-white/10 overflow-hidden"
        style={{ background: "rgba(10,12,20,0.98)", paddingBottom: "env(safe-area-inset-bottom)" }}>

        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10 flex-shrink-0">
          <div className="w-8 h-8 rounded-md overflow-hidden bg-white/10 flex items-center justify-center flex-shrink-0">
            {channel?.logo_url ? (
              <img src={channel.logo_url} alt={channel.name} className="w-full h-full object-cover"
                onError={(e) => { e.target.style.display = "none"; }} />
            ) : (
              <Tv className="w-4 h-4 text-white/40" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-semibold truncate">{channel?.name}</p>
            <p className="text-white/40 text-xs">Programme Guide (EPG)</p>
          </div>
          <button onClick={onClose} data-remote className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Now Playing highlight */}
        {nowProgram && (
          <div className="mx-4 mt-3 mb-1 rounded-xl px-4 py-3 flex-shrink-0" style={{ background: "rgba(6,182,212,0.15)", border: "1px solid rgba(6,182,212,0.3)" }}>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-cyan-400 text-xs font-bold uppercase tracking-wider">Now Playing</span>
            </div>
            <p className="text-white text-sm font-semibold">{nowProgram.name}</p>
            <p className="text-white/50 text-xs mb-2">{formatTime(nowProgram.start)} – {formatTime(nowProgram.end)} · {nowProgram.genre}</p>
            <div className="h-1 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-500 rounded-full transition-all" style={{ width: `${getProgress(nowProgram)}%` }} />
            </div>
          </div>
        )}

        {/* Schedule list */}
        <div className="flex-1 overflow-y-auto px-4 py-2">
          <p className="text-white/30 text-xs font-semibold uppercase tracking-widest mb-2">Today's Schedule</p>
          {programs.map((p) => {
            const active = isNow(p);
            const past = new Date() > p.end;
            return (
              <div
                key={p.id}
                className={`flex items-center gap-3 py-3 border-b border-white/5 ${active ? "opacity-100" : past ? "opacity-40" : "opacity-80"}`}
              >
                <div className="w-16 flex-shrink-0 text-right">
                  <p className={`text-xs font-mono ${active ? "text-cyan-400 font-bold" : "text-white/50"}`}>
                    {formatTime(p.start)}
                  </p>
                </div>
                <div className={`w-0.5 h-10 rounded-full flex-shrink-0 ${active ? "bg-cyan-400" : "bg-white/10"}`} />
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium truncate ${active ? "text-white" : "text-white/70"}`}>{p.name}</p>
                  <p className="text-xs text-white/35">{p.genre} · {p.duration} min</p>
                </div>
                {active && (
                  <div className="flex-shrink-0">
                    <span className="flex items-center gap-1 text-xs text-red-400 font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                      LIVE
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}