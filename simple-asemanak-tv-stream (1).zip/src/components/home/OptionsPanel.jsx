import { Star, Tv, List, Settings, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function OptionsPanel({ channel, onFavorite, isFavorite, onEPG, onClose }) {
  const options = [
    { icon: <Star className={`w-4 h-4 ${isFavorite ? "fill-yellow-400 text-yellow-400" : "text-white/70"}`} />, label: isFavorite ? "Remove from Favorites" : "Add to Favorites", action: () => { onFavorite(); onClose(); } },
    { icon: <List className="w-4 h-4 text-white/70" />, label: "EPG", action: () => { onEPG(); onClose(); } },
    { icon: <Tv className="w-4 h-4 text-white/70" />, label: "Show playback controls", action: onClose },
  ];

  return (
    <div className="fixed inset-0 z-40 flex justify-end" onClick={onClose}>
      <div
        className="h-full w-64 flex flex-col py-4"
        style={{ background: "rgba(0,0,0,0.92)", borderLeft: "1px solid rgba(255,255,255,0.1)" }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Channel info */}
        {channel && (
          <div className="px-5 pb-4 mb-2 border-b border-white/10">
            <p className="text-cyan-400 text-sm font-semibold truncate">{channel.name}</p>
            {channel.country && <p className="text-white/40 text-xs mt-0.5">{channel.country}</p>}
          </div>
        )}

        {options.map((opt, i) => (
          <button
            key={i}
            onClick={opt.action} data-remote
            className="flex items-center gap-3 px-5 py-4 text-white/80 hover:text-white hover:bg-white/5 transition-colors text-left w-full border-b border-white/5"
          >
            {opt.icon}
            <span className="text-sm">{opt.label}</span>
          </button>
        ))}

        <Link
          to="/Settings?from=tv" data-remote
          className="flex items-center gap-3 px-5 py-4 text-white/80 hover:text-white hover:bg-white/5 transition-colors border-b border-white/5"
          onClick={onClose}
        >
          <Settings className="w-4 h-4 text-white/70" />
          <span className="text-sm">Settings</span>
          <ChevronRight className="w-4 h-4 ml-auto text-white/30" />
        </Link>
      </div>
    </div>
  );
}