/**
 * Asemanak brand logo — gradient squircle with white "A".
 * Pure CSS (no image) so it's crisp at any resolution (4K/TV).
 * Matches the official Asemanak Series branding.
 */
export default function AsemanakLogo({ size = 40, showText = true, variant = "series", textClassName = "" }) {
  const fontSize = Math.round(size * 0.52);
  return (
    <div className="flex items-center gap-2.5" style={{ direction: "ltr" }}>
      <div style={{
        width: size,
        height: size,
        borderRadius: '28%',
        background: 'linear-gradient(135deg, #E038F6 0%, #6B54FF 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 4px 20px rgba(107,84,255,0.45), inset 0 1px 0 rgba(255,255,255,0.25)',
        flexShrink: 0,
      }}>
        <span style={{
          color: '#ffffff',
          fontWeight: 900,
          fontSize: fontSize,
          fontFamily: 'Inter, sans-serif',
          lineHeight: 1,
          textShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }}>A</span>
      </div>
      {showText && (
        <div className={`leading-tight ${textClassName}`}>
          <p className="text-white font-black tracking-wide" style={{ fontSize: Math.max(11, size * 0.32) }}>
            ASEMANAK
          </p>
          <p className="text-white/50 font-bold uppercase tracking-[0.2em]" style={{ fontSize: Math.max(8, size * 0.2) }}>
            {variant}
          </p>
        </div>
      )}
    </div>
  );
}