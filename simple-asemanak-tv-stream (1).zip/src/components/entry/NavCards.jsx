import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Tv, Clapperboard, Star, Sparkles } from "lucide-react";
import { useIsMobile } from "@/lib/useIsMobile";
import { useIsTV } from "@/lib/useIsTV";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

// Custom teddy bear SVG (lucide-react has no teddy bear icon)
function TeddyBear({ className, style }) {
  return (
    <svg viewBox="0 0 64 64" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="16" r="7" />
      <circle cx="46" cy="16" r="7" />
      <circle cx="18" cy="16" r="3" fill="currentColor" opacity="0.3" stroke="none" />
      <circle cx="46" cy="16" r="3" fill="currentColor" opacity="0.3" stroke="none" />
      <circle cx="32" cy="30" r="16" />
      <ellipse cx="32" cy="38" rx="9" ry="7" />
      <circle cx="26" cy="28" r="2" fill="currentColor" stroke="none" />
      <circle cx="38" cy="28" r="2" fill="currentColor" stroke="none" />
      <ellipse cx="32" cy="35" rx="2.5" ry="2" fill="currentColor" stroke="none" />
      <path d="M32 37 v3 M32 40 q-3 2 -5 1 M32 40 q3 2 5 1" />
    </svg>
  );
}

// ── Card data — bilingual (FA + EN), no count labels ──────────────────────
const CARDS = [
  { icon: Tv,           badge: "4K LIVE", titleFa: "تلویزیون زنده",  titleEn: "LIVE TV",   route: "/Home",                hex: "#00d4ff", hexDark: "#0891b2" },
  { icon: Clapperboard, badge: "VOD",     titleFa: "سریال‌ها",       titleEn: "SERIES",    route: "/Media?cat=series",    hex: "#9d4edd", hexDark: "#7b2cbf" },
  { icon: TeddyBear,    badge: "KIDS",    titleFa: "انیمیشن",       titleEn: "ANIMATION", route: "/Media?cat=animation",  hex: "#f43f5e", hexDark: "#be123c" },
  { icon: Star,         badge: "HD",      titleFa: "محبوب‌ترین‌ها",  titleEn: "FAVORITES", route: "/Favorites",           hex: "#fbbf24", hexDark: "#d97706" },
];

export default function NavCards() {
  const navigate = useNavigate();
  const isMobile = useIsMobile(480);
  const isTV = useIsTV();
  const [focusIdx, setFocusIdx] = useState(0);
  const [isFa, setIsFa] = useState(true);
  const [pressedIdx, setPressedIdx] = useState(-1);
  const btnRefs = useRef([]);

  // On TV: move محبوب‌ترین‌ها (Favorites) to the bottom of the list
  const cards = isTV ? [...CARDS.filter(c => c.route !== "/Favorites"), ...CARDS.filter(c => c.route === "/Favorites")] : CARDS;

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    syncLang();
    window.addEventListener("storage", syncLang);
    window.addEventListener("ayeneh-settings-changed", syncLang);
    return () => {
      window.removeEventListener("storage", syncLang);
      window.removeEventListener("ayeneh-settings-changed", syncLang);
    };
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.defaultPrevented) return; // useTVRemote already handled spatial nav
      const activeId = document.activeElement?.id || "";
      if (!activeId.startsWith("app-pill-")) return;
      // Only handle OK/Enter for selection — arrow keys are handled by useTVRemote
      if (["Enter", "Return", " ", "XF86OK", "Accept"].includes(e.key)) { e.preventDefault(); handlePress(focusIdx); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [focusIdx, isFa, navigate]);

  // Auto-focus only on TV (not touch devices — focus-stealing breaks taps)
  useEffect(() => { if (isTV) btnRefs.current[focusIdx]?.focus(); }, [focusIdx, isTV]);

  const handlePress = (idx) => {
    const card = cards[idx];
    if (!card) return;
    setPressedIdx(idx);
    setTimeout(() => { setPressedIdx(-1); navigate(card.route); }, 150);
  };

  // ── Mobile vertical sidebar layout (left side, top to bottom) ──
  if (isMobile) {
    return (
      <div className="fixed left-0 top-1/2 -translate-y-1/2 z-50 flex items-center"
        style={{ paddingLeft: 'env(safe-area-inset-left)' }}>
        <style>{`
          .mobile-nav {
            display: flex; flex-direction: column;
            gap: 10px; padding: 10px 6px;
            width: 78px;
          }
          .mobile-nav-item {
            position: relative; flex-shrink: 0;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            width: 70px; height: 64px;
            border-radius: 16px;
            cursor: pointer; outline: none;
            background: linear-gradient(160deg, rgba(22,12,38,0.82), rgba(10,5,20,0.9));
            backdrop-filter: blur(22px) saturate(1.45);
            -webkit-backdrop-filter: blur(22px) saturate(1.45);
            border: 2px solid var(--pc);
            box-shadow: 0 0 14px var(--pc), 0 4px 12px rgba(0,0,0,0.5);
            color: #fff;
            transition: transform .3s cubic-bezier(0.34,1.56,0.64,1), box-shadow .3s ease, border-color .3s ease;
            animation: mobileNavEnter 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
          }
          .mobile-nav-item::before {
            content: ""; position: absolute; inset: 0; border-radius: 16px;
            background: radial-gradient(circle at 50% 38%, var(--pc) 0%, transparent 62%);
            opacity: 0.12; pointer-events: none;
          }
          .mobile-nav-item:focus, .mobile-nav-item:hover {
            transform: scale(1.12) translateX(4px);
            box-shadow: 0 0 24px var(--pc), 0 0 48px var(--pc), 0 6px 16px rgba(0,0,0,0.6);
            border-width: 2px;
          }
          .mobile-nav-item.app-card-pressed { transform: scale(0.92) !important; transition: transform .08s ease-out !important; }
          @keyframes mobileNavEnter {
            0% { opacity: 0; transform: translateX(-40px) scale(0.8); }
            60% { opacity: 1; transform: translateX(4px) scale(1.05); }
            100% { opacity: 1; transform: translateX(0) scale(1); }
          }
        `}</style>
        <div className="mobile-nav">
          {cards.map((c, i) => {
            const Icon = c.icon;
            const focused = focusIdx === i;
            const pressed = pressedIdx === i;
            return (
              <button
                key={i}
                id={`app-pill-${i}`}
                ref={el => btnRefs.current[i] = el}
                data-remote
                className={`mobile-nav-item ${pressed ? "app-card-pressed" : ""}`}
                style={{ "--pc": c.hex, zIndex: focused ? 30 : 10, animationDelay: `${i * 0.08}s` }}
                onClick={() => handlePress(i)}
                onFocus={() => isTV && setFocusIdx(i)}
              >
                <Icon className="w-5 h-5" style={{ color: c.hex, filter: `drop-shadow(0 0 6px ${c.hex})` }} />
                <span className="text-[8px] font-bold mt-0.5 leading-none whitespace-nowrap" style={{ color: c.hex }}>{isFa ? c.titleFa : c.titleEn}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const dir = isFa ? "rtl" : "ltr";

  return (
    <div className="relative z-20 w-full" style={{ direction: dir }}>
      <style>{`
        .app-cards{
          display:grid;
          grid-template-columns:repeat(auto-fit,minmax(clamp(200px,22vw,300px),1fr));
          gap:clamp(16px,2vw,28px);
          max-width:clamp(900px,90vw,1400px);
          margin:0 auto;
          direction:ltr;
          padding:8px 4px;
        }
        .app-card{
          position:relative;overflow:hidden;
          display:flex;flex-direction:column;align-items:center;justify-content:center;
          min-height:clamp(200px,24vh,280px);
          padding:clamp(28px,3vw,44px) clamp(20px,2vw,32px);
          gap:clamp(18px,2vh,28px);
          border-radius:28px;
          cursor:pointer;outline:none;
          background:linear-gradient(160deg, rgba(20,14,35,0.85), rgba(10,8,20,0.92));
          backdrop-filter:blur(24px) saturate(1.5);
          -webkit-backdrop-filter:blur(24px) saturate(1.5);
          border:1.5px solid rgba(255,255,255,0.08);
          box-shadow:0 12px 40px rgba(0,0,0,0.5),inset 0 1px 0 rgba(255,255,255,0.06);
          color:#fff;font-family:Vazirmatn,sans-serif;
          -webkit-font-smoothing:antialiased;text-rendering:geometricPrecision;
          transition:transform .4s cubic-bezier(0.34,1.56,0.64,1),box-shadow .4s ease,border-color .4s ease,background .4s ease;
        }
        .app-card::before{
          content:"";position:absolute;inset:0;
          background:radial-gradient(ellipse 80% 60% at 50% 30%, var(--pc) 0%, transparent 70%);
          opacity:.08;pointer-events:none;
          transition:opacity .4s ease;
        }
        .app-card::after{
          content:"";position:absolute;inset:0;border-radius:28px;
          background:linear-gradient(115deg,transparent 40%,rgba(255,255,255,0.12) 50%,transparent 60%);
          opacity:0;pointer-events:none;transform:translateX(-130%);
        }
        .app-card:focus::after,.app-card:hover::after{animation:cardShine 1.4s ease-out;}
        @keyframes cardShine{0%{transform:translateX(-130%);opacity:0}30%{opacity:1}100%{transform:translateX(130%);opacity:0}}
        .app-card:focus,.app-card:hover{
          transform:translateY(-10px) scale(1.03);
          border-color:var(--pc);
          box-shadow:0 24px 60px rgba(0,0,0,0.6),0 0 40px var(--pc),inset 0 1px 0 rgba(255,255,255,0.12);
          background:linear-gradient(160deg, rgba(28,20,45,0.9), rgba(14,10,25,0.95));
          z-index:30;
        }
        .app-card:focus::before,.app-card:hover::before{opacity:.15;}
        .app-card.app-card-pressed{transform:scale(0.97)!important;transition:transform .1s ease-out!important;}
        .card-icon-wrap{
          position:relative;z-index:1;
          transition:all .4s cubic-bezier(0.34,1.56,0.64,1);
        }
        .app-card:focus .card-icon-wrap,.app-card:hover .card-icon-wrap{transform:scale(1.1) translateY(-2px);}
        .card-badge{
          position:absolute;top:clamp(14px,1.5vw,20px);left:clamp(14px,1.5vw,20px);
          padding:4px 10px;border-radius:8px;
          font-weight:700;font-size:clamp(9px,0.9vw,11px);
          letter-spacing:0.1em;
          background:rgba(255,255,255,0.08);
          border:1px solid rgba(255,255,255,0.12);
          color:rgba(255,255,255,0.7);
          z-index:2;
          backdrop-filter:blur(8px);
        }
        .card-title{
          position:relative;z-index:1;
          font-weight:800;
          font-size:clamp(22px,2.4vw,34px);
          letter-spacing:0.02em;
          text-align:center;
        }
        .card-subtitle{
          position:relative;z-index:1;
          font-size:clamp(11px,1.1vw,14px);
          font-weight:500;
          letter-spacing:0.15em;
          text-transform:uppercase;
          opacity:0.5;
          margin-top:-8px;
        }
      `}</style>
      <div className="app-cards">
        {cards.map((c, i) => {
          const Icon = c.icon;
          const focused = focusIdx === i;
          const pressed = pressedIdx === i;
          const title = isFa ? c.titleFa : c.titleEn;
          const subtitle = isFa ? c.titleEn : c.titleFa;
          return (
            <button
              key={i}
              id={`app-pill-${i}`}
              ref={el => btnRefs.current[i] = el}
              data-remote
              className={`app-card ${pressed ? "app-card-pressed" : ""}`}
              style={{ "--pc": c.hex, zIndex: focused ? 30 : 10 }}
              onClick={() => handlePress(i)}
              onFocus={() => isTV && setFocusIdx(i)}
            >
              <span className="card-badge" style={{ color: c.hex, borderColor: `${c.hex}33` }}>{c.badge}</span>
              <span className="card-icon-wrap flex items-center justify-center rounded-full flex-shrink-0"
                style={{
                  width: "clamp(80px,8vw,120px)", height: "clamp(80px,8vw,120px)",
                  background: `linear-gradient(135deg, ${c.hex}1a, ${c.hexDark}1a)`,
                  border: `2px solid ${c.hex}55`,
                  boxShadow: focused ? `0 0 30px ${c.hex}66, inset 0 0 20px ${c.hex}33` : `0 8px 24px rgba(0,0,0,0.3), inset 0 0 16px ${c.hex}22`,
                }}>
                <Icon className="w-1/2 h-1/2" style={{ color: c.hex }} />
              </span>
              <span className="card-title" style={{ textShadow: `0 0 20px ${c.hex}55` }}>
                {title}
              </span>
              <span className="card-subtitle" style={{ color: c.hex }}>{subtitle}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}