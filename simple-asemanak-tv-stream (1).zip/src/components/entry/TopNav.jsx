import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Settings as SettingsIcon, Wifi, WifiOff } from "lucide-react";
import ProfileBadge from "@/components/ProfileBadge";
import TopClock from "@/components/entry/TopClock";
import ServerStatusReport from "@/components/entry/ServerStatusReport";
import { useIsTV } from "@/lib/useIsTV";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

function tzCity(tz) {
  if (!tz) return "";
  return tz.split("/").pop().replace(/_/g, " ");
}

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

// TV and mobile both include all three top-bar elements — excluding Search
// or Settings from the TV order traps focus (ArrowRight cycles back to the
// same element, and the global useTVRemote handler is skipped because
// e.defaultPrevented is already true).
const TOP_ORDER_TV = ["top-profile", "nav-search", "nav-settings"];
const TOP_ORDER_MOBILE = ["top-profile", "nav-search", "nav-settings"];

export default function TopNav({ isFa, onOpenPicker }) {
  const navigate = useNavigate();
  const isTV = useIsTV();
  const TOP_ORDER = isTV ? TOP_ORDER_TV : TOP_ORDER_MOBILE;
  const [tz, setTz] = useState("Asia/Tehran");
  const [online, setOnline] = useState(navigator.onLine);
  const [showStatus, setShowStatus] = useState(false);

  useEffect(() => {
    const tick = () => setTz(readSettings().clockTimezone || "Asia/Tehran");
    tick();
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    window.addEventListener("ayeneh-settings-changed", tick);
    window.addEventListener("storage", tick);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      window.removeEventListener("ayeneh-settings-changed", tick);
      window.removeEventListener("storage", tick);
    };
  }, []);

  // Remote / keyboard navigation across the top row + down to the app pills
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      const activeId = document.activeElement?.id || "";
      const pos = TOP_ORDER.indexOf(activeId);
      if (e.key === "ArrowDown" && pos >= 0) {
        e.preventDefault();
        document.getElementById("app-pill-0")?.focus();
        return;
      }
      if (pos < 0) return;
      if (e.key === "ArrowRight") {
        e.preventDefault();
        document.getElementById(TOP_ORDER[(pos + 1) % TOP_ORDER.length])?.focus();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        document.getElementById(TOP_ORDER[(pos - 1 + TOP_ORDER.length) % TOP_ORDER.length])?.focus();
      } else if (["Enter", "Return", " ", "XF86OK", "Accept"].includes(e.key)) {
        e.preventDefault();
        document.activeElement?.click();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const city = tzCity(tz);

  const pills = [
    { id: "nav-search", icon: Search, label: isFa ? "جستجو" : "Search", onClick: () => navigate("/Search"), hex: "#00ffff" },
    { id: "nav-settings", icon: SettingsIcon, label: isFa ? "تنظیمات" : "Settings", onClick: () => navigate("/Settings"), hex: "#a855f7" },
  ];

  return (
    <div className="absolute top-0 left-0 right-0 z-30" style={{ direction: "ltr" }}>
      <style>{`
        .pill-btn{transition:all .3s cubic-bezier(0.4,0,0.2,1);}
        .pill-btn:hover,.pill-btn:focus{transform:scale(1.06);border-color:var(--pc)!important;box-shadow:0 0 20px var(--pc);}
      `}</style>

      {/* Left: profile avatar */}
      <div className="absolute" style={{ left: "calc(clamp(16px,2vw,32px) + env(safe-area-inset-left))", top: "calc(clamp(18px,3.5vh,32px) + env(safe-area-inset-top))" }}>
        <div id="top-profile"><ProfileBadge /></div>
      </div>

      {/* Center: pill buttons */}
      <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-2 md:gap-3"
        style={{ top: "calc(clamp(18px,3.5vh,32px) + env(safe-area-inset-top))" }}>
        {pills.map(p => {
          const Icon = p.icon;
          return (
            <button key={p.id} id={p.id} onClick={p.onClick} data-remote aria-label={p.label}
              className="pill-btn flex items-center gap-2 rounded-full text-white font-bold"
              style={{
                "--pc": p.hex,
                padding: "clamp(10px,1.4vw,16px) clamp(16px,2vw,26px)",
                background: "rgba(8,8,16,0.6)",
                border: "1.5px solid rgba(255,255,255,0.18)",
                backdropFilter: "blur(14px)",
                fontSize: "clamp(14px,1.5vw,17px)",
                letterSpacing: "0.03em",
              }}>
              <Icon className="w-5 h-5 md:w-6 md:h-6" style={{ color: p.hex, filter: `drop-shadow(0 0 6px ${p.hex})` }} strokeWidth={2.5} />
              <span className="hidden sm:inline">{p.label}</span>
            </button>
          );
        })}
      </div>

      {/* Right: time + city + brand + logo */}
      <div className="absolute flex items-center gap-2 md:gap-3"
        style={{ right: "calc(clamp(16px,2vw,32px) + env(safe-area-inset-right))", top: "calc(clamp(18px,3.5vh,32px) + env(safe-area-inset-top))" }}>
        {/* Time + city */}
        <div className="hidden md:flex flex-col items-end leading-tight gap-0.5" style={{ direction: "ltr" }}>
          <TopClock />
          <button onClick={() => setShowStatus(true)} className="flex items-center gap-1 hover:opacity-80 transition-opacity">
            {online ? <Wifi style={{ width: 11, height: 11, color: "#34d399" }} /> : <WifiOff style={{ width: 11, height: 11, color: "#f87171" }} />}
            <span style={{ color: online ? "#34d399" : "#f87171", fontSize: "clamp(14px,1vw,16px)", fontWeight: 600 }}>{city}</span>
          </button>
        </div>
        {/* Brand */}
        <div className="hidden lg:flex flex-col items-end leading-tight" style={{ borderLeft: "1px solid rgba(255,255,255,0.12)", paddingLeft: 12 }}>
          <span className="text-white font-extrabold" style={{ fontSize: "clamp(15px,1.8vw,22px)", textShadow: "0 0 12px rgba(168,85,247,0.5)", letterSpacing: "0.03em" }}>Asemanak TV</span>
          <span className="text-white/60 uppercase" style={{ fontSize: "clamp(14px,0.9vw,15px)", letterSpacing: "0.15em" }}>Smart OLED OS</span>
        </div>
        {/* Logo */}
        <img src={LOGO_URL} alt="Asemanak TV" style={{ width: "clamp(38px,4vw,52px)", height: "clamp(38px,4vw,52px)", objectFit: "contain", borderRadius: "50%", border: "2px solid rgba(168,85,247,0.6)", boxShadow: "0 0 14px rgba(168,85,247,0.5)" }} />
      </div>

      {showStatus && <ServerStatusReport isFa={isFa} onClose={() => setShowStatus(false)} />}
    </div>
  );
}