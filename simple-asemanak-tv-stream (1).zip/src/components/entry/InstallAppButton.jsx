import { useState, useEffect } from "react";
import { Download, X, Share, Plus } from "lucide-react";

// "Download app" — triggers the native PWA install prompt when available
// (Android Chrome / Android TV / desktop). On iOS where beforeinstallprompt
// never fires, it shows step-by-step "Add to Home Screen" instructions.
export default function InstallAppButton() {
  const [deferred, setDeferred] = useState(null);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    const onPrompt = (e) => { e.preventDefault(); setDeferred(e); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  const onClick = async () => {
    if (deferred) {
      try { deferred.prompt(); await deferred.userChoice; } catch {}
      setDeferred(null);
    } else {
      setShowHelp(true);
    }
  };

  const isIOS = typeof navigator !== "undefined" && /iphone|ipad|ipod/i.test(navigator.userAgent || "");

  return (
    <>
      <button onClick={onClick}
        className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-white transition-all hover:scale-105"
        style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 14px rgba(123,44,191,0.35)", fontFamily: "Vazirmatn, sans-serif" }}>
        <Download className="w-4 h-4" /> دانلود اپ
      </button>
      {showHelp && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center" onClick={() => setShowHelp(false)}>
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <div className="relative z-10 w-[320px] max-w-[90vw] rounded-2xl overflow-hidden"
            style={{ background: "rgba(13,12,28,0.97)", border: "1px solid rgba(123,44,191,0.4)", boxShadow: "0 20px 60px rgba(0,0,0,0.6)" }}
            onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
              <p className="text-white font-bold text-sm" style={{ fontFamily: "Vazirmatn, sans-serif" }}>نصب برنامه</p>
              <button onClick={() => setShowHelp(false)} className="text-white/50 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <div className="px-5 py-5 text-right" style={{ direction: "rtl", fontFamily: "Vazirmatn, sans-serif" }}>
              {isIOS ? (
                <div className="space-y-3 text-sm text-white/80">
                  <p className="flex items-center gap-2"><Share className="w-4 h-4 text-cyan-300" /> دکمه Share را بزنید</p>
                  <p className="flex items-center gap-2"><Plus className="w-4 h-4 text-cyan-300" /> گزینه «Add to Home Screen» را انتخاب کنید</p>
                </div>
              ) : (
                <p className="text-sm text-white/80">از منوی مرورگر گزینه «Add to Home screen» یا «Install app» را انتخاب کنید تا برنامه روی دستگاه نصب شود.</p>
              )}
              <button onClick={() => setShowHelp(false)}
                className="mt-4 w-full py-2.5 rounded-xl text-sm font-bold text-white"
                style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)" }}>متوجه شدم</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}