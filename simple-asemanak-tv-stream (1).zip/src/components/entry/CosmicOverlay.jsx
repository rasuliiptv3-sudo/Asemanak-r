import { useMemo } from "react";

// Subtle animated overlay on top of the static background image:
// twinkling stars + slowly drifting nebula clouds.
export default function CosmicOverlay() {
  const stars = useMemo(() => Array.from({ length: 70 }, () => ({
    x: Math.random() * 100, y: Math.random() * 100, s: Math.random() * 1.6 + 0.5,
    d: Math.random() * 4, dur: 3 + Math.random() * 3,
  })), []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-[5]">
      {/* Slow drifting nebula clouds */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse 45% 30% at 28% 45%, rgba(138,43,226,0.16), transparent 60%), radial-gradient(ellipse 40% 25% at 75% 60%, rgba(70,60,200,0.12), transparent 60%)",
        mixBlendMode: "screen", animation: "coDrift 80s ease-in-out infinite alternate",
      }} />
      {/* Twinkling stars */}
      {stars.map((s, i) => (
        <div key={i} className="absolute rounded-full" style={{
          left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s,
          background: "#fff", opacity: 0.7, animation: `coTw ${s.dur}s ease-in-out ${s.d}s infinite alternate`,
        }} />
      ))}
      <style>{`@keyframes coTw{from{opacity:0.2}to{opacity:1}}@keyframes coDrift{from{transform:translate3d(0,0,0) scale(1)}to{transform:translate3d(-3%,2%,0) scale(1.05)}}`}</style>
    </div>
  );
}