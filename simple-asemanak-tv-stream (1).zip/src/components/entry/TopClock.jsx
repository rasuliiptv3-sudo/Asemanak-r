import { useState, useEffect } from "react";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

function toFaDigits(s) {
  return String(s).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
}

// Compact time-only clock for the top navigation bar (no date / server / weather).
export default function TopClock() {
  const [now, setNow] = useState(new Date());
  const [isFa, setIsFa] = useState(true);
  const [tz, setTz] = useState("Asia/Tehran");
  const [fmt, setFmt] = useState("24");
  const [offsetH, setOffsetH] = useState(0);
  const [offsetM, setOffsetM] = useState(0);
  const [offsetS, setOffsetS] = useState(0);

  useEffect(() => {
    const tick = () => {
      const s = readSettings();
      setNow(new Date());
      setIsFa(s.language !== "en");
      setTz(s.clockTimezone || "Asia/Tehran");
      setFmt(s.clockFormat || "24");
      setOffsetH(Number(s.clockOffset) || 0);
      setOffsetM(Number(s.clockOffsetMinutes) || 0);
      setOffsetS(Number(s.clockOffsetSeconds) || 0);
    };
    tick();
    const iv = setInterval(tick, 1000);
    window.addEventListener("ayeneh-settings-changed", tick);
    window.addEventListener("storage", tick);
    return () => {
      clearInterval(iv);
      window.removeEventListener("ayeneh-settings-changed", tick);
      window.removeEventListener("storage", tick);
    };
  }, []);

  const adjNow = new Date(now.getTime() + offsetH * 3600000 + offsetM * 60000 + offsetS * 1000);
  const timeParts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    hour12: fmt === "12",
  }).formatToParts(adjNow);
  const hh = timeParts.find(p => p.type === "hour")?.value || "00";
  const mm = timeParts.find(p => p.type === "minute")?.value || "00";
  const dp = timeParts.find(p => p.type === "dayPeriod")?.value || "";
  let timeStr = `${hh}:${mm}`;
  if (fmt === "12" && dp) {
    const dpText = isFa ? (dp.toLowerCase().includes("am") ? "ق.ظ" : "ب.ظ") : dp;
    timeStr = `${timeStr} ${dpText}`;
  }
  if (isFa) timeStr = toFaDigits(timeStr);

  return (
    <span className="font-bold text-white select-none" style={{
      fontFamily: "Vazirmatn, monospace",
      letterSpacing: "0.04em",
      fontSize: "clamp(20px,2.6vw,30px)",
      textShadow: "0 0 10px rgba(168,85,247,0.4)",
      direction: "ltr",
      whiteSpace: "nowrap",
    }}>{timeStr}</span>
  );
}