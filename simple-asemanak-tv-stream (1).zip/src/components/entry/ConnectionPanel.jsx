import { useState, useEffect } from "react";
import { Wifi, Calendar } from "lucide-react";

const PERSIAN_DAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];

function toPersianDigits(s) {
  return String(s).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
}

function toPersianDate(date) {
  try {
    const formatter = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    const parts = formatter.formatToParts(date);
    const dayName = PERSIAN_DAYS[date.getDay()] || "";
    const dayPart = parts.find(p => p.type === "day")?.value || "";
    const monthPart = parts.find(p => p.type === "month")?.value || "";
    const yearPart = parts.find(p => p.type === "year")?.value || "";
    return `${dayName}، ${dayPart} ${monthPart} ${yearPart}`;
  } catch {
    return "";
  }
}

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

// Translucent panel showing connection status and live date/time
export default function ConnectionPanel() {
  const [now, setNow] = useState(new Date());
  const [online, setOnline] = useState(navigator.onLine);
  const [isFa, setIsFa] = useState(true);

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    syncLang();
    const t = setInterval(() => { setNow(new Date()); syncLang(); }, 1000);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    window.addEventListener("ayeneh-settings-changed", syncLang);
    return () => {
      clearInterval(t);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      window.removeEventListener("ayeneh-settings-changed", syncLang);
    };
  }, []);

  const timeStr = toPersianDigits(now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }));
  const dateStr = isFa ? toPersianDate(now) : now.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  return (
    <div className="flex flex-col gap-1.5 rounded-2xl px-3 py-2"
      style={{ background: "rgba(0,0,0,0.4)", border: "1px solid rgba(94,69,162,0.35)", backdropFilter: "blur(10px)", fontFamily: "Vazirmatn, sans-serif", direction: isFa ? "rtl" : "ltr" }}>
      <div className="flex items-center gap-2">
        <Wifi className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
        <span className="text-white/70" style={{ fontSize: "clamp(10px, 0.95vw, 13px)" }}>
          {isFa ? "منبع" : "Source"}: {online ? (isFa ? "متصل" : "Connected") : (isFa ? "قطع" : "Offline")}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <Calendar className="w-3.5 h-3.5 text-purple-300 flex-shrink-0" />
        <span className="text-white/70" style={{ fontSize: "clamp(10px, 0.95vw, 13px)" }}>
          {dateStr} | {timeStr}
        </span>
      </div>
    </div>
  );
}