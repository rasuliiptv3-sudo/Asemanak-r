function YouTubeLogo({ size = 56 }) {
  return (
    <svg viewBox="0 0 28 20" style={{ width: size, height: "auto" }}>
      <rect width="28" height="20" rx="5" fill="#FF0000" />
      <polygon points="11,5 11,15 20,10" fill="#fff" />
    </svg>
  );
}

export default function MoreAppsRow() {
  const openYouTube = () => {
    const isAndroid = /android/i.test(navigator.userAgent);
    if (isAndroid) {
      window.location.href = "intent://www.youtube.com#Intent;scheme=https;package=com.google.android.youtube;end";
    } else {
      window.open("https://www.youtube.com", "_blank");
    }
  };

  return (
    <div className="flex gap-4 md:gap-6 flex-wrap">
      <style>{`
        .more-app-card{
          position:relative;flex-shrink:0;overflow:hidden;
          display:flex;flex-direction:column;align-items:center;justify-content:center;
          width:clamp(150px,16vw,220px);min-height:clamp(120px,14vh,170px);
          gap:14px;padding:24px 20px;border-radius:24px;cursor:pointer;outline:none;
          background:linear-gradient(160deg, rgba(20,14,35,0.85), rgba(10,8,20,0.92));
          backdrop-filter:blur(24px) saturate(1.5);
          -webkit-backdrop-filter:blur(24px) saturate(1.5);
          border:1.5px solid rgba(255,255,255,0.08);
          box-shadow:0 12px 40px rgba(0,0,0,0.5),inset 0 1px 0 rgba(255,255,255,0.06);
          transition:transform .4s cubic-bezier(0.34,1.56,0.64,1),box-shadow .4s ease,border-color .4s ease;
        }
        .more-app-card:hover,.more-app-card:focus{
          transform:translateY(-8px) scale(1.03);
          border-color:rgba(255,0,0,0.4);
          box-shadow:0 20px 50px rgba(0,0,0,0.6),0 0 30px rgba(255,0,0,0.4),inset 0 1px 0 rgba(255,255,255,0.12);
        }
      `}</style>
      <button className="more-app-card" onClick={openYouTube}>
        <div className="flex items-center justify-center" style={{ filter: "drop-shadow(0 0 12px rgba(255,255,255,0.15))" }}>
          <YouTubeLogo size={56} />
        </div>
        <span className="text-white font-bold" style={{ fontSize: "clamp(14px,1.5vw,18px)", letterSpacing: "0.04em" }}>YouTube</span>
      </button>
    </div>
  );
}