// Decorative slanted poster marquee for the Entry hero section.
// Pure CSS animation (no JS rAF loop) — reliable and battery-friendly.
const POSTERS = [
  "https://images.unsplash.com/photo-1485846234645-y6a2e2d7eaa6?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1502685104226-ee32348fefca?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1574267432553-4b4628081c31?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1542204165-65bf26472b80?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1518929458119-e5bf444c30f4?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1440404653325-ab127d49acc1?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1536440136628-849c177e76a7?w=320&h=480&fit=crop&q=80",
  "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=320&h=480&fit=crop&q=80",
];

export default function HeroMarquee() {
  const items = [...POSTERS, ...POSTERS]; // duplicate for seamless loop
  return (
    <div className="relative w-full overflow-hidden" style={{ height: "clamp(210px, 30vh, 340px)" }}>
      <style>{`
        @keyframes heroMarquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        @keyframes heroTwinkle { 0%,100% { opacity: 0.15; transform: scale(0.8); } 50% { opacity: 0.8; transform: scale(1.3); } }
      `}</style>

      {/* Gradient backdrop */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, #1a0b2e 0%, #2d1b4e 45%, #1a0b2e 100%)" }} />

      {/* Starfield */}
      {[...Array(26)].map((_, i) => (
        <div key={i} className="absolute rounded-full bg-white" style={{
          width: `${1 + (i % 3)}px`, height: `${1 + (i % 3)}px`,
          top: `${(i * 37) % 100}%`, left: `${(i * 53) % 100}%`,
          animation: `heroTwinkle ${2 + (i % 4)}s ease-in-out ${i * 0.2}s infinite`,
          opacity: 0.6, zIndex: 1,
        }} />
      ))}

      {/* Perspective-tilted marquee */}
      <div className="absolute inset-0 flex items-center" style={{ perspective: "1400px" }}>
        <div style={{ transform: "rotateX(12deg)", transformStyle: "preserve-3d", width: "100%" }}>
          <div className="flex" style={{
            animation: "heroMarquee 55s linear infinite",
            gap: "clamp(12px,1.6vw,22px)",
            paddingLeft: "2vw",
            willChange: "transform",
          }}>
            {items.map((src, i) => (
              <div key={i} className="flex-shrink-0 rounded-xl overflow-hidden relative" style={{
                width: "clamp(130px, 15vw, 210px)",
                height: "clamp(195px, 22vh, 315px)",
                boxShadow: "0 10px 35px rgba(0,0,0,0.6), 0 0 25px rgba(168,85,247,0.22)",
                border: "1px solid rgba(255,255,255,0.12)",
              }}>
                <img src={src} alt="" className="w-full h-full object-cover" style={{ filter: "saturate(1.15) contrast(1.05) brightness(0.92)" }} />
                <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 55%, rgba(10,5,20,0.65) 100%)" }} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Edge fades */}
      <div className="absolute inset-y-0 left-0 pointer-events-none" style={{ width: "clamp(60px,10vw,140px)", background: "linear-gradient(90deg, #08000f 0%, transparent 100%)", zIndex: 5 }} />
      <div className="absolute inset-y-0 right-0 pointer-events-none" style={{ width: "clamp(60px,10vw,140px)", background: "linear-gradient(270deg, #08000f 0%, transparent 100%)", zIndex: 5 }} />
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none" style={{ height: "80px", background: "linear-gradient(180deg, transparent 0%, #08000f 100%)", zIndex: 5 }} />
    </div>
  );
}