import { useState, useEffect, useMemo } from "react";
import { Wifi, Sun, Cloud, CloudRain, CloudSnow, Wind, CloudSun, CloudFog, Cloudy, Calendar } from "lucide-react";
import { CITIES, getSelectedCity } from "@/lib/cities";

const WEATHER = {
  0: { Icon: Sun, fa: "آفتابی", en: "Sunny", color: "#fbbf24" },
  1: { Icon: Sun, fa: "نیمه‌آفتابی", en: "Mostly Sunny", color: "#fcd34d" },
  2: { Icon: CloudSun, fa: "نیمه‌ابری", en: "Partly Cloudy", color: "#93c5fd" },
  3: { Icon: Cloud, fa: "ابری", en: "Cloudy", color: "#94a3b8" },
  45: { Icon: CloudFog, fa: "مه‌آلود", en: "Foggy", color: "#cbd5e1" },
  48: { Icon: CloudFog, fa: "مه یخی", en: "Ice Fog", color: "#cbd5e1" },
  51: { Icon: CloudRain, fa: "نم‌نم", en: "Drizzle", color: "#60a5fa" },
  53: { Icon: CloudRain, fa: "نم‌نم", en: "Drizzle", color: "#60a5fa" },
  55: { Icon: CloudRain, fa: "نم‌نم", en: "Drizzle", color: "#60a5fa" },
  61: { Icon: CloudRain, fa: "باران", en: "Rain", color: "#3b82f6" },
  63: { Icon: CloudRain, fa: "باران", en: "Rain", color: "#3b82f6" },
  65: { Icon: CloudRain, fa: "باران سنگین", en: "Heavy Rain", color: "#2563eb" },
  71: { Icon: CloudSnow, fa: "برف", en: "Snow", color: "#e0f2fe" },
  73: { Icon: CloudSnow, fa: "برف", en: "Snow", color: "#e0f2fe" },
  75: { Icon: CloudSnow, fa: "برف سنگین", en: "Heavy Snow", color: "#bfdbfe" },
  80: { Icon: CloudRain, fa: "رگبار", en: "Showers", color: "#60a5fa" },
  81: { Icon: CloudRain, fa: "رگبار", en: "Showers", color: "#3b82f6" },
  82: { Icon: CloudRain, fa: "رگبار سنگین", en: "Heavy Showers", color: "#2563eb" },
  95: { Icon: Wind, fa: "رعد و برق", en: "Thunderstorm", color: "#a78bfa" },
  96: { Icon: Wind, fa: "رعد و برق", en: "Thunderstorm", color: "#a78bfa" },
  99: { Icon: Wind, fa: "رعد و برق", en: "Thunderstorm", color: "#a78bfa" },
};

const PERSIAN_DAYS = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const WEEKDAY_SHORT = ["ی", "د", "س", "چ", "پ", "ج", "ش"];

function toFaDigits(s) {
  return String(s).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
}

function toPersianDate(date) {
  try {
    const formatter = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { day: "numeric", month: "long", year: "numeric" });
    const parts = formatter.formatToParts(date);
    const dayName = PERSIAN_DAYS[date.getDay()] || "";
    const dayPart = parts.find(p => p.type === "day")?.value || "";
    const monthPart = parts.find(p => p.type === "month")?.value || "";
    return `${dayName} ${dayPart} ${monthPart}`;
  } catch { return ""; }
}

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

export default function WeatherPanel() {
  const [now, setNow] = useState(new Date());
  const [online, setOnline] = useState(navigator.onLine);
  const [isFa, setIsFa] = useState(true);
  const [tz, setTz] = useState("Asia/Tehran");
  const [fmt, setFmt] = useState("24");
  const [offsetH, setOffsetH] = useState(0);
  const [offsetM, setOffsetM] = useState(0);
  const [offsetS, setOffsetS] = useState(0);
  const [weather, setWeather] = useState(null);
  const [weekly, setWeekly] = useState([]);

  const city = useMemo(() => getSelectedCity(), []);

  useEffect(() => {
    const tick = () => {
      const s = readSettings();
      setNow(new Date());
      setIsFa(s.language !== "en");
      setTz(s.clockTimezone || "Asia/Tehran");
      setFmt(s.clockFormat || "24");
      setOffsetH(Number(s.clockOffset) || 0);
      setOffsetM(Number(s.clockOffsetMinutes) || 0);
      setOffsetS(Number(s.clockOffsetSeconds) || 0);
    };
    tick();
    const iv = setInterval(tick, 1000);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    window.addEventListener("ayeneh-settings-changed", tick);
    window.addEventListener("storage", tick);
    return () => {
      clearInterval(iv);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      window.removeEventListener("ayeneh-settings-changed", tick);
      window.removeEventListener("storage", tick);
    };
  }, []);

  // Fetch current + weekly weather
  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const cache = JSON.parse(localStorage.getItem("ayeneh_weather_cache_v2") || "null");
        if (cache && cache.id === city.id && Date.now() - cache.t < 30 * 60 * 1000) {
          setWeather(cache.data.current);
          setWeekly((cache.data.weekly || []).map(d => ({ ...d, date: d.date instanceof Date ? d.date : new Date(d.date) })));
          return;
        }
        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.long}` +
          `&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=${city.tz}&forecast_days=7`
        );
        const d = await res.json();
        if (cancelled) return;
        const current = { temp: Math.round(d.current?.temperature_2m), code: d.current?.weather_code };
        const weekly = (d.daily?.time || []).slice(0, 7).map((dateStr, i) => ({
          date: dateStr ? new Date(dateStr + "T00:00:00") : new Date(),
          code: d.daily.weather_code?.[i],
          max: Math.round(d.daily.temperature_2m_max?.[i]),
          min: Math.round(d.daily.temperature_2m_min?.[i]),
        }));
        setWeather(current);
        setWeekly(weekly);
        localStorage.setItem("ayeneh_weather_cache_v2", JSON.stringify({ t: Date.now(), id: city.id, data: { current, weekly } }));
      } catch {}
    };
    load();
    return () => { cancelled = true; };
  }, [city.id]);

  const W = (weather && WEATHER[weather.code]) || { Icon: Cloudy, fa: "—", en: "—", color: "#94a3b8" };
  const WIcon = W.Icon;

  // Apply offset + timezone to get the displayed time
  const adjNow = new Date(now.getTime() + offsetH * 3600000 + offsetM * 60000 + offsetS * 1000);
  // Use Intl with timezone + format — show HH:MM:SS so second offsets are visible
  const timeParts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: fmt === "12",
  }).formatToParts(adjNow);
  const hh = timeParts.find(p => p.type === "hour")?.value || "00";
  const mm = timeParts.find(p => p.type === "minute")?.value || "00";
  const ss = timeParts.find(p => p.type === "second")?.value || "00";
  const dp = timeParts.find(p => p.type === "dayPeriod")?.value || "";
  let timeStr = `${hh}:${mm}:${ss}`;
  if (fmt === "12" && dp) {
    const dpText = isFa ? (dp.toLowerCase().includes("am") ? "ق.ظ" : "ب.ظ") : dp;
    timeStr = `${timeStr} ${dpText}`;
  }
  if (isFa) timeStr = toFaDigits(timeStr);

  // Date in selected timezone
  const dateStr = isFa
    ? toPersianDate(adjNow)
    : new Intl.DateTimeFormat("en-GB", { timeZone: tz, weekday: "long", day: "numeric", month: "long" }).format(adjNow);

  return (
    <div className="rounded-2xl overflow-hidden select-none" style={{
      background: "rgba(0,0,0,0.5)",
      border: "1px solid rgba(94,69,162,0.35)",
      backdropFilter: "blur(14px)",
      fontFamily: "Vazirmatn, sans-serif",
      direction: isFa ? "rtl" : "ltr",
      minWidth: "clamp(180px, 20vw, 320px)",
      maxWidth: "calc(100vw - 32px)",
      boxShadow: "0 0 20px rgba(168,85,247,0.15)",
    }}>
      {/* Top: Weather + Time + Date + Internet */}
      <div className="px-4 pt-3 pb-2.5">
        <div className="flex items-center gap-3 mb-2">
          {/* Weather icon */}
          <div className="flex items-center justify-center rounded-xl flex-shrink-0" style={{
            width: "clamp(44px,4vw,56px)", height: "clamp(44px,4vw,56px)",
            background: `${W.color}1a`, border: `1.5px solid ${W.color}55`,
            boxShadow: `0 0 12px ${W.color}33`,
          }}>
            <WIcon style={{ width: "60%", height: "60%", color: W.color }} />
          </div>
          {/* Temp + condition + city */}
          <div className="flex-1 min-w-0">
            <div className="flex items-baseline gap-1.5">
              <span className="text-white font-bold" style={{ fontSize: "clamp(20px,2vw,28px)" }}>
                {weather ? toFaDigits(String(weather.temp)) : "—"}
              </span>
              <span className="text-white/50" style={{ fontSize: "clamp(11px,1vw,14px)" }}>°C</span>
            </div>
            <p className="text-white/70 truncate" style={{ fontSize: "clamp(10px,0.9vw,12px)" }}>
              {weather ? (isFa ? W.fa : W.en) : (isFa ? "در حال دریافت..." : "Loading...")} · {city.nameFa}
            </p>
          </div>
          {/* Time */}
          <div className="text-left flex-shrink-0" style={{ direction: "ltr" }}>
            <p className="text-white font-bold" style={{
              fontSize: "clamp(15px,1.6vw,22px)",
              textShadow: "0 0 10px rgba(168,85,247,0.4)",
              fontFamily: "Vazirmatn, monospace",
              letterSpacing: "0.04em",
            }}>{timeStr}</p>
            <p className="text-white/50" style={{ fontSize: "clamp(8px,0.75vw,10px)" }}>
              {dateStr}
            </p>
          </div>
        </div>

        {/* Internet status row */}
        <div className="flex items-center gap-2 pt-2 border-t" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
          <Wifi className="flex-shrink-0" style={{
            width: 14, height: 14,
            color: online ? "#34d399" : "#f87171",
          }} />
          <span className="text-white/60" style={{ fontSize: "clamp(10px,0.9vw,12px)" }}>
            {isFa ? "سرور" : "Server"}: {online ? (isFa ? "متصل" : "Online") : (isFa ? "قطع" : "Offline")}
          </span>
          <span className="text-white/20">·</span>
          <span className="text-white/40 truncate" style={{ fontSize: "clamp(9px,0.8vw,11px)" }}>
            {city.nameEn}
          </span>
        </div>
      </div>

      {/* Bottom: Weekly forecast */}
      <div className="flex px-2 py-2 gap-1" style={{ background: "rgba(255,255,255,0.03)", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        {weekly.length > 0 ? weekly.map((d, i) => {
          const DW = WEATHER[d.code] || { Icon: Cloud, color: "#94a3b8" };
          const DIcon = DW.Icon;
          const isToday = i === 0;
          return (
            <div key={i} className="flex flex-col items-center justify-center flex-1 rounded-lg py-1.5 px-0.5 transition-all" style={{
              background: isToday ? `${DW.color}15` : "transparent",
              border: isToday ? `1px solid ${DW.color}33` : "1px solid transparent",
            }}>
              <span className="text-white/50 mb-0.5" style={{ fontSize: "clamp(8px,0.7vw,10px)" }}>
                {isToday ? (isFa ? "امروز" : "Today") : (isFa ? WEEKDAY_SHORT[d.date.getDay()] : (d.date.toLocaleDateString ? d.date.toLocaleDateString("en", { weekday: "short" }) : ""))}
              </span>
              <DIcon style={{ width: 16, height: 16, color: DW.color, margin: "1px 0" }} />
              <span className="text-white font-semibold" style={{ fontSize: "clamp(9px,0.8vw,11px)" }}>
                {toFaDigits(String(d.max))}°
              </span>
              <span className="text-white/35" style={{ fontSize: "clamp(8px,0.7vw,9px)" }}>
                {toFaDigits(String(d.min))}°
              </span>
            </div>
          );
        }) : (
          <div className="flex-1 py-3 text-center">
            <Cloudy className="w-5 h-5 text-white/20 mx-auto mb-1 animate-pulse" />
            <span className="text-white/30" style={{ fontSize: 10 }}>
              {isFa ? "آب‌وهوا هفته..." : "Weekly forecast..."}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}