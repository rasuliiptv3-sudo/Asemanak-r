// Space-themed background: deep violet-to-black radial gradient with scattered
// twinkling stars, a glowing moon, and slowly drifting nebula clouds.

const STARS = [
  [8, 12, 1.4], [18, 6, 1], [27, 18, 1.2], [36, 9, 0.9], [44, 22, 1.3],
  [52, 5, 1], [61, 14, 1.1], [70, 8, 0.9], [78, 19, 1.2], [87, 11, 1],
  [94, 16, 1.3], [14, 26, 1], [32, 30, 1.1], [50, 28, 0.9], [68, 32, 1.2],
  [83, 27, 1], [6, 38, 1.1], [24, 42, 1], [42, 40, 1.3], [60, 44, 0.9],
  [78, 41, 1.1], [92, 46, 1], [20, 52, 1], [40, 55, 1.2], [58, 50, 1],
  [76, 56, 1.1], [10, 60, 0.9], [30, 64, 1.3], [48, 62, 1], [66, 66, 1.1],
  [84, 60, 1], [16, 72, 1.2], [36, 76, 1], [54, 74, 0.9], [72, 78, 1.1],
  [90, 72, 1], [8, 84, 1], [28, 88, 1.2], [46, 86, 1], [64, 90, 1.1],
  [82, 84, 1], [22, 94, 1], [40, 96, 1.2], [60, 94, 0.9], [78, 96, 1],
];

export default function CitySkyline() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <style>{`
        @keyframes moonPulse { 0%,100% { opacity: 0.85; box-shadow: 0 0 36px rgba(0,242,255,0.45), inset -8px -8px 18px rgba(0,0,0,0.25); } 50% { opacity: 1; box-shadow: 0 0 60px rgba(0,242,255,0.8), inset -8px -8px 18px rgba(0,0,0,0.25); } }
        @keyframes driftA { 0% { transform: translate(-4%, 0); } 100% { transform: translate(4%, -2%); } }
        @keyframes driftB { 0% { transform: translate(3%, -1%); } 100% { transform: translate(-3%, 1%); } }
      `}</style>

      {/* Deep space radial gradient */}
      <div className="absolute inset-0" style={{
        background:
          "radial-gradient(ellipse at 50% 30%, #1a1238 0%, #120b2a 32%, #0a0718 62%, #05030f 100%)",
      }} />

      {/* Soft violet nebula glows */}
      <div className="absolute inset-0" style={{
        background:
          "radial-gradient(ellipse at 22% 28%, rgba(138,43,226,0.14) 0%, transparent 42%)," +
          "radial-gradient(ellipse at 78% 24%, rgba(123,44,191,0.12) 0%, transparent 45%)," +
          "radial-gradient(ellipse at 50% 50%, rgba(168,85,247,0.06) 0%, transparent 55%)",
      }} />

      {/* Slowly drifting nebula clouds */}
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse 45% 30% at 25% 32%, rgba(138,43,226,0.16) 0%, transparent 52%)", animation: "driftA 26s ease-in-out infinite alternate" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse 40% 28% at 76% 22%, rgba(34,211,238,0.12) 0%, transparent 52%)", animation: "driftB 32s ease-in-out infinite alternate" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse 50% 35% at 58% 72%, rgba(123,44,191,0.10) 0%, transparent 56%)", animation: "driftA 40s ease-in-out infinite alternate" }} />

      {/* Moon — subtle slow glow pulse */}
      <div className="absolute" style={{
        top: "13%", right: "18%", width: 62, height: 62, borderRadius: "50%",
        background: "radial-gradient(circle at 35% 35%, #eaf9ff 0%, #bfe8ff 48%, #6fb8e8 100%)",
        animation: "moonPulse 9s ease-in-out infinite",
      }} />

      {/* Twinkling stars */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
        {STARS.map(([x, y, r], i) => (
          <circle key={i} cx={x} cy={y} r={r * 0.18} fill="#ffffff" opacity="0.85">
            <animate attributeName="opacity"
              values="0.85;0.2;0.85" dur={`${2.5 + (i % 5)}s`} repeatCount="indefinite" />
            <animate attributeName="r"
              values={`${r * 0.18};${r * 0.08};${r * 0.18}`} dur={`${2.5 + (i % 5)}s`} repeatCount="indefinite" />
          </circle>
        ))}
        {/* A few brighter accent stars */}
        {[[33, 16, 0.5], [71, 38, 0.5], [19, 58, 0.45], [88, 70, 0.5], [52, 82, 0.45]].map(([x, y, r], i) => (
          <circle key={`b-${i}`} cx={x} cy={y} r={r} fill="#e9d5ff" opacity="0.9">
            <animate attributeName="opacity" values="0.9;0.4;0.9" dur={`${3 + i}s`} repeatCount="indefinite" />
          </circle>
        ))}
      </svg>
    </div>
  );
}