import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import { useIsTV } from "@/lib/useIsTV";
import { Home, Tv, Clapperboard, Film, MonitorPlay, Star, Settings, ChevronDown, Crown, Sparkles, Trash2, LogOut, Shield } from "lucide-react";

const AVATAR_COLORS = [
  ["#ea4335", "#c5221f"], ["#4285f4", "#1a73e8"], ["#34a853", "#188038"],
  ["#fbbc04", "#f9a825"], ["#a142f4", "#8430ce"], ["#ff6d01", "#e8590c"],
];
function avatarStyle(name) {
  const letter = (name || "?").trim().charAt(0).toUpperCase();
  const [c1, c2] = AVATAR_COLORS[letter.charCodeAt(0) % AVATAR_COLORS.length];
  return { letter, gradient: `linear-gradient(135deg, ${c1}, ${c2})` };
}

const MENU = [
  { id: "home", label: "خانه", sub: "صفحه اصلی", Icon: Home, route: "/", neon: "#c77dff" },
  { id: "tv", label: "تلویزیون زنده", sub: "بیش از ۱۲۰۰ کانال", Icon: Tv, route: "/Home", neon: "#00e5ff" },
  { id: "series", label: "سریال‌ها", sub: "بیش از ۱۲۰۰ سریال", Icon: Clapperboard, route: "/Media", neon: "#bc13fe" },
  { id: "movies", label: "فیلم", sub: "بیش از ۸۵۰۰ فیلم", Icon: Film, route: "/Media", neon: "#4a6cf7" },
  { id: "animation", label: "انیمیشن", sub: "بیش از ۲۵۰۰ انیمیشن", Icon: MonitorPlay, route: "/Media", neon: "#d500f9" },
  { id: "popular", label: "محبوب‌ترین‌ها", sub: "پیشنهاد برترین محتوا", Icon: Star, route: "/Favorites", neon: "#ff9800" },
];

const QUALITIES = ["HD", "Full HD", "4K", "Auto"];

export default function SideNavMenu({ onBack }) {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const isTV = useIsTV();
  const [focusKey, setFocusKey] = useState("home");
  const itemRefs = useRef({});
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [quality, setQuality] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("ayeneh_quality")) || "Full HD");

  // Profile dropdown
  const [profileOpen, setProfileOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const profileRef = useRef(null);

  useEffect(() => {
    const onOn = () => setOnline(true);
    const onOff = () => setOnline(false);
    window.addEventListener("online", onOn);
    window.addEventListener("offline", onOff);
    const onDoc = (e) => { if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("touchstart", onDoc);
    return () => {
      window.removeEventListener("online", onOn);
      window.removeEventListener("offline", onOff);
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("touchstart", onDoc);
    };
  }, []);

  const cycleQuality = () => {
    const next = QUALITIES[(QUALITIES.indexOf(quality) + 1) % QUALITIES.length];
    setQuality(next);
    try { localStorage.setItem("ayeneh_quality", next); } catch {}
  };

  const handleDelete = async () => {
    if (!window.confirm("آیا مطمئن هستید؟ حساب شما برای همیشه حذف می‌شود و قابل بازگشت نیست.")) return;
    setDeleting(true);
    try {
      await base44.functions.invoke("deleteAccount", {});
      logout(false);
      base44.auth.logout(window.location.origin);
    } catch (e) {
      window.alert("حذف حساب ناموفق بود: " + (e?.message || "خطا"));
    } finally {
      setDeleting(false);
    }
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.defaultPrevented) return; // let useTVRemote handle if it already did
      if (e.key === "ArrowUp") {
        e.preventDefault();
        const n = Math.max(0, MENU.findIndex(m => m.id === focusKey) - 1);
        setFocusKey(MENU[n].id);
        itemRefs.current[MENU[n].id]?.focus();
      }
      else if (e.key === "ArrowDown") {
        e.preventDefault();
        const n = Math.min(MENU.length - 1, MENU.findIndex(m => m.id === focusKey) + 1);
        setFocusKey(MENU[n].id);
        itemRefs.current[MENU[n].id]?.focus();
      }
      else if (["ArrowLeft", "ArrowRight"].includes(e.key)) { e.preventDefault(); }
      else if (["Enter", "Return", " ", "XF86OK", "Accept"].includes(e.key)) {
        e.preventDefault();
        const item = MENU.find(m => m.id === focusKey);
        if (item) navigate(item.route);
      } else if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault(); onBack && onBack();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [focusKey, navigate, onBack]);

  // Focus the DOM element when focusKey changes — ensures TV remote D-pad
  // moves actual DOM focus (not just visual state) so spatial nav stays in sync.
  useEffect(() => {
    const el = itemRefs.current[focusKey];
    if (el) {
      el.focus();
      el.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }, [focusKey]);

  const av = user ? avatarStyle(user.full_name || user.email) : null;

  return (
    <div className="absolute top-3 bottom-3 right-3 z-30 flex" style={{ direction: "rtl" }}>
      <div className="rounded-3xl p-3 w-64 max-w-[80vw] h-full flex flex-col"
        style={{
          background: "linear-gradient(180deg, rgba(22,18,32,0.92), rgba(15,12,22,0.94))",
          border: "1px solid rgba(255,255,255,0.09)",
          backdropFilter: "blur(16px)",
          boxShadow: "0 24px 70px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06)",
        }}>
        {/* Top accent */}
        <div className="h-1 rounded-full mb-3 flex-shrink-0" style={{ background: "linear-gradient(90deg, #7b2cbf, #00d4ff, #c77dff)", boxShadow: "0 0 12px rgba(0,212,255,0.45)" }} />

        {/* Profile header */}
        {av && (
          <div ref={profileRef} className="relative flex-shrink-0 mb-3">
            <button onClick={() => setProfileOpen(o => !o)} data-remote
              className="w-full flex items-center gap-2.5 p-2 rounded-2xl transition-all active:scale-[0.97]"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <div className="relative flex-shrink-0">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ background: av.gradient, boxShadow: "0 0 14px rgba(168,85,247,0.4)" }}>{av.letter}</div>
                <Crown className="absolute -top-1.5 -right-1 w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="leading-tight flex-1 min-w-0 text-right">
                <p className="text-white text-xs font-bold truncate">{user.full_name || "کاربر"}</p>
                <p className="text-amber-300/80 text-[10px] flex items-center gap-1 justify-end"><Sparkles className="w-2.5 h-2.5" /> اشتراک ویژه</p>
              </div>
              <ChevronDown className={`w-4 h-4 text-white/50 transition-transform ${profileOpen ? "rotate-180" : ""}`} />
            </button>
            {profileOpen && (
              <div className="absolute top-full mt-2 right-0 left-0 rounded-2xl overflow-hidden z-50"
                style={{ background: "rgba(20,14,30,0.97)", border: "1px solid rgba(168,85,247,0.3)", backdropFilter: "blur(20px)", boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
                <div className="flex items-center gap-2 px-3 py-2.5" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                  <Shield className="w-3.5 h-3.5 text-purple-300/70" />
                  <span className="text-white/60 text-xs">{user.role === "admin" ? "مدیر" : "کاربر"}</span>
                </div>
                <div className="p-2">
                  <button onClick={() => logout()} data-remote className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-white/80 text-sm transition-colors hover:bg-white/5">
                    <LogOut className="w-4 h-4 text-white/60" /> خروج از حساب
                  </button>
                  <button onClick={handleDelete} disabled={deleting} data-remote className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-red-300 text-sm transition-colors hover:bg-red-500/10 disabled:opacity-50">
                    <Trash2 className="w-4 h-4 text-red-400" /> {deleting ? "در حال حذف..." : "حذف حساب"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Nav items */}
        <div className="flex flex-col gap-1.5 flex-1 min-h-0 overflow-y-auto justify-evenly" style={{ scrollbarWidth: "none" }}>
          {MENU.map((item) => {
            const isFocused = focusKey === item.id;
            const Icon = item.Icon;
            return (
              <button key={item.id}
                ref={el => { itemRefs.current[item.id] = el; }}
                data-remote
                onClick={() => { setFocusKey(item.id); navigate(item.route); }}
                onMouseEnter={() => setFocusKey(item.id)}
                onFocus={() => setFocusKey(item.id)}
                className="tv-focusable group relative flex items-center gap-2.5 rounded-2xl px-2.5 py-2.5 transition-all text-right overflow-hidden active:scale-[0.97]"
                style={{
                  background: isFocused ? `linear-gradient(90deg, ${item.neon}22, rgba(255,255,255,0.02) 75%)` : "rgba(255,255,255,0.03)",
                  border: isFocused ? `1.5px solid ${item.neon}` : "1px solid rgba(255,255,255,0.06)",
                  boxShadow: isFocused ? `0 0 24px ${item.neon}66, inset 0 0 14px ${item.neon}22` : "none",
                }}>
                <div className="rounded-xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110"
                  style={{ width: 38, height: 38, background: `linear-gradient(135deg, ${item.neon}, ${item.neon}aa)`, boxShadow: `0 0 14px ${item.neon}80` }}>
                  <Icon className="w-5 h-5 text-white" style={{ filter: "drop-shadow(0 0 4px rgba(255,255,255,0.45))" }} />
                </div>
                <div className="flex-1 min-w-0 leading-tight">
                  <p className="text-white font-bold text-sm truncate" style={{ fontFamily: "Vazirmatn, sans-serif" }}>{item.label}</p>
                  <p className="text-white/45 text-[10px] truncate" style={{ fontFamily: "Vazirmatn, sans-serif" }}>{item.sub}</p>
                </div>
                {isFocused && <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: item.neon, boxShadow: `0 0 8px ${item.neon}` }} />}
              </button>
            );
          })}
        </div>

        {/* Footer status — server + settings + quality (hidden on TV — "دیگر گزینه‌ها") */}
        {!isTV && (
        <div className="flex items-stretch rounded-2xl flex-shrink-0 mt-3 overflow-hidden"
          style={{ border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.03)" }}>
          <div className="flex-1 flex flex-col gap-1 px-2 py-2 min-w-0">
            <span className="text-white/40 text-[9px]">وضعیت سرور</span>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: online ? "#00e676" : "#ff5252", boxShadow: `0 0 8px ${online ? "#00e676" : "#ff5252"}` }} />
              <span style={{ color: online ? "#00e676" : "#ff5252", fontSize: 11, fontWeight: 700 }}>{online ? "آنلاین" : "آفلاین"}</span>
            </div>
          </div>
          <div className="w-px" style={{ background: "rgba(255,255,255,0.1)" }} />
          <button onClick={() => navigate("/Settings")} data-remote className="flex-1 flex flex-col gap-1 px-2 py-2 text-right active:scale-95 transition-transform min-w-0">
            <span className="text-white/40 text-[9px]">تنظیمات</span>
            <div className="flex items-center gap-1">
              <Settings className="w-3 h-3 text-cyan-400 flex-shrink-0" />
              <span style={{ color: "#5ad8ff", fontSize: 11, fontWeight: 700 }}>تنظیمات</span>
            </div>
          </button>
          <div className="w-px" style={{ background: "rgba(255,255,255,0.1)" }} />
          <button onClick={cycleQuality} data-remote className="flex-1 flex flex-col gap-1 px-2 py-2 text-right active:scale-95 transition-transform min-w-0">
            <span className="text-white/40 text-[9px]">کیفیت پخش</span>
            <div className="flex items-center gap-1">
              <span className="px-1 py-0.5 rounded text-[8px] font-black text-black flex-shrink-0" style={{ background: "#ffc107" }}>HD</span>
              <span style={{ color: "#ffc107", fontSize: 10, fontWeight: 700 }} className="truncate">{quality}</span>
              <ChevronDown className="w-3 h-3 text-white/40 flex-shrink-0" />
            </div>
          </button>
        </div>
        )}
      </div>
    </div>
  );
}