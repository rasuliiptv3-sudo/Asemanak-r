import { X, LogOut } from "lucide-react";

// Exit confirmation dialog — shown when the user presses the back/exit key on
// the main menu (Android TV, Android, iPhone, web). Mirrors the standard
// "Exit / No" prompt found in most TV & mobile apps.
export default function ExitConfirmModal({ onCancel }) {
  const handleExit = () => {
    try { window.close(); } catch {}
    // Fallback for browsers that ignore window.close() (web)
    setTimeout(() => {
      try { window.location.href = "about:blank"; } catch {}
    }, 120);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center" onClick={onCancel}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />
      <div className="relative z-10 w-[330px] max-w-[90vw] rounded-2xl overflow-hidden text-center"
        style={{ background: "rgba(13,12,28,0.97)", border: "1px solid rgba(168,85,247,0.4)", boxShadow: "0 24px 70px rgba(0,0,0,0.7)" }}
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3"
          style={{ borderBottom: "1px solid rgba(255,255,255,0.08)", background: "linear-gradient(90deg, rgba(168,85,247,0.25), rgba(34,211,238,0.15))" }}>
          <p className="text-white font-bold text-sm" style={{ fontFamily: "Vazirmatn, sans-serif" }}>خروج از برنامه</p>
          <button onClick={onCancel} className="text-white/50 hover:text-white"><X className="w-4 h-4" /></button>
        </div>
        <div className="px-5 py-6 flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{ background: "rgba(239,68,68,0.15)", border: "1.5px solid rgba(239,68,68,0.5)", boxShadow: "0 0 26px rgba(239,68,68,0.4)" }}>
            <LogOut className="w-8 h-8 text-red-400" />
          </div>
          <p className="text-white/85 text-sm" style={{ fontFamily: "Vazirmatn, sans-serif" }}>آیا می‌خواهید از برنامه خارج شوید؟</p>
          <div className="flex gap-3 w-full mt-2">
            <button onClick={handleExit}
              className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:scale-[1.03]"
              style={{ background: "linear-gradient(135deg, #ef4444, #b91c1c)", boxShadow: "0 6px 18px rgba(239,68,68,0.35)", fontFamily: "Vazirmatn, sans-serif" }}>
              خروج
            </button>
            <button onClick={onCancel}
              className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:scale-[1.03]"
              style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.15)", fontFamily: "Vazirmatn, sans-serif" }}>
              خیر
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}