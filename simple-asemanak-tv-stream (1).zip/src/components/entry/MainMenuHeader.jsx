import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Wifi, SignalHigh, Calendar, Sun, CloudSun, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog } from "lucide-react";
import ProfileBadge from "@/components/ProfileBadge";
import StatusModal from "@/components/entry/StatusModal";
import { getSelectedCity } from "@/lib/cities";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/266732b00_IMG_8638.png";

const WEATHER_MAP = {
  0: { Icon: Sun, fa: "صاف" },
  1: { Icon: CloudSun, fa: "کمی ابری" },
  2: { Icon: CloudSun, fa: "نیمه ابری" },
  3: { Icon: Cloud, fa: "ابری" },
  45: { Icon: CloudFog, fa: "مه‌آلود" },
  48: { Icon: CloudFog, fa: "مه‌آلود" },
  51: { Icon: CloudRain, fa: "نم‌نم" },
  53: { Icon: CloudRain, fa: "باران سبک" },
  55: { Icon: CloudRain, fa: "باران" },
  61: { Icon: CloudRain, fa: "باران" },
  63: { Icon: CloudRain, fa: "باران" },
  65: { Icon: CloudRain, fa: "باران شدید" },
  71: { Icon: CloudSnow, fa: "برف سبک" },
  73: { Icon: CloudSnow, fa: "برف" },
  75: { Icon: CloudSnow, fa: "برف شدید" },
  80: { Icon: CloudRain, fa: "رگبار" },
  81: { Icon: CloudRain, fa: "رگبار" },
  82: { Icon: CloudRain, fa: "رگبار شدید" },
  95: { Icon: CloudLightning, fa: "رعد و برق" },
  96: { Icon: CloudLightning, fa: "رعد و برق" },
  99: { Icon: CloudLightning, fa: "رعد و برق شدید" },
};

function useWeather() {
  const [weather, setWeather] = useState(null);
  const [city, setCity] = useState(getSelectedCity());

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const cache = JSON.parse(localStorage.getItem("ayeneh_weather_cache") || "null");
        if (cache && cache.id === city.id && Date.now() - cache.t < 30 * 60 * 1000) { setWeather(cache.data); return; }
        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.long}&current=temperature_2m,weather_code&timezone=${city.tz}`
        );
        const d = await res.json();
        if (cancelled) return;
        const data = { temp: Math.round(d.current?.temperature_2m), code: d.current?.weather_code };
        setWeather(data);
        localStorage.setItem("ayeneh_weather_cache", JSON.stringify({ t: Date.now(), id: city.id, data }));
      } catch {}
    };
    load();
    return () => { cancelled = true; };
  }, [city.id, city.lat, city.long, city.tz]);

  useEffect(() => {
    const handler = () => setCity(getSelectedCity());
    window.addEventListener("ayeneh-city-changed", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("ayeneh-city-changed", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);

  return { weather, city };
}

export default function MainMenuHeader() {
  const { weather, city } = useWeather();
  const [now, setNow] = useState(new Date());
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [conn, setConn] = useState(typeof navigator !== "undefined" ? (navigator.connection || null) : null);
  // Router-driven overlay: StatusModal opens via ?status=1 so the iOS/Android
  // back swipe closes it instead of leaving the screen.
  const [searchParams, setSearchParams] = useSearchParams();
  const showStatus = searchParams.get("status") === "1";
  const openStatus = () => setSearchParams((prev) => { const p = new URLSearchParams(prev); p.set("status", "1"); return p; });
  const closeStatus = () => setSearchParams((prev) => { const p = new URLSearchParams(prev); p.delete("status"); return p; }, { replace: true });

  useEffect(() => {
    const tick = () => setNow(new Date());
    const iv = setInterval(tick, 30000);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    const updateConn = () => setConn(navigator.connection || null);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    navigator.connection?.addEventListener?.("change", updateConn);
    updateConn();
    return () => {
      clearInterval(iv);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      navigator.connection?.removeEventListener?.("change", updateConn);
    };
  }, []);

  const W = (weather && WEATHER_MAP[weather.code]) || { Icon: Cloud, fa: "—" };
  const WeatherIcon = W.Icon;
  const faDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now);
  const enDate = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(now);
  const signal = conn?.downlink ? Math.min(100, Math.round((conn.downlink / 10) * 100)) : 92;

  return (
    <>
      <div className="relative z-30 flex items-start justify-between pl-[calc(1.25rem+env(safe-area-inset-left))] pr-[calc(1.25rem+env(safe-area-inset-right))] pt-[calc(1rem+env(safe-area-inset-top))] gap-4 flex-shrink-0">
        {/* Left — status + weather + date (auto-updates per selected city) */}
        <button onClick={openStatus}
          className="flex flex-col gap-2 text-right rounded-2xl px-3 py-2 -mx-3 -my-2 hover:bg-white/5 transition-colors cursor-pointer"
          style={{ direction: "rtl" }}>
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-full overflow-hidden flex-shrink-0"
              style={{ boxShadow: "0 0 14px rgba(123,44,191,0.5)", border: "1.5px solid rgba(123,44,191,0.4)" }}>
              <img src={LOGO_URL} alt="Asemanak" className="w-full h-full object-cover" draggable={false} />
            </div>
            <div className="leading-tight">
              <p className="text-white font-bold text-sm tracking-wide">ASEMANAK TV</p>
              <p className="text-purple-300/60 text-[10px]">نسخه 2.1.0</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <Wifi className="w-3.5 h-3.5" style={{ color: "#4da6ff" }} />
            <span className="text-white/55">وضعیت اینترنت</span>
            <span className="font-bold" style={{ color: online ? "#00ff00" : "#ff4d4d" }}>{online ? "متصل" : "قطع"}</span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <SignalHigh className="w-3.5 h-3.5" style={{ color: "#4da6ff" }} />
            <span className="text-white/55">قدرت سیگنال</span>
            <span className="font-bold" style={{ color: online ? "#00ff00" : "#ff4d4d" }}>{online ? `${signal}%` : "—"}</span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <WeatherIcon className="w-3.5 h-3.5 text-amber-300" />
            <span className="text-white/55">آب و هوا</span>
            <span className="text-white font-bold">{weather ? `${weather.temp}°C` : "—"}</span>
            <span className="text-white/45">{city.nameFa} | {W.fa}</span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <Calendar className="w-3.5 h-3.5 text-purple-300/70" />
            <span className="text-white/55">تاریخ</span>
            <span className="text-white/75">{faDate}</span>
            <span className="text-white/35 hidden lg:inline">| {enDate}</span>
          </div>
        </button>

        {/* User profile removed from top bar — sidebar handles navigation */}
      </div>

      <StatusModal open={showStatus} onClose={closeStatus} now={now} />
    </>
  );
}