import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Home, Tv, Clapperboard, Star, Search, Settings, Crown, Youtube, Wifi, Clock } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { useIsTV } from "@/lib/useIsTV";
import DynamicBackground from "@/components/entry/DynamicBackground";
import LanguagePill from "@/components/entry/LanguagePill";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}
function toFaDigits(s) { return String(s).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]); }

function TeddyBear({ className, style }) {
  return (
    <svg viewBox="0 0 64 64" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="16" r="7" /><circle cx="46" cy="16" r="7" />
      <circle cx="32" cy="30" r="16" /><ellipse cx="32" cy="38" rx="9" ry="7" />
      <circle cx="26" cy="28" r="2" fill="currentColor" stroke="none" /><circle cx="38" cy="28" r="2" fill="currentColor" stroke="none" />
      <ellipse cx="32" cy="35" rx="2.5" ry="2" fill="currentColor" stroke="none" />
    </svg>
  );
}

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

const SIDEBAR_ITEMS = [
  { id: "home",      fa: "خانه",          en: "Home",      Icon: Home,         route: "/",                neon: "#5b8def" },
  { id: "tv",        fa: "تلویزیون زنده",  en: "Live TV",   Icon: Tv,           route: "/Home",            neon: "#00d2ff" },
  { id: "series",    fa: "سریال‌ها",      en: "Series",    Icon: Clapperboard, route: "/Media?cat=series", neon: "#9d4edd" },
  { id: "animation", fa: "انیمیشن",       en: "Animation", Icon: TeddyBear,    route: "/Media?cat=animation", neon: "#ff007f" },
  { id: "youtube",   fa: "یوتیوب",        en: "YouTube",   Icon: Youtube,      route: "youtube",            neon: "#ff0000" },
  { id: "favorites", fa: "محبوب‌ترین‌ها",  en: "Favorites", Icon: Star,         route: "/Favorites",       neon: "#ff8c00" },
  { id: "search",    fa: "جستجو",         en: "Search",    Icon: Search,       route: "/Search",           neon: "#5ad8ff" },
  { id: "settings",  fa: "تنظیمات",       en: "Settings",  Icon: Settings,     route: "/Settings",         neon: "#a855f7" },
];

const AVATAR_COLORS = [["#ea4335","#c5221f"],["#4285f4","#1a73e8"],["#34a853","#188038"],["#fbbc04","#f9a825"],["#a142f4","#8430ce"],["#ff6d01","#e8590c"]];

// ── Server online status badge ──
function ServerStatusBadge({ isFa }) {
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [signal, setSignal] = useState(null);

  useEffect(() => {
    const update = () => {
      setOnline(navigator.onLine);
      const conn = navigator.connection;
      if (conn?.downlink) setSignal(Math.min(100, Math.round((conn.downlink / 10) * 100)));
      else setSignal(null);
    };
    update();
    const iv = setInterval(update, 5000);
    const on = () => { setOnline(true); update(); };
    const off = () => { setOnline(false); setSignal(null); };
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      clearInterval(iv);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  const status = !online ? "offline" : (signal !== null && signal < 30) ? "poor" : "online";
  const color = status === "offline" ? "#f87171" : status === "poor" ? "#fbbf24" : "#34d399";
  const label = status === "offline" ? (isFa ? "سرور: قطع" : "Server: Offline") : status === "poor" ? (isFa ? "سرور: ضعیف" : "Server: Poor") : (isFa ? "سرور: متصل" : "Server: Online");

  return (
    <div className="flex items-center gap-2 rounded-xl px-3 py-2 w-full" style={{ background: "rgba(0,0,0,0.3)", backdropFilter: "blur(10px)", border: `1px solid ${color}33` }}>
      <Wifi className="w-4 h-4 flex-shrink-0" style={{ color, filter: `drop-shadow(0 0 4px ${color}88)` }} />
      <span className="text-white text-xs font-bold flex-1">{label}</span>
      {signal !== null && online && <span className="text-white/40 text-[10px]">{signal}%</span>}
    </div>
  );
}

// ── Sidebar digital clock with AM/PM ──
function SidebarClock({ isFa }) {
  const [now, setNow] = useState(new Date());
  const [settings, setSettings] = useState(() => readSettings());

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    const sync = () => setSettings(readSettings());
    window.addEventListener("ayeneh-settings-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      clearInterval(iv);
      window.removeEventListener("ayeneh-settings-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const tz = settings.clockTimezone || "Asia/Tehran";
  const fmt = settings.clockFormat || "24";
  const hourOffset = Number(settings.clockOffset || 0);
  const minOffset = Number(settings.clockOffsetMinutes || 0);
  const secOffset = Number(settings.clockOffsetSeconds || 0);

  const adjusted = new Date(now.getTime() + (hourOffset * 3600 + minOffset * 60 + secOffset) * 1000);

  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    hour12: fmt === "12",
  }).formatToParts(adjusted);

  const hh = parts.find(p => p.type === "hour")?.value || "00";
  const mm = parts.find(p => p.type === "minute")?.value || "00";

  // Compute AM/PM
  let hourNum = parseInt(hh, 10);
  let ampm = "";
  if (fmt === "12") {
    const dp = parts.find(p => p.type === "dayPeriod")?.value || "";
    const isPM = dp.toLowerCase().includes("pm");
    ampm = isFa ? (isPM ? "ب.ظ" : "ق.ظ") : (isPM ? "PM" : "AM");
  } else {
    const isPM = hourNum >= 12;
    ampm = isFa ? (isPM ? "ب.ظ" : "ق.ظ") : (isPM ? "PM" : "AM");
  }

  let timeStr = `${hh}:${mm} ${ampm}`;
  if (isFa) timeStr = toFaDigits(timeStr);

  return (
    <div className="flex flex-col items-center gap-1 rounded-2xl px-4 py-4 w-full" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(168,85,247,0.2)" }}>
      <div className="flex items-center gap-2">
        <Clock className="w-4 h-4 text-purple-400/60" />
        <div className="text-white font-black tracking-wider" style={{
          fontSize: "clamp(22px, 3vw, 34px)",
          textShadow: "0 0 16px rgba(168,85,247,0.7), 0 0 32px rgba(168,85,247,0.4)",
          fontFamily: "Inter, monospace", lineHeight: 1, direction: "ltr",
        }}>{timeStr}</div>
      </div>
    </div>
  );
}

export default function TVEntryLayout() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isTV = useIsTV();
  const [activeNav, setActiveNav] = useState("home");
  const [isFa, setIsFa] = useState(true);
  const navRefs = useRef({});

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    syncLang();
    window.addEventListener("storage", syncLang);
    window.addEventListener("ayeneh-settings-changed", syncLang);
    return () => {
      window.removeEventListener("storage", syncLang);
      window.removeEventListener("ayeneh-settings-changed", syncLang);
    };
  }, []);

  useEffect(() => {
    const first = SIDEBAR_ITEMS[0];
    if (first) {
      const t = setTimeout(() => navRefs.current[first.id]?.focus(), 400);
      return () => clearTimeout(t);
    }
  }, []);

  const userName = user?.full_name || user?.email?.split("@")[0] || (isFa ? "کاربر" : "User");
  const userLetter = (userName || "?").trim().charAt(0).toUpperCase();
  const [c1, c2] = AVATAR_COLORS[userLetter.charCodeAt(0) % AVATAR_COLORS.length];

  return (
    <div className="fixed inset-0 flex overflow-hidden" style={{ background: "#0a0a0c", fontFamily: "Vazirmatn, sans-serif", direction: "ltr" }}>
      <style>{`
        .tv-sidebar-item{transition:all .3s cubic-bezier(0.34,1.56,0.64,1);position:relative;overflow:hidden;}
        .tv-sidebar-item::after{content:"";position:absolute;inset:0;background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,0.15) 50%,transparent 65%);opacity:0;pointer-events:none;transform:translateX(-130%);}
        .tv-sidebar-item:focus::after,.tv-sidebar-item:hover::after{animation:tvShine 1.2s ease-out;}
        @keyframes tvShine{0%{transform:translateX(-130%);opacity:0}30%{opacity:1}100%{transform:translateX(130%);opacity:0}}
        .tv-sidebar-item:focus,.tv-sidebar-item:hover{transform:translateX(4px) scale(1.04);}
        @keyframes tvGlowPulse{
          0%,100%{box-shadow:0 0 24px var(--n-g1),0 0 48px var(--n-g2),inset 0 0 12px var(--n-g3)}
          50%{box-shadow:0 0 40px var(--n-g1b),0 0 80px var(--n-g2b),inset 0 0 22px var(--n-g3b)}
        }
        .tv-sidebar-active{animation:tvGlowPulse 2.5s ease-in-out infinite;}
        @keyframes tvIconFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}
        .tv-sidebar-active .tv-icon-wrap{animation:tvIconFloat 2s ease-in-out infinite;}
      `}</style>

      {/* ── Dynamic background — very light dim ── */}
      <DynamicBackground dim={0.02} />

      {/* ── Left Sidebar — glassmorphism — responsive width for TV/mobile ── */}
      <div className="relative z-10 flex-shrink-0 flex flex-col py-4 px-3" style={{ width: "clamp(220px, 16vw, 300px)", background: "rgba(10,10,16,0.38)", backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)", borderRight: `1px solid rgba(255,255,255,0.08)`, direction: "rtl" }}>
        {/* Logo + Brand */}
        <div className="flex items-center gap-3 mb-6 px-2" style={{ marginBottom: "clamp(16px, 3vh, 32px)" }}>
          <div className="rounded-full flex items-center justify-center flex-shrink-0" style={{ width: "clamp(44px, 5vw, 56px)", height: "clamp(44px, 5vw, 56px)", background: "linear-gradient(135deg, #1c2a5c, #0f1636)", border: "2px solid #5b8def", boxShadow: "0 0 20px rgba(91,141,239,0.4)" }}>
            <img src={LOGO_URL} alt="Asemanak TV" className="w-full h-full object-cover rounded-full" />
          </div>
          <div className="leading-tight">
            <p className="text-white font-black" style={{ fontSize: "clamp(14px, 1.4vw, 18px)" }}>Asemanak TV</p>
            <p className="text-white/55" style={{ fontSize: "clamp(10px, 0.9vw, 12px)" }}>{isFa ? "پلتفرم سرگرمی" : "Entertainment"}</p>
          </div>
        </div>

        {/* Nav items — responsive gap and padding for TV/mobile */}
        <div className="flex flex-col w-full flex-1" style={{ gap: "clamp(6px, 1vh, 12px)" }}>
          {SIDEBAR_ITEMS.map((item) => {
            const isActive = activeNav === item.id;
            const Icon = item.Icon;
            return (
              <button
                key={item.id}
                ref={el => { navRefs.current[item.id] = el; }}
                data-remote
                data-tvnav="1"
                onClick={() => { setActiveNav(item.id); if (item.route === "youtube") window.open("https://www.youtube.com", "_blank"); else navigate(item.route); }}
                onMouseEnter={() => setActiveNav(item.id)}
                onFocus={() => setActiveNav(item.id)}
                className={`tv-sidebar-item flex items-center rounded-2xl text-right w-full ${isActive ? "tv-sidebar-active" : ""}`}
                style={{
                  gap: "clamp(10px, 1.2vw, 16px)",
                  padding: "clamp(10px, 1.2vh, 16px) clamp(12px, 1.2vw, 20px)",
                  "--n-g1": item.neon + "66",
                  "--n-g2": item.neon + "33",
                  "--n-g3": item.neon + "20",
                  "--n-g1b": item.neon + "99",
                  "--n-g2b": item.neon + "55",
                  "--n-g3b": item.neon + "33",
                  background: isActive ? `linear-gradient(135deg, ${item.neon}55, ${item.neon}15)` : "rgba(255,255,255,0.06)",
                  border: isActive ? `2px solid ${item.neon}` : "1px solid rgba(255,255,255,0.12)",
                }}
              >
                <span className="tv-icon-wrap flex-shrink-0" style={{ filter: isActive ? `drop-shadow(0 0 10px ${item.neon})` : "none" }}>
                  <Icon style={{ width: "clamp(20px, 2vw, 28px)", height: "clamp(20px, 2vw, 28px)", color: isActive ? item.neon : "rgba(255,255,255,0.7)" }} />
                </span>
                <span className="font-bold truncate" style={{ fontSize: "clamp(13px, 1.3vw, 17px)", color: isActive ? "#fff" : "rgba(255,255,255,0.8)", textShadow: isActive ? `0 0 12px ${item.neon}aa` : "0 1px 4px rgba(0,0,0,0.9)" }}>{isFa ? item.fa : item.en}</span>
              </button>
            );
          })}
        </div>

        {/* Bottom: Digital clock (top) + Server status (below clock) */}
        <div className="flex flex-col gap-2 mt-4">
          <SidebarClock isFa={isFa} />
          <ServerStatusBadge isFa={isFa} />
        </div>
      </div>

      {/* ── Main content area ── */}
      <div className="relative z-10 flex-1 flex flex-col min-w-0">
        {/* Header — profile display only */}
        <div className="flex items-center justify-end px-8 py-5 flex-shrink-0">
          <div
            className="flex items-center gap-3 rounded-2xl px-4 py-2.5"
            style={{ background: "rgba(45,36,56,0.5)", backdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,0.12)" }}
          >
            <div className="text-right leading-tight">
              <p className="text-white text-sm font-bold">{userName}</p>
              <p className="text-amber-300/80 text-xs flex items-center gap-1 justify-end"><Crown className="w-3 h-3" /> {isFa ? "اشتراک ویژه" : "Premium"}</p>
            </div>
            <div className="relative">
              <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-base" style={{ background: `linear-gradient(135deg, ${c1}, ${c2})`, boxShadow: "0 0 14px rgba(168,85,247,0.4)" }}>{userLetter}</div>
              <Crown className="absolute -top-1.5 -right-1.5 w-4 h-4 text-amber-400" />
            </div>
          </div>
        </div>

        {/* Empty content area — background shows through */}
        <div className="flex-1 relative overflow-hidden" />
      </div>

      {/* Language selector — bottom right, TV remote accessible */}
      <LanguagePill />
    </div>
  );
}