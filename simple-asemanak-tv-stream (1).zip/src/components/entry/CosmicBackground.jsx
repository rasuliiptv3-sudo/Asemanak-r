import { useMemo } from "react";

// Space background with enhanced animated stars, shooting stars, and nebula glow
export default function CosmicBackground() {
  const stars = useMemo(() => Array.from({ length: 50 }, () => ({
    x: Math.random() * 100, y: Math.random() * 100,
    s: Math.random() * 2.5 + 0.5,
    d: Math.random() * 5, dur: 2 + Math.random() * 6,
    o: Math.random() * 0.5 + 0.2,
    color: Math.random() > 0.7 ? "#a855f7" : Math.random() > 0.5 ? "#00d4ff" : "#ffffff",
  })), []);

  const bigStars = useMemo(() => Array.from({ length: 8 }, () => ({
    x: Math.random() * 100, y: Math.random() * 100,
    s: Math.random() * 2 + 2,
    d: Math.random() * 3, dur: 3 + Math.random() * 4,
    color: Math.random() > 0.5 ? "#00d4ff" : "#a855f7",
  })), []);

  // Shooting stars — cross the screen periodically
  const shootingStars = useMemo(() => Array.from({ length: 3 }, (_, i) => ({
    delay: i * 4 + Math.random() * 3,
    duration: 2 + Math.random() * 2,
    startX: Math.random() * 60,
    startY: Math.random() * 40,
    angle: 30 + Math.random() * 20,
  })), []);

  // Drifting particles — slow floating dust
  const dust = useMemo(() => Array.from({ length: 15 }, () => ({
    x: Math.random() * 100, y: Math.random() * 100,
    s: Math.random() * 3 + 1,
    dx: (Math.random() - 0.5) * 30,
    dy: (Math.random() - 0.5) * 30,
    dur: 15 + Math.random() * 20,
    delay: Math.random() * 10,
  })), []);

  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: "#08000f" }}>
      <img
        src="https://media.base44.com/images/public/69bb192550659e77af7bd3fe/f4f72a9e9_1783259768224.png"
        alt=""
        draggable={false}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ userSelect: "none", pointerEvents: "none", imageRendering: "high-quality", filter: "saturate(1.25) contrast(1.1) brightness(0.85)" }}
      />

      {/* Nebula glow overlays for depth */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse 70% 50% at 25% 15%, rgba(168,85,247,0.08) 0%, transparent 50%), radial-gradient(ellipse 60% 40% at 75% 85%, rgba(0,212,255,0.06) 0%, transparent 50%), radial-gradient(ellipse 50% 30% at 50% 50%, rgba(123,44,191,0.04) 0%, transparent 60%)",
      }} />

      {/* Drifting dust particles */}
      <div className="absolute inset-0" style={{ pointerEvents: "none" }}>
        {dust.map((p, i) => (
          <div key={`d${i}`} className="absolute rounded-full" style={{
            left: `${p.x}%`, top: `${p.y}%`,
            width: p.s, height: p.s,
            background: "rgba(255,255,255,0.15)",
            boxShadow: `0 0 ${p.s * 2}px rgba(168,85,247,0.3)`,
            animation: `cbDrift ${p.dur}s ease-in-out ${p.delay}s infinite alternate`,
            '--dx': `${p.dx}px`, '--dy': `${p.dy}px`,
          }} />
        ))}
      </div>

      {/* Twinkling stars */}
      <div className="absolute" style={{ inset: "0", pointerEvents: "none" }}>
        {stars.map((st, i) => (
          <div key={i} className="absolute rounded-full" style={{
            left: `${st.x}%`, top: `${st.y}%`, width: st.s, height: st.s,
            background: st.color, opacity: st.o,
            boxShadow: `0 0 ${st.s * 3}px ${st.color}`,
            animation: `cbTw ${st.dur}s ease-in-out ${st.d}s infinite alternate`,
          }} />
        ))}
        {bigStars.map((st, i) => (
          <div key={`b${i}`} className="absolute rounded-full" style={{
            left: `${st.x}%`, top: `${st.y}%`, width: st.s, height: st.s,
            background: "#fff",
            boxShadow: `0 0 ${st.s * 5}px ${st.color}, 0 0 ${st.s * 12}px ${st.color}88`,
            animation: `cbTw ${st.dur}s ease-in-out ${st.d}s infinite alternate, cbGlow 3s ease-in-out ${st.d}s infinite`,
          }} />
        ))}
      </div>

      {/* Shooting stars */}
      <div className="absolute inset-0" style={{ pointerEvents: "none", overflow: "hidden" }}>
        {shootingStars.map((ss, i) => (
          <div key={`s${i}`} className="absolute" style={{
            left: `${ss.startX}%`, top: `${ss.startY}%`,
            width: 2, height: 2,
            background: "#fff",
            borderRadius: "50%",
            boxShadow: "0 0 6px #fff, 0 0 12px rgba(0,212,255,0.6)",
            animation: `cbShoot ${ss.duration}s ease-in ${ss.delay}s infinite`,
            transform: `rotate(${ss.angle}deg)`,
          }}>
            <div style={{
              position: "absolute", right: 0, top: 0,
              width: 80, height: 1,
              background: "linear-gradient(90deg, transparent, rgba(0,212,255,0.6), #fff)",
              transformOrigin: "right center",
            }} />
          </div>
        ))}
      </div>

      {/* Vignette — lighter for more transparency */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse at center, transparent 35%, rgba(8,0,15,0.2) 100%)",
      }} />

      <style>{`
        @keyframes cbTw { from { opacity: 0.1; } to { opacity: 0.8; } }
        @keyframes cbGlow { 0%,100% { transform: scale(1); } 50% { transform: scale(1.4); } }
        @keyframes cbDrift {
          from { transform: translate(0, 0); }
          to { transform: translate(var(--dx, 20px), var(--dy, -20px)); }
        }
        @keyframes cbShoot {
          0% { opacity: 0; transform: translate(0, 0) rotate(var(--angle, 35deg)) scale(0.5); }
          5% { opacity: 1; }
          15% { opacity: 1; }
          25% { opacity: 0; transform: translate(300px, 200px) rotate(var(--angle, 35deg)) scale(1.2); }
          100% { opacity: 0; transform: translate(300px, 200px) rotate(var(--angle, 35deg)) scale(1.2); }
        }
      `}</style>
    </div>
  );
}