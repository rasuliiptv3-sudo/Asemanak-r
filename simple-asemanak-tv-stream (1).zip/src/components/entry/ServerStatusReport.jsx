import { useState, useEffect } from "react";
import { X, Wifi, WifiOff, Activity, Globe, Clock, Signal, Server } from "lucide-react";

// Server status report modal — opened from the TopNav server indicator.
// Measures live latency to the app origin and shows connection details.
export default function ServerStatusReport({ isFa, onClose }) {
  const [online, setOnline] = useState(navigator.onLine);
  const [latency, setLatency] = useState(null);
  const [measuring, setMeasuring] = useState(true);
  const [now, setNow] = useState(new Date());
  const [conn, setConn] = useState(null);

  const tr = (f, e) => (isFa ? f : e);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    if (navigator.connection) setConn(navigator.connection.effectiveType);
    const measure = async () => {
      setMeasuring(true);
      try {
        const start = performance.now();
        await fetch(window.location.origin + "/?_ping=" + Date.now(), { cache: "no-store", mode: "no-cors" });
        setLatency(Math.round(performance.now() - start));
      } catch {
        setLatency(null);
      }
      setMeasuring(false);
    };
    measure();
    const iv = setInterval(measure, 5000);
    return () => clearInterval(iv);
  }, []);

  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  const timeStr = now.toLocaleTimeString(isFa ? "fa-IR" : "en-GB");
  const dateStr = isFa
    ? new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now)
    : new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now);

  const latencyLabel = measuring
    ? tr("در حال اندازه‌گیری...", "Measuring...")
    : latency == null ? tr("نامشخص", "N/A") : `${latency} ms`;
  const latencyColor = latency == null ? "#f87171" : latency < 150 ? "#34d399" : latency < 400 ? "#fbbf24" : "#f87171";

  const rows = [
    { icon: online ? Wifi : WifiOff, label: tr("وضعیت اتصال", "Connection"), value: online ? tr("متصل", "Online") : tr("قطع", "Offline"), color: online ? "#34d399" : "#f87171" },
    { icon: Activity, label: tr("تأخیر سرور", "Server Latency"), value: latencyLabel, color: latencyColor },
    { icon: Signal, label: tr("نوع شبکه", "Network Type"), value: conn || tr("نامشخص", "Unknown"), color: "#94a3b8" },
    { icon: Globe, label: tr("منطقه زمانی", "Timezone"), value: tz, color: "#94a3b8" },
    { icon: Clock, label: tr("زمان فعلی", "Current Time"), value: timeStr, color: "#94a3b8" },
  ];

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center" style={{ direction: isFa ? "rtl" : "ltr" }}>
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="relative w-[90vw] max-w-md rounded-2xl border border-white/15 p-5"
        style={{ background: "rgba(12,15,24,0.98)", backdropFilter: "blur(16px)" }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-cyan-400" />
            <span className="text-white font-bold text-base">{tr("گزارش وضعیت سرور", "Server Status Report")}</span>
          </div>
          <button onClick={onClose} className="text-white/50 hover:text-white p-1"><X className="w-5 h-5" /></button>
        </div>

        <div className="rounded-xl p-3 mb-4 flex items-center gap-3"
          style={{ background: online ? "rgba(52,211,153,0.10)" : "rgba(248,113,113,0.10)", border: `1px solid ${online ? "rgba(52,211,153,0.3)" : "rgba(248,113,113,0.3)"}` }}>
          <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: online ? "rgba(52,211,153,0.2)" : "rgba(248,113,113,0.2)" }}>
            {online ? <Wifi className="w-5 h-5 text-green-400" /> : <WifiOff className="w-5 h-5 text-red-400" />}
          </div>
          <div className="min-w-0">
            <p className="text-white font-bold text-sm">{online ? tr("سرور متصل است", "Server is Online") : tr("سرور قطع است", "Server is Offline")}</p>
            <p className="text-white/40 text-xs mt-0.5 truncate">{dateStr}</p>
          </div>
        </div>

        <div className="space-y-2">
          {rows.map((r, i) => {
            const Icon = r.icon;
            return (
              <div key={i} className="flex items-center gap-3 px-3 py-2.5 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>
                <Icon className="w-4 h-4 flex-shrink-0" style={{ color: r.color }} />
                <span className="text-white/60 text-xs flex-1">{r.label}</span>
                <span className="text-white text-sm font-semibold truncate">{r.value}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}