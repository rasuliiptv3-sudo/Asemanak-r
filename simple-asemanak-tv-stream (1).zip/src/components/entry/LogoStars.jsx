// Small twinkling stars placed around the "آسمانک" logo for a starry feel.
const STARS = [
  { top: "-12%", left: "6%", size: 3, delay: "0s", color: "#c77dff" },
  { top: "18%", left: "-8%", size: 2, delay: "0.6s", color: "#5ad8ff" },
  { top: "50%", left: "-14%", size: 4, delay: "1.2s", color: "#a855f7" },
  { top: "88%", left: "4%", size: 2, delay: "0.3s", color: "#ec4899" },
  { top: "-8%", right: "8%", size: 3, delay: "0.9s", color: "#5ad8ff" },
  { top: "28%", right: "-10%", size: 2, delay: "1.5s", color: "#c77dff" },
  { top: "68%", right: "-8%", size: 4, delay: "0.4s", color: "#a855f7" },
  { top: "102%", right: "10%", size: 2, delay: "1.1s", color: "#ec4899" },
  { top: "8%", left: "40%", size: 2, delay: "1.8s", color: "#5ad8ff" },
  { top: "95%", left: "46%", size: 3, delay: "0.7s", color: "#c77dff" },
];

export default function LogoStars() {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {STARS.map((s, i) => (
        <span key={i} className="absolute rounded-full"
          style={{
            top: s.top, left: s.left, right: s.right,
            width: s.size, height: s.size,
            background: s.color,
            boxShadow: `0 0 6px ${s.color}, 0 0 14px ${s.color}`,
            animation: `twinkle 2.6s ease-in-out ${s.delay} infinite`,
          }} />
      ))}
    </div>
  );
}