import { useState, useEffect } from "react";

const toFaDigits = (s) => s.replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

// Digital clock — HH:MM:SS with seconds
export default function DigitalClock() {
  const [now, setNow] = useState(new Date());
  const [tz, setTz] = useState("Asia/Tehran");
  const [fmt, setFmt] = useState("24");
  const [offset, setOffset] = useState(0);
  const [offsetMin, setOffsetMin] = useState(0);
  const [offsetSec, setOffsetSec] = useState(0);
  const [isFa, setIsFa] = useState(false);

  useEffect(() => {
    const tick = () => {
      setNow(new Date());
      const s = readSettings();
      setTz(s.clockTimezone || "Asia/Tehran");
      setFmt(s.clockFormat || "24");
      setOffset(Number(s.clockOffset) || 0);
      setOffsetMin(Number(s.clockOffsetMinutes) || 0);
      setOffsetSec(Number(s.clockOffsetSeconds) || 0);
      setIsFa(s.language === "fa");
    };
    tick();
    const iv = setInterval(tick, 1000);
    const onSettings = () => tick();
    window.addEventListener("ayeneh-settings-changed", onSettings);
    window.addEventListener("storage", onSettings);
    return () => {
      clearInterval(iv);
      window.removeEventListener("ayeneh-settings-changed", onSettings);
      window.removeEventListener("storage", onSettings);
    };
  }, []);

  const displayDate = new Date(now.getTime() + offset * 3600000 + offsetMin * 60000 + offsetSec * 1000);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz, hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: fmt === "12",
  }).formatToParts(displayDate);

  const hh = parts.find(p => p.type === "hour")?.value || "00";
  const mm = parts.find(p => p.type === "minute")?.value || "00";
  const ss = parts.find(p => p.type === "second")?.value || "00";
  const dayPeriod = parts.find(p => p.type === "dayPeriod")?.value || "";

  let timeStr = `${hh}:${mm}:${ss}`;
  if (fmt === "12" && dayPeriod) {
    const dp = isFa ? (dayPeriod.toLowerCase().includes("am") ? "ق.ظ" : "ب.ظ") : dayPeriod;
    timeStr = `${timeStr} ${dp}`;
  }
  if (isFa) timeStr = toFaDigits(timeStr);

  return (
    <div className="flex flex-col items-center gap-1 select-none" style={{ direction: "ltr" }}>
      <style>{`
        @keyframes dcGlow {
          0%,100% { text-shadow: 0 0 14px rgba(168,85,247,0.5), 0 0 28px rgba(168,85,247,0.3); }
          50% { text-shadow: 0 0 20px rgba(168,85,247,0.7), 0 0 40px rgba(0,204,255,0.4); }
        }
      `}</style>
      <div className="font-bold text-white" style={{
        fontFamily: "Vazirmatn, monospace",
        fontSize: "clamp(1.6rem,4.2vw,2.6rem)",
        letterSpacing: "0.06em",
        animation: "dcGlow 3s ease-in-out infinite",
      }}>
        {timeStr}
      </div>
      <div className="text-purple-300/40 text-[9px] tracking-widest">
        {isFa ? "ساعت" : "CLOCK"}
      </div>
    </div>
  );
}