import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Tv, Clapperboard, Film, MonitorPlay, Star } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/266732b00_IMG_8638.png";

const TILES = [
  { id: "tv", label: "تلویزیون زنده", sub: "بیش از 1200 کانال", Icon: Tv, route: "/Home", neon: "#00bfff" },
  { id: "series", label: "سریال ها", sub: "بیش از 1200 سریال", Icon: Clapperboard, route: "/Media", neon: "#9b5de5" },
  { id: "movies", label: "فیلم", sub: "بیش از 8500 فیلم", Icon: Film, route: "/Media", neon: "#7b5fff" },
  { id: "animation", label: "انیمیشن", sub: "بیش از 2500 انیمیشن", Icon: MonitorPlay, route: "/Media", neon: "#c77dff" },
  { id: "popular", label: "محبوب ترین ها", sub: "پیشنهاد برترین محتوا", Icon: Star, route: "/Favorites", neon: "#ffb703" },
];

export default function NavGrid({ onBack }) {
  const navigate = useNavigate();
  const [focusIdx, setFocusIdx] = useState(0);

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.key === "ArrowLeft") { e.preventDefault(); setFocusIdx(i => Math.max(0, i - 1)); }
      else if (e.key === "ArrowRight") { e.preventDefault(); setFocusIdx(i => Math.min(TILES.length - 1, i + 1)); }
      else if (["ArrowUp", "ArrowDown"].includes(e.key)) { e.preventDefault(); }
      else if (["Enter", "Return", " ", "XF86OK", "Accept"].includes(e.key)) { e.preventDefault(); navigate(TILES[focusIdx].route); }
      else if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) { e.preventDefault(); onBack && onBack(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [focusIdx, navigate, onBack]);

  return (
    <div className="flex flex-col items-center gap-8">
      {/* Glowing logo with orbit ring */}
      <div className="relative flex flex-col items-center">
        <div className="relative w-24 h-24">
          <div className="absolute -inset-2 rounded-full" style={{ border: "1.5px solid rgba(0,212,255,0.35)", boxShadow: "0 0 30px rgba(0,212,255,0.25)", animation: "ringSpin 18s linear infinite" }} />
          <div className="absolute inset-0 rounded-full overflow-hidden"
            style={{ boxShadow: "0 0 28px rgba(0,242,255,0.85), 0 0 60px rgba(168,85,247,0.55)", border: "2.5px solid rgba(0,242,255,0.55)" }}>
            <img src={LOGO_URL} alt="Asemanak TV" className="w-full h-full object-cover" draggable={false} />
          </div>
        </div>
        <p className="text-cyan-200/80 text-xs tracking-[0.4em] mt-4 font-bold">ASEMANAK.TV</p>
      </div>

      {/* Navigation tiles */}
      <div className="flex flex-wrap items-stretch justify-center gap-4 max-w-5xl">
        {TILES.map((t, i) => {
          const focused = focusIdx === i;
          const I = t.Icon;
          return (
            <button key={t.id}
              onClick={() => navigate(t.route)}
              onMouseEnter={() => setFocusIdx(i)}
              className="tv-focusable group relative flex flex-col items-center justify-center gap-3 rounded-3xl px-6 py-7 w-44 transition-all duration-200 active:scale-95 hover:scale-105"
              style={{
                background: focused ? `linear-gradient(180deg, ${t.neon}33, rgba(255,255,255,0.02))` : `linear-gradient(180deg, ${t.neon}14, rgba(255,255,255,0.03))`,
                border: focused ? `2px solid ${t.neon}` : `1.5px solid ${t.neon}66`,
                boxShadow: focused ? `0 0 36px ${t.neon}aa, inset 0 0 22px ${t.neon}33` : `0 0 14px ${t.neon}44`,
                transform: focused ? "translateY(-6px) scale(1.06)" : undefined,
              }}>
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110"
                style={{ background: `linear-gradient(135deg, ${t.neon}, ${t.neon}aa)`, boxShadow: `0 0 18px ${t.neon}99` }}>
                <I className="w-7 h-7 text-white" />
              </div>
              <div className="text-center leading-tight">
                <p className="text-white font-bold text-sm" style={{ fontFamily: "Vazirmatn, sans-serif" }}>{t.label}</p>
                <p className="text-white/50 text-[11px] mt-1" style={{ fontFamily: "Vazirmatn, sans-serif" }}>{t.sub}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}