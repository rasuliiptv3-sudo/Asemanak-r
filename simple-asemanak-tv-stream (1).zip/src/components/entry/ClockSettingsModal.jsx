import { useState, useEffect, useRef } from "react";
import { X, ChevronUp, ChevronDown, Clock, Globe, Plus, Minus } from "lucide-react";
import { TIMEZONES } from "@/components/DigitalClock";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

export default function ClockSettingsModal({ isFa, onClose }) {
  const [settings, setSettings] = useState(() => readSettings());
  const [tzQuery, setTzQuery] = useState("");
  const [showTzList, setShowTzList] = useState(false);
  const scrollRef = useRef(null);

  const get = (key, def) => settings[key] !== undefined ? settings[key] : def;
  const set = (key, value) => {
    setSettings(prev => {
      const updated = { ...prev, [key]: value };
      localStorage.setItem("ayeneh_settings", JSON.stringify(updated));
      window.dispatchEvent(new Event("ayeneh-settings-changed"));
      return updated;
    });
  };

  const tr = (fa, en) => isFa ? fa : en;

  const currentTz = get("clockTimezone", "Asia/Tehran");
  const currentTzLabel = TIMEZONES.find(t => t.value === currentTz)?.[isFa ? "labelFa" : "labelEn"] || currentTz;

  const hourOffset = Number(get("clockOffset", 0));
  const minOffset = Number(get("clockOffsetMinutes", 0));
  const fmt = get("clockFormat", "24");

  const filteredTz = TIMEZONES.filter(t => {
    if (!tzQuery) return true;
    const q = tzQuery.toLowerCase();
    return (t.labelEn || "").toLowerCase().includes(q) || (t.labelFa || "").includes(tzQuery) || t.value.toLowerCase().includes(q);
  });

  // Remote navigation: Enter/OK on focused data-remote element triggers click
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape" || e.key === "Backspace" || e.key === "GoBack" || e.key === "XF86Back") {
        e.preventDefault(); e.stopPropagation(); onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center" style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)" }}>
      <div className="relative w-full max-w-lg mx-4 rounded-3xl overflow-hidden flex flex-col" style={{ background: "linear-gradient(180deg, rgba(20,20,30,0.98), rgba(10,10,15,0.98))", border: "1px solid rgba(168,85,247,0.3)", boxShadow: "0 0 60px rgba(168,85,247,0.3)", maxHeight: "85vh" }}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 flex-shrink-0" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)" }}>
              <Clock className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">{tr("تنظیمات ساعت", "Clock Settings")}</h2>
              <p className="text-white/40 text-xs">{tr("منطقه زمانی و تنظیم دستی ساعت", "Timezone & manual adjustment")}</p>
            </div>
          </div>
          <button data-remote onClick={onClose} className="w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:scale-110 tv-focusable" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)" }}>
            <X className="w-4 h-4 text-white/60" />
          </button>
        </div>

        {/* Scrollable content */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Timezone selector */}
          <div>
            <label className="text-white/50 text-xs font-bold uppercase tracking-widest mb-2 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" /> {tr("منطقه زمانی", "Timezone")}
            </label>
            <button data-remote onClick={() => setShowTzList(v => !v)}
              className="tv-focusable w-full flex items-center justify-between rounded-xl px-4 py-3 text-right transition-all"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
              <span className="text-white text-sm font-medium">{currentTzLabel}</span>
              <ChevronDown className={`w-4 h-4 text-white/40 transition-transform ${showTzList ? "rotate-180" : ""}`} />
            </button>
            {showTzList && (
              <div className="mt-2 rounded-xl overflow-hidden" style={{ background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.08)" }}>
                <input data-remote value={tzQuery} onChange={e => setTzQuery(e.target.value)} placeholder={tr("جستجوی کشور...", "Search country...")}
                  className="w-full bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-white/30 outline-none border-b border-white/8" />
                <div className="max-h-48 overflow-y-auto">
                  {filteredTz.map(tz => (
                    <button key={tz.value} data-remote onClick={() => { set("clockTimezone", tz.value); setShowTzList(false); setTzQuery(""); }}
                      className={`tv-focusable w-full text-right px-4 py-2.5 text-sm transition-colors ${currentTz === tz.value ? "text-purple-400 bg-purple-500/10" : "text-white/70 hover:bg-white/5"}`}>
                      {isFa ? tz.labelFa : tz.labelEn}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Hour offset */}
          <div>
            <label className="text-white/50 text-xs font-bold uppercase tracking-widest mb-2 block">
              {tr("تنظیم ساعت", "Hour Adjustment")}
            </label>
            <div className="flex items-center gap-3">
              <button data-remote onClick={() => set("clockOffset", Math.max(-12, hourOffset - 1))}
                className="tv-focusable w-12 h-12 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                style={{ background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)" }}>
                <Minus className="w-5 h-5 text-purple-400" />
              </button>
              <div className="flex-1 text-center rounded-xl py-3" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
                <span className="text-white font-black text-2xl" style={{ fontFamily: "Inter, monospace" }}>
                  {hourOffset > 0 ? "+" : ""}{hourOffset} {tr("ساعت", "h")}
                </span>
              </div>
              <button data-remote onClick={() => set("clockOffset", Math.min(12, hourOffset + 1))}
                className="tv-focusable w-12 h-12 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                style={{ background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)" }}>
                <Plus className="w-5 h-5 text-purple-400" />
              </button>
            </div>
          </div>

          {/* Minute offset */}
          <div>
            <label className="text-white/50 text-xs font-bold uppercase tracking-widest mb-2 block">
              {tr("تنظیم دقیقه", "Minute Adjustment")}
            </label>
            <div className="flex items-center gap-3">
              <button data-remote onClick={() => set("clockOffsetMinutes", Math.max(0, minOffset - 1))}
                className="tv-focusable w-12 h-12 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                style={{ background: "rgba(34,211,238,0.15)", border: "1px solid rgba(34,211,238,0.3)" }}>
                <Minus className="w-5 h-5 text-cyan-400" />
              </button>
              <div className="flex-1 text-center rounded-xl py-3" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>
                <span className="text-white font-black text-2xl" style={{ fontFamily: "Inter, monospace" }}>
                  {minOffset} {tr("دقیقه", "min")}
                </span>
              </div>
              <button data-remote onClick={() => set("clockOffsetMinutes", Math.min(59, minOffset + 1))}
                className="tv-focusable w-12 h-12 rounded-xl flex items-center justify-center transition-all hover:scale-110"
                style={{ background: "rgba(34,211,238,0.15)", border: "1px solid rgba(34,211,238,0.3)" }}>
                <Plus className="w-5 h-5 text-cyan-400" />
              </button>
            </div>
          </div>

          {/* Format */}
          <div>
            <label className="text-white/50 text-xs font-bold uppercase tracking-widest mb-2 block">
              {tr("فرمت نمایش", "Display Format")}
            </label>
            <div className="flex gap-2">
              <button data-remote onClick={() => set("clockFormat", "24")}
                className={`tv-focusable flex-1 rounded-xl py-3 text-sm font-bold transition-all ${fmt === "24" ? "text-white" : "text-white/50"}`}
                style={{ background: fmt === "24" ? "rgba(168,85,247,0.2)" : "rgba(255,255,255,0.05)", border: fmt === "24" ? "1px solid rgba(168,85,247,0.4)" : "1px solid rgba(255,255,255,0.08)" }}>
                {tr("۲۴ ساعته", "24-hour")}
              </button>
              <button data-remote onClick={() => set("clockFormat", "12")}
                className={`tv-focusable flex-1 rounded-xl py-3 text-sm font-bold transition-all ${fmt === "12" ? "text-white" : "text-white/50"}`}
                style={{ background: fmt === "12" ? "rgba(168,85,247,0.2)" : "rgba(255,255,255,0.05)", border: fmt === "12" ? "1px solid rgba(168,85,247,0.4)" : "1px solid rgba(255,255,255,0.08)" }}>
                {tr("۱۲ ساعته", "12-hour")}
              </button>
            </div>
          </div>

          {/* Reset */}
          <button data-remote onClick={() => { set("clockOffset", 0); set("clockOffsetMinutes", 0); }}
            className="tv-focusable w-full rounded-xl py-3 text-sm font-bold text-amber-400 transition-all"
            style={{ background: "rgba(251,191,36,0.08)", border: "1px solid rgba(251,191,36,0.2)" }}>
            {tr("بازنشانی تنظیمات", "Reset Adjustments")}
          </button>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 flex-shrink-0" style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <button data-remote onClick={onClose}
            className="tv-focusable w-full rounded-xl py-3 text-sm font-bold text-white transition-all hover:scale-[1.02]"
            style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 20px rgba(123,44,191,0.4)" }}>
            {tr("ذخیره و بستن", "Save & Close")}
          </button>
        </div>
      </div>
    </div>
  );
}