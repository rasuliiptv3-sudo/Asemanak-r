import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Settings, ChevronDown } from "lucide-react";

const QUALITIES = ["HD", "Full HD", "4K", "Auto"];

export default function FooterBar() {
  const navigate = useNavigate();
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [quality, setQuality] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("ayeneh_quality")) || "Full HD");

  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);

  const cycle = () => {
    const n = QUALITIES[(QUALITIES.indexOf(quality) + 1) % QUALITIES.length];
    setQuality(n);
    try { localStorage.setItem("ayeneh_quality", n); } catch {}
  };

  return (
    <div className="absolute bottom-0 left-0 right-0 z-30 flex justify-center px-4" style={{ paddingBottom: "calc(1rem + env(safe-area-inset-bottom))" }}>
      <div className="flex items-stretch rounded-2xl overflow-hidden w-full max-w-3xl"
        style={{ background: "rgba(18,18,22,0.85)", border: "1px solid rgba(255,255,255,0.08)", backdropFilter: "blur(12px)" }}>
        <div className="flex-1 flex items-center justify-center gap-2 px-4 py-3">
          <span className="text-white/45 text-[11px]" style={{ fontFamily: "Vazirmatn, sans-serif" }}>وضعیت سرور</span>
          <span className="w-2 h-2 rounded-full" style={{ background: online ? "#00e676" : "#ff5252", boxShadow: `0 0 8px ${online ? "#00e676" : "#ff5252"}` }} />
          <span style={{ color: online ? "#00e676" : "#ff5252", fontSize: 12, fontWeight: 700 }}>{online ? "آنلاین" : "آفلاین"}</span>
        </div>
        <div className="w-px" style={{ background: "rgba(255,255,255,0.1)" }} />
        <button onClick={() => navigate("/Settings")} className="flex-1 flex items-center justify-center gap-2 px-4 py-3 active:scale-95 transition-transform">
          <Settings className="w-4 h-4 text-cyan-400" />
          <span className="text-white/90 text-xs font-bold" style={{ fontFamily: "Vazirmatn, sans-serif" }}>تنظیمات</span>
        </button>
        <div className="w-px" style={{ background: "rgba(255,255,255,0.1)" }} />
        <button onClick={cycle} className="flex-1 flex items-center justify-center gap-2 px-4 py-3 active:scale-95 transition-transform">
          <span className="text-white/45 text-[11px]" style={{ fontFamily: "Vazirmatn, sans-serif" }}>کیفیت پخش</span>
          <span className="px-1.5 py-0.5 rounded text-[10px] font-black text-black" style={{ background: "#ffc107" }}>HD</span>
          <span style={{ color: "#ffc107", fontSize: 12, fontWeight: 700 }}>{quality}</span>
          <ChevronDown className="w-3.5 h-3.5 text-white/45" />
        </button>
      </div>
    </div>
  );
}