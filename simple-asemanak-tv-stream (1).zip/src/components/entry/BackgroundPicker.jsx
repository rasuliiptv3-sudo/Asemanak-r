import { useState, useRef } from "react";
import { X, Check, Upload, Trash2, Loader2, ImagePlus, Sparkles, Layers } from "lucide-react";
import { base44 } from "@/api/base44Client";
import {
  BACKGROUND_LIBRARY, getSelectedIds, setSelectedBackgrounds,
  getCustomBackgrounds, addCustomBackground, removeCustomBackground,
} from "@/lib/backgrounds";

export default function BackgroundPicker({ isFa, onClose }) {
  const [selected, setSelected] = useState(() => getSelectedIds());
  const [custom, setCustom] = useState(() => getCustomBackgrounds());
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const fileRef = useRef(null);

  const toggle = (id) => {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []).filter(f => f.type.startsWith("image/"));
    if (!files.length) return;
    setUploading(true);
    setUploadError(null);
    try {
      const uploaded = [];
      for (const f of files) {
        const res = await base44.integrations.Core.UploadFile({ file: f });
        if (res?.file_url) {
          const item = addCustomBackground(res.file_url, f.name.replace(/\.[^.]+$/, ""));
          uploaded.push(item);
          setCustom(prev => [...prev, item]);
        }
      }
      // Immediately set the uploaded image(s) as the active background slideshow.
      if (uploaded.length > 0) {
        setSelectedBackgrounds(uploaded.map(u => u.id));
        setSelected(uploaded.map(u => u.id));
        onClose();
        return;
      }
    } catch (err) {
      setUploadError(isFa ? "آپلود ناموفق بود — دوباره تلاش کنید" : "Upload failed — try again");
    }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleRemoveCustom = (id) => {
    removeCustomBackground(id);
    setCustom(prev => prev.filter(b => b.id !== id));
    setSelected(prev => prev.filter(x => x !== id));
  };

  const apply = () => {
    setSelectedBackgrounds(selected);
    onClose();
  };

  const selectAll = () => {
    setSelected([]);
  };

  const count = selected.length;
  const statusText = isFa
    ? (count === 0 ? "همه پس‌زمینه‌ها فعال‌اند (اسلایدشو)" : `${count} مورد انتخاب شده — اسلایدشو`)
    : (count === 0 ? "All backgrounds active (slideshow)" : `${count} selected — slideshow`);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(14px)" }}
      onClick={onClose}>
      <div className="w-full max-w-4xl max-h-[88vh] overflow-y-auto rounded-3xl"
        style={{
          background: "linear-gradient(160deg, rgba(20,14,35,0.97), rgba(10,8,20,0.98))",
          border: "1.5px solid rgba(255,255,255,0.1)",
          boxShadow: "0 24px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06)",
        }}
        onClick={e => e.stopPropagation()}>
      <style>{`
        .bg-picker-scroll::-webkit-scrollbar{width:6px;}
        .bg-picker-scroll::-webkit-scrollbar-thumb{background:rgba(34,211,238,0.3);border-radius:3px;}
        .bg-picker-scroll::-webkit-scrollbar-track{background:transparent;}
        .bg-tile{
          position:relative;border-radius:20px;overflow:hidden;cursor:pointer;outline:none;
          border:2px solid rgba(255,255,255,0.08);
          transition:transform .35s cubic-bezier(0.34,1.56,0.64,1),box-shadow .35s ease,border-color .35s ease;
        }
        .bg-tile::after{
          content:"";position:absolute;inset:0;border-radius:20px;
          background:linear-gradient(115deg,transparent 40%,rgba(255,255,255,0.1) 50%,transparent 60%);
          opacity:0;transform:translateX(-130%);pointer-events:none;
        }
        .bg-tile:focus::after,.bg-tile:hover::after{animation:bgShine 1.2s ease-out;}
        @keyframes bgShine{0%{transform:translateX(-130%);opacity:0}30%{opacity:1}100%{transform:translateX(130%);opacity:0}}
        .bg-tile:focus,.bg-tile:hover{
          transform:translateY(-4px) scale(1.03);
          border-color:rgba(34,211,238,0.6);
          box-shadow:0 16px 40px rgba(0,0,0,0.5),0 0 24px rgba(34,211,238,0.3);
        }
        .bg-tile.bg-tile-on{
          border-color:#22d3ee;
          box-shadow:0 0 24px rgba(34,211,238,0.45),0 8px 24px rgba(0,0,0,0.4);
        }
      `}</style>

      {/* Header */}
      <div className="flex items-center justify-between px-6 pt-6 pb-4"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
            style={{ background: "linear-gradient(135deg, rgba(123,44,191,0.3), rgba(34,211,238,0.2))", border: "1px solid rgba(255,255,255,0.12)" }}>
            <ImagePlus className="w-5 h-5 text-cyan-300" />
          </div>
          <div>
            <h2 className="text-white font-bold text-lg leading-tight">
              {isFa ? "انتخاب پس‌زمینه‌ها" : "Choose Backgrounds"}
            </h2>
            <p className="text-white/40 text-xs flex items-center gap-1.5 mt-0.5">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              {isFa ? "کیفیت 4K — اسلایدشو خودکار هر ۲ دقیقه" : "4K quality — auto slideshow every 2 min"}
            </p>
          </div>
        </div>
        <button onClick={onClose} data-remote className="w-10 h-10 rounded-xl flex items-center justify-center text-white/50 hover:text-white hover:bg-white/10 transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Info bar */}
      <div className="flex items-center gap-2 px-6 py-3 mx-6 mt-4 rounded-xl"
        style={{ background: "rgba(34,211,238,0.06)", border: "1px solid rgba(34,211,238,0.15)" }}>
        <Layers className="w-4 h-4 text-cyan-400 flex-shrink-0" />
        <p className="text-white/60 text-xs leading-relaxed">
          {isFa
            ? "چند پس‌زمینه را انتخاب کنید تا در اسلایدشو بچرخند. هیچ‌کدام را انتخاب نکنید تا همه نمایش داده شوند."
            : "Select multiple backgrounds to rotate in a slideshow. Select none to use all."}
        </p>
      </div>

      <div className="bg-picker-scroll overflow-y-auto px-6 pb-4" style={{ maxHeight: "calc(88vh - 200px)" }}>
        {/* Library grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mt-4">
          {BACKGROUND_LIBRARY.map(b => {
            const on = count === 0 || selected.includes(b.id);
            return (
              <button key={b.id} data-remote onClick={() => toggle(b.id)}
                className={`bg-tile ${on ? "bg-tile-on" : ""}`}>
                <div style={{ aspectRatio: "16 / 9", backgroundImage: `url("${b.thumb}")`, backgroundSize: "cover", backgroundPosition: "center" }} />
                {on && (
                  <div className="absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center"
                    style={{ background: "#22d3ee", boxShadow: "0 0 12px rgba(34,211,238,0.6)" }}>
                    <Check className="w-3.5 h-3.5 text-black" strokeWidth={3} />
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 px-2 py-1.5"
                  style={{ background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.8))" }}>
                  <span className="text-white text-[11px] font-semibold">{isFa ? b.labelFa : b.label}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Custom uploaded backgrounds */}
        <div className="mt-6 pt-5" style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white/70 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
              <ImagePlus className="w-3.5 h-3.5 text-purple-400" />
              {isFa ? "پس‌زمینه‌های شما" : "Your Backgrounds"}
            </h3>
            <button onClick={() => fileRef.current?.click()} data-remote disabled={uploading}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white transition-transform hover:scale-105 disabled:opacity-50"
              style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 14px rgba(123,44,191,0.35)" }}>
              {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
              {isFa ? "آپلود از گالری" : "Upload from Gallery"}
            </button>
            <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} />
          </div>
          {uploadError && <p className="text-red-400 text-xs mb-2">{uploadError}</p>}
          {custom.length === 0 ? (
            <div className="text-center py-8 rounded-xl" style={{ background: "rgba(255,255,255,0.03)", border: "1px dashed rgba(255,255,255,0.1)" }}>
              <Upload className="w-6 h-6 text-white/20 mx-auto mb-2" />
              <p className="text-white/30 text-xs">{isFa ? "هنوز عکسی آپلود نشده — از گالری اضافه کنید" : "No custom backgrounds yet — upload from gallery"}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {custom.map(b => {
                const on = count === 0 || selected.includes(b.id);
                return (
                  <button key={b.id} data-remote onClick={() => toggle(b.id)}
                    className={`bg-tile ${on ? "bg-tile-on" : ""}`}>
                    <div style={{ aspectRatio: "16 / 9", backgroundImage: `url("${b.thumb}")`, backgroundSize: "cover", backgroundPosition: "center" }} />
                    {on && (
                      <div className="absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center"
                        style={{ background: "#22d3ee", boxShadow: "0 0 12px rgba(34,211,238,0.6)" }}>
                        <Check className="w-3.5 h-3.5 text-black" strokeWidth={3} />
                      </div>
                    )}
                    <div className="absolute top-2 left-2">
                      <div onClick={(e) => { e.stopPropagation(); handleRemoveCustom(b.id); }}
                        className="w-6 h-6 rounded-full flex items-center justify-center bg-red-500/80 hover:bg-red-500 transition-colors cursor-pointer"
                        style={{ backdropFilter: "blur(4px)" }}>
                        <Trash2 className="w-3 h-3 text-white" />
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 px-2 py-1.5"
                      style={{ background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.8))" }}>
                      <span className="text-white text-[11px] font-semibold truncate block">{isFa ? b.labelFa : b.label}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-6 py-4 mt-2"
        style={{ borderTop: "1px solid rgba(255,255,255,0.08)", background: "rgba(0,0,0,0.2)" }}>
        <div className="flex items-center gap-3">
          <span className="text-white/50 text-xs flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            {statusText}
          </span>
          {count > 0 && (
            <button onClick={selectAll} data-remote className="text-cyan-400 text-xs font-semibold hover:text-cyan-300 transition-colors">
              {isFa ? "انتخاب همه" : "Select All"}
            </button>
          )}
        </div>
        <button onClick={apply} data-remote
          className="flex items-center gap-2 px-7 py-2.5 rounded-xl font-bold text-white transition-transform hover:scale-105"
          style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 18px rgba(123,44,191,0.45)" }}>
          <Check className="w-4 h-4" />
          {isFa ? "اعمال" : "Apply"}
        </button>
      </div>
      </div>
    </div>
  );
}