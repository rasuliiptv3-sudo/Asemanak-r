import { useState, useEffect } from "react";
import { Wifi, SignalHigh, Server, Calendar, Clock, Sun, CloudSun, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog } from "lucide-react";
import { getSelectedCity } from "@/lib/cities";

const WEATHER_MAP = {
  0: { Icon: Sun, fa: "صاف" }, 1: { Icon: CloudSun, fa: "کمی ابری" }, 2: { Icon: CloudSun, fa: "نیمه ابری" }, 3: { Icon: Cloud, fa: "ابری" },
  45: { Icon: CloudFog, fa: "مه" }, 48: { Icon: CloudFog, fa: "مه" }, 51: { Icon: CloudRain, fa: "نم‌نم" }, 53: { Icon: CloudRain, fa: "باران سبک" },
  55: { Icon: CloudRain, fa: "باران" }, 61: { Icon: CloudRain, fa: "باران" }, 63: { Icon: CloudRain, fa: "باران" }, 65: { Icon: CloudRain, fa: "باران شدید" },
  71: { Icon: CloudSnow, fa: "برف" }, 73: { Icon: CloudSnow, fa: "برف" }, 75: { Icon: CloudSnow, fa: "برف شدید" },
  80: { Icon: CloudRain, fa: "رگبار" }, 81: { Icon: CloudRain, fa: "رگبار" }, 82: { Icon: CloudRain, fa: "رگبار شدید" },
  95: { Icon: CloudLightning, fa: "رعد و برق" }, 96: { Icon: CloudLightning, fa: "رعد و برق" }, 99: { Icon: CloudLightning, fa: "رعد و برق شدید" },
};
const toFa = (s) => s.replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

function useLive() {
  const [now, setNow] = useState(new Date());
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [conn, setConn] = useState(typeof navigator !== "undefined" ? (navigator.connection || null) : null);
  const [weather, setWeather] = useState(null);
  const [city, setCity] = useState(getSelectedCity());

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    const on = () => setOnline(true), off = () => setOnline(false);
    const uc = () => setConn(navigator.connection || null);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    navigator.connection?.addEventListener?.("change", uc);
    return () => { clearInterval(iv); window.removeEventListener("online", on); window.removeEventListener("offline", off); navigator.connection?.removeEventListener?.("change", uc); };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const cache = JSON.parse(localStorage.getItem("ayeneh_weather_cache") || "null");
        if (cache && cache.id === city.id && Date.now() - cache.t < 30 * 60 * 1000) { setWeather(cache.data); return; }
        const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.long}&current=temperature_2m,weather_code&timezone=${city.tz}`);
        const d = await r.json();
        if (cancelled) return;
        const data = { temp: Math.round(d.current?.temperature_2m), code: d.current?.weather_code };
        setWeather(data);
        localStorage.setItem("ayeneh_weather_cache", JSON.stringify({ t: Date.now(), id: city.id, data }));
      } catch {}
    };
    load();
    return () => { cancelled = true; };
  }, [city.id, city.lat, city.long, city.tz]);

  useEffect(() => {
    const h = () => setCity(getSelectedCity());
    window.addEventListener("ayeneh-city-changed", h); window.addEventListener("storage", h);
    return () => { window.removeEventListener("ayeneh-city-changed", h); window.removeEventListener("storage", h); };
  }, []);

  return { now, online, conn, weather, city };
}

export default function LiveStatusPanel() {
  const { now, online, conn, weather, city } = useLive();
  const W = (weather && WEATHER_MAP[weather.code]) || { Icon: Cloud, fa: "—" };
  const signal = conn?.downlink ? Math.min(100, Math.round((conn.downlink / 10) * 100)) : (online ? 92 : 0);
  const faDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now);
  const enDate = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(now);
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");

  const rows = [
    { Icon: Wifi, label: "وضعیت اینترنت", value: online ? "متصل" : "قطع", color: online ? "#00ff00" : "#ff4d4d", iconColor: "#4da6ff" },
    { Icon: SignalHigh, label: "کیفیت اینترنت", value: online ? `${signal}%` : "—", color: online ? "#00ff00" : "#ff4d4d", iconColor: "#4da6ff" },
    { Icon: Server, label: "وضعیت سرور", value: online ? "آنلاین" : "آفلاین", color: online ? "#00ff00" : "#ff4d4d", iconColor: "#34d399" },
    { Icon: W.Icon, label: "آب و هوا", value: weather ? `${weather.temp}°C` : "—", sub: `${city.nameFa} | ${W.fa}`, color: "#fff", iconColor: "#fbbf24" },
    { Icon: Calendar, label: "تاریخ", value: faDate, sub: enDate, color: "#fff", iconColor: "#c084fc" },
    { Icon: Clock, label: "ساعت", value: toFa(`${hh}:${mm}`), color: "#fff", iconColor: "#c084fc" },
  ];

  return (
    <div className="absolute z-20 rounded-2xl overflow-hidden" style={{ left: "2.5%", top: "9%", width: "21%", direction: "rtl", background: "rgba(6,6,16,0.66)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(8px)", boxShadow: "0 8px 30px rgba(0,0,0,0.4)" }}>
      {rows.map((r, i) => (
        <div key={i} className="flex items-center gap-2 px-3 py-1.5" style={{ borderBottom: i < rows.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
          <r.Icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: r.iconColor }} />
          <div className="flex-1 min-w-0 leading-tight">
            <p className="text-white/45 text-[9px]">{r.label}</p>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-[11px] truncate" style={{ color: r.color }}>{r.value}</span>
              {r.sub && <span className="text-white/40 text-[9px] truncate">{r.sub}</span>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}