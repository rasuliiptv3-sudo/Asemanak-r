import { LOGO_URL } from "@/lib/brandAssets";

// Circular brand hub with layered neon rings — inspired by the reference design.
// Concentric rings: purple (#662d91) → deep blue (#1b1464) → cyan (#00aee3)
export default function BrandHub({ isFa }) {
  return (
    <div className="flex flex-col items-center gap-3 mb-6">
      <style>{`
        @keyframes bhPulse {
          0%,100% { box-shadow: 0 0 40px rgba(0,174,227,0.45), 0 0 80px rgba(102,45,145,0.25), inset 0 0 30px rgba(0,174,227,0.1); }
          50%     { box-shadow: 0 0 60px rgba(0,174,227,0.65), 0 0 110px rgba(102,45,145,0.35), inset 0 0 40px rgba(168,85,247,0.15); }
        }
        @keyframes bhRingRotate { from { transform: translateX(-50%) rotate(0deg); } to { transform: translateX(-50%) rotate(360deg); } }
        @keyframes bhRingRotateRev { from { transform: translateX(-50%) rotate(360deg); } to { transform: translateX(-50%) rotate(0deg); } }
        @keyframes bhGlowSweep {
          0%   { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
      `}</style>

      <div className="relative flex items-center justify-center"
        style={{ width: "clamp(90px,11vw,170px)", height: "clamp(90px,11vw,170px)" }}>

        {/* Outer glow halo */}
        <div className="absolute inset-0 rounded-full" style={{
          background: "radial-gradient(circle, rgba(0,174,227,0.12) 0%, rgba(102,45,145,0.08) 50%, transparent 75%)",
          animation: "bhPulse 3.5s ease-in-out infinite",
        }} />

        {/* Outer ring — cyan with animated gradient border */}
        <div className="absolute rounded-full" style={{
          inset: 0,
          padding: "3px",
          background: "linear-gradient(135deg, #662d91, #1b1464, #00aee3, #662d91)",
          backgroundSize: "200% 200%",
          animation: "bhGlowSweep 4s linear infinite",
          WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
          WebkitMaskComposite: "xor",
          maskComposite: "exclude",
        }} />

        {/* Mid ring — deep blue/purple */}
        <div className="absolute rounded-full" style={{
          inset: "9%",
          padding: "2px",
          background: "linear-gradient(225deg, #00aee3, #1b1464, #662d91, #00aee3)",
          backgroundSize: "200% 200%",
          animation: "bhGlowSweep 5s linear infinite reverse",
          WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
          WebkitMaskComposite: "xor",
          maskComposite: "exclude",
        }} />

        {/* Inner ring — subtle purple */}
        <div className="absolute rounded-full" style={{
          inset: "16%",
          border: "1px solid rgba(168,85,247,0.3)",
          boxShadow: "inset 0 0 12px rgba(102,45,145,0.2)",
        }} />

        {/* Logo disc — white-ish background with logo */}
        <div className="relative flex items-center justify-center rounded-full overflow-hidden"
          style={{
            width: "78%", height: "78%",
            background: "radial-gradient(circle at 50% 35%, rgba(255,255,255,0.08) 0%, rgba(10,0,15,0.6) 70%)",
            boxShadow: "inset 0 0 20px rgba(0,174,227,0.12), 0 0 18px rgba(102,45,145,0.3)",
          }}>
          <img src={LOGO_URL} alt="Asemanak TV" draggable={false}
            style={{ width: "82%", height: "82%", objectFit: "contain", filter: "drop-shadow(0 0 6px rgba(0,174,227,0.4))" }} />
        </div>

        {/* Orbiting cyan dot — outer */}
        <div className="absolute rounded-full" style={{
          width: 8, height: 8, top: "-4px", left: "50%",
          background: "#00e6ff",
          boxShadow: "0 0 10px rgba(0,230,255,0.9), 0 0 20px rgba(0,174,227,0.5)",
          transformOrigin: "50% calc(100% + clamp(49px,5.5vw,89px))",
          animation: "bhRingRotate 9s linear infinite",
        }} />
        {/* Orbiting purple dot — inner, opposite direction */}
        <div className="absolute rounded-full" style={{
          width: 5, height: 5, top: "9%", left: "50%",
          background: "#a855f7",
          boxShadow: "0 0 8px rgba(168,85,247,0.8)",
          transformOrigin: "50% calc(100% + clamp(40px,4.5vw,76px))",
          animation: "bhRingRotateRev 7s linear infinite",
        }} />
      </div>

      <div className="text-center leading-tight">
        <p className="text-white font-bold tracking-wider" style={{
          fontSize: "clamp(13px,1.3vw,16px)",
          textShadow: "0 0 12px rgba(0,174,227,0.5), 0 0 24px rgba(102,45,145,0.3)",
        }}>ASEMANAK.TV</p>
        <p className="text-white/40" style={{ fontSize: "clamp(9px,0.85vw,11px)" }}>{isFa ? "نسخه ۲.۲.۰" : "Version 2.2.0"}</p>
      </div>
    </div>
  );
}