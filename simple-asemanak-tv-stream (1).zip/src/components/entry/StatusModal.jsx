import { useState, useEffect } from "react";
import { Wifi, WifiOff, SignalHigh, Calendar, Sun, CloudSun, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog, X, Globe, Activity, MapPin, MapPinned } from "lucide-react";
import { CITIES, getSelectedCity, setSelectedCity, detectCityByGeo } from "@/lib/cities";
import { LocateFixed } from "lucide-react";

const WEATHER_MAP = {
  0: { Icon: Sun, fa: "صاف" },
  1: { Icon: CloudSun, fa: "کمی ابری" },
  2: { Icon: CloudSun, fa: "نیمه ابری" },
  3: { Icon: Cloud, fa: "ابری" },
  45: { Icon: CloudFog, fa: "مه‌آلود" },
  48: { Icon: CloudFog, fa: "مه‌آلود" },
  51: { Icon: CloudRain, fa: "نم‌نم" },
  53: { Icon: CloudRain, fa: "باران سبک" },
  55: { Icon: CloudRain, fa: "باران" },
  61: { Icon: CloudRain, fa: "باران" },
  63: { Icon: CloudRain, fa: "باران" },
  65: { Icon: CloudRain, fa: "باران شدید" },
  71: { Icon: CloudSnow, fa: "برف سبک" },
  73: { Icon: CloudSnow, fa: "برف" },
  75: { Icon: CloudSnow, fa: "برف شدید" },
  80: { Icon: CloudRain, fa: "رگبار" },
  81: { Icon: CloudRain, fa: "رگبار" },
  82: { Icon: CloudRain, fa: "رگبار شدید" },
  95: { Icon: CloudLightning, fa: "رعد و برق" },
  96: { Icon: CloudLightning, fa: "رعد و برق" },
  99: { Icon: CloudLightning, fa: "رعد و برق شدید" },
};

function Row({ icon, label, value, valueColor }) {
  return (
    <div className="flex items-center justify-between py-2.5 px-1" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
      <div className="flex items-center gap-2.5">
        <span style={{ color: "#4da6ff" }}>{icon}</span>
        <span className="text-white/70 text-sm">{label}</span>
      </div>
      <span className="text-sm font-bold" style={{ color: valueColor || "#fff" }}>{value}</span>
    </div>
  );
}

export default function StatusModal({ open, onClose, now }) {
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [conn, setConn] = useState(typeof navigator !== "undefined" ? (navigator.connection || null) : null);
  const [city, setCity] = useState(getSelectedCity());
  const [weather, setWeather] = useState(null);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    if (!open) return;
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    const updateConn = () => setConn(navigator.connection || null);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    navigator.connection?.addEventListener?.("change", updateConn);
    updateConn();
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      navigator.connection?.removeEventListener?.("change", updateConn);
    };
  }, [open]);

  // Fetch weather for the selected city (refreshes immediately when city changes)
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const load = async () => {
      try {
        const cache = JSON.parse(localStorage.getItem("ayeneh_weather_cache") || "null");
        if (cache && cache.id === city.id && Date.now() - cache.t < 30 * 60 * 1000) { setWeather(cache.data); return; }
        const res = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.long}&current=temperature_2m,weather_code&timezone=${city.tz}`
        );
        const d = await res.json();
        if (cancelled) return;
        const data = { temp: Math.round(d.current?.temperature_2m), code: d.current?.weather_code };
        setWeather(data);
        localStorage.setItem("ayeneh_weather_cache", JSON.stringify({ t: Date.now(), id: city.id, data }));
      } catch {}
    };
    load();
    return () => { cancelled = true; };
  }, [open, city.id, city.lat, city.long, city.tz]);

  if (!open) return null;

  const W = (weather && WEATHER_MAP[weather.code]) || { Icon: Cloud, fa: "—" };
  const WeatherIcon = W.Icon;
  const faDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now);
  const enDate = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(now);
  const faTime = new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit", timeZone: city.tz }).format(now);

  const effType = conn?.effectiveType || "—";
  const downlink = conn?.downlink ? `${conn.downlink} Mbps` : "—";
  const rtt = conn?.rtt != null ? `${conn.rtt} ms` : "—";
  const signal = conn?.downlink ? Math.min(100, Math.round((conn.downlink / 10) * 100)) : 92;

  const pickCity = (id) => {
    const c = setSelectedCity(id);
    setCity(c);
  };
  const detectMe = async () => {
    setLocating(true);
    const c = await detectCityByGeo();
    setLocating(false);
    if (c) setCity(c);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" />
      <div className="relative z-10 w-[340px] max-w-[90vw] rounded-2xl overflow-hidden max-h-[88vh] flex flex-col"
        style={{ background: "rgba(13,12,28,0.97)", border: "1px solid rgba(123,44,191,0.35)", boxShadow: "0 20px 60px rgba(0,0,0,0.6)" }}
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 flex-shrink-0" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)", background: "linear-gradient(90deg, rgba(123,44,191,0.2), rgba(0,212,255,0.15))" }}>
          <p className="text-white font-bold text-sm">وضعیت سیستم</p>
          <button onClick={onClose} className="text-white/50 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        <div className="px-4 py-2 overflow-y-auto" style={{ direction: "rtl" }}>
          {/* Internet */}
          <div className="flex items-center gap-2 pt-2 pb-1">
            <Globe className="w-4 h-4" style={{ color: "#4da6ff" }} />
            <p className="text-white/50 text-xs font-bold uppercase tracking-widest">اینترنت</p>
          </div>
          <Row icon={<Wifi className="w-4 h-4" />} label="وضعیت اتصال" value={online ? "متصل" : "قطع"} valueColor={online ? "#00ff00" : "#ff4d4d"} />
          <Row icon={<Activity className="w-4 h-4" />} label="نوع اتصال" value={effType.toUpperCase()} />
          <Row icon={<SignalHigh className="w-4 h-4" />} label="سرعت" value={downlink} />
          <Row icon={<Activity className="w-4 h-4" />} label="تأخیر" value={rtt} />
          <Row icon={<SignalHigh className="w-4 h-4" />} label="قدرت سیگنال" value={`${signal}%`} valueColor="#4da6ff" />

          {/* Weather */}
          <div className="flex items-center gap-2 pt-4 pb-1">
            <WeatherIcon className="w-4 h-4 text-amber-300" />
            <p className="text-white/50 text-xs font-bold uppercase tracking-widest">آب و هوا</p>
          </div>
          <Row icon={<WeatherIcon className="w-4 h-4" />} label={`دمای ${city.nameFa}`} value={weather ? `${weather.temp}°C` : "—"} />
          <Row icon={<MapPin className="w-4 h-4" />} label="موقعیت" value={`${city.nameFa} | ${W.fa}`} />

          {/* City picker */}
          <div className="flex items-center gap-2 pt-3 pb-2">
            <MapPinned className="w-4 h-4 text-purple-300" />
            <p className="text-white/50 text-xs font-bold uppercase tracking-widest">انتخاب شهر</p>
          </div>
          <div className="flex items-center gap-2 pb-2">
            <button onClick={detectMe} disabled={locating}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-bold text-white transition-all hover:scale-[1.03] disabled:opacity-60"
              style={{ background: "linear-gradient(135deg, #7b2cbf, #00d4ff)", fontFamily: "Vazirmatn, sans-serif" }}>
              <LocateFixed className="w-3.5 h-3.5" /> {locating ? "در حال یافتن..." : "موقعیت من (خودکار)"}
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5 pb-1">
            {CITIES.map(c => (
              <button key={c.id} onClick={() => pickCity(c.id)}
                className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-all"
                style={{
                  background: c.id === city.id ? "rgba(123,44,191,0.3)" : "rgba(255,255,255,0.04)",
                  border: c.id === city.id ? "1.5px solid rgba(168,85,247,0.7)" : "1px solid rgba(255,255,255,0.1)",
                  color: c.id === city.id ? "#fff" : "rgba(255,255,255,0.6)",
                  fontFamily: "Vazirmatn, sans-serif",
                }}>
                {c.nameFa}
              </button>
            ))}
          </div>

          {/* Date & time */}
          <div className="flex items-center gap-2 pt-4 pb-1">
            <Calendar className="w-4 h-4" style={{ color: "#c77dff" }} />
            <p className="text-white/50 text-xs font-bold uppercase tracking-widest">تاریخ و زمان</p>
          </div>
          <Row icon={<Calendar className="w-4 h-4" />} label="تاریخ شمسی" value={faDate} />
          <Row icon={<Calendar className="w-4 h-4" />} label="تاریخ میلادی" value={enDate} />
          <Row icon={<Calendar className="w-4 h-4" />} label={`ساعت ${city.nameFa}`} value={faTime} />
        </div>
        <div className="h-3" />
      </div>
    </div>
  );
}