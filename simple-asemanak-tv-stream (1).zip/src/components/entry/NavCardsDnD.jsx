import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Tv, Clapperboard, Star, GripVertical, ZoomIn, ZoomOut, RotateCcw, Palette, Youtube } from "lucide-react";
import { useIsMobile } from "@/lib/useIsMobile";
import { useIsTV } from "@/lib/useIsTV";
import { useAuth } from "@/lib/AuthContext";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

function TeddyBear({ className, style }) {
  return (
    <svg viewBox="0 0 64 64" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="16" r="7" />
      <circle cx="46" cy="16" r="7" />
      <circle cx="18" cy="16" r="3" fill="currentColor" opacity="0.3" stroke="none" />
      <circle cx="46" cy="16" r="3" fill="currentColor" opacity="0.3" stroke="none" />
      <circle cx="32" cy="30" r="16" />
      <ellipse cx="32" cy="38" rx="9" ry="7" />
      <circle cx="26" cy="28" r="2" fill="currentColor" stroke="none" />
      <circle cx="38" cy="28" r="2" fill="currentColor" stroke="none" />
      <ellipse cx="32" cy="35" rx="2.5" ry="2" fill="currentColor" stroke="none" />
      <path d="M32 37 v3 M32 40 q-3 2 -5 1 M32 40 q3 2 5 1" />
    </svg>
  );
}

const DEFAULT_CARDS = [
  { icon: Tv,           badge: "4K LIVE", titleFa: "تلویزیون زنده",  titleEn: "LIVE TV",   route: "/Home",                hex: "#00d4ff", hexDark: "#0891b2" },
  { icon: Clapperboard, badge: "VOD",     titleFa: "سریال‌ها",       titleEn: "SERIES",    route: "/Media?cat=series",    hex: "#9d4edd", hexDark: "#7b2cbf" },
  { icon: TeddyBear,    badge: "KIDS",    titleFa: "انیمیشن",       titleEn: "ANIMATION", route: "/Media?cat=animation",  hex: "#f43f5e", hexDark: "#be123c" },
  { icon: Youtube,      badge: "YT",      titleFa: "یوتیوب",        titleEn: "YOUTUBE",   route: "youtube",              hex: "#ff0000", hexDark: "#cc0000", external: true, url: "https://www.youtube.com" },
  { icon: Star,         badge: "HD",      titleFa: "محبوب‌ترین‌ها",  titleEn: "FAVORITES", route: "/Favorites",           hex: "#fbbf24", hexDark: "#d97706" },
];

const COLOR_PRESETS = [
  { hex: "#9d4edd", hexDark: "#7b2cbf" },
  { hex: "#00d4ff", hexDark: "#0891b2" },
  { hex: "#f43f5e", hexDark: "#be123c" },
  { hex: "#fbbf24", hexDark: "#d97706" },
  { hex: "#34d399", hexDark: "#059669" },
  { hex: "#3b82f6", hexDark: "#1d4ed8" },
  { hex: "#ec4899", hexDark: "#db2777" },
  { hex: "#6366f1", hexDark: "#4338ca" },
];

const ORDER_KEY = "ayeneh_nav_order";
const SIZE_KEY = "ayeneh_nav_size";
const COLOR_KEY = "ayeneh_nav_colors";

function loadOrder() {
  try {
    const saved = JSON.parse(localStorage.getItem(ORDER_KEY) || "[]");
    if (Array.isArray(saved) && saved.length > 0) {
      const ordered = saved.map(route => DEFAULT_CARDS.find(c => c.route === route)).filter(Boolean);
      const missing = DEFAULT_CARDS.filter(c => !saved.includes(c.route));
      return [...ordered, ...missing];
    }
  } catch {}
  return DEFAULT_CARDS;
}

function saveOrder(cards) {
  try { localStorage.setItem(ORDER_KEY, JSON.stringify(cards.map(c => c.route))); } catch {}
}

export default function NavCardsDnD() {
  const navigate = useNavigate();
  const isMobile = useIsMobile(480);
  const isTV = useIsTV();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [focusIdx, setFocusIdx] = useState(0);
  const [isFa, setIsFa] = useState(true);
  const [pressedIdx, setPressedIdx] = useState(-1);
  const [cards, setCards] = useState(loadOrder);
  const [iconSize, setIconSize] = useState(() => {
    try { return parseFloat(localStorage.getItem(SIZE_KEY)) || 1; } catch { return 1; }
  });
  const [cardColors, setCardColors] = useState(() => {
    try { return JSON.parse(localStorage.getItem(COLOR_KEY) || "{}"); } catch { return {}; }
  });
  const [editMode, setEditMode] = useState(false);
  const [dragIdx, setDragIdx] = useState(-1);
  const [dragOverIdx, setDragOverIdx] = useState(-1);
  const [touchDragIdx, setTouchDragIdx] = useState(-1);
  const btnRefs = useRef([]);
  const touchStart = useRef({ x: 0, y: 0 });
  const longPressTimer = useRef(null);

  const displayCards = isTV ? [...cards.filter(c => c.route !== "/Favorites"), ...cards.filter(c => c.route === "/Favorites")] : cards;

  useEffect(() => {
    const syncLang = () => setIsFa(readSettings().language !== "en");
    syncLang();
    window.addEventListener("storage", syncLang);
    window.addEventListener("ayeneh-settings-changed", syncLang);
    return () => {
      window.removeEventListener("storage", syncLang);
      window.removeEventListener("ayeneh-settings-changed", syncLang);
    };
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.defaultPrevented) return;
      const activeId = document.activeElement?.id || "";
      if (!activeId.startsWith("app-pill-")) return;
      if (["Enter", "Return", " ", "XF86OK", "Accept"].includes(e.key)) { e.preventDefault(); handlePress(focusIdx); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [focusIdx, isFa, navigate, displayCards]);

  useEffect(() => { if (isTV) btnRefs.current[focusIdx]?.focus(); }, [focusIdx, isTV]);

  const handlePress = (idx) => {
    if (editMode) return;
    const card = displayCards[idx];
    if (!card) return;
    setPressedIdx(idx);
    setTimeout(() => {
      setPressedIdx(-1);
      if (card.external) {
        const ua = navigator.userAgent || "";
        if (/android/i.test(ua)) {
          window.location.href = "intent://www.youtube.com#Intent;package=com.google.android.youtube;scheme=https;end";
        } else {
          window.open(card.url, "_blank");
        }
      } else {
        navigate(card.route);
      }
    }, 150);
  };

  const changeSize = (delta) => {
    setIconSize(prev => {
      const next = Math.max(0.6, Math.min(1.6, prev + delta));
      try { localStorage.setItem(SIZE_KEY, String(next)); } catch {}
      return next;
    });
  };

  const resetOrder = () => {
    setCards(DEFAULT_CARDS);
    saveOrder(DEFAULT_CARDS);
  };

  const cycleColor = (route) => {
    setCardColors(prev => {
      const currentIdx = prev[route] ?? -1;
      const nextIdx = (currentIdx + 1) % COLOR_PRESETS.length;
      const updated = { ...prev, [route]: nextIdx };
      try { localStorage.setItem(COLOR_KEY, JSON.stringify(updated)); } catch {}
      return updated;
    });
  };

  const getCardColor = (card) => {
    const colorIdx = cardColors[card.route];
    if (colorIdx !== undefined && colorIdx >= 0 && colorIdx < COLOR_PRESETS.length) {
      return COLOR_PRESETS[colorIdx];
    }
    return { hex: card.hex, hexDark: card.hexDark };
  };

  // Desktop drag & drop (mouse)
  const handleDragStart = (e, idx) => {
    if (!editMode) return;
    setDragIdx(idx);
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData("text/plain", String(idx)); } catch {}
  };
  const handleDragOver = (e, idx) => {
    if (!editMode || dragIdx === -1) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (dragOverIdx !== idx) setDragOverIdx(idx);
  };
  const handleDrop = (e, idx) => {
    if (!editMode || dragIdx === -1) return;
    e.preventDefault();
    const newCards = [...cards];
    const [moved] = newCards.splice(dragIdx, 1);
    newCards.splice(idx, 0, moved);
    setCards(newCards);
    saveOrder(newCards);
    setDragIdx(-1);
    setDragOverIdx(-1);
  };
  const handleDragEnd = () => { setDragIdx(-1); setDragOverIdx(-1); };

  // Touch drag (tablets/touchscreens on desktop layout)
  const handleTouchStart = (e, idx) => {
    if (!editMode) return;
    const t = e.touches[0];
    touchStart.current = { x: t.clientX, y: t.clientY };
    longPressTimer.current = setTimeout(() => {
      setTouchDragIdx(idx);
      setDragIdx(idx);
    }, 400);
  };
  const handleTouchMove = (e) => {
    if (!editMode || touchDragIdx === -1) return;
    if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
    const t = e.touches[0];
    const el = document.elementFromPoint(t.clientX, t.clientY);
    const cardEl = el?.closest("[data-card-idx]");
    if (cardEl) {
      const overIdx = parseInt(cardEl.dataset.cardIdx);
      if (dragOverIdx !== overIdx) setDragOverIdx(overIdx);
    }
  };
  const handleTouchEnd = () => {
    if (longPressTimer.current) { clearTimeout(longPressTimer.current); longPressTimer.current = null; }
    if (touchDragIdx !== -1 && dragOverIdx !== -1 && touchDragIdx !== dragOverIdx) {
      const newCards = [...cards];
      const [moved] = newCards.splice(touchDragIdx, 1);
      newCards.splice(dragOverIdx, 0, moved);
      setCards(newCards);
      saveOrder(newCards);
    }
    setTouchDragIdx(-1);
    setDragIdx(-1);
    setDragOverIdx(-1);
  };

  const sizeScale = iconSize;

  // ── Mobile vertical sidebar layout ──
  if (isMobile) {
    return (
      <div className="relative z-20 w-full" style={{ direction: isFa ? "rtl" : "ltr" }}>
        {editMode && isAdmin && (
          <div className="flex items-center gap-2 mb-3 px-2">
            <button onClick={() => setEditMode(false)} data-remote className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-white bg-cyan-600/30 border border-cyan-500/40">
              {isFa ? "تکمیل" : "Done"}
            </button>
            <button onClick={resetOrder} data-remote className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-white/70 bg-white/5 border border-white/10">
              <RotateCcw className="w-3.5 h-3.5" /> {isFa ? "بازنشانی" : "Reset"}
            </button>
            <span className="text-white/60 text-sm mr-auto">{isFa ? "نگه دارید و بکشید" : "Hold & drag"}</span>
          </div>
        )}
        <div className="fixed left-0 top-1/2 -translate-y-1/2 z-50 flex items-center" style={{ paddingLeft: 'env(safe-area-inset-left)' }}>
          <style>{`
            .mobile-nav { display: flex; flex-direction: column; gap: 10px; padding: 10px 6px; width: 78px; }
            .mobile-nav-item {
              position: relative; flex-shrink: 0;
              display: flex; flex-direction: column; align-items: center; justify-content: center;
              width: 70px; height: 64px; border-radius: 16px;
              cursor: pointer; outline: none;
              background: linear-gradient(160deg, rgba(22,12,38,0.82), rgba(10,5,20,0.9));
              backdrop-filter: blur(22px) saturate(1.45);
              -webkit-backdrop-filter: blur(22px) saturate(1.45);
              border: 2px solid var(--pc);
              box-shadow: 0 0 14px var(--pc), 0 4px 12px rgba(0,0,0,0.5);
              color: #fff;
              transition: transform .3s cubic-bezier(0.34,1.56,0.64,1), box-shadow .3s ease, border-color .3s ease;
            }
            .mobile-nav-item.dragging { opacity: 0.5; transform: scale(0.9); }
            .mobile-nav-item.drag-over { border-color: #22d3ee; box-shadow: 0 0 24px #22d3ee, 0 0 48px #22d3ee; }
          `}</style>
          <div className="mobile-nav">
            {displayCards.map((c, i) => {
              const Icon = c.icon;
              const cc = getCardColor(c);
              const focused = focusIdx === i;
              const pressed = pressedIdx === i;
              return (
                <button
                  key={c.route}
                  id={`app-pill-${i}`}
                  ref={el => btnRefs.current[i] = el}
                  data-remote
                  data-card-idx={i}
                  className={`mobile-nav-item ${pressed ? "app-card-pressed" : ""} ${touchDragIdx === i ? "dragging" : ""} ${dragOverIdx === i && touchDragIdx !== -1 ? "drag-over" : ""}`}
                  style={{ "--pc": cc.hex, zIndex: focused ? 30 : 10, touchAction: editMode ? "none" : "auto" }}
                  onClick={() => handlePress(i)}
                  aria-label={isFa ? c.titleFa : c.titleEn}
                  onFocus={() => isTV && setFocusIdx(i)}
                  onTouchStart={(e) => handleTouchStart(e, i)}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                >
                  <Icon className="w-5 h-5" style={{ color: cc.hex, filter: `drop-shadow(0 0 6px ${cc.hex})`, transform: `scale(${sizeScale})` }} />
                  <span className="text-sm font-bold mt-0.5 leading-none whitespace-nowrap" style={{ color: cc.hex }}>{isFa ? c.titleFa : c.titleEn}</span>
                </button>
              );
            })}
          </div>
        </div>
        {isAdmin && (
          <button onClick={() => setEditMode(v => !v)} data-remote
            className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-bold text-white transition-all hover:scale-105"
            style={{ background: editMode ? 'rgba(34,211,238,0.85)' : 'rgba(0,0,0,0.7)', backdropFilter: 'blur(12px)', border: `1px solid ${editMode ? 'rgba(255,255,255,0.4)' : 'rgba(255,255,255,0.15)'}` }}>
            <GripVertical className="w-4 h-4" />
            {editMode ? (isFa ? "ویرایش روشن" : "Edit On") : (isFa ? "چیدمان آیکون‌ها" : "Edit Icons")}
          </button>
        )}
      </div>
    );
  }

  // ── Desktop / tablet grid layout ──
  const dir = isFa ? "rtl" : "ltr";

  return (
    <div className="relative z-20 w-full" style={{ direction: dir }}>
      <style>{`
        .app-cards{
          display:grid;
          grid-template-columns:repeat(auto-fit,minmax(clamp(200px,22vw,300px),1fr));
          gap:clamp(16px,2vw,28px);
          max-width:clamp(900px,90vw,1400px);
          margin:0 auto;
          direction:ltr;
          padding:8px 4px;
        }
        .app-card{
          position:relative;overflow:hidden;
          display:flex;flex-direction:column;align-items:center;justify-content:center;
          min-height:clamp(200px,24vh,280px);
          padding:clamp(28px,3vw,44px) clamp(20px,2vw,32px);
          gap:clamp(18px,2vh,28px);
          border-radius:28px;
          cursor:pointer;outline:none;
          background:linear-gradient(160deg, rgba(20,14,35,0.85), rgba(10,8,20,0.92));
          backdrop-filter:blur(24px) saturate(1.5);
          -webkit-backdrop-filter:blur(24px) saturate(1.5);
          border:1.5px solid rgba(255,255,255,0.08);
          box-shadow:0 12px 40px rgba(0,0,0,0.5),inset 0 1px 0 rgba(255,255,255,0.06);
          color:#fff;font-family:Vazirmatn,sans-serif;
          -webkit-font-smoothing:antialiased;text-rendering:geometricPrecision;
          transition:transform .4s cubic-bezier(0.34,1.56,0.64,1),box-shadow .4s ease,border-color .4s ease,background .4s ease;
        }
        .app-card.dragging{opacity:0.4;transform:scale(0.95)!important;}
        .app-card.drag-over{border-color:#22d3ee!important;box-shadow:0 0 30px rgba(34,211,238,0.6),0 12px 40px rgba(0,0,0,0.5)!important;}
        .app-card.edit-mode{cursor:grab;}
        .app-card.edit-mode:active{cursor:grabbing;}
        .app-card:focus,.app-card:hover{
          transform:translateY(-10px) scale(1.03);
          border-color:var(--pc);
          box-shadow:0 24px 60px rgba(0,0,0,0.6),0 0 40px var(--pc),inset 0 1px 0 rgba(255,255,255,0.12);
          background:linear-gradient(160deg, rgba(28,20,45,0.9), rgba(14,10,25,0.95));
          z-index:30;
        }
        .app-card.app-card-pressed{transform:scale(0.97)!important;transition:transform .1s ease-out!important;}
      `}</style>

      {editMode && isAdmin && (
        <div className="flex items-center gap-2 mb-4" style={{ maxWidth: 'clamp(900px,90vw,1400px)', margin: '0 auto 16px' }}>
          <button onClick={() => setEditMode(false)} data-remote
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-bold text-white transition-colors"
          style={{ background: 'rgba(34,211,238,0.2)', border: '1px solid rgba(34,211,238,0.4)' }}>
          {isFa ? "تکمیل ویرایش" : "Done"}
          </button>
          <button onClick={resetOrder} data-remote
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-bold text-white/70 bg-white/5 border border-white/10 transition-colors hover:bg-white/10">
          <RotateCcw className="w-3.5 h-3.5" /> {isFa ? "بازنشانی ترتیب" : "Reset Order"}
          </button>
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-bold text-white/70 bg-white/5 border border-white/10">
          <button onClick={() => changeSize(-0.1)} data-remote aria-label="Decrease icon size" className="min-w-[44px] min-h-[44px] rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors">
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-white/60 min-w-[44px] text-center text-sm">{Math.round(sizeScale * 100)}%</span>
          <button onClick={() => changeSize(0.1)} data-remote aria-label="Increase icon size" className="min-w-[44px] min-h-[44px] rounded-lg flex items-center justify-center hover:bg-white/15 transition-colors">
            <ZoomIn className="w-4 h-4" />
          </button>
          </div>
          <span className="text-white/60 text-sm ml-auto">{isFa ? "آیکون‌ها را بکشید و جابه‌جا کنید • رنگ را با Palette تغییر دهید" : "Drag icons to rearrange • Tap Palette to change color"}</span>
        </div>
      )}

      <div className="app-cards">
        {displayCards.map((c, i) => {
          const Icon = c.icon;
          const cc = getCardColor(c);
          const focused = focusIdx === i;
          const pressed = pressedIdx === i;
          const title = isFa ? c.titleFa : c.titleEn;
          const subtitle = isFa ? c.titleEn : c.titleFa;
          const isDragging = dragIdx === i;
          const isDragOver = dragOverIdx === i && dragIdx !== -1;
          return (
            <button
              key={c.route}
              id={`app-pill-${i}`}
              ref={el => btnRefs.current[i] = el}
              data-remote
              data-card-idx={i}
              draggable={editMode}
              onDragStart={(e) => handleDragStart(e, i)}
              onDragOver={(e) => handleDragOver(e, i)}
              onDrop={(e) => handleDrop(e, i)}
              onDragEnd={handleDragEnd}
              onTouchStart={(e) => handleTouchStart(e, i)}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className={`app-card ${pressed ? "app-card-pressed" : ""} ${editMode ? "edit-mode" : ""} ${isDragging ? "dragging" : ""} ${isDragOver ? "drag-over" : ""}`}
              style={{ "--pc": cc.hex, zIndex: focused ? 30 : 10, touchAction: editMode ? "none" : "auto" }}
              onClick={() => handlePress(i)}
              aria-label={title}
              onFocus={() => isTV && setFocusIdx(i)}
            >
              {editMode && (
                <span className="absolute top-3 right-3 z-10 text-white/50">
                  <GripVertical className="w-5 h-5" />
                </span>
              )}
              {editMode && isAdmin && (
                <button
                  onClick={(e) => { e.stopPropagation(); cycleColor(c.route); }}
                  data-remote
                  className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 min-w-[44px] min-h-[44px] rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{ background: cc.hex, boxShadow: `0 0 12px ${cc.hex}66` }}
                  aria-label={isFa ? "تغییر رنگ" : "Change color"}
                >
                  <Palette className="w-3.5 h-3.5 text-white" />
                </button>
              )}
              <span className="card-badge" style={{ color: cc.hex, borderColor: `${cc.hex}33`, fontSize: `clamp(14px,1vw,16px)`, padding: '4px 10px', borderRadius: '8px', fontWeight: 700, letterSpacing: '0.1em', background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)', position: 'absolute', top: 'clamp(14px,1.5vw,20px)', left: 'clamp(14px,1.5vw,20px)' }}>{c.badge}</span>
              <span className="card-icon-wrap flex items-center justify-center rounded-full flex-shrink-0"
                style={{
                  width: `clamp(${80 * sizeScale}px,${8 * sizeScale}vw,${120 * sizeScale}px)`,
                  height: `clamp(${80 * sizeScale}px,${8 * sizeScale}vw,${120 * sizeScale}px)`,
                  background: `linear-gradient(135deg, ${cc.hex}1a, ${cc.hexDark}1a)`,
                  border: `2px solid ${cc.hex}55`,
                  boxShadow: focused ? `0 0 30px ${cc.hex}66, inset 0 0 20px ${cc.hex}33` : `0 8px 24px rgba(0,0,0,0.3), inset 0 0 16px ${cc.hex}22`,
                }}>
                <Icon className="w-1/2 h-1/2" style={{ color: cc.hex }} />
              </span>
              <span className="card-title" style={{ textShadow: `0 0 20px ${cc.hex}55`, fontWeight: 800, fontSize: `clamp(${22 * sizeScale}px,${2.4 * sizeScale}vw,${34 * sizeScale}px)`, letterSpacing: '0.02em', textAlign: 'center', position: 'relative', zIndex: 1 }}>
                {title}
              </span>
              <span className="card-subtitle" style={{ color: cc.hex, fontSize: `clamp(${14 * sizeScale}px,${1.4 * sizeScale}vw,${18 * sizeScale}px)`, fontWeight: 500, letterSpacing: '0.15em', textTransform: 'uppercase', opacity: 0.5, marginTop: '-8px', position: 'relative', zIndex: 1 }}>
                {subtitle}
              </span>
            </button>
          );
        })}
      </div>

      {!editMode && isAdmin && (
        <button onClick={() => setEditMode(true)} data-remote
          className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-bold text-white transition-all hover:scale-105"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.15)' }}>
          <GripVertical className="w-4 h-4" />
          {isFa ? "چیدمان و رنگ آیکون‌ها" : "Edit & Color Icons"}
        </button>
      )}
    </div>
  );
}