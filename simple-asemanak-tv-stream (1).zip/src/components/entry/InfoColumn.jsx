import { useState, useEffect } from "react";
import { Wifi, SignalHigh, Droplets, Calendar, Clock, Sun, CloudSun, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog } from "lucide-react";
import { getSelectedCity } from "@/lib/cities";

const WEATHER_MAP = {
  0: { Icon: Sun, fa: "صاف" }, 1: { Icon: CloudSun, fa: "کمی ابری" }, 2: { Icon: CloudSun, fa: "نیمه ابری" },
  3: { Icon: Cloud, fa: "ابری" }, 45: { Icon: CloudFog, fa: "مه‌آلود" }, 48: { Icon: CloudFog, fa: "مه‌آلود" },
  51: { Icon: CloudRain, fa: "نم‌نم" }, 53: { Icon: CloudRain, fa: "باران سبک" }, 55: { Icon: CloudRain, fa: "باران" },
  61: { Icon: CloudRain, fa: "باران" }, 63: { Icon: CloudRain, fa: "باران" }, 65: { Icon: CloudRain, fa: "باران شدید" },
  71: { Icon: CloudSnow, fa: "برف سبک" }, 73: { Icon: CloudSnow, fa: "برف" }, 75: { Icon: CloudSnow, fa: "برف شدید" },
  80: { Icon: CloudRain, fa: "رگبار" }, 81: { Icon: CloudRain, fa: "رگبار" }, 82: { Icon: CloudRain, fa: "رگبار شدید" },
  95: { Icon: CloudLightning, fa: "رعد و برق" }, 96: { Icon: CloudLightning, fa: "رعد و برق" }, 99: { Icon: CloudLightning, fa: "رعد و برق شدید" },
};

const toFa = (s) => s.replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
function readSettings() { try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; } }

export default function InfoColumn() {
  const [now, setNow] = useState(new Date());
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [weather, setWeather] = useState(null);
  const [humidity, setHumidity] = useState(null);
  const [city, setCity] = useState(getSelectedCity());

  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    return () => { clearInterval(iv); window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.long}&current=temperature_2m,relative_humidity_2m,weather_code&timezone=${city.tz}`);
        const d = await res.json();
        if (cancelled) return;
        setWeather({ temp: Math.round(d.current?.temperature_2m), code: d.current?.weather_code });
        setHumidity(d.current?.relative_humidity_2m);
      } catch {}
    };
    load();
    const handler = () => setCity(getSelectedCity());
    window.addEventListener("ayeneh-city-changed", handler);
    return () => { cancelled = true; window.removeEventListener("ayeneh-city-changed", handler); };
  }, [city.id, city.lat, city.long, city.tz]);

  const W = (weather && WEATHER_MAP[weather.code]) || { Icon: Cloud, fa: "—" };
  const WeatherIcon = W.Icon;
  const s = readSettings();
  const isFa = s.language === "fa";
  const faDate = new Intl.DateTimeFormat("fa-IR-u-ca-persian", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now);
  const enDate = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(now);

  const tz = s.clockTimezone || "Asia/Tehran";
  const fmt = s.clockFormat || "24";
  const offset = Number(s.clockOffset) || 0;
  const disp = new Date(now.getTime() + offset * 3600000);
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: fmt === "12" }).formatToParts(disp);
  const hh = parts.find(p => p.type === "hour")?.value || "00";
  const mm = parts.find(p => p.type === "minute")?.value || "00";
  let timeStr = `${hh}:${mm}`;
  if (isFa) timeStr = toFa(timeStr);

  const rows = [
    { Icon: Wifi, color: "#4da6ff", label: "وضعیت اینترنت", value: online ? "متصل" : "قطع", valueColor: online ? "#00ff00" : "#ff4d4d" },
    { Icon: SignalHigh, color: "#4da6ff", label: "کیفیت اینترنت", value: online ? "خیلی خوب" : "—", valueColor: online ? "#00ff00" : "#ff4d4d" },
    { Icon: WeatherIcon, color: "#ffc107", label: "آب و هوا", value: weather ? `${weather.temp}°C` : "—", sub: city.nameFa },
    { Icon: Droplets, color: "#4da6ff", label: "رطوبت", value: humidity != null ? `${humidity}%` : "—" },
    { Icon: Calendar, color: "#c77dff", label: "تاریخ", value: faDate, sub: enDate },
    { Icon: Clock, color: "#5ad8ff", label: "ساعت", value: timeStr },
  ];

  return (
    <div className="flex absolute left-6 top-24 z-20 flex-col gap-2.5 w-60" style={{ direction: "rtl" }}>
      {rows.map((r, i) => {
        const I = r.Icon;
        return (
          <div key={i} className="flex items-center gap-2.5 rounded-xl px-3 py-2"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", backdropFilter: "blur(8px)" }}>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${r.color}1a`, border: `1px solid ${r.color}55` }}>
              <I className="w-4 h-4" style={{ color: r.color }} />
            </div>
            <div className="flex-1 min-w-0 leading-tight">
              <p className="text-white/45 text-[10px]">{r.label}</p>
              <p className="text-white font-bold text-xs truncate" style={{ color: r.valueColor || "#fff" }}>{r.value}</p>
              {r.sub && <p className="text-white/35 text-[10px] truncate">{r.sub}</p>}
            </div>
          </div>
        );
      })}
    </div>
  );
}