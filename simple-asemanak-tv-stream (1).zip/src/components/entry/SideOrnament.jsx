// Decorative ornament placed on either side of the central clock to balance
// the empty space and frame the hero area.
export default function SideOrnament({ color, icon, label }) {
  return (
    <div className="flex flex-col items-center gap-2.5 select-none" style={{ opacity: 0.8 }}>
      <div className="w-11 h-11 rounded-full flex items-center justify-center transition-transform hover:scale-110"
        style={{ background: `${color}1a`, border: `1.5px solid ${color}80`, boxShadow: `0 0 18px ${color}55` }}>
        {icon}
      </div>
      <div className="w-px h-8" style={{ background: `linear-gradient(to bottom, ${color}, transparent)` }} />
      <p className="text-[10px] text-white/55 tracking-wide" style={{ fontFamily: "Vazirmatn, sans-serif" }}>{label}</p>
    </div>
  );
}