import { useState, useEffect, useRef } from "react";
import { getSelectedBackgrounds } from "@/lib/backgrounds";

const CYCLE_MS = 2 * 60 * 1000; // rotate every 2 minutes

export default function DynamicBackground({ dim = 0 }) {
  const [images, setImages] = useState(() => getSelectedBackgrounds());
  const [idx, setIdx] = useState(0);
  const [failed, setFailed] = useState({});
  const prevCountRef = useRef(images.length);

  // React to user background selection changes
  useEffect(() => {
    const update = () => {
      const next = getSelectedBackgrounds();
      // Jump to a newly added background so the user sees it immediately.
      setIdx(next.length > prevCountRef.current ? Math.max(0, next.length - 1) : 0);
      prevCountRef.current = next.length;
      setImages(next);
      setFailed({});
    };
    window.addEventListener("ayeneh-bg-changed", update);
    window.addEventListener("storage", update);
    // Manual next-background cycle (from TV remote button)
    const nextBg = () => {
      setImages(curr => {
        const goodCount = curr.filter(b => !failed[b.id]).length;
        if (goodCount <= 1) return curr;
        setIdx(i => {
          let n = i;
          for (let k = 0; k < curr.length; k++) {
            n = (n + 1) % curr.length;
            if (!failed[curr[n].id]) return n;
          }
          return i;
        });
        return curr;
      });
    };
    window.addEventListener("ayeneh-bg-next", nextBg);
    return () => {
      window.removeEventListener("ayeneh-bg-changed", update);
      window.removeEventListener("storage", update);
      window.removeEventListener("ayeneh-bg-next", nextBg);
    };
  }, [failed]);

  // Auto-cycle among non-failed images (only when more than one good image)
  useEffect(() => {
    const goodCount = images.filter(b => !failed[b.id]).length;
    if (goodCount <= 1) return;
    const iv = setInterval(() => {
      setIdx(i => {
        let n = i;
        for (let k = 0; k < images.length; k++) {
          n = (n + 1) % images.length;
          if (!failed[images[n].id]) return n;
        }
        return i;
      });
    }, CYCLE_MS);
    return () => clearInterval(iv);
  }, [images, failed]);

  // If the currently shown image fails, jump to the first good one
  useEffect(() => {
    if (images.length && failed[images[idx]?.id]) {
      const goodIdx = images.findIndex(b => !failed[b.id]);
      if (goodIdx >= 0) setIdx(goodIdx);
    }
  }, [failed, images, idx]);

  return (
    <div className="absolute inset-0 overflow-hidden" style={{ zIndex: 0, background: "linear-gradient(135deg, #0a0418 0%, #150a28 40%, #08000f 100%)" }}>
      {/* Gradient fallback — visible behind images while they load or if all fail */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse 80% 60% at 30% 20%, rgba(168,85,247,0.12) 0%, transparent 60%), radial-gradient(ellipse 60% 50% at 80% 90%, rgba(34,211,238,0.08) 0%, transparent 50%), linear-gradient(135deg, #0a0418 0%, #150a28 40%, #08000f 100%)",
      }} />
      {images.map((b, i) => {
        const active = idx === i && !failed[b.id];
        return (
          <img key={b.id} src={b.full} alt="" decoding="async"
            onError={() => setFailed(f => f[b.id] ? f : { ...f, [b.id]: true })}
            className="absolute inset-0 w-full h-full"
            style={{
              objectFit: "cover",
              objectPosition: "center",
              opacity: active ? 1 : 0,
              transform: active ? "scale(1.0)" : "scale(1.0)",
              transition: "opacity 2s ease-in-out",
              imageRendering: "high-quality",
            }} />
        );
      })}

      {/* Clean image — no filters; only bottom darkened for text readability */}
      {dim > 0 && <div className="absolute inset-0" style={{ background: `rgba(8,0,15,${dim})` }} />}
      {/* Subtle frost glass overlay — gradient only (no backdrop-filter for performance) */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: "linear-gradient(180deg, rgba(8,0,15,0.15)  0%, transparent 25%, transparent 75%, rgba(8,0,15,0.2) 100%)",
      }} />
      <div className="absolute inset-0" style={{
        background: "linear-gradient(180deg, transparent 0%, transparent 70%, rgba(8,0,15,0.12) 90%, rgba(8,0,15,0.3) 100%)",
      }} />

      {/* Subtle particle/star effect — reduced count for TV/mobile performance */}
      <div className="absolute inset-0 pointer-events-none" style={{ overflow: "hidden" }}>
        <style>{`
          @keyframes db-particle-float {
            0% { transform: translateY(0) translateX(0) scale(1); opacity: 0; }
            15% { opacity: 1; }
            85% { opacity: 1; }
            100% { transform: translateY(-120px) translateX(var(--drift, 0px)) scale(0.3); opacity: 0; }
          }
          @keyframes db-twinkle {
            0%, 100% { opacity: 0.2; transform: scale(0.7); }
            50% { opacity: 0.9; transform: scale(1.2); }
          }
          @media (prefers-reduced-motion: reduce) {
            .db-particle, .db-twinkle { animation: none !important; opacity: 0.3 !important; }
          }
        `}</style>
        {[...Array(8)].map((_, i) => {
          const size = 1 + (i % 4);
          const left = (i * 12 + 5) % 97;
          const top = (i * 18 + 8) % 95;
          const delay = (i * 0.7) % 6;
          const dur = 5 + (i % 5);
          const isGold = i % 3 === 0;
          const isCyan = i % 3 === 1;
          const color = isGold ? "rgba(212,175,55,0.8)" : isCyan ? "rgba(34,211,238,0.7)" : "rgba(255,255,255,0.6)";
          const glow = isGold ? "rgba(212,175,55,0.5)" : isCyan ? "rgba(34,211,238,0.4)" : "rgba(255,255,255,0.3)";
          const drift = ((i % 6) - 3) * 10;
          return (
            <div key={i} className="db-particle" style={{
              position: "absolute",
              left: `${left}%`, top: `${top}%`,
              width: `${size}px`, height: `${size}px`,
              borderRadius: "50%",
              background: color,
              boxShadow: `0 0 ${size * 3}px ${glow}`,
              willChange: "transform, opacity",
              ["--drift"]: `${drift}px`,
              animation: `db-particle-float ${dur}s ease-in ${delay}s infinite`,
            }} />
          );
        })}
        {/* Twinkling stars — reduced count for performance */}
        {[...Array(6)].map((_, i) => {
          const size = 1.5 + (i % 3) * 0.5;
          const left = (i * 16 + 3) % 98;
          const top = (i * 22 + 5) % 90;
          const delay = (i * 0.8) % 5;
          const isPurple = i % 2 === 0;
          const color = isPurple ? "rgba(199,125,255,0.7)" : "rgba(255,255,255,0.5)";
          const glow = isPurple ? "rgba(168,85,247,0.4)" : "rgba(255,255,255,0.2)";
          return (
            <div key={`tw-${i}`} className="db-twinkle" style={{
              position: "absolute",
              left: `${left}%`, top: `${top}%`,
              width: `${size}px`, height: `${size}px`,
              borderRadius: "50%",
              background: color,
              boxShadow: `0 0 ${size * 4}px ${glow}`,
              willChange: "transform, opacity",
              animation: `db-twinkle ${3 + (i % 4)}s ease-in-out ${delay}s infinite`,
            }} />
          );
        })}
      </div>
    </div>
  );
}