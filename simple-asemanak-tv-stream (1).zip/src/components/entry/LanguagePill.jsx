import { useState, useEffect } from "react";
import { Languages, Check } from "lucide-react";

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

/**
 * Language selector pill — fixed at bottom-right of the Entry page.
 * Opens a dropdown with Persian/English options. Fully TV-remote navigable
 * (all buttons have data-remote). Replaces the old admin-only TV/Mobile toggle.
 */
export default function LanguagePill() {
  const [open, setOpen] = useState(false);
  const [lang, setLang] = useState("fa");

  useEffect(() => {
    const sync = () => setLang(readSettings().language === "en" ? "en" : "fa");
    sync();
    window.addEventListener("ayeneh-settings-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("ayeneh-settings-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const select = (code) => {
    const settings = readSettings();
    settings.language = code;
    localStorage.setItem("ayeneh_settings", JSON.stringify(settings));
    setLang(code);
    setOpen(false);
    window.dispatchEvent(new Event("ayeneh-settings-changed"));
  };

  return (
    <div className="fixed bottom-4 right-4 z-[100]" style={{ right: 'calc(1rem + env(safe-area-inset-right))', bottom: 'calc(1rem + env(safe-area-inset-bottom))' }}>
      <button
        data-remote
        onClick={() => setOpen(v => !v)}
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-white backdrop-blur-md transition-all hover:scale-105"
        style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.25)', boxShadow: '0 4px 15px rgba(0,0,0,0.4)' }}
      >
        <Languages className="w-3.5 h-3.5" />
        {lang === "fa" ? "فارسی" : "English"}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-[99]" onClick={() => setOpen(false)} />
          <div className="absolute bottom-full right-0 mb-2 rounded-xl overflow-hidden backdrop-blur-md"
            style={{ background: "rgba(10,13,22,0.97)", border: "1px solid rgba(255,255,255,0.15)", boxShadow: "0 8px 24px rgba(0,0,0,0.5)", minWidth: "140px" }}>
            <p className="px-4 py-1.5 text-[10px] text-white/40 uppercase tracking-wider border-b border-white/10">زبان / Language</p>
            {[
              { code: "fa", label: "فارسی", sub: "Persian" },
              { code: "en", label: "English", sub: "انگلیسی" },
            ].map(opt => (
              <button key={opt.code} data-remote
                onClick={() => select(opt.code)}
                className={`flex items-center gap-2 px-4 py-2.5 hover:bg-white/5 transition-colors w-full text-right ${lang === opt.code ? "text-cyan-400" : "text-white/70"}`}>
                <span className="text-xs flex-1">{opt.label}</span>
                <span className="text-[9px] text-white/30">{opt.sub}</span>
                {lang === opt.code && <Check className="w-3.5 h-3.5 ml-1" />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}