import { useState, useEffect } from "react";
import { WifiOff, CloudOff } from "lucide-react";

// Detects online/offline state and shows a non-blocking badge when offline.
export default function OfflineBadge() {
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);
  const [justChanged, setJustChanged] = useState(false);

  useEffect(() => {
    const on = () => { setOnline(true); setJustChanged(true); setTimeout(() => setJustChanged(false), 2500); };
    const off = () => { setOnline(false); setJustChanged(true); setTimeout(() => setJustChanged(false), 2500); };
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  if (online && !justChanged) return null;

  return (
    <div
      className="fixed top-1/2 left-1/2 -translate-x-1/2 z-40 pointer-events-none"
      style={{ top: online ? "12%" : "50%", transform: online ? "translate(-50%, 0)" : "translate(-50%, -50%)" }}
    >
      <div
        className="flex items-center gap-3 px-5 py-3 rounded-2xl backdrop-blur-xl transition-all"
        style={{
          background: online ? "rgba(34,197,94,0.12)" : "rgba(245,158,11,0.12)",
          border: `1.5px solid ${online ? "rgba(34,197,94,0.5)" : "rgba(245,158,11,0.5)"}`,
          boxShadow: `0 8px 40px ${online ? "rgba(34,197,94,0.25)" : "rgba(245,158,11,0.3)"}`,
        }}
      >
        {online ? (
          <CloudOff className="w-5 h-5 text-green-400" />
        ) : (
          <WifiOff className="w-5 h-5 text-amber-400" />
        )}
        <div className="leading-tight text-right">
          <p className="text-white font-bold text-sm" style={{ fontFamily: "Vazirmatn, sans-serif" }}>
            {online ? "اتصال اینترنت برقرار شد" : "حالت آفلاین"}
          </p>
          <p className="text-white/60 text-[11px]" style={{ fontFamily: "Vazirmatn, sans-serif" }}>
            {online ? "دوباره آنلاین هستید" : "نمایش داده‌های ذخیره‌شده — منو فعال است"}
          </p>
        </div>
      </div>
    </div>
  );
}