import { useState, useEffect } from "react";
import { Bell, X, Check, Sparkles, Tv, Info } from "lucide-react";
import { base44 } from "@/api/base44Client";

const TYPE_META = {
  update: { icon: Sparkles, color: "#22d3ee", label: "بروزرسانی" },
  new_series: { icon: Tv, color: "#a78bfa", label: "سریال جدید" },
  general: { icon: Info, color: "#fbbf24", label: "اعلان" },
};

function timeAgo(iso) {
  if (!iso) return "";
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "هم‌اکنون";
  if (m < 60) return `${m} دقیقه پیش`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} ساعت پیش`;
  const d = Math.floor(h / 24);
  return `${d} روز پیش`;
}

export default function NotificationBell() {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [readIds, setReadIds] = useState([]);

  useEffect(() => {
    try {
      setReadIds(JSON.parse(localStorage.getItem("ayeneh_read_notifs") || "[]"));
    } catch {}
    const load = async () => {
      try {
        const res = await base44.entities.Notification.filter({ is_active: true }, "-created_date", 30);
        setItems(res || []);
      } catch {}
    };
    load();
    let unsub;
    try {
      unsub = base44.entities.Notification.subscribe(() => { load(); });
    } catch {}
    return () => { if (unsub) unsub(); };
  }, []);

  const unread = items.filter(i => !readIds.includes(i.id));

  const markAllRead = () => {
    const merged = Array.from(new Set([...readIds, ...items.map(i => i.id)]));
    setReadIds(merged);
    localStorage.setItem("ayeneh_read_notifs", JSON.stringify(merged));
  };

  return (
    <div className="relative" style={{ direction: "rtl" }}>
      <button onClick={() => setOpen(o => !o)}
        className="relative w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
        style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(8px)" }}>
        <Bell className="w-5 h-5 text-white/80" />
        {unread.length > 0 && (
          <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
            style={{ background: "#ef4444", boxShadow: "0 0 8px rgba(239,68,68,0.6)" }}>
            {unread.length > 9 ? "9+" : unread.length}
          </span>
        )}
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute top-full mt-2 left-0 w-80 max-w-[90vw] rounded-2xl overflow-hidden z-50"
            style={{ background: "rgba(20,14,30,0.96)", border: "1px solid rgba(168,85,247,0.3)", backdropFilter: "blur(20px)", boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
            <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-purple-300" />
                <h3 className="text-white font-bold text-sm">اعلان‌ها</h3>
                {unread.length > 0 && <span className="text-purple-300/70 text-xs">({unread.length} جدید)</span>}
              </div>
              {unread.length > 0 && (
                <button onClick={markAllRead} className="flex items-center gap-1 text-xs text-cyan-300/80 hover:text-cyan-300">
                  <Check className="w-3.5 h-3.5" /> خواندن همه
                </button>
              )}
            </div>

            <div className="max-h-[360px] overflow-y-auto">
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
                  <Bell className="w-9 h-9 text-white/15 mb-2" />
                  <p className="text-white/40 text-sm">اعلانی وجود ندارد</p>
                </div>
              ) : (
                items.map(n => {
                  const isUnread = !readIds.includes(n.id);
                  const meta = TYPE_META[n.type] || TYPE_META.general;
                  const Icon = meta.icon;
                  return (
                    <div key={n.id} className="flex gap-3 px-4 py-3 transition-colors hover:bg-white/5"
                      style={{ borderBottom: "1px solid rgba(255,255,255,0.04)", background: isUnread ? "rgba(168,85,247,0.06)" : "transparent" }}>
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: `${meta.color}22`, border: `1px solid ${meta.color}44` }}>
                        <Icon className="w-4 h-4" style={{ color: meta.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-white text-sm font-bold truncate">{n.title}</p>
                          {isUnread && <span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />}
                        </div>
                        {n.body && <p className="text-white/55 text-xs mt-1 leading-relaxed">{n.body}</p>}
                        <p className="text-white/30 text-[10px] mt-1.5">{timeAgo(n.created_date)}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}