import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";

// Unified native-style navigation header: a back chevron + screen title.
// Pops the browser history stack when available (respects the hardware/Android
// back gesture natively), falling back to `fallbackTo` (defaults to "/").
// RTL is auto-detected from the app language/rtl setting unless overridden.
function readRtl() {
  try {
    const s = JSON.parse(localStorage.getItem("ayeneh_settings") || "{}");
    return s.language === "fa" || s.rtl === true;
  } catch { return false; }
}

export default function NavHeader({ title, fallbackTo = "/", rtl, className = "", children }) {
  const navigate = useNavigate();
  const isRtl = rtl !== undefined ? rtl : readRtl();
  const goBack = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate(fallbackTo, { replace: true });
  };
  return (
    <div
      className={`flex items-center gap-3 flex-shrink-0 z-20 ${className}`}
      dir={isRtl ? "rtl" : "ltr"}
      style={{
        height: "calc(56px + env(safe-area-inset-top))",
        background: "rgb(var(--chrome-bg-rgb) / 0.92)",
        backdropFilter: "blur(18px) saturate(1.3)",
        WebkitBackdropFilter: "blur(18px) saturate(1.3)",
        borderBottom: "1px solid rgb(var(--chrome-border-rgb) / 0.08)",
        paddingTop: "env(safe-area-inset-top)",
        paddingLeft: "calc(1rem + env(safe-area-inset-left))",
        paddingRight: "calc(1rem + env(safe-area-inset-right))",
      }}
    >
      <button onClick={goBack} aria-label="Back"
        className="rounded-lg text-muted-foreground hover:text-foreground hover:bg-foreground/10 transition-colors flex-shrink-0 flex items-center justify-center"
        style={{ minWidth: 44, minHeight: 44 }}>
        <ChevronLeft className="w-6 h-6" style={{ transform: isRtl ? "rotate(180deg)" : "none" }} />
      </button>
      <h1 className="text-foreground font-bold text-base truncate flex-1">{title}</h1>
      {children}
    </div>
  );
}