import { useLocation, useNavigate } from "react-router-dom";
import { Home, Tv, Clapperboard, Star, Settings as SettingsIcon, Search } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

const TABS = [
  { to: "/", icon: Home, labelFa: "خانه", labelEn: "Home" },
  { to: "/Home", icon: Tv, labelFa: "تلویزیون", labelEn: "Live TV" },
  { to: "/Media", icon: Clapperboard, labelFa: "سریال‌ها", labelEn: "Media" },
  { to: "/Search", icon: Search, labelFa: "جستجو", labelEn: "Search" },
  { to: "/Favorites", icon: Star, labelFa: "علاقه‌مندی", labelEn: "Favorites" },
  { to: "/Settings", icon: SettingsIcon, labelFa: "تنظیمات", labelEn: "Settings" },
];

function readLang() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"; } catch { return true; }
}

/**
 * TV Shell — persistent top navigation bar optimized for Android TV / TV box.
 * Large icons + labels, D-pad navigable, auto-hides on the Entry (home) page
 * which has its own NavCards.
 */
export default function TVShell({ children }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const isFa = readLang();
  const dir = isFa ? "rtl" : "ltr";

  // Don't show the nav bar on the Entry page — it has its own NavCards
  const showNav = pathname !== "/";

  return (
    <div className="flex flex-col h-[100dvh] w-full overflow-hidden" dir={dir}>
      {showNav && (
        <nav
          className="flex items-center gap-1 px-4 flex-shrink-0 z-40"
          style={{
            background: "rgba(8,11,20,0.95)",
            backdropFilter: "blur(18px)",
            WebkitBackdropFilter: "blur(18px)",
            borderBottom: "1px solid rgba(255,255,255,0.08)",
            height: "clamp(64px, 7vh, 80px)",
            paddingTop: "env(safe-area-inset-top)",
          }}
        >
          {/* Logo — click to go home */}
          <button
            data-remote
            onClick={() => navigate("/")}
            className="flex items-center gap-3 mx-3 flex-shrink-0"
          >
            <img
              src={LOGO_URL}
              alt="Asemanak TV"
              className="w-10 h-10 rounded-xl object-cover"
            />
          </button>

          {/* Nav items */}
          <div className="flex items-center gap-1 flex-1">
            {TABS.map((t) => {
              const active = pathname === t.to || (t.to !== "/" && pathname.startsWith(t.to));
              const Icon = t.icon;
              return (
                <button
                  key={t.to}
                  onClick={() => navigate(t.to)}
                  data-remote
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                    active
                      ? "bg-cyan-500/20 text-cyan-300"
                      : "text-white/60 hover:text-white hover:bg-white/5"
                  }`}
                  style={
                    active
                      ? { boxShadow: "0 0 16px rgba(34,211,238,0.3)" }
                      : {}
                  }
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <span className="text-base font-medium">
                    {isFa ? t.labelFa : t.labelEn}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      )}
      <div className="flex-1 relative overflow-hidden min-h-0">{children}</div>
    </div>
  );
}