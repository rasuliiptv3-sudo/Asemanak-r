import { Link, useLocation } from "react-router-dom";
import { Tv, Home, Grid3X3, Star, Search, Menu, X } from "lucide-react";
import { useState } from "react";

const navLinks = [
  { label: "Home", labelFa: "خانه", path: "/Home", icon: Home },
  { label: "Channels", labelFa: "کانال‌ها", path: "/Channels", icon: Grid3X3 },
  { label: "Favorites", labelFa: "علاقه‌مندی", path: "/Favorites", icon: Star },
];

export default function Navbar() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/Home" className="flex items-center gap-2">
          <div className="relative w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center shadow-lg shadow-cyan-500/30" style={{ boxShadow: "0 0 12px rgba(0,242,255,0.25)" }}>
            <img src="https://media.base44.com/images/public/69bb192550659e77af7bd3fe/266732b00_IMG_8638.png" alt="Asemanak TV" className="w-full h-full object-cover" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-xs text-cyan-400/60 font-vazir">آسمانک تی وی</span>
            <span className="text-sm font-bold text-white tracking-wide">ASEMANAK TV</span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {navLinks.map(({ label, labelFa, path, icon: Icon }) => (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                location.pathname === path
                  ? "bg-primary/20 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </Link>
          ))}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2">
          <Link to="/Channels" className="hidden md:flex items-center gap-2 bg-primary hover:bg-primary/80 text-white text-sm font-medium px-4 py-2 rounded-lg transition-all">
            <Search className="w-4 h-4" />
            Search
          </Link>
          <button className="md:hidden p-2 text-muted-foreground" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl px-4 py-3 space-y-1">
          {navLinks.map(({ label, path, icon: Icon }) => (
            <Link
              key={path}
              to={path}
              onClick={() => setMenuOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                location.pathname === path
                  ? "bg-primary/20 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}