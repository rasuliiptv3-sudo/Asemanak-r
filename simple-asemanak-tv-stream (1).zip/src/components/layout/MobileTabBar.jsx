import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Tv, Clapperboard, Star, Settings as SettingsIcon } from "lucide-react";

const TABS = [
  { id: "tv",      to: "/Home",      icon: Tv,            labelFa: "تلویزیون", labelEn: "TV" },
  { id: "media",   to: "/Media",     icon: Clapperboard,  labelFa: "سریال‌ها", labelEn: "Media" },
  { id: "fav",     to: "/Favorites", icon: Star,          labelFa: "علاقه‌مندی", labelEn: "Favorites" },
  { id: "settings",to: "/Settings", icon: SettingsIcon,  labelFa: "تنظیمات", labelEn: "Settings" },
];

function readLang() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"; } catch { return true; }
}

function tabIdForPath(pathname) {
  const t = TABS.find((t) => pathname === t.to || pathname.startsWith(t.to + "/"));
  return t ? t.id : null;
}

export default function MobileTabBar() {
  const { pathname, search } = useLocation();
  const navigate = useNavigate();
  const isFa = readLang();
  const dir = isFa ? "rtl" : "ltr";

  // Hide the tab bar on media-player screens and while a video is fullscreen on
  // Media, so it never overlaps a fullscreen video.
  const [isFullscreen, setIsFullscreen] = useState(false);
  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    onFs();
    document.addEventListener("fullscreenchange", onFs);
    document.addEventListener("webkitfullscreenchange", onFs);
    return () => {
      document.removeEventListener("fullscreenchange", onFs);
      document.removeEventListener("webkitfullscreenchange", onFs);
    };
  }, []);

  // Per-tab history stack: each tab remembers the last URL visited while it was active,
  // so switching tabs restores that tab's view instead of always jumping to its root.
  const tabHistory = useRef(Object.fromEntries(TABS.map((t) => [t.id, t.to])));

  useEffect(() => {
    const id = tabIdForPath(pathname);
    if (id) tabHistory.current[id] = pathname + (search || "");
  }, [pathname, search]);

  // Hide the tab bar on media-player screens and while a video is fullscreen on Media.
  if (pathname.startsWith("/Player") || (pathname.startsWith("/Media") && isFullscreen)) return null;

  const handleSelect = (tab) => {
    const isActive = pathname === tab.to;
    if (isActive) {
      // Re-selecting the active tab resets its view to the root route.
      // replace:true avoids pushing a duplicate history entry so Back still works.
      navigate(tab.to, { replace: true });
      tabHistory.current[tab.id] = tab.to;
      window.dispatchEvent(new CustomEvent("mobile-tab-reset", { detail: { tabId: tab.id, to: tab.to } }));
    } else {
      // Switching tabs restores that tab's last URL (preserves visual history).
      navigate(tabHistory.current[tab.id] || tab.to);
    }
  };

  return (
    <nav
      role="tablist"
      aria-label={isFa ? "ناوبری اصلی" : "Main navigation"}
      className="fixed bottom-0 left-0 right-0 z-40 flex items-stretch pb-[env(safe-area-inset-bottom)] md:hidden"
      dir={dir}
      style={{
        background: "rgb(var(--chrome-bg-rgb) / 0.92)",
        backdropFilter: "blur(18px) saturate(1.3)",
        WebkitBackdropFilter: "blur(18px) saturate(1.3)",
        borderTop: "1px solid rgb(var(--chrome-border-rgb) / 0.1)",
        boxShadow: "0 -6px 24px rgba(0,0,0,0.4)",
        paddingBottom: "env(safe-area-inset-bottom)",
      }}
    >
      {TABS.map((t) => {
        const active = pathname === t.to || pathname.startsWith(t.to + "/");
        const Icon = t.icon;
        return (
          <button
            key={t.id}
            role="tab"
            aria-selected={active}
            aria-label={isFa ? t.labelFa : t.labelEn}
            onClick={() => handleSelect(t)}
            data-remote
            className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2.5 min-h-[56px] outline-none transition-colors"
            style={{ background: active ? "rgba(34,211,238,0.10)" : "transparent" }}
          >
            <Icon
              className="w-5 h-5"
              style={{
                color: active ? "#22d3ee" : "hsl(var(--muted-foreground))",
                filter: active ? "drop-shadow(0 0 6px rgba(34,211,238,0.6))" : "none",
              }}
            />
            <span
              className="text-[0.875rem] font-semibold leading-none"
              style={{ color: active ? "#22d3ee" : "hsl(var(--muted-foreground))" }}
            >
              {isFa ? t.labelFa : t.labelEn}
            </span>
          </button>
        );
      })}
    </nav>
  );
}