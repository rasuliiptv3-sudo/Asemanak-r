import { useEffect, useRef, useState } from "react";
import { Tv, Volume2, Wifi, Sparkles } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

export default function SplashScreen({ onDone }) {
  const [phase, setPhase] = useState("enter");
  const [progress, setProgress] = useState(0);
  // Keep onDone in a ref so the effect runs exactly once on mount — if the
  // parent re-renders (e.g. auth state loads) and passes a new onDone function,
  // the timers and progress bar won't reset, which was causing an infinite loop.
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  useEffect(() => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      try { sessionStorage.setItem("ayeneh_splash_done", "true"); } catch {}
      onDoneRef.current();
    };

    const t1 = setTimeout(() => setPhase("hold"), 300);
    // Use setInterval instead of requestAnimationFrame — rAF is unreliable
    // on many Android TV box WebViews (throttled or never fires), which was
    // causing the splash to freeze mid-animation. setInterval is reliable.
    const start = Date.now();
    const dur = 3500;
    const iv = setInterval(() => {
      const elapsed = Date.now() - start;
      const pct = Math.min(100, Math.round((elapsed / dur) * 100));
      setProgress(pct);
      if (pct >= 100) clearInterval(iv);
    }, 50);
    const t2 = setTimeout(() => setPhase("exit"), 3800);
    // Hard fallback — always fires even if timers are throttled
    const t3 = setTimeout(finish, 4200);

    // Allow skip on click / keypress (TV remote OK button) — matches the
    // "Click anywhere or press any key to start" hint at the bottom.
    // ALSO: on the first key press, enter fullscreen + lock landscape — this is
    // critical for Android TV boxes whose WebView starts in portrait.
    const skip = () => {
      try {
        const el = document.documentElement;
        if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen().catch(() => {});
        if (screen.orientation && screen.orientation.lock) screen.orientation.lock("landscape").catch(() => {});
      } catch {}
      finish();
    };
    window.addEventListener("click", skip, { once: true });
    window.addEventListener("keydown", skip, { once: true });

    return () => {
      clearInterval(iv);
      clearTimeout(t1); clearTimeout(t2); clearTimeout(t3);
      window.removeEventListener("click", skip);
      window.removeEventListener("keydown", skip);
    };
  }, []);

  const entered = phase !== "enter";

  // Twinkling stars
  const stars = Array.from({ length: 50 }, (_, i) => ({
    top: (i * 3.7 + 5) % 96,
    left: (i * 6.3 + 3) % 97,
    size: i % 5 === 0 ? 2.5 : i % 3 === 0 ? 2 : 1,
    delay: (i * 0.09) % 5,
    duration: 2 + (i % 4),
  }));

  return (
    <div
      style={{
        position: "fixed", inset: 0, zIndex: 9999,
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
        overflow: "hidden",
        opacity: phase === "exit" ? 0 : 1,
        transition: phase === "exit" ? "opacity 0.8s ease-in-out" : "none",
        background: "radial-gradient(ellipse 120% 100% at 50% 50%, #1a0b2e 0%, #050308 70%, #000000 100%)",
        contain: "layout style paint",
      }}
    >
      {/* Stars */}
      {stars.map((s, i) => (
        <div key={`star-${i}`} style={{
          position: "absolute",
          width: s.size, height: s.size,
          borderRadius: "50%", background: "#fff",
          top: `${s.top}%`, left: `${s.left}%`,
          opacity: 0,
          boxShadow: s.size > 2 ? "0 0 8px rgba(255,255,255,0.8)" : "none",
          animation: `twinkle ${s.duration}s ease-in-out ${s.delay}s infinite`,
          zIndex: 2,
        }} />
      ))}

      {/* ── Central logo container (rounded square, glass-morphism) ── */}
      <div style={{
        position: "relative", zIndex: 10,
        marginBottom: 28,
        opacity: entered ? 1 : 0,
        transform: entered ? "scale(1)" : "scale(0.6)",
        transition: "transform 1.2s cubic-bezier(0.34,1.56,0.64,1), opacity 1s ease-out",
      }}>
        <div style={{
          width: "clamp(110px, 16vw, 150px)",
          height: "clamp(110px, 16vw, 150px)",
          borderRadius: "28px",
          background: "linear-gradient(135deg, rgba(30,20,45,0.8), rgba(10,5,20,0.9))",
          border: "1.5px solid rgba(168,85,247,0.5)",
          boxShadow: "0 0 40px rgba(168,85,247,0.35), 0 0 80px rgba(168,85,247,0.15), inset 0 0 30px rgba(168,85,247,0.08)",
          backdropFilter: "blur(20px)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          {/* Asemanak gradient squircle with white "A" */}
          <div style={{
            width: "78%", height: "78%", borderRadius: "28%",
            background: "linear-gradient(135deg, #E038F6 0%, #6B54FF 100%)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 0 30px rgba(107,84,255,0.6), 0 0 60px rgba(224,56,246,0.3), inset 0 2px 0 rgba(255,255,255,0.25)",
          }}>
            <span style={{
              color: "#ffffff", fontWeight: 900,
              fontSize: "clamp(48px, 7vw, 72px)",
              fontFamily: "Inter, sans-serif", lineHeight: 1,
              textShadow: "0 2px 8px rgba(0,0,0,0.2)",
            }}>A</span>
          </div>
        </div>
      </div>

      {/* ── Brand title ── */}
      <div style={{
        position: "relative", zIndex: 10, textAlign: "center",
        opacity: entered ? 1 : 0,
        transform: entered ? "translateY(0)" : "translateY(20px)",
        transition: "transform 1s ease-out 0.3s, opacity 1s ease-out 0.3s",
      }}>
        <h1 style={{
          margin: 0, fontFamily: "Inter, sans-serif",
          fontSize: "clamp(30px, 5.5vw, 48px)",
          fontWeight: 900, letterSpacing: "0.06em",
          textShadow: "0 0 24px rgba(168,85,247,0.5)",
        }}>
          <span style={{ color: "#ffffff" }}>Asemanak</span>
          <span style={{ color: "#c77dff" }}> TV</span>
        </h1>

        {/* Subtitle + 4K HDR badge */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 14 }}>
          <span style={{
            color: "#9ca3af", fontSize: "clamp(10px, 1.4vw, 13px)",
            fontFamily: "Inter, sans-serif", fontWeight: 600,
            letterSpacing: "0.18em", textTransform: "uppercase",
          }}>Smart Entertainment OS</span>
          <span style={{ width: 4, height: 4, borderRadius: "50%", background: "#a855f7", boxShadow: "0 0 6px rgba(168,85,247,0.8)" }} />
          <span style={{
            background: "rgba(168,85,247,0.25)",
            border: "1px solid rgba(168,85,247,0.4)",
            color: "#fff", fontSize: "clamp(9px, 1.1vw, 11px)",
            fontWeight: 700, letterSpacing: "0.08em",
            padding: "3px 8px", borderRadius: 6,
          }}>4K HDR</span>
        </div>
      </div>

      {/* ── Progress bar + loading text ── */}
      <div style={{
        position: "relative", zIndex: 10, marginTop: 36,
        width: "clamp(240px, 36vw, 380px)",
        opacity: entered ? 1 : 0,
        transition: "opacity 0.8s ease 0.6s",
      }}>
        <div style={{
          width: "100%", height: 3, borderRadius: 99,
          background: "rgba(255,255,255,0.08)", overflow: "hidden",
        }}>
          <div style={{
            height: "100%", width: `${progress}%`, borderRadius: 99,
            background: "linear-gradient(90deg, #a855f7, #ec4899)",
            boxShadow: "0 0 12px rgba(168,85,247,0.8)",
            transition: "width 0.1s linear",
          }} />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10 }}>
          <span style={{
            color: "#9ca3af", fontSize: "clamp(10px, 1.3vw, 12px)",
            fontFamily: "Inter, sans-serif", letterSpacing: "0.04em",
          }}>Connecting Smart TV & Dolby Atmos...</span>
          <span style={{
            color: "#9ca3af", fontSize: "clamp(10px, 1.3vw, 12px)",
            fontFamily: "Inter, sans-serif", fontWeight: 600,
          }}>{progress}%</span>
        </div>
      </div>

      {/* ── CTA pill ── */}
      <div style={{
        position: "relative", zIndex: 10, marginTop: 32,
        opacity: entered ? 1 : 0,
        transition: "opacity 0.8s ease 0.9s",
      }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "12px 28px", borderRadius: 99,
          background: "rgba(168,85,247,0.12)",
          border: "1px solid rgba(168,85,247,0.4)",
          boxShadow: "0 0 20px rgba(168,85,247,0.2), inset 0 0 12px rgba(168,85,247,0.05)",
          backdropFilter: "blur(12px)",
        }}>
          <Sparkles style={{ width: 16, height: 16, color: "#c77dff" }} />
          <span style={{
            color: "#e9d5ff", fontSize: "clamp(12px, 1.5vw, 15px)",
            fontFamily: "Inter, sans-serif", fontWeight: 500,
          }}>Live tv, series, animation, and more</span>
        </div>
      </div>

      {/* ── Feature bar ── */}
      <div style={{
        position: "relative", zIndex: 10, marginTop: 28,
        display: "flex", alignItems: "center", gap: 20,
        opacity: entered ? 1 : 0,
        transition: "opacity 0.8s ease 1.1s",
      }}>
        <FeatureItem icon={<Tv style={{ width: 14, height: 14 }} />} label="4K Ultra HD" />
        <Dot />
        <FeatureItem icon={<Volume2 style={{ width: 14, height: 14 }} />} label="Dolby Atmos" />
        <Dot />
        <FeatureItem icon={<Wifi style={{ width: 14, height: 14 }} />} label="Connected" />
      </div>

      {/* ── Footer instruction ── */}
      <div style={{
        position: "absolute", bottom: "6%", zIndex: 10,
        opacity: entered ? 1 : 0,
        transition: "opacity 0.8s ease 1.3s",
      }}>
        <div style={{
          padding: "10px 22px", borderRadius: 99,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.15)",
        }}>
          <span style={{
            color: "#9ca3af", fontSize: "clamp(11px, 1.3vw, 13px)",
            fontFamily: "Inter, sans-serif", fontWeight: 500, letterSpacing: "0.04em",
          }}>Click anywhere or press any key to start</span>
        </div>
      </div>

      <style>{`
        @keyframes twinkle { 0%,100% { opacity: 0.1; } 50% { opacity: 0.9; } }
      `}</style>
      {/* Click/tap overlay to catch skip events on touch devices */}
      <div style={{ position: "absolute", inset: 0, zIndex: 9998, cursor: "pointer" }}
        onClick={() => onDoneRef.current()} />
    </div>
  );
}

function FeatureItem({ icon, label }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <span style={{ color: "#9ca3af", display: "flex" }}>{icon}</span>
      <span style={{
        color: "#9ca3af", fontSize: "clamp(10px, 1.2vw, 12px)",
        fontFamily: "Inter, sans-serif", fontWeight: 500, letterSpacing: "0.04em",
      }}>{label}</span>
    </div>
  );
}

function Dot() {
  return <span style={{ width: 3, height: 3, borderRadius: "50%", background: "rgba(255,255,255,0.2)" }} />;
}