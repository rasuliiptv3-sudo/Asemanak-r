import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

export default function TVTopBar({ title, isFa = true }) {
  const navigate = useNavigate();
  const goBack = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate("/", { replace: true });
  };

  return (
    <div
      className="flex items-center gap-6 flex-shrink-0 z-30"
      dir={isFa ? "rtl" : "ltr"}
      style={{
        height: "clamp(72px, 8vh, 96px)",
        padding: "0 clamp(24px, 4vw, 64px)",
        paddingTop: "env(safe-area-inset-top)",
        background: "linear-gradient(180deg, rgba(8,0,15,0.95) 0%, rgba(8,0,15,0.7) 100%)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <button
        onClick={goBack}
        data-remote
        aria-label={isFa ? "بازگشت" : "Back"}
        className="flex items-center gap-3 rounded-2xl px-6 py-3 transition-all hover:bg-white/10"
        style={{ minHeight: "56px" }}
      >
        <ChevronLeft className="w-8 h-8 text-white" style={{ transform: isFa ? "rotate(180deg)" : "none" }} />
        <span className="text-xl font-bold text-white/80">{isFa ? "بازگشت" : "Back"}</span>
      </button>
      <div className="flex-1" />
      <img src={LOGO_URL} alt="Asemanak TV" className="w-12 h-12 rounded-xl object-cover" />
    </div>
  );
}