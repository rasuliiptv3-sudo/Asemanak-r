import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import { ChevronDown, LogOut, Trash2, Crown, Shield, Sparkles, MessageSquare, Trash, Palette, X } from "lucide-react";
import DeleteAccountModal from "@/components/settings/DeleteAccountModal";
import FeedbackModal from "@/components/settings/FeedbackModal";
import { clearAppCache, getActiveSeason } from "@/lib/seasonalTheme";

// Gmail-style avatar colors based on the first letter
const AVATAR_COLORS = [
  ["#ea4335", "#c5221f"],
  ["#4285f4", "#1a73e8"],
  ["#34a853", "#188038"],
  ["#fbbc04", "#f9a825"],
  ["#a142f4", "#8430ce"],
  ["#ff6d01", "#e8590c"],
];

function avatarStyle(name) {
  const letter = (name || "?").trim().charAt(0).toUpperCase();
  const idx = letter.charCodeAt(0) % AVATAR_COLORS.length;
  const [c1, c2] = AVATAR_COLORS[idx];
  return { letter, gradient: `linear-gradient(135deg, ${c1}, ${c2})` };
}

export default function ProfileBadge() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteError, setDeleteError] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [cacheClearing, setCacheClearing] = useState(false);
  const [cacheCleared, setCacheCleared] = useState(false);
  const [showThemes, setShowThemes] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("touchstart", onDoc);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("touchstart", onDoc);
    };
  }, []);

  if (!user) return null;
  const av = avatarStyle(user.full_name || user.email);

  const handleDelete = async () => {
    setDeleting(true);
    setDeleteError(null);
    try {
      await base44.functions.invoke("deleteAccount", {});
      logout(false);
      base44.auth.logout(window.location.origin);
    } catch (e) {
      setDeleteError(e?.message || "خطا");
      setDeleting(false);
    }
  };

  return (
    <div ref={ref} className="relative" style={{ direction: "ltr" }}>
      {/* Collapsed badge */}
      <button id="top-profile" data-remote aria-label={user.full_name || user.email || "Profile"} onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2.5 pl-2.5 pr-1.5 py-1.5 rounded-full transition-all hover:scale-105"
        style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(8px)" }}>
        <div className="relative flex-shrink-0">
          <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
            style={{ background: av.gradient, boxShadow: "0 2px 10px rgba(0,0,0,0.35)" }}>
            {av.letter}
          </div>
          <Crown className="absolute -top-2 -right-1 w-5 h-5 text-amber-400" style={{ filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.5))" }} />
        </div>
        <div className="leading-tight text-left hidden sm:block">
          <p className="text-white text-base font-bold max-w-[160px] truncate">{user.full_name || "کاربر"}</p>
          <p className="text-amber-300/80 text-[13px] max-w-[160px] truncate flex items-center gap-1"><Sparkles className="w-3.5 h-3.5" /> اشتراک ویژه</p>
        </div>
        <ChevronDown className="w-6 h-6 text-white/50" />
      </button>

      {/* Expanded panel */}
      {open && (
        <div className="absolute top-full mt-2 right-0 w-72 rounded-2xl overflow-hidden z-50"
          style={{ background: "rgba(20,14,30,0.95)", border: "1px solid rgba(168,85,247,0.3)", backdropFilter: "blur(20px)", boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
          {/* Header */}
          <div className="flex items-center gap-3 p-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0"
              style={{ background: av.gradient, boxShadow: "0 4px 14px rgba(0,0,0,0.35)" }}>
              {av.letter}
            </div>
            <div className="leading-tight flex-1 min-w-0">
              <p className="text-white font-bold text-sm truncate">{user.full_name || "کاربر"}</p>
              <div className="flex items-center gap-1 mt-0.5">
                <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0" />
                <p className="text-amber-300/80 text-xs truncate">اشتراک ویژه</p>
              </div>
            </div>
          </div>

          {/* Role badge */}
          <div className="flex items-center gap-2 px-4 py-2.5" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
            <Shield className="w-3.5 h-3.5 text-purple-300/70" />
            <span className="text-white/60 text-xs">{user.role === "admin" ? "مدیر" : "کاربر"}</span>
          </div>

          {/* Actions */}
          <div className="p-2">
            {/* نظریات کاربران — User Comments */}
            <button onClick={() => { setShowFeedback(true); setOpen(false); }} data-remote
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/80 text-sm transition-colors hover:bg-white/5">
              <MessageSquare className="w-4 h-4 text-cyan-400/80" />
              نظریات کاربران
            </button>

            {/* حافظه پنهان — Clear Cache */}
            <button onClick={async () => {
                if (cacheClearing) return;
                setCacheClearing(true);
                await clearAppCache();
                setCacheClearing(false);
                setCacheCleared(true);
                setTimeout(() => setCacheCleared(false), 3000);
              }}
              disabled={cacheClearing} data-remote
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/80 text-sm transition-colors hover:bg-white/5 disabled:opacity-50">
              <Trash className={`w-4 h-4 text-white/60 ${cacheClearing ? "animate-spin" : ""}`} />
              {cacheClearing ? "در حال پاکسازی..." : cacheCleared ? "پاکسازی شد ✓" : "حافظه پنهان"}
            </button>

            {/* تم‌های مناسبتی — Seasonal Themes */}
            <button onClick={() => { setShowThemes(true); }} data-remote
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/80 text-sm transition-colors hover:bg-white/5">
              <Palette className="w-4 h-4 text-purple-400/80" />
              تم‌های مناسبتی
            </button>

            {/* Divider */}
            <div className="my-1.5 h-px" style={{ background: "rgba(255,255,255,0.06)" }} />

            <button onClick={() => logout()} data-remote
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/80 text-sm transition-colors hover:bg-white/5">
              <LogOut className="w-4 h-4 text-white/60" />
              خروج از حساب
            </button>
            <button onClick={() => { setDeleteError(null); setShowDeleteModal(true); }} disabled={deleting} data-remote
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-300 text-sm transition-colors hover:bg-red-500/10 disabled:opacity-50">
              <Trash2 className="w-4 h-4 text-red-400" />
              {deleting ? "در حال حذف..." : "حذف حساب"}
            </button>
          </div>
        </div>
      )}

      <DeleteAccountModal
        open={showDeleteModal}
        loading={deleting}
        error={deleteError}
        onClose={() => { if (!deleting) { setShowDeleteModal(false); setDeleteError(null); } }}
        onConfirm={handleDelete}
      />

      {/* User Comments Modal */}
      {showFeedback && <FeedbackModal onClose={() => setShowFeedback(false)} />}

      {/* Seasonal Themes Modal */}
      {showThemes && <SeasonalThemeModal onClose={() => setShowThemes(false)} />}
    </div>
  );
}

function SeasonalThemeModal({ onClose }) {
  const season = getActiveSeason();
  const [enabled, setEnabled] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").seasonalThemes !== false; } catch { return true; }
  });

  const toggle = () => {
    const next = !enabled;
    setEnabled(next);
    try {
      const s = JSON.parse(localStorage.getItem("ayeneh_settings") || "{}");
      s.seasonalThemes = next;
      localStorage.setItem("ayeneh_settings", JSON.stringify(s));
    } catch {}
    window.dispatchEvent(new Event("ayeneh-settings-changed"));
    if (next) window.location.reload();
    else window.location.reload();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-sm rounded-2xl overflow-hidden"
        style={{ background: "rgba(20,14,30,0.98)", border: "1px solid rgba(168,85,247,0.3)", boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <h2 className="text-white font-bold text-base">تم‌های مناسبتی</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors">
            <X className="w-4 h-4 text-white/60" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {season ? (
            <div className="rounded-xl p-4 text-center" style={{ background: season.glow || "rgba(168,85,247,0.15)", border: "1px solid rgba(255,255,255,0.1)" }}>
              <div className="text-4xl mb-2">{season.icon}</div>
              <p className="text-white font-bold text-lg">{season.name}</p>
              <p className="text-white/50 text-xs mt-1">{season.nameEn}</p>
              <p className="text-cyan-300/70 text-xs mt-2">مناسبت فعال است ✓</p>
            </div>
          ) : (
            <div className="rounded-xl p-4 text-center" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <p className="text-white/40 text-sm">در حال حاضر مناسبت فعالی فعال نیست</p>
              <p className="text-white/30 text-xs mt-1">در ایام خاص تم به صورت خودکار تغییر می‌کند</p>
            </div>
          )}

          {/* Toggle */}
          <button onClick={toggle}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors"
            style={{ background: enabled ? "rgba(34,197,94,0.15)" : "rgba(255,255,255,0.05)", border: `1px solid ${enabled ? "rgba(34,197,94,0.3)" : "rgba(255,255,255,0.1)"}` }}>
            <span className="text-white text-sm font-medium">فعال‌سازی تم‌های خودکار</span>
            <div className="w-10 h-6 rounded-full flex items-center transition-colors" style={{ background: enabled ? "rgba(34,197,94,0.5)" : "rgba(255,255,255,0.15)" }}>
              <div className="w-5 h-5 rounded-full bg-white transition-transform" style={{ transform: enabled ? "translateX(20px)" : "translateX(2px)" }} />
            </div>
          </button>

          {/* Supported occasions list */}
          <div className="space-y-1.5">
            <p className="text-white/40 text-xs font-bold uppercase tracking-wider">مناسبت‌های پشتیبانی شده</p>
            {[
              { icon: "🌿", name: "نوروز" },
              { icon: "🌙", name: "عید فطر / قربان" },
              { icon: "🍉", name: "شب یلدا" },
              { icon: "🎉", name: "سال نو" },
              { icon: "❤️", name: "ولنتاین" },
              { icon: "☀️", name: "تابستان" },
            ].map(occ => (
              <div key={occ.name} className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ background: "rgba(255,255,255,0.03)" }}>
                <span className="text-sm">{occ.icon}</span>
                <span className="text-white/50 text-xs">{occ.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}