import { useState, useEffect } from "react";

// Comprehensive list of world country/city timezones (IANA)
export const TIMEZONES = [
  // Iran & Afghanistan
  { value: "Asia/Tehran", labelFa: "ایران (تهران)", labelEn: "Iran (Tehran)" },
  { value: "Asia/Kabul", labelFa: "افغانستان (کابل)", labelEn: "Afghanistan (Kabul)" },
  // Middle East
  { value: "Asia/Dubai", labelFa: "امارات (دبی)", labelEn: "UAE (Dubai)" },
  { value: "Asia/Doha", labelFa: "قطر (دوحه)", labelEn: "Qatar (Doha)" },
  { value: "Asia/Riyadh", labelFa: "عربستان (ریاض)", labelEn: "Saudi Arabia (Riyadh)" },
  { value: "Asia/Kuwait", labelFa: "کویت", labelEn: "Kuwait" },
  { value: "Asia/Bahrain", labelFa: "بحرین (منامه)", labelEn: "Bahrain (Manama)" },
  { value: "Asia/Muscat", labelFa: "عمان (مسقط)", labelEn: "Oman (Muscat)" },
  { value: "Asia/Baghdad", labelFa: "عراق (بغداد)", labelEn: "Iraq (Baghdad)" },
  { value: "Asia/Damascus", labelFa: "سوریه (دمشق)", labelEn: "Syria (Damascus)" },
  { value: "Asia/Beirut", labelFa: "لبنان (بیروت)", labelEn: "Lebanon (Beirut)" },
  { value: "Asia/Jerusalem", labelFa: "فلسطین (قدس)", labelEn: "Palestine (Jerusalem)" },
  { value: "Asia/Amman", labelFa: "اردن (عمّان)", labelEn: "Jordan (Amman)" },
  { value: "Asia/Aden", labelFa: "یمن (عدن)", labelEn: "Yemen (Aden)" },
  // Central Asia
  { value: "Asia/Tashkent", labelFa: "ازبکستان (تاشکند)", labelEn: "Uzbekistan (Tashkent)" },
  { value: "Asia/Almaty", labelFa: "قزاقستان (آلماتی)", labelEn: "Kazakhstan (Almaty)" },
  { value: "Asia/Bishkek", labelFa: "قرقیزستان (بیشکک)", labelEn: "Kyrgyzstan (Bishkek)" },
  { value: "Asia/Dushanbe", labelFa: "تاجیکستان (دوشنبه)", labelEn: "Tajikistan (Dushanbe)" },
  { value: "Asia/Ashgabat", labelFa: "ترکمنستان (عشق‌آباد)", labelEn: "Turkmenistan (Ashgabat)" },
  // South Asia
  { value: "Asia/Karachi", labelFa: "پاکستان (کراچی)", labelEn: "Pakistan (Karachi)" },
  { value: "Asia/Kolkata", labelFa: "هند (کلکته)", labelEn: "India (Kolkata)" },
  { value: "Asia/Colombo", labelFa: "سری‌لانکا (کلمبو)", labelEn: "Sri Lanka (Colombo)" },
  { value: "Asia/Dhaka", labelFa: "بنگلادش (داکا)", labelEn: "Bangladesh (Dhaka)" },
  { value: "Asia/Kathmandu", labelFa: "نپال (کاتماندو)", labelEn: "Nepal (Kathmandu)" },
  { value: "Asia/Thimphu", labelFa: "بوتان (تیمفو)", labelEn: "Bhutan (Thimphu)" },
  { value: "Asia/Male", labelFa: "مالدیو (ماله)", labelEn: "Maldives (Male)" },
  // Southeast Asia
  { value: "Asia/Bangkok", labelFa: "تایلند (بانکوک)", labelEn: "Thailand (Bangkok)" },
  { value: "Asia/Jakarta", labelFa: "اندونزی (جاکارتا)", labelEn: "Indonesia (Jakarta)" },
  { value: "Asia/Kuala_Lumpur", labelFa: "مالزی (کوالالامپور)", labelEn: "Malaysia (Kuala Lumpur)" },
  { value: "Asia/Singapore", labelFa: "سنگاپور", labelEn: "Singapore" },
  { value: "Asia/Manila", labelFa: "فیلیپین (مانیل)", labelEn: "Philippines (Manila)" },
  { value: "Asia/Ho_Chi_Minh", labelFa: "ویتنام (هوشی‌مین)", labelEn: "Vietnam (Ho Chi Minh)" },
  { value: "Asia/Phnom_Penh", labelFa: "کامبوج (پنوم‌پن)", labelEn: "Cambodia (Phnom Penh)" },
  { value: "Asia/Vientiane", labelFa: "لائوس (وینتیان)", labelEn: "Laos (Vientiane)" },
  { value: "Asia/Yangon", labelFa: "میانمار (یانگون)", labelEn: "Myanmar (Yangon)" },
  { value: "Asia/Brunei", labelFa: "برونئی", labelEn: "Brunei" },
  // East Asia
  { value: "Asia/Tokyo", labelFa: "ژاپن (توکیو)", labelEn: "Japan (Tokyo)" },
  { value: "Asia/Seoul", labelFa: "کره جنوبی (سئول)", labelEn: "South Korea (Seoul)" },
  { value: "Asia/Pyongyang", labelFa: "کره شمالی (پیونگ‌یانگ)", labelEn: "North Korea (Pyongyang)" },
  { value: "Asia/Shanghai", labelFa: "چین (شانگهای)", labelEn: "China (Shanghai)" },
  { value: "Asia/Hong_Kong", labelFa: "هنگ‌کنگ", labelEn: "Hong Kong" },
  { value: "Asia/Taipei", labelFa: "تایوان (تایپه)", labelEn: "Taiwan (Taipei)" },
  { value: "Asia/Ulaanbaatar", labelFa: "مغولستان (اولان‌باتور)", labelEn: "Mongolia (Ulaanbaatar)" },
  { value: "Asia/Macau", labelFa: "ماکائو", labelEn: "Macau" },
  // Russia & Caucasus
  { value: "Europe/Moscow", labelFa: "روسیه (مسکو)", labelEn: "Russia (Moscow)" },
  { value: "Asia/Yerevan", labelFa: "ارمنستان (ایروان)", labelEn: "Armenia (Yerevan)" },
  { value: "Asia/Baku", labelFa: "آذربایجان (باکو)", labelEn: "Azerbaijan (Baku)" },
  { value: "Asia/Tbilisi", labelFa: "گرجستان (تفلیس)", labelEn: "Georgia (Tbilisi)" },
  // Europe
  { value: "Europe/London", labelFa: "انگلستان (لندن)", labelEn: "UK (London)" },
  { value: "Europe/Dublin", labelFa: "ایرلند (دوبلین)", labelEn: "Ireland (Dublin)" },
  { value: "Europe/Paris", labelFa: "فرانسه (پاریس)", labelEn: "France (Paris)" },
  { value: "Europe/Berlin", labelFa: "آلمان (برلین)", labelEn: "Germany (Berlin)" },
  { value: "Europe/Madrid", labelFa: "اسپانیا (مادرید)", labelEn: "Spain (Madrid)" },
  { value: "Europe/Rome", labelFa: "ایتالیا (رم)", labelEn: "Italy (Rome)" },
  { value: "Europe/Lisbon", labelFa: "پرتغال (لیسبون)", labelEn: "Portugal (Lisbon)" },
  { value: "Europe/Amsterdam", labelFa: "هلند (آمستردام)", labelEn: "Netherlands (Amsterdam)" },
  { value: "Europe/Brussels", labelFa: "بلژیک (بروکسل)", labelEn: "Belgium (Brussels)" },
  { value: "Europe/Vienna", labelFa: "اتریش (وین)", labelEn: "Austria (Vienna)" },
  { value: "Europe/Zurich", labelFa: "سوئیس (زوریخ)", labelEn: "Switzerland (Zurich)" },
  { value: "Europe/Stockholm", labelFa: "سوئد (استکهلم)", labelEn: "Sweden (Stockholm)" },
  { value: "Europe/Oslo", labelFa: "نروژ (اسلو)", labelEn: "Norway (Oslo)" },
  { value: "Europe/Copenhagen", labelFa: "دانمارک (کپنهاگ)", labelEn: "Denmark (Copenhagen)" },
  { value: "Europe/Helsinki", labelFa: "فنلاند (هلسینکی)", labelEn: "Finland (Helsinki)" },
  { value: "Europe/Warsaw", labelFa: "لهستان (ورشو)", labelEn: "Poland (Warsaw)" },
  { value: "Europe/Prague", labelFa: "چک (پراگ)", labelEn: "Czech Republic (Prague)" },
  { value: "Europe/Budapest", labelFa: "مجارستان (بوداپست)", labelEn: "Hungary (Budapest)" },
  { value: "Europe/Bucharest", labelFa: "رومانی (بخارست)", labelEn: "Romania (Bucharest)" },
  { value: "Europe/Athens", labelFa: "یونان (آتن)", labelEn: "Greece (Athens)" },
  { value: "Europe/Sofia", labelFa: "بلغارستان (صوفیه)", labelEn: "Bulgaria (Sofia)" },
  { value: "Europe/Belgrade", labelFa: "صربستان (بلگراد)", labelEn: "Serbia (Belgrade)" },
  { value: "Europe/Zagreb", labelFa: "کرواسی (زاگرب)", labelEn: "Croatia (Zagreb)" },
  { value: "Europe/Ljubljana", labelFa: "اسلوونی (لیوبلیانا)", labelEn: "Slovenia (Ljubljana)" },
  { value: "Europe/Sarajevo", labelFa: "بوسنی (سارایوو)", labelEn: "Bosnia (Sarajevo)" },
  { value: "Europe/Skopje", labelFa: "مقدونیه شمالی", labelEn: "North Macedonia" },
  { value: "Europe/Tirane", labelFa: "آلبانی (تیرانا)", labelEn: "Albania (Tirana)" },
  { value: "Europe/Istanbul", labelFa: "ترکیه (استانبول)", labelEn: "Turkey (Istanbul)" },
  { value: "Europe/Minsk", labelFa: "بلاروس (مینسک)", labelEn: "Belarus (Minsk)" },
  { value: "Europe/Vilnius", labelFa: "لیتوانی (ویلنیوس)", labelEn: "Lithuania (Vilnius)" },
  { value: "Europe/Riga", labelFa: "لتونی (ریگا)", labelEn: "Latvia (Riga)" },
  { value: "Europe/Tallinn", labelFa: "استونی (تالین)", labelEn: "Estonia (Tallinn)" },
  { value: "Europe/Kiev", labelFa: "اوکراین (کیف)", labelEn: "Ukraine (Kyiv)" },
  { value: "Europe/Chisinau", labelFa: "مولداوی (کیشیناو)", labelEn: "Moldova (Chisinau)" },
  { value: "Europe/Reykjavik", labelFa: "ایسلند (ریکیاویک)", labelEn: "Iceland (Reykjavik)" },
  { value: "Europe/Luxembourg", labelFa: "لوکزامبورگ", labelEn: "Luxembourg" },
  { value: "Europe/Monaco", labelFa: "موناکو", labelEn: "Monaco" },
  { value: "Europe/Malta", labelFa: "مالت", labelEn: "Malta" },
  { value: "Europe/Vatican", labelFa: "واتیکان", labelEn: "Vatican" },
  { value: "Europe/Andorra", labelFa: "آندورا", labelEn: "Andorra" },
  { value: "Europe/San_Marino", labelFa: "سان‌مارینو", labelEn: "San Marino" },
  { value: "Europe/Gibraltar", labelFa: "جبل‌الطارق", labelEn: "Gibraltar" },
  { value: "Europe/Guernsey", labelFa: "گرنزی", labelEn: "Guernsey" },
  // North America
  { value: "America/New_York", labelFa: "آمریکا (نیویورک)", labelEn: "USA (New York)" },
  { value: "America/Chicago", labelFa: "آمریکا (شیکاگو)", labelEn: "USA (Chicago)" },
  { value: "America/Denver", labelFa: "آمریکا (دنور)", labelEn: "USA (Denver)" },
  { value: "America/Los_Angeles", labelFa: "آمریکا (لس‌آنجلس)", labelEn: "USA (Los Angeles)" },
  { value: "America/Phoenix", labelFa: "آمریکا (فینیکس)", labelEn: "USA (Phoenix)" },
  { value: "America/Anchorage", labelFa: "آمریکا (انکوریج)", labelEn: "USA (Anchorage)" },
  { value: "America/Toronto", labelFa: "کانادا (تورنتو)", labelEn: "Canada (Toronto)" },
  { value: "America/Vancouver", labelFa: "کانادا (ونکوور)", labelEn: "Canada (Vancouver)" },
  { value: "America/Edmonton", labelFa: "کانادا (ادمونتون)", labelEn: "Canada (Edmonton)" },
  { value: "America/Winnipeg", labelFa: "کانادا (وینیپگ)", labelEn: "Canada (Winnipeg)" },
  { value: "America/Halifax", labelFa: "کانادا (هالیفاکس)", labelEn: "Canada (Halifax)" },
  { value: "America/Mexico_City", labelFa: "مکزیک (مکزیکوسیتی)", labelEn: "Mexico (Mexico City)" },
  // Central America & Caribbean
  { value: "America/Guatemala", labelFa: "گواتمالا", labelEn: "Guatemala" },
  { value: "America/Tegucigalpa", labelFa: "هندوراس", labelEn: "Honduras" },
  { value: "America/El_Salvador", labelFa: "ال‌سالوادور", labelEn: "El Salvador" },
  { value: "America/Managua", labelFa: "نیکاراگوئه", labelEn: "Nicaragua" },
  { value: "America/Costa_Rica", labelFa: "کاستاریکا", labelEn: "Costa Rica" },
  { value: "America/Panama", labelFa: "پاناما", labelEn: "Panama" },
  { value: "America/Havana", labelFa: "کوبا (هاوانا)", labelEn: "Cuba (Havana)" },
  { value: "America/Santo_Domingo", labelFa: "جمهوری دومینیکن", labelEn: "Dominican Republic" },
  { value: "America/Port-au-Prince", labelFa: "هائیتی", labelEn: "Haiti" },
  { value: "America/Jamaica", labelFa: "جامائیکا", labelEn: "Jamaica" },
  { value: "America/Nassau", labelFa: "باهاما", labelEn: "Bahamas" },
  { value: "America/Port_of_Spain", labelFa: "ترینیداد و توباگو", labelEn: "Trinidad & Tobago" },
  { value: "America/Bridgetown", labelFa: "باربادوس", labelEn: "Barbados" },
  { value: "America/St_Johns", labelFa: "گرنادا", labelEn: "Grenada" },
  // South America
  { value: "America/Sao_Paulo", labelFa: "برزیل (سائوپائولو)", labelEn: "Brazil (São Paulo)" },
  { value: "America/Argentina/Buenos_Aires", labelFa: "آرژانتین (بوئنوس‌آیرس)", labelEn: "Argentina (Buenos Aires)" },
  { value: "America/Santiago", labelFa: "شیلی (سانتیاگو)", labelEn: "Chile (Santiago)" },
  { value: "America/Lima", labelFa: "پرو (لیما)", labelEn: "Peru (Lima)" },
  { value: "America/Bogota", labelFa: "کلمبیا (بوگوتا)", labelEn: "Colombia (Bogota)" },
  { value: "America/Caracas", labelFa: "ونزوئلا (کاراکاس)", labelEn: "Venezuela (Caracas)" },
  { value: "America/La_Paz", labelFa: "بولیوی (لاپاز)", labelEn: "Bolivia (La Paz)" },
  { value: "America/Quito", labelFa: "اکوادور (کیتو)", labelEn: "Ecuador (Quito)" },
  { value: "America/Asuncion", labelFa: "پاراگوئه (آسونسیون)", labelEn: "Paraguay (Asuncion)" },
  { value: "America/Montevideo", labelFa: "اوروگوئه (مونته‌ویدئو)", labelEn: "Uruguay (Montevideo)" },
  { value: "America/Paramaribo", labelFa: "سورینام", labelEn: "Suriname" },
  { value: "America/Cayenne", labelFa: "گویان فرانسه", labelEn: "French Guiana" },
  // Africa
  { value: "Africa/Cairo", labelFa: "مصر (قاهره)", labelEn: "Egypt (Cairo)" },
  { value: "Africa/Casablanca", labelFa: "مراکش (کازابلانکا)", labelEn: "Morocco (Casablanca)" },
  { value: "Africa/Tunis", labelFa: "تونس", labelEn: "Tunisia" },
  { value: "Africa/Algiers", labelFa: "الجزایر", labelEn: "Algeria" },
  { value: "Africa/Tripoli", labelFa: "لیبی (طرابلس)", labelEn: "Libya (Tripoli)" },
  { value: "Africa/Khartoum", labelFa: "سودان (خرطوم)", labelEn: "Sudan (Khartoum)" },
  { value: "Africa/Addis_Ababa", labelFa: "اتیوپی (آدیس‌آبابا)", labelEn: "Ethiopia (Addis Ababa)" },
  { value: "Africa/Nairobi", labelFa: "کنیا (نایروبی)", labelEn: "Kenya (Nairobi)" },
  { value: "Africa/Kampala", labelFa: "اوگاندا (کامپالا)", labelEn: "Uganda (Kampala)" },
  { value: "Africa/Dar_es_Salaam", labelFa: "تانزانیا (دارالسلام)", labelEn: "Tanzania (Dar es Salaam)" },
  { value: "Africa/Kigali", labelFa: "رواندا (کیگالی)", labelEn: "Rwanda (Kigali)" },
  { value: "Africa/Bujumbura", labelFa: "بوروندی", labelEn: "Burundi" },
  { value: "Africa/Lagos", labelFa: "نیجریه (لاگوس)", labelEn: "Nigeria (Lagos)" },
  { value: "Africa/Accra", labelFa: "غنا (آکرا)", labelEn: "Ghana (Accra)" },
  { value: "Africa/Abidjan", labelFa: "ساحل عاج (آبیجان)", labelEn: "Ivory Coast (Abidjan)" },
  { value: "Africa/Dakar", labelFa: "سنگال (داکار)", labelEn: "Senegal (Dakar)" },
  { value: "Africa/Bamako", labelFa: "مالی (باماکو)", labelEn: "Mali (Bamako)" },
  { value: "Africa/Ouagadougou", labelFa: "بورکینافاسو", labelEn: "Burkina Faso" },
  { value: "Africa/Niamey", labelFa: "نیجر", labelEn: "Niger" },
  { value: "Africa/Lome", labelFa: "توگو", labelEn: "Togo" },
  { value: "Africa/Cotonou", labelFa: "بنین", labelEn: "Benin" },
  { value: "Africa/Libreville", labelFa: "گابن", labelEn: "Gabon" },
  { value: "Africa/Douala", labelFa: "کامرون (دوالا)", labelEn: "Cameroon (Douala)" },
  { value: "Africa/Brazzaville", labelFa: "کنگو (برازاویل)", labelEn: "Congo (Brazzaville)" },
  { value: "Africa/Kinshasa", labelFa: "کنگو (کینشاسا)", labelEn: "DR Congo (Kinshasa)" },
  { value: "Africa/Luanda", labelFa: "آنگولا (لوآندا)", labelEn: "Angola (Luanda)" },
  { value: "Africa/Lusaka", labelFa: "زامبیا (لوساکا)", labelEn: "Zambia (Lusaka)" },
  { value: "Africa/Harare", labelFa: "زیمبابوه (هاراره)", labelEn: "Zimbabwe (Harare)" },
  { value: "Africa/Maputo", labelFa: "موزامبیک (ماپوتو)", labelEn: "Mozambique (Maputo)" },
  { value: "Africa/Windhoek", labelFa: "نامیبیا (ویندهوک)", labelEn: "Namibia (Windhoek)" },
  { value: "Africa/Gaborone", labelFa: "بوتسوانا", labelEn: "Botswana" },
  { value: "Africa/Maseru", labelFa: "لسوتو", labelEn: "Lesotho" },
  { value: "Africa/Mbabane", labelFa: "اسواتینی", labelEn: "Eswatini" },
  { value: "Africa/Johannesburg", labelFa: "آفریقای جنوبی (ژوهانسبورگ)", labelEn: "South Africa (Johannesburg)" },
  { value: "Africa/Antananarivo", labelFa: "ماداگاسکار", labelEn: "Madagascar" },
  { value: "Africa/Port_Louis", labelFa: "موریس", labelEn: "Mauritius" },
  { value: "Africa/Asmara", labelFa: "اریتره (اسمارا)", labelEn: "Eritrea (Asmara)" },
  { value: "Africa/Mogadishu", labelFa: "سومالی (مقديشو)", labelEn: "Somalia (Mogadishu)" },
  { value: "Africa/Juba", labelFa: "سودان جنوبی", labelEn: "South Sudan" },
  // Oceania
  { value: "Australia/Sydney", labelFa: "استرالیا (سیدنی)", labelEn: "Australia (Sydney)" },
  { value: "Australia/Melbourne", labelFa: "استرالیا (ملبورن)", labelEn: "Australia (Melbourne)" },
  { value: "Australia/Brisbane", labelFa: "استرالیا (بریسبین)", labelEn: "Australia (Brisbane)" },
  { value: "Australia/Perth", labelFa: "استرالیا (پرت)", labelEn: "Australia (Perth)" },
  { value: "Australia/Adelaide", labelFa: "استرالیا (آدلاید)", labelEn: "Australia (Adelaide)" },
  { value: "Pacific/Auckland", labelFa: "نیوزیلند (اوکلند)", labelEn: "New Zealand (Auckland)" },
  { value: "Pacific/Fiji", labelFa: "فیجی", labelEn: "Fiji" },
  { value: "Pacific/Guam", labelFa: "گوام", labelEn: "Guam" },
  { value: "Pacific/Honolulu", labelFa: "هاوایی", labelEn: "Hawaii" },
  { value: "Pacific/Samoa", labelFa: "ساموا", labelEn: "Samoa" },
  { value: "Pacific/Tahiti", labelFa: "تاهیتی", labelEn: "Tahiti" },
  // Antarctica & other
  { value: "Antarctica/Casey", labelFa: "قطب جنوب (کیسی)", labelEn: "Antarctica (Casey)" },
  { value: "UTC", labelFa: "UTC هماهنگ جهانی", labelEn: "UTC (Coordinated Universal)" },
];

const toFaDigits = (s) => s.replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

function readSettings() {
  try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}"); } catch { return {}; }
}

export default function DigitalClock() {
  const [now, setNow] = useState(new Date());
  const [tz, setTz] = useState("Asia/Tehran");
  const [fmt, setFmt] = useState("24");
  const [offset, setOffset] = useState(0);
  const [offsetMin, setOffsetMin] = useState(0);
  const [offsetSec, setOffsetSec] = useState(0);
  const [isFa, setIsFa] = useState(false);
  const [clockSize, setClockSize] = useState(100);

  useEffect(() => {
    const tick = () => {
      setNow(new Date());
      const s = readSettings();
      setTz(s.clockTimezone || "Asia/Tehran");
      setFmt(s.clockFormat || "24");
      setOffset(Number(s.clockOffset) || 0);
      setOffsetMin(Number(s.clockOffsetMinutes) || 0);
      setOffsetSec(Number(s.clockOffsetSeconds) || 0);
      setIsFa(s.language === "fa");
      setClockSize(Number(s.clockSize) || 100);
    };
    tick();
    const iv = setInterval(tick, 1000);
    const onSettings = () => tick();
    window.addEventListener("ayeneh-settings-changed", onSettings);
    window.addEventListener("storage", onSettings);
    return () => {
      clearInterval(iv);
      window.removeEventListener("ayeneh-settings-changed", onSettings);
      window.removeEventListener("storage", onSettings);
    };
  }, []);

  const displayDate = new Date(now.getTime() + offset * 3600000 + offsetMin * 60000 + offsetSec * 1000);
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: fmt === "12",
  }).formatToParts(displayDate);

  const hh = parts.find(p => p.type === "hour")?.value || "00";
  const mm = parts.find(p => p.type === "minute")?.value || "00";
  const ss = parts.find(p => p.type === "second")?.value || "00";
  const dayPeriod = parts.find(p => p.type === "dayPeriod")?.value || "";

  let timeStr = `${hh}:${mm}:${ss}`;
  if (fmt === "12" && dayPeriod) {
    const dp = isFa ? (dayPeriod.toLowerCase().includes("am") ? "ق.ظ" : "ب.ظ") : dayPeriod;
    timeStr = `${timeStr} ${dp}`;
  }
  if (isFa) timeStr = toFaDigits(timeStr);

  return (
    <div className="flex flex-col items-center gap-1 select-none">
      <div className="font-bold text-white" style={{ fontFamily: "Vazirmatn, monospace", fontSize: "clamp(1.8rem, 5vw, 2.6rem)", textShadow: "0 0 18px rgba(168,85,247,0.6)", letterSpacing: "0.06em", transform: `scale(${clockSize / 100})`, transformOrigin: "center" }}>
        {timeStr}
      </div>
      <div className="text-purple-300/50 text-[10px] tracking-widest">
        {isFa ? "ساعت دیجیتال" : "DIGITAL CLOCK"}
      </div>
    </div>
  );
}