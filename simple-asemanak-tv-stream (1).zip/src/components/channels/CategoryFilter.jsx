const categories = [
  { value: "all", label: "All", emoji: "🌐" },
  { value: "news", label: "News", emoji: "📰" },
  { value: "sports", label: "Sports", emoji: "⚽" },
  { value: "entertainment", label: "Entertainment", emoji: "🎭" },
  { value: "movies", label: "Movies", emoji: "🎬" },
  { value: "music", label: "Music", emoji: "🎵" },
  { value: "kids", label: "Kids", emoji: "🧸" },
  { value: "documentary", label: "Documentary", emoji: "🎥" },
  { value: "religious", label: "Religious", emoji: "☪️" },
  { value: "lifestyle", label: "Lifestyle", emoji: "✨" },
];

export default function CategoryFilter({ selected, onChange }) {
  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {categories.map(({ value, label, emoji }) => (
        <button
          key={value}
          data-remote
          onClick={() => onChange(value)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all flex-shrink-0 ${
            selected === value
              ? "bg-primary text-white shadow-lg shadow-primary/30"
              : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80"
          }`}
        >
          <span>{emoji}</span>
          {label}
        </button>
      ))}
    </div>
  );
}