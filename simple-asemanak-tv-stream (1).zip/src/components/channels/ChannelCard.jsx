import { Play, Star, Radio } from "lucide-react";
import { Link } from "react-router-dom";

const categoryColors = {
  news: "from-blue-600 to-blue-800",
  sports: "from-green-600 to-green-800",
  entertainment: "from-pink-600 to-purple-800",
  movies: "from-yellow-600 to-orange-800",
  music: "from-cyan-600 to-blue-800",
  kids: "from-orange-500 to-yellow-600",
  documentary: "from-teal-600 to-emerald-800",
  religious: "from-amber-600 to-yellow-800",
  lifestyle: "from-rose-600 to-pink-800",
};

const categoryLabels = {
  news: "News",
  sports: "Sports",
  entertainment: "Entertainment",
  movies: "Movies",
  music: "Music",
  kids: "Kids",
  documentary: "Documentary",
  religious: "Religious",
  lifestyle: "Lifestyle",
};

export default function ChannelCard({ channel, isFavorite, onToggleFavorite, onPlay }) {
  return (
    <div data-remote tabIndex={0} role="button" onClick={onPlay} className="group relative bg-card border border-border rounded-xl overflow-hidden hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10 transition-all duration-300">
      {/* Thumbnail */}
      <div className={`relative h-40 bg-gradient-to-br ${categoryColors[channel.category] || "from-purple-700 to-blue-800"} flex items-center justify-center overflow-hidden`}>
        {channel.cover_url ? (
          <img src={channel.cover_url} alt={channel.name} className="w-full h-full object-cover opacity-60" />
        ) : null}

        {/* Logo overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          {channel.logo_url ? (
            <img src={channel.logo_url} alt={channel.name} className="w-16 h-16 object-contain rounded-lg shadow-xl" />
          ) : (
            <div className="w-16 h-16 rounded-xl bg-white/10 backdrop-blur flex items-center justify-center">
              <Radio className="w-8 h-8 text-white/70" />
            </div>
          )}
        </div>

        {/* Live badge */}
        <div className="absolute top-2 left-2 flex items-center gap-1 bg-red-600 text-white text-sm font-bold px-2 py-0.5 rounded-full">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          LIVE
        </div>

        {/* Favorite button */}
        <button
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onToggleFavorite(channel.id); }} data-remote
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
          className="absolute top-2 right-2 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full bg-black/40 backdrop-blur hover:bg-black/60 transition-all"
        >
          <Star className={`w-4 h-4 ${isFavorite ? "fill-yellow-400 text-yellow-400" : "text-white/70"}`} />
        </button>

        {/* Play overlay */}
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <Link to={`/Player/${channel.id}`} className="w-14 h-14 rounded-full bg-primary/90 hover:bg-primary flex items-center justify-center shadow-xl">
            <Play className="w-6 h-6 text-white fill-white ml-1" />
          </Link>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="font-semibold text-sm text-foreground truncate">{channel.name}</h3>
        {channel.name_fa && <p className="text-sm text-muted-foreground font-vazir truncate">{channel.name_fa}</p>}
        <div className="mt-2 flex items-center justify-between">
          <span className="text-sm bg-secondary px-2 py-0.5 rounded-full text-muted-foreground capitalize">
            {categoryLabels[channel.category] || channel.category}
          </span>
          {channel.language && (
            <span className="text-sm text-muted-foreground">{channel.language}</span>
          )}
        </div>
      </div>
    </div>
  );
}