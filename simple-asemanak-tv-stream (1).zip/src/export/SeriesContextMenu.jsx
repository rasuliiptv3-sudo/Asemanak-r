import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Trash2, Pencil, ImagePlus, Upload, Loader2, Heart, Plus, Download, Check, Music, EyeOff } from "lucide-react";
import { cacheVideoOffline, removeOfflineVideo, isVideoOffline, getOfflineIndex } from "@/lib/offlineVideo";

const MEDIA_FAV_KEY = "ayeneh_media_favorites";

function isMediaFav(id) {
  try { return JSON.parse(localStorage.getItem(MEDIA_FAV_KEY) || "[]").includes(id); } catch { return false; }
}
function toggleMediaFav(id) {
  try {
    const list = JSON.parse(localStorage.getItem(MEDIA_FAV_KEY) || "[]");
    const next = list.includes(id) ? list.filter(x => x !== id) : [...list, id];
    localStorage.setItem(MEDIA_FAV_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event("ayeneh-media-favorites-changed"));
    return !list.includes(id);
  } catch { return false; }
}

function parsePosterPos(pos) {
  if (!pos) return { x: 50, y: 20 };
  const parts = pos.trim().split(/\s+/);
  const parseVal = (v) => {
    if (v === "center") return 50;
    if (v === "top" || v === "left") return 0;
    if (v === "bottom" || v === "right") return 100;
    return parseInt(v) || 50;
  };
  return { x: parts[0] ? parseVal(parts[0]) : 50, y: parts[1] ? parseVal(parts[1]) : 20 };
}

export default function SeriesContextMenu({ series, onDelete, onRename, onChangePhoto, onAddEpisode, onClose, isAdmin = false }) {
  const [mode, setMode] = useState("menu");
  const [isFav, setIsFav] = useState(() => isMediaFav(series.id));
  const [nameInput, setNameInput] = useState(series.title);
  const [photoInput, setPhotoInput] = useState(series.poster || "");
  const [uploading, setUploading] = useState(false);
  const [musicUploading, setMusicUploading] = useState(false);
  const initialPos = parsePosterPos(series.posterPosition);
  const [posX, setPosX] = useState(initialPos.x);
  const [posY, setPosY] = useState(initialPos.y);
  const fileRef = useRef(null);
  const musicRef = useRef(null);

  // ── Offline download state ──
  const downloadableEps = (series.episodes || []).filter(ep => ep.fileUrl);
  const [downloadedCount, setDownloadedCount] = useState(() => {
    const idx = getOfflineIndex();
    return downloadableEps.filter(ep => idx.some(e => e.fileUrl === ep.fileUrl)).length;
  });
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState({ current: 0, total: 0 });
  const isFullyDownloaded = downloadableEps.length > 0 && downloadedCount === downloadableEps.length;

  const handleDownloadSeries = async () => {
    if (downloadableEps.length === 0) return;
    setDownloading(true);
    setDownloadProgress({ current: 0, total: downloadableEps.length });
    try {
      for (let i = 0; i < downloadableEps.length; i++) {
        const ep = downloadableEps[i];
        const isAlready = await isVideoOffline(ep.fileUrl);
        if (!isAlready) {
          await cacheVideoOffline(ep.fileUrl, { label: `${series.title} — ${ep.title || `قسمت ${ep.number}`}` });
        }
        setDownloadProgress({ current: i + 1, total: downloadableEps.length });
      }
      setDownloadedCount(downloadableEps.length);
    } catch {
      window.alert("دانلود ناموفق بود — ممکن است فایل‌ها خیلی بزرگ باشند");
    } finally {
      setDownloading(false);
    }
  };

  const handleRemoveDownload = async () => {
    for (const ep of downloadableEps) {
      await removeOfflineVideo(ep.fileUrl);
    }
    setDownloadedCount(0);
  };

  const handlePickFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setUploading(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file: f });
      setPhotoInput(res.file_url);
    } catch {
      alert("آپلود ناموفق بود");
    } finally {
      setUploading(false);
    }
  };

  // Upload a short audio clip as cover music for the series (admin only)
  const handlePickMusic = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    // Limit to ~5MB audio clips (a few seconds)
    if (f.size > 5 * 1024 * 1024) {
      alert("فایل صوتی باید کمتر از ۵ مگابایت باشد (چند ثانیه)");
      return;
    }
    setMusicUploading(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file: f });
      await base44.entities.Series.update(series.id, { coverMusic: res.file_url });
      window.location.reload();
    } catch {
      alert("آپلود موسیقی ناموفق بود");
    } finally {
      setMusicUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center" style={{ paddingTop: '8vh' }} onClick={onClose}>
      <div className="absolute inset-0 bg-black/80" />
      <div className="relative z-10 w-80 rounded-2xl p-5 border border-white/10" style={{ background: 'rgba(13,17,23,0.98)' }} onClick={e => e.stopPropagation()}>
        {mode === "menu" && (
          <>
            <div className="flex items-center gap-3 mb-4">
              {series.poster && <img src={series.poster} className="w-10 h-14 rounded object-cover" onError={e => { e.target.style.display = 'none'; }} />}
              <p className="text-white font-bold text-sm truncate flex-1">{series.title}</p>
              <button onClick={onClose} data-remote className="text-white/40 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-2">
              {isAdmin && (
                <button onClick={() => setMode("rename")} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                  <Pencil className="w-4 h-4 text-purple-400" /> تغییر اسم سریال
                </button>
              )}
              {isAdmin && (
                <button onClick={() => setMode("photo")} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                  <ImagePlus className="w-4 h-4 text-cyan-400" /> تغییر عکس سریال
                </button>
              )}
              <button onClick={() => setIsFav(toggleMediaFav(series.id))} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                <Heart className={`w-4 h-4 ${isFav ? "text-pink-500 fill-pink-500" : "text-pink-400"}`} />
                {isFav ? "حذف از علاقه‌مندی‌ها" : "افزودن به علاقه‌مندی‌ها"}
              </button>
              {isAdmin && (
                <label className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm cursor-pointer">
                  <Music className={`w-4 h-4 ${series.coverMusic ? "text-green-400" : "text-cyan-400"}`} />
                  {musicUploading ? (
                    <><Loader2 className="w-3.5 h-3.5 animate-spin" /> در حال آپلود...</>
                  ) : series.coverMusic ? (
                    "تغییر موسیقی کاور ✓"
                  ) : (
                    "افزودن موسیقی کاور (چند ثانیه)"
                  )}
                  <input ref={musicRef} type="file" accept="audio/*" className="hidden" onChange={handlePickMusic} />
                </label>
              )}
              {downloadableEps.length > 0 && (
                <>
                  {downloading ? (
                    <div className="px-4 py-3">
                      <div className="flex items-center gap-2 text-white/80 text-sm mb-2">
                        <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                        در حال دانلود... {downloadProgress.current}/{downloadProgress.total}
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div className="h-full rounded-full transition-all" style={{ width: `${(downloadProgress.current / downloadProgress.total) * 100}%`, background: 'linear-gradient(90deg, #0e7490, #22d3ee)' }} />
                      </div>
                    </div>
                  ) : isFullyDownloaded ? (
                    <button onClick={handleRemoveDownload} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                      <Check className="w-4 h-4 text-green-400" />
                      حذف دانلود آفلاین ({downloadableEps.length} قسمت)
                    </button>
                  ) : (
                    <button onClick={handleDownloadSeries} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                      <Download className="w-4 h-4 text-cyan-400" />
                      {downloadedCount > 0 ? `ادامه دانلود (${downloadedCount}/${downloadableEps.length})` : `دانلود سریال (${downloadableEps.length} قسمت)`}
                    </button>
                  )}
                </>
              )}
              {downloadableEps.length === 0 && (series.episodes || []).some(ep => ep.videoId) && (
                <p className="px-4 py-2 text-white/30 text-xs">دانلود فقط برای ویدیوهای آپلودی ممکن است</p>
              )}
              {isAdmin && onAddEpisode && (
                <button onClick={onAddEpisode} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                  <Plus className="w-4 h-4 text-cyan-400" /> افزودن قسمت جدید
                </button>
              )}
              {isAdmin && (
                <button onClick={async () => {
                  try {
                    await base44.entities.Series.update(series.id, { hideOverlays: !series.hideOverlays });
                    window.location.reload();
                  } catch {}
                }} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition-colors text-sm">
                  <EyeOff className={`w-4 h-4 ${series.hideOverlays ? "text-cyan-400" : "text-cyan-400/60"}`} />
                  {series.hideOverlays ? "غیرفعال‌کردن پنهان‌سازی ویدیو" : "پنهان‌کردن لوگو/نوشته ویدیو"}
                </button>
              )}
              {isAdmin && (
                <>
                  <div className="my-2 border-t border-white/10" />
                  <button onClick={() => { if (window.confirm('حذف این سریال؟')) onDelete(); }} data-remote className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors text-sm">
                    <Trash2 className="w-4 h-4" /> حذف سریال
                  </button>
                </>
              )}
            </div>
          </>
        )}
        {mode === "rename" && (
          <>
            <p className="text-white font-bold text-sm mb-3">تغییر اسم سریال</p>
            <input value={nameInput} onChange={e => setNameInput(e.target.value)} data-remote className="w-full text-white text-sm px-3 py-2.5 rounded-xl outline-none mb-3" style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.1)' }} autoFocus />
            <div className="flex gap-2">
              <button onClick={() => onRename(nameInput)} data-remote className="flex-1 py-2.5 rounded-xl text-white text-sm font-bold" style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)' }}>ذخیره</button>
              <button onClick={() => setMode("menu")} data-remote className="px-4 py-2.5 rounded-xl text-white/60 text-sm bg-white/5">بازگشت</button>
            </div>
          </>
        )}
        {mode === "photo" && (
          <>
            <p className="text-white font-bold text-sm mb-3">تغییر عکس سریال</p>
            {/* Upload from gallery */}
            <button onClick={() => fileRef.current?.click()} data-remote
              className="w-full mb-3 border-2 border-dashed border-cyan-500/30 rounded-xl py-4 flex flex-col items-center gap-1.5 hover:border-cyan-500/60 transition-colors">
              {uploading ? <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" /> : <Upload className="w-5 h-5 text-cyan-400" />}
              <span className="text-xs text-cyan-300/80">{uploading ? "در حال آپلود..." : "آپلود از گالری"}</span>
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePickFile} />
            <p className="text-white/40 text-xs mb-2">یا آدرس عکس (URL) را وارد کنید:</p>
            <input value={photoInput} onChange={e => setPhotoInput(e.target.value)} data-remote placeholder="https://..." className="w-full text-white text-sm px-3 py-2.5 rounded-xl outline-none mb-3" style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.1)' }} />

            {/* Position adjuster — live preview */}
            {photoInput && (
              <div className="mb-3">
                <p className="text-white/40 text-xs mb-2">تنظیم موقعیت عکس (برای مرکز کردن چهره‌ها):</p>
                <div className="w-full h-40 rounded-xl overflow-hidden mb-3 relative bg-black/40">
                  <img src={photoInput} alt="preview" className="w-full h-full object-cover"
                    style={{ objectPosition: `${posX}% ${posY}%` }}
                    onError={e => { e.target.style.display = 'none'; }} />
                </div>
                <div className="space-y-2.5">
                  <div>
                    <label className="text-xs text-white/50 flex items-center justify-between mb-1">
                      <span>موقعیت افقی (Horizontal)</span>
                      <span className="text-cyan-400 font-bold">{posX}%</span>
                    </label>
                    <input type="range" min="0" max="100" value={posX} onChange={e => setPosX(Number(e.target.value))} className="w-full h-1.5 cursor-pointer" style={{ accentColor: '#22d3ee' }} />
                  </div>
                  <div>
                    <label className="text-xs text-white/50 flex items-center justify-between mb-1">
                      <span>موقعیت عمودی (Vertical)</span>
                      <span className="text-cyan-400 font-bold">{posY}%</span>
                    </label>
                    <input type="range" min="0" max="100" value={posY} onChange={e => setPosY(Number(e.target.value))} className="w-full h-1.5 cursor-pointer" style={{ accentColor: '#22d3ee' }} />
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <button onClick={() => onChangePhoto(photoInput, `${posX}% ${posY}%`)} disabled={uploading} data-remote className="flex-1 py-2.5 rounded-xl text-white text-sm font-bold disabled:opacity-40" style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)' }}>ذخیره</button>
              <button onClick={() => setMode("menu")} data-remote className="px-4 py-2.5 rounded-xl text-white/60 text-sm bg-white/5">بازگشت</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}