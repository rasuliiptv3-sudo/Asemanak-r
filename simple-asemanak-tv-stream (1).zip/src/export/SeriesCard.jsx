import { useRef, useState, useEffect } from "react";
import { Play, Sparkles, Clapperboard, CirclePlay, Wifi } from "lucide-react";
import { getOfflineIndex } from "@/lib/offlineVideo";

const APP_LOGO = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

// Get YouTube thumbnail URL for a video ID (a frame from the series itself)
function getYouTubeThumb(videoId, quality = 'maxres') {
  if (!videoId) return null;
  const q = quality === 'maxres' ? 'maxresdefault' : quality === 'hq' ? 'hqdefault' : 'mqdefault';
  return `https://img.youtube.com/vi/${videoId}/${q}.jpg`;
}

// Check if series has new episodes (updated within last 7 days)
function hasNewEpisodes(item) {
  try {
    const updated = new Date(item.updated_date || item.created_date);
    if (isNaN(updated.getTime())) return false;
    const daysSince = (Date.now() - updated.getTime()) / (1000 * 60 * 60 * 24);
    return daysSince < 7;
  } catch { return false; }
}

// Lightweight YouTube preview embed — muted, no controls, plays from a random offset.
function PreviewEmbed({ videoId }) {
  const startSec = useRef(Math.floor(Math.random() * 60) + 10);
  const src = `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&controls=0&modestbranding=1&rel=0&iv_load_policy=3&start=${startSec.current}&playsinline=1`;
  return (
    <div className="absolute inset-0 z-20 overflow-hidden" style={{ background: '#000' }}>
      <iframe
        src={src}
        style={{
          position: 'absolute', top: '-9%', left: '0', width: '100%', height: '118%',
          border: 'none', pointerEvents: 'none',
        }}
        allow="autoplay; encrypted-media"
        title="preview"
      />
      <div className="absolute top-0 left-0 right-0" style={{ height: '14%', background: 'rgba(0,0,0,0.92)', pointerEvents: 'auto' }} />
      <div className="absolute bottom-0 left-0 right-0" style={{ height: '14%', background: 'rgba(0,0,0,0.92)', pointerEvents: 'auto' }} />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div style={{
          width: 120, height: 120, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(10,13,22,0.7) 0%, transparent 70%)',
        }} />
      </div>
      <div className="absolute top-1 left-1 flex items-center gap-1.5 px-1.5 py-0.5 rounded-md" style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}>
        <img src={APP_LOGO} alt="" className="w-4 h-4 rounded-full object-cover" draggable={false} />
        <span className="text-white text-[8px] font-bold">آسمانک</span>
      </div>
    </div>
  );
}

// Gallery video preview embed — muted, no controls, plays from a random offset.
// Mirrors PreviewEmbed but for direct file uploads (gallery videos).
function GalleryPreviewEmbed({ fileUrl }) {
  const videoRef = useRef(null);
  const startSec = useRef(Math.floor(Math.random() * 30) + 5);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = true;
    const onLoaded = () => {
      try { v.currentTime = startSec.current; } catch {}
      v.play().catch(() => {});
    };
    v.addEventListener('loadedmetadata', onLoaded, { once: true });
    if (v.readyState >= 1) onLoaded();
    return () => { try { v.pause(); } catch {} };
  }, [fileUrl]);

  return (
    <div className="absolute inset-0 z-20 overflow-hidden" style={{ background: '#000' }}>
      <video
        ref={videoRef}
        src={fileUrl}
        autoPlay
        muted
        playsInline
        preload="auto"
        className="w-full h-full object-cover"
        style={{ pointerEvents: 'none' }}
      />
      <div className="absolute top-0 left-0 right-0" style={{ height: '14%', background: 'rgba(0,0,0,0.92)', pointerEvents: 'auto' }} />
      <div className="absolute bottom-0 left-0 right-0" style={{ height: '14%', background: 'rgba(0,0,0,0.92)', pointerEvents: 'auto' }} />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div style={{
          width: 120, height: 120, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(10,13,22,0.7) 0%, transparent 70%)',
        }} />
      </div>
      <div className="absolute top-1 left-1 flex items-center gap-1.5 px-1.5 py-0.5 rounded-md" style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}>
        <img src={APP_LOGO} alt="" className="w-4 h-4 rounded-full object-cover" draggable={false} />
        <span className="text-white text-[8px] font-bold">آسمانک</span>
      </div>
    </div>
  );
}

export default function SeriesCard({ item, onSelect, onDoubleSelect, onLongPress, isFocused, onFocus, index = 0, isTV = false }) {
  const longPressTimer = useRef(null);
  const touchStartY = useRef(null);
  const movedRef = useRef(false);
  const clickTimer = useRef(null);
  const previewTimer = useRef(null);
  const [showPreview, setShowPreview] = useState(false);
  const [thumbFallback, setThumbFallback] = useState(false);
  const epCount = (item.episodes || []).length;

  const lastEpId = (() => { try { return localStorage.getItem(`ayeneh_last_ep_${item.id}`); } catch { return null; } })();
  const hasContinue = !!lastEpId && lastEpId !== "undefined";
  const continueEpisode = (item.episodes || []).find(ep => (ep.videoId || ep.fileUrl) === lastEpId);
  const continueNumber = continueEpisode?.number;

  const previewVideoId = (item.episodes || []).find(ep => ep.videoId)?.videoId;

  // Auto-generate cover from YouTube thumbnail (a frame from the series itself) if no poster
  const coverImage = item.poster
    || (previewVideoId && !thumbFallback ? getYouTubeThumb(previewVideoId, 'maxres') : null)
    || (previewVideoId && thumbFallback ? getYouTubeThumb(previewVideoId, 'hq') : null);

  const previewFileUrl = (item.episodes || []).find(ep => ep.fileUrl)?.fileUrl;

  const isNew = hasNewEpisodes(item) && epCount > 0;

  // Offline download status — read from localStorage index (synchronous)
  const offlineIndex = getOfflineIndex();
  const downloadableEps = (item.episodes || []).filter(ep => ep.fileUrl || ep.videoId);
  const isDownloaded = downloadableEps.length > 0 && downloadableEps.every(ep => {
    const key = ep.fileUrl || `yt_${ep.videoId}`;
    return offlineIndex.some(e => e.fileUrl === key);
  });

  useEffect(() => {
    if (isFocused && (previewVideoId || previewFileUrl)) {
      previewTimer.current = setTimeout(() => setShowPreview(true), 800);
    } else {
      clearTimeout(previewTimer.current);
      setShowPreview(false);
    }
    return () => clearTimeout(previewTimer.current);
  }, [isFocused, previewVideoId, previewFileUrl]);

  useEffect(() => {
    if (!isFocused) return;
    const onKey = (e) => {
      if (!!["Enter", "Return", " ", "XF86OK", "Accept"].includes(e.key)) {
        e.preventDefault();
        e.stopPropagation();
        // Both TV and mobile: OK/Enter opens the series detail directly.
        // No more trailer-on-select — trailer is a separate explicit action.
        if (onDoubleSelect) onDoubleSelect(item);
        else onSelect(item);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [isFocused, item, onSelect, onDoubleSelect]);

  const handleTouchStart = (e) => {
    movedRef.current = false;
    if (!onLongPress) return;
    touchStartY.current = e.touches[0].clientY;
    longPressTimer.current = setTimeout(() => {
      longPressTimer.current = null;
      onLongPress(item);
    }, 600);
  };

  const handleTouchMove = (e) => {
    if (touchStartY.current !== null && Math.abs(e.touches[0].clientY - touchStartY.current) > 8) {
      movedRef.current = true;
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const handleTouchEnd = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const handleClick = (e) => {
    if (movedRef.current) { movedRef.current = false; e.preventDefault(); e.stopPropagation(); return; }
    // Single click opens the series detail directly — no more double-click / trailer delay.
    if (onDoubleSelect) onDoubleSelect(item);
    else onSelect(item);
  };

  const animDelay = Math.min(index * 0.07, 0.7);

  return (
    <div
      id={`series-card-${item.id}`}
      data-remote
      tabIndex={0}
      onClick={handleClick}
      onMouseEnter={() => onFocus && onFocus()}
      onFocus={() => { if (onFocus) onFocus(); }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onContextMenu={(e) => { if (onLongPress) { e.preventDefault(); onLongPress(item); } }}
      className="group flex-shrink-0 rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.06] relative"
      style={{
        width: 'clamp(135px,16vw,180px)',
        background: 'rgba(255,255,255,0.04)',
        border: isFocused ? '2px solid rgb(34,211,238)' : '1px solid rgba(255,255,255,0.08)',
        boxShadow: isFocused
          ? '0 0 32px rgba(34,211,238,0.5), 0 12px 36px rgba(0,0,0,0.6), inset 0 0 0 1px rgba(34,211,238,0.2)'
          : '0 6px 24px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.06)',
        transform: isFocused ? 'scale(1.05)' : undefined,
        animation: `cardEnter 0.6s cubic-bezier(0.34,1.56,0.64,1) ${animDelay}s both`,
      }}
    >
      <style>{`
        @keyframes cardEnter {
          0% { opacity: 0; transform: translateY(40px) scale(0.85); }
          60% { opacity: 1; transform: translateY(-4px) scale(1.02); }
          100% { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
      <div className="relative w-full aspect-[2/3]" style={{ background: 'linear-gradient(135deg, rgba(76,29,149,0.3) 0%, rgba(14,116,144,0.2) 100%)' }}>
        {coverImage ? (
          <img src={coverImage} alt={item.title} className="w-full h-full object-cover"
            style={{ transform: 'scale(1.01)' }}
            onError={e => {
              if (previewVideoId && e.target.src.includes('maxresdefault')) {
                e.target.src = getYouTubeThumb(previewVideoId, 'hq');
                setThumbFallback(true);
              } else {
                e.target.style.display = 'none';
              }
            }}
            draggable={false} />
        ) : previewFileUrl ? (
          <video src={`${previewFileUrl}#t=0.1`} className="w-full h-full object-cover" muted preload="metadata" playsInline
            style={{ transform: 'scale(1.02)' }} />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-2"
            style={{ background: 'linear-gradient(135deg, rgba(123,44,191,0.25), rgba(14,116,144,0.25))' }}>
            <Clapperboard className="w-10 h-10 text-white/20" />
            <p className="text-white/40 text-[11px] font-bold text-center px-2" style={{ fontFamily: 'Vazirmatn, sans-serif' }}>
              {item.title}
            </p>
          </div>
        )}

        {/* Preview embeds disabled — they show YouTube error text (Error 153) over the
            cover when embedding is restricted. Clean cover image is shown instead. */}

        {/* Top gradient — masks channel logos and text on the original cover */}
        <div className="absolute inset-0 pointer-events-none" style={{
          background: 'linear-gradient(180deg, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0.2) 18%, transparent 35%)'
        }} />

        {/* Bottom gradient — strong dark fade for legible title */}
        <div className="absolute inset-0 pointer-events-none" style={{
          background: 'linear-gradient(180deg, transparent 30%, rgba(0,0,0,0.5) 55%, rgba(5,5,12,0.95) 78%, rgba(5,5,12,0.98) 100%)'
        }} />

        {/* Episode count chip */}
        <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-full z-10"
          style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)', border: '1px solid rgba(255,255,255,0.12)' }}>
          <Sparkles className="w-3 h-3 text-cyan-300" />
          <span className="text-white text-[10px] font-bold">{epCount} قسمت</span>
        </div>

        {/* Downloaded badge — shown when all fileUrl episodes are cached for offline */}
        {isDownloaded ? (
          <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-full z-10"
            style={{ background: 'rgba(34,197,94,0.85)', backdropFilter: 'blur(6px)', boxShadow: '0 0 12px rgba(34,197,94,0.5)' }}>
            <Wifi className="w-3 h-3 fill-white text-white" />
            <span className="text-white text-[10px] font-bold">آفلاین</span>
          </div>
        ) : hasContinue && !isNew ? (
          <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-full z-10"
            style={{ background: 'rgba(123,44,191,0.85)', backdropFilter: 'blur(6px)', boxShadow: '0 0 12px rgba(168,85,247,0.6)' }}>
            <CirclePlay className="w-3 h-3 fill-white text-white" />
            <span className="text-white text-[10px] font-bold">{continueNumber ? `قسمت ${continueNumber}` : 'ادامه'}</span>
          </div>
        ) : null}

        {/* Hover play overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"
          style={{ background: 'radial-gradient(circle at center, rgba(123,44,191,0.45), rgba(6,6,15,0.5))' }}>
          <div className="w-14 h-14 rounded-full flex items-center justify-center backdrop-blur-md transition-transform group-hover:scale-110"
            style={{ background: 'rgba(123,44,191,0.7)', border: '2px solid rgba(255,255,255,0.5)', boxShadow: '0 0 24px rgba(123,44,191,0.6)' }}>
            <Play className="w-6 h-6 fill-white text-white ml-0.5" />
          </div>
        </div>

        {/* Title — large bold text with cinematic dark gradient */}
        <div className="absolute bottom-0 left-0 right-0 z-10" style={{ padding: '40px 11px 12px' }}>
          <p style={{
            fontFamily: 'Vazirmatn, sans-serif',
            fontSize: '15px',
            fontWeight: 900,
            color: '#ffffff',
            textShadow: '0 2px 10px rgba(0,0,0,1), 0 0 6px rgba(0,0,0,0.9), 0 0 2px rgba(0,0,0,1)',
            letterSpacing: '-0.01em',
            lineHeight: '1.22',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}>{item.title}</p>
          <div className="flex items-center gap-1.5 mt-2">
            <span className="w-1 h-1 rounded-full bg-cyan-400" style={{ boxShadow: '0 0 6px rgba(34,211,238,0.8)' }} />
            <p className="text-cyan-300 text-[10px] font-bold">{epCount} قسمت</p>
            {isNew && <p className="text-amber-400 text-[10px] font-bold mr-1">• جدید</p>}
          </div>
        </div>
      </div>
    </div>
  );
}