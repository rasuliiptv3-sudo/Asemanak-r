import { useRef, useEffect, useState, useMemo } from "react";
import { Play, List, Volume2, VolumeX } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";
const SWITCH_MS = 25000;

export default function HeroVideo({ series, onPlay, onShowEpisodes }) {
  const divARef = useRef(null);
  const divBRef = useRef(null);
  const playerARef = useRef(null);
  const playerBRef = useRef(null);
  const videoARef = useRef(null);
  const videoBRef = useRef(null);
  const clipsRef = useRef([]);
  const idxRef = useRef(0);
  const activeRef = useRef(0);
  const startedRef = useRef(false);
  const pendingSwapRef = useRef(null);
  const switchTimerRef = useRef(null);
  const mountedRef = useRef(true);
  const slotClipRef = useRef([null, null]);

  const [currentClip, setCurrentClip] = useState(null);
  const [muted, setMuted] = useState(true);
  const mutedRef = useRef(true);
  const [activeSlot, setActiveSlot] = useState(0);
  const [ready, setReady] = useState(false);
  const [slotClips, setSlotClips] = useState([null, null]);

  const isNative = (clip) => !!clip?.fileUrl;

  // Interleave ALL episodes across different series — both YouTube and gallery uploads.
  const clips = useMemo(() => {
    const validSeries = series.filter(s => (s.episodes || []).length > 0);
    if (!validSeries.length) return [];
    const maxEps = Math.max(...validSeries.map(s => (s.episodes || []).length));
    const result = [];
    for (let epIdx = 0; epIdx < maxEps; epIdx++) {
      for (const s of validSeries) {
        const ep = (s.episodes || [])[epIdx];
        if (ep && (ep.videoId || ep.fileUrl)) {
          result.push({
            videoId: ep.videoId || null,
            fileUrl: ep.fileUrl || null,
            title: ep.title,
            seriesId: s.id,
            seekTo: Math.floor(Math.random() * 90) + 15,
          });
        }
      }
    }
    return result.slice(0, 24);
  }, [series]);

  const hasYtClips = clips.some(c => c.videoId);
  const divs = [divARef, divBRef];
  const ytPlayers = [playerARef, playerBRef];
  const videos = [videoARef, videoBRef];

  const setSlotClip = (slot, clip) => {
    slotClipRef.current[slot] = clip;
    setSlotClips(prev => { const next = [...prev]; next[slot] = clip; return next; });
  };

  const seekNative = (v, clip) => {
    try { if (v.duration > 20) v.currentTime = Math.min(clip.seekTo || 0, v.duration * 0.7); } catch {}
  };

  // Preload a clip into the inactive slot (muted)
  const preloadInto = (slot, clip) => {
    if (!mountedRef.current || !clip) return;
    setSlotClip(slot, clip);
    if (isNative(clip)) {
      const v = videos[slot].current;
      if (v) {
        v.muted = true;
        v.src = clip.fileUrl;
        v.load();
        const onMeta = () => {
          seekNative(v, clip);
          v.removeEventListener('loadedmetadata', onMeta);
          v.play().catch(() => {});
        };
        v.addEventListener('loadedmetadata', onMeta);
      }
    } else {
      const p = ytPlayers[slot].current;
      if (p) {
        try { p.mute(); p.loadVideoById({ videoId: clip.videoId, startSeconds: clip.seekTo || 0, suggestedQuality: "hd720" }); } catch {}
      }
    }
  };

  // Crossfade to the inactive slot
  const performSwap = (slot, clip, idx) => {
    if (!mountedRef.current) return;
    const old = 1 - slot;
    const oldClip = slotClipRef.current[old];
    if (oldClip && isNative(oldClip)) {
      const v = videos[old].current; if (v) v.muted = true;
    } else {
      try { ytPlayers[old].current?.mute(); } catch {}
    }
    if (isNative(clip)) {
      const v = videos[slot].current;
      if (v) {
        if (!mutedRef.current) { v.muted = false; v.volume = 1; }
        v.play().catch(() => {});
      }
    } else {
      try { const p = ytPlayers[slot].current; if (p) { if (!mutedRef.current) { p.unMute(); p.setVolume(100); } p.playVideo(); } } catch {}
    }
    setActiveSlot(slot);
    setCurrentClip(clip);
    idxRef.current = idx;
    activeRef.current = slot;
    setMuted(mutedRef.current);
    const nextIdx = (idx + 1) % clipsRef.current.length;
    preloadInto(old, clipsRef.current[nextIdx]);
  };

  const switchToNext = () => {
    if (!mountedRef.current) return;
    const list = clipsRef.current;
    if (!list.length) return;
    const nextIdx = (idxRef.current + 1) % list.length;
    const clip = list[nextIdx];
    const inactive = 1 - activeRef.current;
    let canSwapNow = false;
    if (isNative(clip)) {
      const v = videos[inactive].current;
      if (v && !v.paused && v.src && v.src.includes(clip.fileUrl)) canSwapNow = true;
    } else {
      try {
        const p = ytPlayers[inactive].current;
        if (p && p.getPlayerState && p.getPlayerState() === 1) {
          const data = p.getVideoData && p.getVideoData();
          if (data && data.video_id === clip.videoId) canSwapNow = true;
        }
      } catch {}
    }
    if (canSwapNow) {
      performSwap(inactive, clip, nextIdx);
    } else {
      pendingSwapRef.current = { slot: inactive, clip, idx: nextIdx };
      preloadInto(inactive, clip);
    }
  };

  // Native video started playing — complete pending swap if waiting on this slot
  const onNativePlaying = (slot) => () => {
    if (!mountedRef.current) return;
    if (pendingSwapRef.current && pendingSwapRef.current.slot === slot) {
      const { slot: s, clip, idx } = pendingSwapRef.current;
      pendingSwapRef.current = null;
      performSwap(s, clip, idx);
    }
  };

  useEffect(() => {
    clipsRef.current = clips;
    if (!clips.length) return;
    mountedRef.current = true;
    startedRef.current = false;
    pendingSwapRef.current = null;
    setCurrentClip(clips[0]);
    setReady(false);
    setSlotClips([null, null]);

    const makeStateHandler = (slot) => (e) => {
      if (!mountedRef.current) return;
      const st = e.data;
      try {
        if (st === window.YT.PlayerState.PAUSED || st === window.YT.PlayerState.CUED) e.target.playVideo();
      } catch {}
      if (st === window.YT.PlayerState.PLAYING) {
        if (slot === 0 && !startedRef.current && !isNative(clips[0])) {
          startedRef.current = true;
          try {
            e.target.seekTo(clips[0].seekTo || 0, true);
            if (!mutedRef.current) { e.target.unMute(); e.target.setVolume(100); }
            e.target.playVideo();
          } catch {}
          setMuted(mutedRef.current);
          setActiveSlot(0);
          activeRef.current = 0;
          setReady(true);
          if (clips[1]) preloadInto(1, clips[1]);
          switchTimerRef.current = setInterval(switchToNext, SWITCH_MS);
        }
        if (pendingSwapRef.current && pendingSwapRef.current.slot === slot && !isNative(pendingSwapRef.current.clip)) {
          const { slot: s, clip, idx } = pendingSwapRef.current;
          pendingSwapRef.current = null;
          performSwap(s, clip, idx);
        }
      }
      if (st === window.YT.PlayerState.ENDED) {
        if (mountedRef.current && slot === activeRef.current) switchToNext();
      }
    };

    const initYtPlayer = (slot, videoId) => {
      if (!mountedRef.current) return;
      const div = divs[slot].current;
      if (!div || !window.YT || !window.YT.Player) return;
      if (ytPlayers[slot].current) { try { ytPlayers[slot].current.destroy(); } catch {} }
      ytPlayers[slot].current = new window.YT.Player(div, {
        videoId,
        width: "100%",
        height: "100%",
        playerVars: { autoplay: 1, mute: 1, controls: 0, loop: 1, modestbranding: 1, rel: 0, iv_load_policy: 3, playsinline: 1, disablekb: 1, fs: 0 },
        events: { onStateChange: makeStateHandler(slot), onError: () => { if (mountedRef.current && slot === activeRef.current) { setReady(false); switchToNext(); } } },
      });
    };

    // Start with a native (gallery) first clip — plays immediately, no YT API needed
    const startNative = () => {
      const clip = clips[0];
      setSlotClip(0, clip);
      const v = videos[0].current;
      if (!v) return;
      v.muted = true;
      v.src = clip.fileUrl;
      v.load();
      const onMeta = () => {
        seekNative(v, clip);
        v.removeEventListener('loadedmetadata', onMeta);
        v.play().then(() => {
          if (!mountedRef.current) return;
          startedRef.current = true;
          setReady(true);
          if (!mutedRef.current) { v.muted = false; v.volume = 1; }
          setMuted(mutedRef.current);
          if (clips[1]) preloadInto(1, clips[1]);
          switchTimerRef.current = setInterval(switchToNext, SWITCH_MS);
        }).catch(() => {
          if (!mountedRef.current) return;
          startedRef.current = true;
          setReady(true);
          if (clips[1]) preloadInto(1, clips[1]);
          switchTimerRef.current = setInterval(switchToNext, SWITCH_MS);
        });
      };
      v.addEventListener('loadedmetadata', onMeta);
    };

    const ensureYtApi = (cb) => {
      if (window.YT && window.YT.Player) { cb(); return; }
      if (!window.YT) {
        const tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(tag);
      }
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { if (prev) prev(); cb(); };
      const check = setInterval(() => { if (window.YT && window.YT.Player) { clearInterval(check); cb(); } }, 200);
      setTimeout(() => clearInterval(check), 5000);
    };

    const initYtPlayers = () => {
      if (!mountedRef.current) return;
      const firstYtVid = clips.find(c => c.videoId)?.videoId;
      if (firstYtVid) {
        initYtPlayer(0, firstYtVid);
        const secondYtVid = clips.slice(1).find(c => c.videoId)?.videoId || firstYtVid;
        initYtPlayer(1, secondYtVid);
      }
    };

    if (isNative(clips[0])) {
      // First clip is gallery — start immediately, init YT players in background
      startNative();
      if (hasYtClips) ensureYtApi(initYtPlayers);
    } else {
      // First clip is YouTube — wait for YT API then init
      ensureYtApi(initYtPlayers);
    }

    return () => {
      mountedRef.current = false;
      if (switchTimerRef.current) clearInterval(switchTimerRef.current);
      [playerARef, playerBRef].forEach(r => {
        if (r.current) {
          try { r.current.stopVideo(); } catch {}
          try { r.current.destroy(); } catch {}
          r.current = null;
        }
      });
      [videoARef, videoBRef].forEach(r => {
        if (r.current) { try { r.current.pause(); r.current.src = ""; } catch {} }
      });
    };
  }, [clips]);

  const toggleMute = () => {
    const next = !muted;
    mutedRef.current = next;
    const clip = currentClip || clips[0];
    if (clip && isNative(clip)) {
      const v = videos[activeRef.current]?.current;
      if (v) { v.muted = next; if (!next) v.volume = 1; }
    } else {
      const p = ytPlayers[activeRef.current]?.current;
      if (p) { if (next) { try { p.mute(); } catch {} } else { try { p.unMute(); p.setVolume(100); } catch {} } }
    }
    setMuted(next);
  };

  if (!clips.length) return null;

  const heroClip = currentClip || clips[0];
  const heroSeries = series.find(s => s.id === heroClip?.seriesId) || series[0];

  return (
    <div className="relative w-full overflow-hidden flex-shrink-0" style={{ height: "45vh", minHeight: "280px", maxHeight: "420px" }}>
      {/* Two stacked slots — each can render YouTube or native video */}
      {[0, 1].map((slot) => {
        const clip = slotClips[slot];
        const showNative = isNative(clip);
        return (
          <div key={slot} className="absolute inset-0" style={{ overflow: "hidden", opacity: ready && activeSlot === slot ? 1 : 0, transition: "opacity 0.7s ease" }}>
            <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", width: "100vw", height: "56.25vw", minHeight: "100%", minWidth: "177.78vh", pointerEvents: "none" }}>
              <div ref={divs[slot]} className="w-full h-full" style={{ display: showNative ? 'none' : 'block' }} />
              <video ref={videos[slot]} className="w-full h-full object-cover" muted playsInline loop preload="auto"
                style={{ display: showNative ? 'block' : 'none' }}
                onPlaying={onNativePlaying(slot)}
                onEnded={() => { if (mountedRef.current && slot === activeRef.current) switchToNext(); }} />
            </div>
          </div>
        );
      })}

      {/* Darkening + gradient overlays */}
      <div className="absolute inset-0" style={{ background: "rgba(10,13,22,0.5)" }} />
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(10,13,22,0.15) 0%, rgba(10,13,22,0.35) 50%, #0a0d16 100%)" }} />
      <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(10,13,22,0.9) 0%, transparent 60%)" }} />

      {/* Initial loading veil */}
      <div className="absolute inset-0 z-[7] pointer-events-none" style={{ background: ready ? "transparent" : "#08000f", transition: "background 0.5s ease" }} />

      {/* Full transparent click-blocker — tap toggles sound */}
      <div className="absolute inset-0 z-[6]" style={{ pointerEvents: "auto" }} onClick={toggleMute} />

      {/* Content overlay */}
      <div className="absolute bottom-0 left-0 p-5 md:p-8 z-10 max-w-lg">
        <span className="text-xs font-bold uppercase tracking-widest mb-2 block shimmer-text">ویژه • Featured</span>
        <h2 className="text-white font-black text-2xl md:text-4xl mb-3 drop-shadow-lg">{heroSeries?.title}</h2>
        <p className="text-white/60 text-sm mb-4 line-clamp-2">{heroSeries?.description}</p>
        <div className="flex items-center gap-3">
          <button onClick={() => onPlay(heroClip)} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
            style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 20px rgba(123,44,191,0.5)" }}>
            <Play className="w-4 h-4 fill-white" /> پخش
          </button>
          <button onClick={() => onShowEpisodes(heroSeries)} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white/80 transition-all hover:scale-105"
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)" }}>
            <List className="w-4 h-4" /> قسمت‌ها
          </button>
        </div>
      </div>

      {/* App logo — top left */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-2.5">
        <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0" style={{ boxShadow: "0 0 12px rgba(123,44,191,0.4)", border: "1.5px solid rgba(123,44,191,0.35)" }}>
          <img src={LOGO_URL} alt="Asemanak" className="w-full h-full object-cover" />
        </div>
        <div className="leading-tight">
          <p className="text-white font-bold text-sm">آسمانک</p>
          <p className="text-purple-300/70 text-[9px] tracking-wide">TV</p>
        </div>
      </div>

      {/* Sound toggle — bottom right */}
      <button onClick={toggleMute} data-remote className="absolute bottom-4 right-4 z-10 w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
        style={{ background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.15)", backdropFilter: "blur(8px)" }}>
        {muted ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
      </button>

      {/* Scene indicator dots */}
      <div className="absolute top-4 right-4 flex gap-1.5 z-10">
        {clips.slice(0, 10).map((c, i) => {
          const cid = c.videoId || c.fileUrl;
          const hid = heroClip?.videoId || heroClip?.fileUrl;
          return (
            <div key={i} className="w-1.5 h-1.5 rounded-full transition-all"
              style={{
                background: cid === hid ? "#c77dff" : "rgba(255,255,255,0.25)",
                boxShadow: cid === hid ? "0 0 6px rgba(199,125,255,0.8)" : "none",
              }} />
          );
        })}
      </div>
    </div>
  );
}