import { useRef, useEffect, useState } from "react";
import { Play, List, Volume2, VolumeX, Loader2 } from "lucide-react";

const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";

/**
 * Trailer hero — plays a single series' first episode in the featured header.
 * Gallery videos use a callback ref + retry to ensure instant playback.
 */
export default function TrailerHero({ series, onEnter, onStop, isTV = false }) {
  const containerRef = useRef(null);
  const nativeVideoRef = useRef(null);
  const playerRef = useRef(null);
  const mountedRef = useRef(true);
  const [isPlaying, setIsPlaying] = useState(true);
  // On TV: always muted. On mobile: start unmuted (user clicked to open trailer).
  const [muted, setMuted] = useState(isTV ? true : false);
  const mutedRef = useRef(isTV ? true : false);
  const [ready, setReady] = useState(false);

  const firstEp = (series?.episodes || [])[0];
  const videoId = firstEp?.videoId;
  const fileUrl = firstEp?.fileUrl;
  const epCount = (series?.episodes || []).length;

  // YouTube player init
  useEffect(() => {
    mountedRef.current = true;
    if (!videoId) { setReady(true); return; }
    setReady(false);

    const init = () => {
      if (!mountedRef.current || !containerRef.current) return;
      if (playerRef.current) { try { playerRef.current.destroy(); } catch {} }

      playerRef.current = new window.YT.Player(containerRef.current, {
        videoId,
        width: "100%",
        height: "100%",
        playerVars: {
          autoplay: 1, mute: isTV ? 1 : 0, controls: 0, modestbranding: 1,
          rel: 0, iv_load_policy: 3, playsinline: 1, disablekb: 1, fs: 0,
        },
        events: {
          onReady: (e) => {
            if (!mountedRef.current) return;
            try {
              e.target.seekTo(15, true);
              if (isTV) {
                e.target.mute();
              } else {
                e.target.unMute();
                e.target.setVolume(100);
              }
              e.target.playVideo();
            } catch {}
            setReady(true);
            mutedRef.current = isTV;
            setMuted(isTV);
            if (!isTV) {
              setTimeout(() => {
                if (mountedRef.current && playerRef.current) {
                  try {
                    if (playerRef.current.getPlayerState() !== 1) {
                      playerRef.current.mute();
                      mutedRef.current = true;
                      setMuted(true);
                      playerRef.current.playVideo();
                    }
                  } catch {}
                }
              }, 3000);
            }
          },
          onStateChange: (e) => {
            if (!mountedRef.current) return;
            const st = e.data;
            if (st === 1) setIsPlaying(true);
            else if (st === 2) setIsPlaying(false);
          },
        },
      });
    };

    if (window.YT && window.YT.Player) init();
    else {
      if (!window.ytApiLoading) {
        window.ytApiLoading = true;
        const tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(tag);
      }
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { if (prev) prev(); init(); };
      const check = setInterval(() => {
        if (window.YT && window.YT.Player) { clearInterval(check); init(); }
      }, 200);
      setTimeout(() => clearInterval(check), 8000);
    }

    return () => {
      mountedRef.current = false;
      if (playerRef.current) {
        try { playerRef.current.stopVideo(); } catch {}
        try { playerRef.current.destroy(); } catch {}
        playerRef.current = null;
      }
    };
  }, [videoId]);

  // Native video: cleanup + fallback timer (play is handled by callback ref)
  useEffect(() => {
    if (!fileUrl) return;
    setReady(false);
    // On TV: muted. On mobile: unmuted (user clicked to open trailer).
    setMuted(isTV);
    const timer = setTimeout(() => setReady(true), 3000);
    return () => {
      clearTimeout(timer);
      const v = nativeVideoRef.current;
      if (v) {
        try { v.pause(); } catch {}
        try { v.removeAttribute('src'); } catch {}
        try { v.load(); } catch {}
      }
    };
  }, [fileUrl]);

  const togglePlay = () => {
    if (playerRef.current) {
      try {
        if (isPlaying) playerRef.current.pauseVideo();
        else playerRef.current.playVideo();
      } catch {}
    } else if (nativeVideoRef.current) {
      if (nativeVideoRef.current.paused) nativeVideoRef.current.play();
      else nativeVideoRef.current.pause();
    }
  };

  const toggleMute = () => {
    if (playerRef.current) {
      const next = !muted;
      mutedRef.current = next;
      try {
        if (next) playerRef.current.mute();
        else { playerRef.current.unMute(); playerRef.current.setVolume(100); }
      } catch {}
      setMuted(next);
    } else if (nativeVideoRef.current) {
      nativeVideoRef.current.muted = !nativeVideoRef.current.muted;
      setMuted(nativeVideoRef.current.muted);
    }
  };

  if (!videoId && !fileUrl) return null;

  return (
    <div className="relative w-full overflow-hidden flex-shrink-0" style={{ height: "45vh", minHeight: "280px", maxHeight: "420px" }}>
      {/* Video — YouTube or native */}
      <div className="absolute inset-0 overflow-hidden">
        {fileUrl ? (
          <video
            key={`${fileUrl}_${series?._trailerPlayId || ''}`}
            ref={(el) => {
              nativeVideoRef.current = el;
              if (el) {
                el.muted = isTV ? true : true; // start muted to allow autoplay, unmute after play
                el.play().then(() => {
                  if (isTV) {
                    el.muted = true;
                    setMuted(true);
                  } else {
                    el.muted = false;
                    el.volume = 1;
                    setMuted(false);
                  }
                }).catch(() => {
                  setMuted(true);
                  setTimeout(() => { try { el.play().catch(() => {}); } catch {} }, 500);
                });
              }
            }}
            autoPlay
            muted
            playsInline
            preload="auto"
            src={fileUrl}
            className="w-full h-full object-cover"
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onPlaying={() => setReady(true)}
            onCanPlay={() => { setReady(true); try { nativeVideoRef.current?.play().catch(() => {}); } catch {} }}
            onLoadedMetadata={(e) => {
              // Seek to an attractive scene (random 10-70s, or 70% of duration for short clips)
              const v = e.target;
              if (v.duration > 20) {
                try { v.currentTime = Math.min(Math.floor(Math.random() * 60) + 10, v.duration * 0.7); } catch {}
              }
            }}
            onLoadedData={() => { setReady(true); try { nativeVideoRef.current?.play().catch(() => {}); } catch {} }}
            onError={() => setReady(true)}
          />
        ) : videoId ? (
          <div style={{
            position: "absolute", top: "50%", left: "50%",
            transform: "translate(-50%, -50%)",
            width: "100vw", height: "56.25vw",
            minHeight: "100%", minWidth: "177.78vh",
            pointerEvents: "none",
          }}>
            <div ref={containerRef} className="w-full h-full" />
          </div>
        ) : null}
      </div>

      {/* Gradient overlays — YouTube gets full gradients; gallery gets minimal bottom gradient */}
      {videoId ? (
        <>
          <div className="absolute inset-0" style={{ background: "rgba(10,13,22,0.4)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(10,13,22,0.15) 0%, rgba(10,13,22,0.35) 50%, #0a0d16 100%)" }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(90deg, rgba(10,13,22,0.9) 0%, transparent 60%)" }} />
        </>
      ) : (
        <div className="absolute inset-0 pointer-events-none z-[5]"
          style={{ background: "linear-gradient(180deg, transparent 0%, transparent 50%, rgba(10,13,22,0.85) 100%)" }} />
      )}

      {/* Loading */}
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center z-[7]">
          <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
        </div>
      )}

      {/* Click-blocker — YouTube only */}
      {videoId && <div className="absolute inset-0 z-[6]" />}

      {/* Pause indicator */}
      {!isPlaying && ready && (
        <div className="absolute inset-0 z-10 flex items-center justify-center" onClick={(e) => { e.stopPropagation(); togglePlay(); }}>
          <div className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{ background: "rgba(123,44,191,0.6)", backdropFilter: "blur(8px)", border: "2px solid rgba(255,255,255,0.3)" }}>
            <Play className="w-8 h-8 fill-white text-white ml-1" />
          </div>
        </div>
      )}

      {/* Content overlay */}
      <div className="absolute bottom-0 left-0 p-5 md:p-8 z-[40] max-w-lg" style={{ pointerEvents: 'none' }}>
        <span className="text-xs font-bold uppercase tracking-widest mb-2 block shimmer-text">ویژه • Featured</span>
        <h2 className="text-white font-black text-2xl md:text-4xl mb-1 drop-shadow-lg">{series?.title}</h2>
        <p className="text-white/60 text-sm mb-4">قسمت — پخش از داخل برنامه {epCount}</p>
        <div className="flex items-center gap-3" style={{ pointerEvents: 'auto' }}>
          <button onClick={() => onEnter(series)} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white transition-all hover:scale-105"
            style={{ background: "linear-gradient(135deg, #7b2cbf, #9d4edd)", boxShadow: "0 4px 20px rgba(123,44,191,0.5)" }}>
            <Play className="w-4 h-4 fill-white" /> پخش
          </button>
          <button onClick={() => onEnter(series)} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold text-white/80 transition-all hover:scale-105"
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)" }}>
            <List className="w-4 h-4" /> قسمت‌ها
          </button>
        </div>
      </div>

      {/* App logo */}
      <div className="absolute top-4 left-4 z-[40] flex items-center gap-2.5">
        <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0" style={{ boxShadow: "0 0 12px rgba(123,44,191,0.4)", border: "1.5px solid rgba(123,44,191,0.35)" }}>
          <img src={LOGO_URL} alt="Asemanak" className="w-full h-full object-cover" />
        </div>
        <div className="leading-tight">
          <p className="text-white font-bold text-sm">آسمانک</p>
          <p className="text-purple-300/70 text-[9px] tracking-wide">TV</p>
        </div>
      </div>

      {/* Sound toggle — visible for both YouTube and gallery */}
      <button onClick={toggleMute} data-remote className="absolute bottom-4 right-4 z-[40] w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
        style={{ background: "rgba(0,0,0,0.6)", border: "1px solid rgba(255,255,255,0.15)", backdropFilter: "blur(8px)" }}>
        {muted ? <VolumeX className="w-4 h-4 text-white/70" /> : <Volume2 className="w-4 h-4 text-white" />}
      </button>

    </div>
  );
}