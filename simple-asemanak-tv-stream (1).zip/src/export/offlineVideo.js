import { idbGet, idbSet, idbDel } from "@/lib/idb";

const STORE = "videos";
const INDEX_KEY = "ayeneh_offline_index";
const urlCache = new Map();

function readIndex() {
  try { return JSON.parse(localStorage.getItem(INDEX_KEY) || "[]"); } catch { return []; }
}
function writeIndex(list) {
  localStorage.setItem(INDEX_KEY, JSON.stringify(list));
  window.dispatchEvent(new Event("ayeneh-offline-changed"));
}

export function getOfflineIndex() { return readIndex(); }

export async function getOfflineVideoUrl(fileUrl) {
  if (urlCache.has(fileUrl)) return urlCache.get(fileUrl);
  const blob = await idbGet(STORE, fileUrl);
  if (!blob) return null;
  const objUrl = URL.createObjectURL(blob);
  urlCache.set(fileUrl, objUrl);
  return objUrl;
}

export function getOfflineVideoUrlSync(fileUrl) {
  return urlCache.has(fileUrl) ? urlCache.get(fileUrl) : null;
}

export async function isVideoOffline(fileUrl) {
  if (urlCache.has(fileUrl)) return true;
  const blob = await idbGet(STORE, fileUrl);
  return !!blob;
}

export async function cacheVideoOffline(fileUrl, meta = {}, directUrl) {
  const url = directUrl || fileUrl;
  const res = await fetch(url);
  if (!res.ok) throw new Error("fetch_failed");
  const blob = await res.blob();
  await idbSet(STORE, fileUrl, blob);
  const list = readIndex().filter(e => e.fileUrl !== fileUrl);
  list.push({ fileUrl, label: meta.label || fileUrl, size: blob.size, cachedAt: Date.now() });
  writeIndex(list);
  return true;
}

export async function removeOfflineVideo(fileUrl) {
  if (urlCache.has(fileUrl)) { URL.revokeObjectURL(urlCache.get(fileUrl)); urlCache.delete(fileUrl); }
  await idbDel(STORE, fileUrl);
  writeIndex(readIndex().filter(e => e.fileUrl !== fileUrl));
}

export async function clearAllOffline() {
  const list = readIndex();
  for (const e of list) {
    if (urlCache.has(e.fileUrl)) { URL.revokeObjectURL(urlCache.get(e.fileUrl)); urlCache.delete(e.fileUrl); }
    await idbDel(STORE, e.fileUrl);
  }
  writeIndex([]);
}