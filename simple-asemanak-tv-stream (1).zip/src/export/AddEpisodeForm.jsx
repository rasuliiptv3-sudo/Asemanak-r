import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Loader2, Link2, Type, AlertCircle, Upload, Film, Video, Hash } from "lucide-react";

// ── Link parsing helpers (single episode) ──
function extractVideoId(url) {
  if (!url) return null;
  const patterns = [
    /[?&]v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) { const m = url.match(p); if (m) return m[1]; }
  if (/^[a-zA-Z0-9_-]{11}$/.test(url.trim())) return url.trim();
  return null;
}
function isDirectVideoUrl(url) {
  if (!url) return false;
  const lower = url.toLowerCase().split("?")[0];
  return /\.(mp4|webm|ogg|mkv|m3u8|mov|avi|m4v)(\?|$)/.test(lower);
}
function extractAparatHash(url) {
  if (!url) return null;
  const m = url.match(/aparat\.com\/v\/([a-zA-Z0-9]+)/);
  return m ? m[1] : null;
}

const MAX_VIDEO_MB = 1000;
const MAX_VIDEO_SIZE = MAX_VIDEO_MB * 1024 * 1024;
function fmtSize(bytes) {
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}
function uploadWithTimeout(file, timeoutMs = 1200000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("timeout")), timeoutMs);
    base44.integrations.Core.UploadFile({ file })
      .then(res => { clearTimeout(timer); resolve(res); })
      .catch(e => { clearTimeout(timer); reject(e); });
  });
}

// Add a single new episode to an existing series (YouTube link, direct video URL, Aparat, or gallery upload).
export default function AddEpisodeForm({ onAdd, onClose, nextNumber = 1, currentSeason = 1, isFa = true }) {
  const [mode, setMode] = useState("youtube"); // "youtube" | "link" | "gallery"
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [number, setNumber] = useState(String(nextNumber));
  const [season, setSeason] = useState(String(currentSeason));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [videoFile, setVideoFile] = useState(null);
  const fileInputRef = useRef(null);
  const tr = (f, e) => isFa ? f : e;

  const submit = async () => {
    setError(null);
    const epTitle = title.trim() || `${tr("قسمت", "Episode")} ${Number(number) || nextNumber}`;
    const epNumber = Number(number) || nextNumber;

    // Gallery upload (single file)
    if (mode === "gallery") {
      if (!videoFile) { setError(tr("یک ویدیو از گالری انتخاب کنید", "Pick a video from gallery")); return; }
      if (videoFile.size > MAX_VIDEO_SIZE) {
        setError(tr(
          `فایل (${fmtSize(videoFile.size)}) بزرگ‌تر از ${MAX_VIDEO_MB} مگابایت است. ویدیوی کوچک‌تر انتخاب کنید.`,
          `File (${fmtSize(videoFile.size)}) is larger than ${MAX_VIDEO_MB}MB. Pick a smaller video.`
        ));
        return;
      }
      setLoading(true);
      setUploadProgress(0);
      const estimatedSeconds = Math.max(5, videoFile.size / (5 * 1024 * 1024));
      const startTime = Date.now();
      const progressInterval = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        setUploadProgress(Math.min(95, (elapsed / estimatedSeconds) * 100));
      }, 200);
      try {
        const res = await uploadWithTimeout(videoFile);
        clearInterval(progressInterval);
        setUploadProgress(100);
        onAdd({ fileUrl: res.file_url, title: epTitle, number: epNumber, season: Number(season) || 1 });
        onClose();
      } catch (e) {
        clearInterval(progressInterval);
        setUploadProgress(0);
        setError(e?.message === "timeout"
          ? tr(`آپلود طول کشید — فایل کمتر از ${MAX_VIDEO_MB} مگابایت انتخاب کنید.`, `Upload timed out — pick a file under ${MAX_VIDEO_MB}MB.`)
          : tr("خطا در آپلود فایل", "Upload failed"));
        setLoading(false);
      }
      return;
    }

    const trimmed = url.trim();
    if (!trimmed) { setError(tr("لینک را وارد کنید", "Enter a link")); return; }
    setLoading(true);

    if (mode === "youtube") {
      const vid = extractVideoId(trimmed);
      if (!vid) { setError(tr("لینک یوتیوب معتبر نیست", "Invalid YouTube link")); setLoading(false); return; }
      onAdd({ videoId: vid, title: epTitle, number: epNumber, season: Number(season) || 1 });
      onClose();
      return;
    }

    // Direct link / Aparat
    const aparat = extractAparatHash(trimmed);
    if (aparat) {
      onAdd({ embedUrl: `https://www.aparat.com/video/video/embed/videohash/${aparat}/vt/frame`, title: epTitle, number: epNumber, season: Number(season) || 1 });
      onClose();
      return;
    }
    if (isDirectVideoUrl(trimmed)) {
      onAdd({ fileUrl: trimmed, title: epTitle, number: epNumber, season: Number(season) || 1 });
      onClose();
      return;
    }
    setError(tr("لینک مستقیم ویدیو (mp4, webm, m3u8) یا لینک آپارات وارد کنید", "Enter a direct video link (mp4/webm/m3u8) or Aparat link"));
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85" onClick={onClose}>
      <div className="w-full max-w-md mx-4 rounded-2xl p-6 flex flex-col gap-4 max-h-[92vh] overflow-y-auto"
        style={{ background: 'rgba(13,17,30,0.98)', border: '1px solid rgba(34,211,238,0.25)' }}
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <p className="text-white font-bold text-base">{tr("افزودن قسمت جدید", "Add New Episode")}</p>
          <button onClick={onClose} data-remote className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="flex rounded-xl overflow-hidden border border-white/10">
          <button onClick={() => setMode("youtube")} data-remote
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${mode === "youtube" ? "bg-purple-600/30 text-purple-300" : "text-white/40 hover:text-white"}`}>
            <Link2 className="w-3.5 h-3.5" /> {tr("یوتیوب", "YouTube")}
          </button>
          <button onClick={() => setMode("link")} data-remote
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${mode === "link" ? "bg-cyan-600/30 text-cyan-300" : "text-white/40 hover:text-white"}`}>
            <Video className="w-3.5 h-3.5" /> {tr("لینک مستقیم", "Direct Link")}
          </button>
          <button onClick={() => setMode("gallery")} data-remote
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${mode === "gallery" ? "bg-cyan-600/30 text-cyan-300" : "text-white/40 hover:text-white"}`}>
            <Upload className="w-3.5 h-3.5" /> {tr("گالری", "Gallery")}
          </button>
        </div>

        <div>
          <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Type className="w-3 h-3" /> {tr("عنوان قسمت", "Episode title")}</label>
          <input value={title} onChange={e => setTitle(e.target.value)} data-remote
            placeholder={`${tr("قسمت", "Episode")} ${nextNumber}`}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
        </div>

        <div className="flex gap-3">
          <div className="flex-1">
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Hash className="w-3 h-3" /> {tr("شماره قسمت", "Episode number")}</label>
            <input type="number" min="1" value={number} onChange={e => setNumber(e.target.value)} data-remote
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-cyan-500/50" />
          </div>
          <div className="flex-1">
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Hash className="w-3 h-3" /> {tr("فصل", "Season")}</label>
            <input type="number" min="1" value={season} onChange={e => setSeason(e.target.value)} data-remote
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-cyan-500/50" />
          </div>
        </div>

        {mode === "youtube" ? (
          <div>
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Link2 className="w-3 h-3" /> {tr("لینک ویدیوی یوتیوب", "YouTube video link")}</label>
            <input value={url} onChange={e => setUrl(e.target.value)} data-remote
              placeholder="https://youtube.com/watch?v=... یا youtu.be/..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-purple-500/50" />
          </div>
        ) : mode === "link" ? (
          <div>
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Video className="w-3 h-3" /> {tr("لینک مستقیم ویدیو", "Direct video link")}</label>
            <input value={url} onChange={e => setUrl(e.target.value)} data-remote
              placeholder="https://example.com/ep.mp4 یا آپارات"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
            <p className="text-[11px] text-cyan-400/60 mt-1.5">
              ⓘ {tr("لینک مستقیم فایل ویدیو (mp4, webm, m3u8) یا لینک آپارات", "Direct video file (mp4/webm/m3u8) or Aparat link")}
            </p>
          </div>
        ) : (
          <div>
            <label className="text-xs text-white/40 mb-1.5 flex items-center gap-1.5"><Film className="w-3 h-3" /> {tr("فایل ویدیو", "Video file")}</label>
            <button onClick={() => fileInputRef.current?.click()} data-remote
              className="w-full border-2 border-dashed border-white/15 rounded-xl py-6 flex flex-col items-center gap-2 hover:border-cyan-500/50 transition-colors">
              <Upload className="w-7 h-7 text-white/40" />
              <span className="text-xs text-white/50">{videoFile ? videoFile.name : (tr("انتخاب ویدیو از گالری", "Pick a video from gallery"))}</span>
              {videoFile && <span className={`text-[11px] ${videoFile.size > MAX_VIDEO_SIZE ? "text-red-400" : "text-white/30"}`}>{fmtSize(videoFile.size)}</span>}
            </button>
            <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={e => setVideoFile(e.target.files?.[0] || null)} />
            <p className="text-[11px] text-white/30">ⓘ {tr(`حداکثر ${MAX_VIDEO_MB} مگابایت برای هر ویدیو`, `Max ${MAX_VIDEO_MB}MB per video`)}</p>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 text-red-400 text-xs bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" /> {error}
          </div>
        )}

        {loading && mode === "gallery" && uploadProgress > 0 && (
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/60">{tr("در حال آپلود...", "Uploading...")}</span>
              <span className="text-cyan-400 font-bold">{Math.round(uploadProgress)}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-200"
                style={{ width: `${uploadProgress}%`, background: 'linear-gradient(90deg, #0e7490, #22d3ee)' }} />
            </div>
            <p className="text-white/30 text-[10px] text-center">
              {tr("لطفاً صبر کنید — آپلود ممکن است چند دقیقه طول بکشد", "Please wait — upload may take a few minutes")}
            </p>
          </div>
        )}

        <button onClick={submit} data-remote
          disabled={loading || (mode !== "gallery" ? !url.trim() : !videoFile)}
          className="w-full py-3 rounded-xl text-sm font-bold text-white transition-colors disabled:opacity-40 flex items-center justify-center gap-2"
          style={{ background: 'linear-gradient(135deg, #0e7490, #22d3ee)', boxShadow: '0 4px 15px rgba(34,211,238,0.35)' }}>
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> {mode === "gallery" ? tr("در حال آپلود...", "Uploading...") : tr("در حال پردازش...", "Processing...")}</> : (tr("افزودن قسمت", "Add Episode"))}
        </button>
      </div>
    </div>
  );
}