import { useState, useEffect, useRef } from "react";

export function usePullToRefresh({ onRefresh, disabled, threshold = 70, containerRef }) {
  const ownRef = useRef(null);
  const ref = containerRef || ownRef;
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const st = useRef({ startY: null, pulling: false, refreshing: false, lastDy: 0 });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const isMobile = () => window.innerWidth < 768;

    const onStart = (e) => {
      st.current.startY = e.touches[0].clientY;
      st.current.lastDy = 0;
      st.current.pulling = false;
    };
    const onMove = (e) => {
      if (st.current.startY === null || st.current.refreshing) return;
      const dy = e.touches[0].clientY - st.current.startY;
      st.current.lastDy = dy;
      const atTop = el.scrollTop <= 0;
      if (disabled || !isMobile() || !atTop) {
        if (st.current.pulling) { st.current.pulling = false; setPull(0); }
        return;
      }
      if (dy <= 0) { st.current.pulling = false; setPull(0); return; }
      st.current.pulling = true;
      setPull(Math.min(threshold * 1.6, dy * 0.5));
    };
    const onEnd = async () => {
      if (!st.current.pulling) { st.current.startY = null; return; }
      st.current.pulling = false;
      st.current.startY = null;
      if (st.current.lastDy >= threshold && !st.current.refreshing) {
        st.current.refreshing = true;
        setRefreshing(true);
        setPull(threshold);
        try { await onRefresh?.(); } finally {
          st.current.refreshing = false;
          setRefreshing(false);
          setPull(0);
        }
      } else { setPull(0); }
    };

    el.addEventListener("touchstart", onStart, { passive: true });
    el.addEventListener("touchmove", onMove, { passive: true });
    el.addEventListener("touchend", onEnd, { passive: true });
    return () => {
      el.removeEventListener("touchstart", onStart);
      el.removeEventListener("touchmove", onMove);
      el.removeEventListener("touchend", onEnd);
    };
  }, [ref, disabled, threshold, onRefresh]);

  return { ref, pull, refreshing };
}