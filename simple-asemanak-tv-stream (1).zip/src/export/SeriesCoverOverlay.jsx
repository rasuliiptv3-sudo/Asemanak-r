import { Loader2 } from "lucide-react";

export default function SeriesCoverOverlay({ poster, title, phase, visible = true, onReplay, posterPosition }) {
  const isImage = poster && poster.match(/\.(jpg|jpeg|png|gif|webp|svg|avif)(\?|#|$)/i);
  const objPos = posterPosition || 'center 20%';

  return (
    <div className="absolute inset-0 z-[35] overflow-hidden transition-opacity duration-700"
      style={{ opacity: visible ? 1 : 0, pointerEvents: phase === "end" && visible ? "auto" : "none" }}>
      {isImage ? (
        <img src={poster} alt={title} className="absolute inset-0 w-full h-full object-cover"
          style={{ objectPosition: objPos }} onError={(e) => { e.target.style.display = 'none'; }} />
      ) : poster ? (
        <video src={`${poster}#t=0.1`} className="absolute inset-0 w-full h-full object-cover"
          style={{ objectPosition: objPos }} muted preload="metadata" playsInline />
      ) : (
        <div className="absolute inset-0" style={{ background: '#0a0d16' }} />
      )}
      {poster && (
        <div className="absolute inset-0" style={{
          background: 'linear-gradient(180deg, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0.6) 100%)'
        }} />
      )}
      {phase === "start" && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-10 h-10 text-purple-400 animate-spin" style={{ filter: 'drop-shadow(0 0 8px rgba(168,85,247,0.5))' }} />
        </div>
      )}
      {phase === "end" && onReplay && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button onClick={onReplay} data-remote
            className="flex items-center gap-2 px-6 py-3 rounded-xl text-white font-semibold transition-all hover:scale-105"
            style={{ background: 'rgba(123,44,191,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.2)' }}>
            <Loader2 className="w-5 h-5" /> تماشای دوباره
          </button>
        </div>
      )}
    </div>
  );
}