import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { LOGO_URL } from "@/lib/brandAssets";

export default function MediaSplash({ onDone }) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setExiting(true), 1500);
    const t2 = setTimeout(() => onDone(), 2000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onDone]);

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: "#0a0d16",
      opacity: exiting ? 0 : 1,
      transition: "opacity 0.5s ease-in-out",
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center", gap: "20px",
    }}>
      <img src={LOGO_URL} alt="Asemanak TV" style={{ width: 64, height: 64, opacity: 0.4 }} />
      <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
    </div>
  );
}