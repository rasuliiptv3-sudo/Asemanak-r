import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Loader2, Link2, Type, Tv2, Clapperboard, AlertCircle, Upload, Film, ImagePlus, Video, Smile, Heart, Gift, Hash } from "lucide-react";

const CATEGORIES = [
  { id: "series", label: "سریال", icon: <Tv2 className="w-4 h-4" /> },
  { id: "movies", label: "فیلم", icon: <Film className="w-4 h-4" /> },
  { id: "animation", label: "انیمیشن", icon: <Clapperboard className="w-4 h-4" /> },
  { id: "comedy", label: "کمدی", icon: <Smile className="w-4 h-4" /> },
  { id: "drama", label: "داستانی", icon: <Heart className="w-4 h-4" /> },
  { id: "occasional", label: "مناسبتی", icon: <Gift className="w-4 h-4" /> },
];

const MAX_VIDEO_MB = 1000;
const MAX_VIDEO_SIZE = MAX_VIDEO_MB * 1024 * 1024;

function fmtSize(bytes) {
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

function uploadWithTimeout(file, timeoutMs = 1200000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("timeout")), timeoutMs);
    base44.integrations.Core.UploadFile({ file })
      .then(res => { clearTimeout(timer); resolve(res); })
      .catch(e => { clearTimeout(timer); reject(e); });
  });
}

// ── YouTube helpers ──
function extractPlaylistId(url) {
  if (!url) return null;
  const patterns = [/[?&]list=([a-zA-Z0-9_-]+)/, /playlist\/([a-zA-Z0-9_-]+)/];
  for (const p of patterns) { const m = url.match(p); if (m) return m[1]; }
  if (/^[a-zA-Z0-9_-]{20,}$/.test(url.trim())) return url.trim();
  return null;
}

function extractVideoId(url) {
  if (!url) return null;
  const patterns = [
    /[?&]v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const p of patterns) { const m = url.match(p); if (m) return m[1]; }
  if (/^[a-zA-Z0-9_-]{11}$/.test(url.trim())) return url.trim();
  return null;
}

// ── Direct video URL detection ──
function isDirectVideoUrl(url) {
  if (!url) return false;
  const lower = url.toLowerCase().split("?")[0];
  return /\.(mp4|webm|ogg|mkv|m3u8|mov|avi|m4v)(\?|$)/.test(lower);
}

// ── Aparat helper ──
function extractAparatHash(url) {
  if (!url) return null;
  const m = url.match(/aparat\.com\/v\/([a-zA-Z0-9]+)/);
  return m ? m[1] : null;
}

function extractJSONObject(html, marker) {
  const startIdx = html.indexOf(marker);
  if (startIdx === -1) return null;
  const braceStart = html.indexOf('{', startIdx);
  if (braceStart === -1) return null;
  let depth = 0, inString = false, escape = false;
  for (let i = braceStart; i < html.length && i < braceStart + 5000000; i++) {
    const c = html[i];
    if (escape) { escape = false; continue; }
    if (c === '\\') { escape = true; continue; }
    if (c === '"') { inString = !inString; continue; }
    if (inString) continue;
    if (c === '{') depth++;
    if (c === '}') { depth--; if (depth === 0) { try { return JSON.parse(html.substring(braceStart, i + 1)); } catch { return null; } } }
  }
  return null;
}

// Parses YouTube playlist page data — supports both the legacy
// playlistVideoListRenderer layout and the new lockupViewModel layout.
function parsePlaylistData(data) {
  const episodes = [];
  const seen = new Set();
  let continuationToken = null;
  const extract = (videoId, title) => {
    if (!videoId || seen.has(videoId)) return;
    seen.add(videoId);
    // Use playlist position as the episode number (reliable for 400+ episodes).
    episodes.push({ videoId, title: title || '', number: episodes.length + 1 });
  };
  const extractLockup = (lv) => {
    let videoId = null;
    let title = '';
    try {
      const sources = lv?.contentImage?.thumbnailViewModel?.image?.sources || [];
      for (const s of sources) {
        if (s?.url) {
          const m = s.url.match(/\/(?:vi|vi_webp)\/([a-zA-Z0-9_-]{6,})\//);
          if (m) { videoId = m[1]; break; }
        }
      }
    } catch {}
    if (!videoId) {
      try {
        const tap = lv?.navigationViewModel?.onTap || {};
        const we = tap?.innertubeCommand?.watchEndpoint || tap?.watchEndpoint;
        if (we?.videoId) videoId = we.videoId;
      } catch {}
    }
    if (!videoId) {
      try {
        const json = JSON.stringify(lv);
        const m = json.match(/"videoId":"([a-zA-Z0-9_-]{6,})"/);
        if (m) videoId = m[1];
      } catch {}
    }
    try { title = lv?.metadata?.lockupMetadataViewModel?.title?.content || ''; } catch {}
    extract(videoId, title);
  };
  const processItem = (item) => {
    if (!item || typeof item !== 'object') return;
    if (item.continuationItemRenderer) {
      const ce = item.continuationItemRenderer.continuationEndpoint || {};
      const tok = ce.continuationCommand?.token;
      if (tok) continuationToken = tok;
      return;
    }
    if (item.lockupViewModel) extractLockup(item.lockupViewModel);
    else if (item.playlistVideoRenderer) {
      const v = item.playlistVideoRenderer;
      extract(v.videoId, (v.title?.runs || []).map(r => r.text).join(''));
    } else if (item.playlistPanelVideoRenderer) {
      const v = item.playlistPanelVideoRenderer;
      extract(v.videoId, v.title?.simpleText || (v.title?.runs || []).map(r => r.text).join(''));
    }
  };
  const visit = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    if (Array.isArray(obj)) { obj.forEach(visit); return; }
    if (Array.isArray(obj.continuationItems)) obj.continuationItems.forEach(processItem);
    if (obj.appendContinuationItemsAction?.continuationItems) obj.appendContinuationItemsAction.continuationItems.forEach(processItem);
    if (obj.itemSectionRenderer) {
      const c = obj.itemSectionRenderer.contents || [];
      if (c.some(x => x?.lockupViewModel)) c.forEach(processItem);
    }
    if (obj.playlistVideoListRenderer) (obj.playlistVideoListRenderer.contents || []).forEach(processItem);
    for (const k of Object.keys(obj)) {
      if (k === 'continuationItems') continue;
      visit(obj[k]);
    }
  };
  let title = '';
  try {
    const h = data?.header?.playlistHeaderRenderer;
    if (h?.title?.simpleText) title = h.title.simpleText;
    else if (h?.title?.runs) title = h.title.runs.map(r => r.text).join('');
  } catch {}
  visit(data);
  episodes.sort((a, b) => a.number - b.number);
  return { title, episodes, continuationToken };
}

// Extract YouTube internal API key + client version from the playlist page HTML.
function extractYtcfg(html) {
  if (!html || typeof html !== 'string') return null;
  let apiKey = null, clientVersion = null;
  const keyMatch = html.match(/"INNERTUBE_API_KEY"\s*:\s*"([a-zA-Z0-9_-]+)"/);
  if (keyMatch) apiKey = keyMatch[1];
  const verMatch = html.match(/"INNERTUBE_CONTEXT_CLIENT_VERSION"\s*:\s*"([0-9.]+)"/) || html.match(/"clientVersion"\s*:\s*"([0-9.]+)"/);
  if (verMatch) clientVersion = verMatch[1];
  if (!apiKey || !clientVersion) return null;
  return {
    apiKey,
    context: { client: { clientName: "WEB", clientVersion, hl: "en", gl: "US" } },
  };
}

// Fetch one continuation page (next ~100 episodes) via the YouTube internal API.
async function fetchContinuationPage(token, cfg) {
  const apiUrl = `https://www.youtube.com/youtubei/v1/browse?key=${cfg.apiKey}`;
  const proxied = `https://corsproxy.io/?url=${encodeURIComponent(apiUrl)}`;
  const res = await fetch(proxied, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ context: cfg.context, continuation: token }),
  });
  if (!res.ok) return { episodes: [], continuationToken: null };
  const json = await res.json();
  return parsePlaylistData(json);
}

// Public YouTube web API key + context (used to call the internal browse API
// directly — far more reliable than scraping the HTML page, which YouTube often
// blocks with a consent redirect).
const INNERTUBE_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
const INNERTUBE_CONTEXT = { client: { clientName: "WEB", clientVersion: "2.20240801.00.00", hl: "en", gl: "US" } };

// Fetch one continuation page (next ~100 episodes) via the YouTube browse API.
async function fetchBrowseContinuation(token) {
  const apiUrl = `https://www.youtube.com/youtubei/v1/browse?key=${INNERTUBE_API_KEY}`;
  const proxies = [
    (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
    (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
    (u) => `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(u)}`,
  ];
  for (let i = 0; i < proxies.length; i++) {
    try {
      const res = await fetch(proxies[i](apiUrl), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ context: INNERTUBE_CONTEXT, continuation: token }),
      });
      if (!res.ok) continue;
      const json = await res.json();
      return parsePlaylistData(json);
    } catch {}
  }
  return { episodes: [], continuationToken: null };
}

// Fetch ALL video IDs from a YouTube playlist via the IFrame Player API.
// This is the most reliable client-side method — no CORS proxies needed.
// cuePlaylist loads the full playlist metadata; getPlaylist() returns every
// video ID (works for 400+ episode playlists).
function fetchPlaylistViaIframe(playlistId) {
  return new Promise((resolve, reject) => {
    let resolved = false;
    let pollTimer = null;
    let timeoutTimer = null;
    let player = null;
    let lastLength = 0;
    let stableCount = 0;
    const holder = document.createElement("div");
    holder.style.cssText = "position:fixed;width:1px;height:1px;left:-9999px;top:-9999px;opacity:0;pointer-events:none;overflow:hidden";
    document.body.appendChild(holder);
    const inner = document.createElement("div");
    inner.id = `yt-pl-fetch-${Date.now()}`;
    holder.appendChild(inner);
    const cleanup = () => {
      if (pollTimer) clearInterval(pollTimer);
      if (timeoutTimer) clearTimeout(timeoutTimer);
      try { if (player) player.destroy(); } catch {}
      try { holder.remove(); } catch {}
    };
    const tryGetPlaylist = () => {
      if (resolved) return;
      try {
        const list = player && player.getPlaylist && player.getPlaylist();
        if (list && list.length > 0) {
          // Wait for the list to stabilize — YouTube loads playlists incrementally,
          // so we poll until the length stops growing (3 consecutive same-length polls).
          if (list.length === lastLength) {
            stableCount++;
            if (stableCount >= 3) {
              resolved = true;
              cleanup();
              resolve(list);
              return;
            }
          } else {
            stableCount = 0;
            lastLength = list.length;
          }
        }
      } catch {}
    };
    const start = () => {
      player = new window.YT.Player(inner, {
        width: "1", height: "1",
        playerVars: { mute: 1, autoplay: 0, controls: 0, disablekb: 1, fs: 0, iv_load_policy: 3, modestbranding: 1 },
        events: {
          onReady: () => { try { player.mute(); player.cuePlaylist({ list: playlistId, listType: "playlist", index: 0 }); } catch {} },
          onStateChange: (e) => { if (e.data === 5 || e.data === 1) tryGetPlaylist(); },
          onError: () => { if (!resolved) { cleanup(); reject(new Error("iframe_error")); } },
        },
      });
      pollTimer = setInterval(tryGetPlaylist, 800);
      timeoutTimer = setTimeout(() => {
        if (!resolved) {
          // Before timing out, return whatever we have so far
          try {
            const list = player && player.getPlaylist && player.getPlaylist();
            if (list && list.length > 0) {
              resolved = true;
              cleanup();
              resolve(list);
              return;
            }
          } catch {}
          cleanup();
          reject(new Error("timeout"));
        }
      }, 45000);
    };
    if (window.YT && window.YT.Player) start();
    else {
      if (!window.YT) {
        const tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(tag);
      }
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { if (prev) prev(); start(); };
      const check = setInterval(() => { if (window.YT && window.YT.Player) { clearInterval(check); start(); } }, 200);
      setTimeout(() => clearInterval(check), 8000);
    }
  });
}

export async function fetchPlaylistEpisodes(playlistId) {
  // 1) Backend function — server-side fetch (fast, reliable, returns episode titles).
  //    Tried first so the user doesn't wait 45s for the IFrame API to time out.
  try {
    const res = await base44.functions.invoke("fetchYoutubePlaylist", { playlistId });
    const data = res.data;
    if (data && Array.isArray(data.episodes) && data.episodes.length > 0) {
      return { title: data.title || "", episodes: data.episodes };
    }
  } catch {}
  // 2) IFrame Player API — client-side fallback (no CORS proxies needed).
  //    cuePlaylist loads the full playlist; getPlaylist() returns every video ID (400+).
  try {
    const videoIds = await fetchPlaylistViaIframe(playlistId);
    if (videoIds && videoIds.length > 0) {
      // YouTube default playlist sort is newest-first; reverse for chronological order (ep 1 at top)
      const episodes = videoIds
        .filter(vid => vid && vid.length >= 6)
        .reverse()
        .map((vid, i) => ({ videoId: vid, title: `قسمت ${i + 1}`, number: i + 1 }));
      if (episodes.length > 0) return { title: `سریال ${playlistId.slice(-6)}`, episodes };
    }
  } catch {}
  // 3) YouTube internal browse API via CORS proxies (fallback for titles).
  try {
    const apiUrl = `https://www.youtube.com/youtubei/v1/browse?key=${INNERTUBE_API_KEY}`;
    const proxies = [
      (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
      (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
      (u) => `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(u)}`,
    ];
    let data = null;
    for (let i = 0; i < proxies.length; i++) {
      try {
        const res = await fetch(proxies[i](apiUrl), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ context: INNERTUBE_CONTEXT, browseId: "VL" + playlistId }),
        });
        if (!res.ok) continue;
        data = await res.json();
        if (data) break;
      } catch {}
    }
    if (data) {
      const { title, episodes, continuationToken } = parsePlaylistData(data);
      if (episodes.length > 0) {
        let token = continuationToken;
        let pages = 0;
        while (token && pages < 60) {
          try {
            const more = await fetchBrowseContinuation(token);
            if (!more.episodes.length) break;
            for (const ep of more.episodes) {
              if (!episodes.find(e => e.videoId === ep.videoId)) {
                episodes.push({ ...ep, number: episodes.length + 1 });
              }
            }
            token = more.continuationToken;
            pages++;
          } catch { break; }
        }
        // YouTube default sort is newest-first; reverse for chronological order (ep 1 at top)
        episodes.reverse();
        episodes.forEach((ep, i) => { ep.number = i + 1; });
        return { title, episodes };
      }
    }
  } catch {}
  // 4) HTML scrape fallback (ytInitialData).
  try {
  const pageUrl = `https://www.youtube.com/playlist?list=${playlistId}`;
  const proxies = [
    (u) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
    (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
    (u) => `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(u)}`,
  ];
  let firstHtml = null;
  for (let i = 0; i < proxies.length; i++) {
    try {
      const res = await fetch(proxies[i](pageUrl));
      if (!res.ok) continue;
      firstHtml = await res.text();
      break;
    } catch {}
  }
  if (firstHtml) {
    const data = extractJSONObject(firstHtml, 'ytInitialData');
    if (data) {
      const { title, episodes, continuationToken } = parsePlaylistData(data);
      if (episodes.length > 0) {
        const cfg = extractYtcfg(firstHtml);
        let token = continuationToken;
        let pages = 0;
        while (token && cfg?.apiKey && pages < 60) {
          try {
            const more = await fetchContinuationPage(token, cfg);
            if (!more.episodes.length) break;
            for (const ep of more.episodes) {
              if (!episodes.find(e => e.videoId === ep.videoId)) {
                episodes.push({ ...ep, number: episodes.length + 1 });
              }
            }
            token = more.continuationToken;
            pages++;
          } catch { break; }
        }
        // YouTube default sort is newest-first; reverse for chronological order (ep 1 at top)
        episodes.reverse();
        episodes.forEach((ep, i) => { ep.number = i + 1; });
        return { title, episodes };
      }
    }
  }
  } catch {}
  // 5) RSS fallback (returns the last ~15 entries).
  const rssUrl = `https://www.youtube.com/feeds/videos.xml?playlist_id=${playlistId}`;
  const res = await fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(rssUrl)}`);
  if (!res.ok) throw new Error("fetch_failed");
  const xml = await res.text();
  const doc = new DOMParser().parseFromString(xml, "text/xml");
  const entries = doc.querySelectorAll("entry");
  if (!entries.length) throw new Error("no_videos");
  const episodes = [];
  let playlistTitle = (doc.querySelector("feed > title")?.textContent || "").trim();
  Array.from(entries).reverse().forEach((entry, i) => {
    const idText = entry.querySelector("id")?.textContent || "";
    const videoId = idText.replace("yt:video:", "");
    const rawTitle = entry.querySelector("title")?.textContent || `قسمت ${i + 1}`;
    episodes.push({ videoId, title: rawTitle, number: i + 1 });
  });
  return { title: playlistTitle, episodes };
}

export default function AddPlaylistForm({ onAdd, onClose, defaultCategory = "series" }) {
  const [mode, setMode] = useState("youtube"); // "youtube" | "link" | "gallery"
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(defaultCategory);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState("");
  const [error, setError] = useState(null);
  const [videoFiles, setVideoFiles] = useState([]);
  const [posterFile, setPosterFile] = useState(null);
  const [posterPreview, setPosterPreview] = useState("");
  const [season, setSeason] = useState("1");
  const fileInputRef = useRef(null);
  const posterInputRef = useRef(null);

  // ── YouTube: playlist OR single video ──
  const handleSubmitYouTube = async () => {
    const trimmed = url.trim();
    const playlistId = extractPlaylistId(trimmed);
    const videoId = extractVideoId(trimmed);

    if (!playlistId && !videoId) {
      setError("لینک یوتیوب معتبر نیست — پلی‌لیست یا ویدیوی تکی وارد کنید");
      return;
    }

    setLoading(true); setError(null);

    // Single YouTube video → 1 episode
    if (!playlistId && videoId) {
      const finalTitle = title.trim() || "ویدیوی یوتیوب";
      onAdd({
        id: `yt_single_${videoId}`,
        title: finalTitle,
        description: "۱ ویدیو — پخش از داخل برنامه",
        category,
        type: "youtube",
        poster: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        episodes: [{ videoId, title: finalTitle, number: 1 }],
      });
      onClose();
      return;
    }

    // YouTube playlist → fetch all episodes
    try {
      setProgress("در حال دریافت قسمت‌ها (ممکن است چند ثانیه طول بکشد)...");
      const { title: autoTitle, episodes } = await fetchPlaylistEpisodes(playlistId);
      if (!episodes.length) { setError("هیچ ویدیویی در این پلی‌لیست پیدا نشد"); setLoading(false); return; }
      const finalTitle = title.trim() || autoTitle || `سریال ${playlistId.slice(-6)}`;
      onAdd({
        id: `yt_${playlistId}`,
        title: finalTitle,
        description: `${episodes.length} قسمت — پخش از داخل برنامه`,
        playlistId,
        playlistUrl: trimmed,
        category,
        type: "youtube",
        poster: `https://img.youtube.com/vi/${episodes[0].videoId}/hqdefault.jpg`,
        episodes,
      });
      onClose();
    } catch {
      setError("خطا در دریافت پلی‌لیست. لینک را بررسی کنید.");
      setLoading(false);
    }
  };

  // ── Direct video link (mp4, webm, m3u8, Aparat, etc.) ──
  const handleSubmitDirectLink = async () => {
    const trimmed = url.trim();
    if (!trimmed) { setError("لینک ویدیو را وارد کنید"); return; }

    setLoading(true); setError(null);

    const aparatHash = extractAparatHash(trimmed);
    const isDirect = isDirectVideoUrl(trimmed);

    if (!isDirect && !aparatHash) {
      setError("لینک باید یک فایل ویدیویی مستقیم (mp4, webm, m3u8) یا لینک آپارات باشد");
      setLoading(false);
      return;
    }

    const finalTitle = title.trim() || "ویدیو";

    if (aparatHash) {
      // Aparat embed URL
      onAdd({
        id: `aparat_${aparatHash}`,
        title: finalTitle,
        description: "۱ ویدیو — پخش از آپارات",
        category,
        type: "embed",
        poster: "",
        episodes: [{
          embedUrl: `https://www.aparat.com/video/video/embed/videohash/${aparatHash}/vt/frame`,
          title: finalTitle,
          number: 1,
        }],
      });
    } else {
      // Direct video file URL
      onAdd({
        id: `link_${Date.now()}`,
        title: finalTitle,
        description: "۱ ویدیو — پخش مستقیم",
        category,
        type: "file",
        poster: "",
        episodes: [{ fileUrl: trimmed, title: finalTitle, number: 1 }],
      });
    }
    onClose();
  };

  const handlePickVideos = (e) => {
    const files = Array.from(e.target.files || []).filter(f => f.type.startsWith("video/"));
    setVideoFiles(files);
  };

  const handlePickPoster = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setPosterFile(f);
    setPosterPreview(URL.createObjectURL(f));
  };

  const handleSubmitGallery = async () => {
    if (videoFiles.length === 0) { setError("حداقل یک ویدیو از گالری انتخاب کنید"); return; }
    const tooBig = videoFiles.find(f => f.size > MAX_VIDEO_SIZE);
    if (tooBig) {
      setError(`فایل «${tooBig.name}» (${fmtSize(tooBig.size)}) بزرگ‌تر از ${MAX_VIDEO_MB} مگابایت است. ویدیوی کوچک‌تر انتخاب کنید.`);
      return;
    }
    setLoading(true); setError(null);
    try {
      let posterUrl = "";
      if (posterFile) {
        setProgress("در حال آپلود کاور...");
        const pr = await uploadWithTimeout(posterFile);
        posterUrl = pr.file_url;
      }
      const episodes = [];
      for (let i = 0; i < videoFiles.length; i++) {
        const f = videoFiles[i];
        setProgress(`آپلود ویدیو ${i + 1} از ${videoFiles.length} (${fmtSize(f.size)})...`);
        const res = await uploadWithTimeout(f);
        episodes.push({
          fileUrl: res.file_url,
          title: title.trim() ? `${title.trim()} — قسمت ${i + 1}` : (f.name.replace(/\.[^.]+$/, "") || `قسمت ${i + 1}`),
          number: i + 1,
          season: Number(season) || 1,
        });
      }
      const finalTitle = title.trim() || videoFiles[0].name.replace(/\.[^.]+$/, "") || "سریال گالری";
      onAdd({
        id: `gallery_${Date.now()}`,
        title: finalTitle,
        description: `${episodes.length} قسمت`,
        category,
        type: "file",
        poster: posterUrl || "",
        episodes,
      });
      onClose();
    } catch (e) {
      setError(e?.message === "timeout"
        ? `آپلود طول کشید — فایل کمتر از ${MAX_VIDEO_MB} مگابایت انتخاب کنید.`
        : "خطا در آپلود فایل‌ها. دوباره تلاش کنید.");
      setLoading(false);
    } finally {
      setProgress("");
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85" onClick={onClose}>
      <div className="w-full max-w-md mx-4 rounded-2xl p-6 flex flex-col gap-4 max-h-[92vh] overflow-y-auto"
        style={{ background: 'rgba(13,17,30,0.98)', border: '1px solid rgba(168,85,247,0.25)' }}
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <p className="text-white font-bold text-base">افزودن محتوا</p>
          <button onClick={onClose} data-remote className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        {/* Mode toggle — 3 modes */}
        <div className="flex rounded-xl overflow-hidden border border-white/10">
          <button onClick={() => setMode("youtube")} data-remote
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${mode === "youtube" ? "bg-purple-600/30 text-purple-300" : "text-white/40 hover:text-white"}`}>
            <Link2 className="w-3.5 h-3.5" /> یوتیوب
          </button>
          <button onClick={() => setMode("link")} data-remote
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${mode === "link" ? "bg-cyan-600/30 text-cyan-300" : "text-white/40 hover:text-white"}`}>
            <Video className="w-3.5 h-3.5" /> لینک مستقیم
          </button>
          <button onClick={() => setMode("gallery")} data-remote
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${mode === "gallery" ? "bg-cyan-600/30 text-cyan-300" : "text-white/40 hover:text-white"}`}>
            <Upload className="w-3.5 h-3.5" /> گالری
          </button>
        </div>

        {/* Category selector */}
        <div>
          <label className="text-xs text-white/40 mb-2 block">دسته‌بندی</label>
          <div className="flex rounded-xl overflow-hidden border border-white/10">
            {CATEGORIES.map(cat => (
              <button key={cat.id} onClick={() => setCategory(cat.id)} data-remote
                className={`flex-1 py-2.5 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${category === cat.id ? "bg-purple-600/30 text-purple-300" : "text-white/40 hover:text-white"}`}>
                {cat.icon} {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Title (always) */}
        <div>
          <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Type className="w-3 h-3" /> عنوان</label>
          <input value={title} onChange={e => setTitle(e.target.value)} data-remote
            placeholder="نام سریال، فیلم یا انیمیشن..."
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-purple-500/50" />
        </div>

        {mode === "youtube" ? (
          <div>
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Link2 className="w-3 h-3" /> لینک یوتیوب (پلی‌لیست یا ویدیوی تکی)</label>
            <input value={url} onChange={e => setUrl(e.target.value)} data-remote
              placeholder="https://youtube.com/watch?v=... یا playlist?list=..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-purple-500/50" />
            <p className="text-[11px] text-purple-400/60 mt-1.5 flex items-start gap-1">
              ⓘ هم پلی‌لیست و هم ویدیوی تکی یوتیوب پشتیبانی می‌شود
            </p>
          </div>
        ) : mode === "link" ? (
          <div>
            <label className="text-xs text-white/40 mb-1 flex items-center gap-1.5"><Video className="w-3 h-3" /> لینک مستقیم ویدیو</label>
            <input value={url} onChange={e => setUrl(e.target.value)} data-remote
              placeholder="https://example.com/movie.mp4 یا آپارات"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-purple-500/50" />
            <p className="text-[11px] text-cyan-400/60 mt-1.5 flex items-start gap-1">
              ⓘ لینک مستقیم فایل ویدیو (mp4, webm, m3u8) یا لینک آپارات قابل قبول است
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="text-xs text-white/40 mb-1.5 flex items-center gap-1.5"><Film className="w-3 h-3" /> ویدیوهای سریال (از گالری)</label>
              <button onClick={() => fileInputRef.current?.click()} data-remote
                className="w-full border-2 border-dashed border-white/15 rounded-xl py-6 flex flex-col items-center gap-2 hover:border-purple-500/50 transition-colors">
                <Upload className="w-7 h-7 text-white/40" />
                <span className="text-xs text-white/50">{videoFiles.length > 0 ? `${videoFiles.length} ویدیو انتخاب شد` : "انتخاب ویدیوها از گالری"}</span>
              </button>
              <input ref={fileInputRef} type="file" accept="video/*" multiple className="hidden" onChange={handlePickVideos} />
              <p className="text-[11px] text-white/30 mt-1">ⓘ حداکثر ۱۰۰ مگابایت برای هر ویدیو — ویدیوهای بزرگ‌تر را فشرده کنید یا از «لینک مستقیم» استفاده کنید</p>
              {videoFiles.length > 0 && (
                <div className="mt-2 max-h-24 overflow-y-auto text-xs text-white/40 space-y-1">
                  {videoFiles.map((f, i) => (
                    <div key={i} className="truncate flex items-center justify-between gap-2">
                      <span className="truncate">• {f.name}</span>
                      <span className={`flex-shrink-0 ${f.size > MAX_VIDEO_SIZE ? "text-red-400" : "text-white/30"}`}>{fmtSize(f.size)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1.5 flex items-center gap-1.5"><ImagePlus className="w-3 h-3" /> کاور (اختیاری)</label>
              <button onClick={() => posterInputRef.current?.click()} data-remote
                className="w-full border border-white/15 rounded-xl py-3 flex items-center justify-center gap-2 hover:border-cyan-500/50 transition-colors text-xs text-white/50">
                {posterPreview ? <img src={posterPreview} className="h-10 rounded object-cover" /> : "انتخاب عکس کاور"}
              </button>
              <input ref={posterInputRef} type="file" accept="image/*" className="hidden" onChange={handlePickPoster} />
            </div>
            <div>
              <label className="text-xs text-white/40 mb-1.5 flex items-center gap-1.5"><Hash className="w-3 h-3" /> شماره فصل</label>
              <input type="number" min="1" value={season} onChange={e => setSeason(e.target.value)} data-remote
                placeholder="1"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/25 outline-none focus:border-cyan-500/50" />
              <p className="text-[11px] text-white/30 mt-1">ⓘ تمام ویدیوهای انتخاب‌شده در این فصل قرار می‌گیرند</p>
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 text-red-400 text-xs bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" /> {error}
          </div>
        )}

        <button onClick={mode === "youtube" ? handleSubmitYouTube : mode === "link" ? handleSubmitDirectLink : handleSubmitGallery} data-remote
          disabled={loading || (mode !== "gallery" ? !url.trim() : videoFiles.length === 0)}
          className="w-full py-3 rounded-xl text-sm font-bold text-white transition-colors disabled:opacity-40 flex items-center justify-center gap-2"
          style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)', boxShadow: '0 4px 15px rgba(123,44,191,0.4)' }}>
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> {progress || "در حال پردازش..."}</> : (mode === "youtube" ? "افزودن از یوتیوب" : mode === "link" ? "افزودن لینک" : "آپلود و افزودن")}
        </button>
      </div>
    </div>
  );
}