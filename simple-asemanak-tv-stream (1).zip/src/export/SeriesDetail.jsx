import { useState, useEffect, useRef } from "react";
import { ArrowLeft, Play, Trash2, List, Clock, Languages, Check, Film, Plus, Download, Loader2, X, ChevronUp, ChevronDown, Music, EyeOff, Eye, Settings2 } from "lucide-react";
import YouTubePlayer from "@/components/media/YouTubePlayer";
import HlsVideoPlayer from "@/components/media/HlsVideoPlayer";
import AddEpisodeForm from "@/components/media/AddEpisodeForm";
import { getOfflineVideoUrl, getOfflineVideoUrlSync, cacheVideoOffline, getOfflineIndex } from "@/lib/offlineVideo";
import { base44 } from "@/api/base44Client";

// Cover music removed — silent loading only

export default function SeriesDetail({ series, onPlayEpisode, playingEpisode, onBack, onExitPlayer, onDelete, onAddEpisode, onReorderEpisodes, onEditEpisodeNumber, onDeleteEpisode, isFa = true, isAdmin = false }) {
  const [showSidebar, setShowSidebar] = useState(false);
  const [showAddEpisode, setShowAddEpisode] = useState(false);
  const [editingEpIdx, setEditingEpIdx] = useState(null);
  const [epNumValue, setEpNumValue] = useState("");
  const [selectedSeason, setSelectedSeason] = useState(1);
  const episodeListRef = useRef(null);
  const [offlineSrc, setOfflineSrc] = useState(null);
  const [offlineReady, setOfflineReady] = useState(false);
  const [downloading, setDownloading] = useState(false);
  // Default true — player renders immediately with direct URL (like YouTube).
  // Only set to false when a cached blob URL needs to be fetched from IndexedDB.
  const [offlineChecked, setOfflineChecked] = useState(true);
  const [langPref, setLangPref] = useState(() => {
    try { return localStorage.getItem("ayeneh_series_lang") || "fa"; } catch { return "fa"; }
  });
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [dlProgress, setDlProgress] = useState({ current: 0, total: 0 });
  const [uiLang, setUiLang] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"; } catch { return true; }
  });
  // Hide-info: blur/hide series title, channel name, and video details in the detail header
  const [hideInfo, setHideInfo] = useState(false);
  // Granular admin-only hide/blur controls for the playing screen
  const [showHidePanel, setShowHidePanel] = useState(false);
  const [hideTitle, setHideTitle] = useState(false);
  const [hideEpisodeInfo, setHideEpisodeInfo] = useState(false);
  const [hideLogos, setHideLogos] = useState(false);
  // Combined: if any granular toggle is on, pass true to players for branding hide
  const hideVideoOverlays = hideInfo || hideLogos;

  // Sync hideOverlays from series setting when series changes — admin can enable
  // this per-series to auto-hide logos/text/branding on the video screen.
  useEffect(() => {
    if (series?.hideOverlays) {
      setHideInfo(true);
      setHideTitle(true);
      setHideEpisodeInfo(true);
      setHideLogos(true);
    }
  }, [series?.id]);

  // Auto-hide overlay UI (top bar + controls + floating buttons) after inactivity.
  const [showUI, setShowUI] = useState(true);
  const uiTimer = useRef(null);
  const embedRef = useRef(null);
  const videoRef = useRef(null);
  const resetUI = () => {
    setShowUI(true);
    if (uiTimer.current) clearTimeout(uiTimer.current);
    uiTimer.current = setTimeout(() => setShowUI(false), 4000);
  };
  const toggleUI = () => {
    setShowUI(v => {
      const next = !v;
      if (uiTimer.current) clearTimeout(uiTimer.current);
      if (next) uiTimer.current = setTimeout(() => setShowUI(false), 4000);
      return next;
    });
  };
  useEffect(() => {
    uiTimer.current = setTimeout(() => setShowUI(false), 4000);
    return () => { if (uiTimer.current) clearTimeout(uiTimer.current); };
  }, []);

  // Stop ALL audio when leaving the player (full unmount) — YouTube, Aparat, HTML5 video.
  useEffect(() => {
    return () => {
      document.querySelectorAll("iframe").forEach(f => {
        try { f.contentWindow.postMessage(JSON.stringify({ event: "command", func: "stopVideo", args: "" }), "*"); } catch {}
        try { f.src = "about:blank"; } catch {}
        try { f.remove(); } catch {}
      });
      if (embedRef.current) { try { embedRef.current.src = "about:blank"; } catch {} }
      if (videoRef.current) {
        try { videoRef.current.pause(); } catch {}
        try { videoRef.current.src = ""; } catch {}
        try { videoRef.current.load(); } catch {}
      }
    };
  }, []);

  useEffect(() => {
    const syncLang = () => {
      try { setUiLang(JSON.parse(localStorage.getItem("ayeneh_settings") || "{}").language !== "en"); } catch {}
    };
    window.addEventListener("ayeneh-settings-changed", syncLang);
    window.addEventListener("storage", syncLang);
    return () => {
      window.removeEventListener("ayeneh-settings-changed", syncLang);
      window.removeEventListener("storage", syncLang);
    };
  }, []);

  // ── TV remote: Back key exits player or goes back to series list ──
  useEffect(() => {
    const onKey = (e) => {
      if (e.defaultPrevented) return;
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (["Backspace", "Escape", "GoBack", "XF86Back", "XF86AudioStop", "BrowserBack"].includes(e.key)) {
        e.preventDefault();
        if (playingEpisode) (onExitPlayer || onBack)();
        else onBack();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [playingEpisode, onBack, onExitPlayer]);

  const fa = isFa && uiLang;
  const tr = (f, e) => fa ? f : e;

  // Offline playback: render immediately with direct URL (like YouTube player).
  // Only block if the video is cached in IndexedDB but the blob URL isn't in memory yet.
  useEffect(() => {
    let active = true;
    setOfflineSrc(null);
    setOfflineReady(false);
    setOfflineChecked(true);

    const fu = playingEpisode?.fileUrl;
    const ytKey = playingEpisode?.videoId ? `yt_${playingEpisode.videoId}` : null;
    const key = fu || ytKey;
    if (!key) return;

    // 1. Check memory cache (sync) — instant playback with offline blob
    const cachedUrl = getOfflineVideoUrlSync(key);
    if (cachedUrl) { setOfflineSrc(cachedUrl); setOfflineReady(true); return; }

    // 2. Check offline index (sync) — if cached, fetch blob URL (brief spinner)
    const idx = getOfflineIndex();
    const isCached = idx.some(e => e.fileUrl === key);
    if (isCached) {
      setOfflineChecked(false); // brief spinner while fetching blob URL
      getOfflineVideoUrl(key).then(url => {
        if (!active) return;
        if (url) { setOfflineSrc(url); setOfflineReady(true); }
        setOfflineChecked(true);
      }).catch(() => { if (active) setOfflineChecked(true); });
    }
    // 3. Not cached — play direct URL immediately (offlineChecked stays true)

    return () => { active = false; };
  }, [playingEpisode]);

  const changeLang = (lang) => {
    setLangPref(lang);
    try { localStorage.setItem("ayeneh_series_lang", lang); } catch {}
    setShowLangMenu(false);
  };

  // When a playing episode is set (e.g. resume from Continue Watching), switch to its season
  useEffect(() => {
    if (playingEpisode?.season) {
      setSelectedSeason(Number(playingEpisode.season) || 1);
    }
  }, [playingEpisode]);

  // Auto-focus the first episode when the detail page opens (non-playing mode).
  // This lets TV users immediately navigate episodes with D-pad without first
  // having to focus something manually.
  useEffect(() => {
    if (playingEpisode) return; // skip in player mode
    const timer = setTimeout(() => {
      const firstEp = episodeListRef.current?.querySelector('[data-remote]');
      if (firstEp) firstEp.focus();
    }, 300);
    return () => clearTimeout(timer);
  }, [playingEpisode, series?.id, selectedSeason]);

  if (!series) return null;
  const allEpisodes = (series.episodes || []).slice().sort((a, b) => a.number - b.number);
  const seasons = [...new Set(allEpisodes.map(e => Number(e.season) || 1))].sort((a, b) => a - b);
  const currentSeason = seasons.includes(selectedSeason) ? selectedSeason : (seasons[0] || 1);
  const episodes = allEpisodes.filter(e => (Number(e.season) || 1) === currentSeason);
  const nextEpNumber = episodes.length > 0 ? Math.max(...episodes.map(e => Number(e.number) || 0)) + 1 : 1;

  // Download all episodes for offline viewing (stored in IndexedDB — app-private, not in gallery)
  // Works for both gallery uploads (fileUrl) AND YouTube videos (videoId → backend resolves direct URL)
  const downloadableEps = allEpisodes.filter(ep => ep.fileUrl || ep.videoId);
  const offlineIdx = getOfflineIndex();
  const allDownloaded = downloadableEps.length > 0 && downloadableEps.every(ep => {
    const key = ep.fileUrl || `yt_${ep.videoId}`;
    return offlineIdx.some(e => e.fileUrl === key);
  });

  const handleDownloadAll = async () => {
    if (downloadingAll || allDownloaded) return;
    const toDownload = downloadableEps.filter(ep => {
      const key = ep.fileUrl || `yt_${ep.videoId}`;
      return !offlineIdx.some(e => e.fileUrl === key);
    });
    if (toDownload.length === 0) return;
    setDownloadingAll(true);
    setDlProgress({ current: 0, total: toDownload.length });
    for (let i = 0; i < toDownload.length; i++) {
      try {
        const ep = toDownload[i];
        const key = ep.fileUrl || `yt_${ep.videoId}`;
        const label = `${series.title} — ${ep.title || tr("قسمت", "Episode")}`;
        if (ep.fileUrl) {
          // Gallery video — direct download
          await cacheVideoOffline(key, { label });
        } else if (ep.videoId) {
          // YouTube video — backend resolves direct URL, then download
          const res = await base44.functions.invoke('downloadYoutubeVideo', { videoId: ep.videoId });
          if (res?.data?.fileUrl) {
            await cacheVideoOffline(key, { label }, res.data.fileUrl);
          }
        }
      } catch {}
      setDlProgress({ current: i + 1, total: toDownload.length });
    }
    setDownloadingAll(false);
    setDlProgress({ current: 0, total: 0 });
  };

  // ── Playing mode: video fills the ENTIRE screen; overlays auto-hide ──
  if (playingEpisode) {
    return (
      <div className="fixed inset-0 text-white overflow-hidden"
        style={{ background: '#000', WebkitTouchCallout: 'none', WebkitUserSelect: 'none', userSelect: 'none' }}
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* Video — fills the whole screen, no black bars */}
        <div className="absolute inset-0 bg-black">
          {playingEpisode.embedUrl ? (
            <iframe ref={embedRef} src={playingEpisode.embedUrl} allow="autoplay; fullscreen" allowFullScreen
              className="absolute inset-0 w-full h-full" frameBorder="0" />
          ) : (playingEpisode.fileUrl || playingEpisode.videoId) ? (
            offlineChecked ? (
              offlineSrc ? (
                <HlsVideoPlayer key={playingEpisode._playId || offlineSrc} src={offlineSrc} onVideoClick={toggleUI} seriesTitle={series.title} seriesPoster={series.poster} isAdmin={isAdmin} posterPosition={series.posterPosition} hideInfo={hideInfo} />
              ) : playingEpisode.fileUrl ? (
                <HlsVideoPlayer key={playingEpisode._playId || playingEpisode.fileUrl} src={playingEpisode.fileUrl} onVideoClick={toggleUI} seriesTitle={series.title} seriesPoster={series.poster} isAdmin={isAdmin} posterPosition={series.posterPosition} hideInfo={hideVideoOverlays} />
              ) : (
                <YouTubePlayer videoId={playingEpisode.videoId} onVideoClick={toggleUI} langPref={langPref} onLangChange={changeLang} controlsVisible={showUI} seriesTitle={series.title} seriesPoster={series.poster} posterPosition={series.posterPosition} hideInfo={hideVideoOverlays} />
              )
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-black z-[20]">
                <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
              </div>
            )
          ) : null}
        </div>

        {/* Floating back + list buttons — always visible on mobile for easy reach */}
        <button onClick={() => (onExitPlayer || onBack)()} data-remote className="md:hidden absolute z-50 w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
          style={{ bottom: 'calc(5rem + env(safe-area-inset-bottom))', left: 'calc(1rem + env(safe-area-inset-left))', background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.25)' }}>
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <button onClick={() => setShowSidebar(v => !v)} data-remote className="md:hidden absolute z-50 w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95"
          style={{ bottom: 'calc(5rem + env(safe-area-inset-bottom))', right: 'calc(1rem + env(safe-area-inset-right))', background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.25)' }}>
          <List className="w-6 h-6 text-white" />
        </button>

        {/* Top bar overlay (auto-hides) */}
        {showUI && (
          <div className="absolute top-0 left-0 right-0 z-30 flex items-center gap-3 px-4 py-3"
            style={{ background: 'linear-gradient(180deg, rgba(0,0,0,0.85) 0%, transparent 100%)', paddingTop: 'calc(0.75rem + env(safe-area-inset-top))' }}>
            <button onClick={() => (onExitPlayer || onBack)()} data-remote className="flex items-center gap-2 text-white/90 hover:text-white bg-white/10 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors flex-shrink-0">
              <ArrowLeft className="w-4 h-4" /> {tr("بازگشت", "Back")}
            </button>
            <p className="text-white font-bold text-sm truncate flex-1 drop-shadow-lg"
              style={(hideInfo || hideTitle || hideEpisodeInfo) ? { filter: 'blur(8px)', opacity: 0.25 } : {}}>{playingEpisode.title}</p>
            <button onClick={() => setHideInfo(v => !v)} data-remote
              className={`flex items-center gap-1.5 bg-white/10 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors flex-shrink-0 ${hideInfo ? 'text-cyan-400' : 'text-white/70'}`}>
              {hideInfo ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
            {isAdmin && (
              <button onClick={() => setShowHidePanel(v => !v)} data-remote
                className={`flex items-center gap-1.5 bg-white/10 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors flex-shrink-0 ${showHidePanel ? 'text-cyan-400' : 'text-white/70'}`}>
                <Settings2 className="w-4 h-4" />
              </button>
            )}
            {playingEpisode.fileUrl && (
              <button onClick={async () => {
                if (offlineReady) return;
                try {
                  setDownloading(true);
                  await cacheVideoOffline(playingEpisode.fileUrl, { label: `${series?.title ? series.title + " — " : ""}${playingEpisode.title || tr("قسمت", "Episode")}` });
                  const u = await getOfflineVideoUrl(playingEpisode.fileUrl);
                  if (u) { setOfflineSrc(u); setOfflineReady(true); }
                } catch { window.alert(tr("دانلود ناموفق بود", "Download failed")); }
                finally { setDownloading(false); }
              }} disabled={downloading || offlineReady}
                className="flex items-center gap-1.5 text-cyan-300 bg-white/10 backdrop-blur-md hover:bg-white/15 rounded-xl px-3 py-2 text-xs font-semibold transition-colors disabled:opacity-60 flex-shrink-0">
                {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : offlineReady ? <Check className="w-4 h-4 text-green-400" /> : <Download className="w-4 h-4" />}
                {offlineReady ? (tr("افلاین ✓", "Offline ✓")) : ""}
              </button>
            )}
          </div>
        )}

        {/* Floating controls — sidebar toggle + language (auto-hide) */}
        {showUI && (
          <div className="absolute top-3 right-3 z-40 flex gap-2">
            <div className="relative">
              <button
                onClick={() => setShowLangMenu(v => !v)} data-remote
                className="w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-md transition-all hover:scale-105"
                style={{ background: 'rgba(0,0,0,0.6)', border: '1px solid rgba(255,255,255,0.15)' }}
              >
                <Languages className="w-5 h-5 text-white/80" />
              </button>
              {showLangMenu && (
                <div className="absolute top-12 right-0 rounded-xl overflow-hidden backdrop-blur-md"
                  style={{ background: 'rgba(10,13,22,0.95)', border: '1px solid rgba(255,255,255,0.15)', boxShadow: '0 8px 24px rgba(0,0,0,0.5)' }}>
                  <p className="px-4 py-2 text-[10px] text-white/40 uppercase tracking-wider border-b border-white/10">{tr("زبان / Language", "Language")}</p>
                  {[
                    { code: "fa", label: tr("فارسی", "Persian"), sub: "Persian" },
                    { code: "en", label: tr("انگلیسی", "English"), sub: "English" },
                    { code: "off", label: tr("خاموش", "Off"), sub: "Off" },
                  ].map(opt => (
                    <button key={opt.code} onClick={() => changeLang(opt.code)}
                      className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition-colors w-full text-right">
                      <div className="flex-1">
                        <p className="text-sm text-white font-medium">{opt.label}</p>
                        <p className="text-[10px] text-white/40">{opt.sub}</p>
                      </div>
                      {langPref === opt.code && <Check className="w-4 h-4 text-cyan-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <button
              onClick={() => setShowSidebar(v => !v)} data-remote
              className="w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-md transition-all hover:scale-105"
              style={{ background: 'rgba(0,0,0,0.6)', border: '1px solid rgba(255,255,255,0.15)' }}
            >
              <List className="w-5 h-5 text-white/80" />
            </button>
          </div>
        )}

        {/* Admin hide/blur panel — granular controls for hiding video screen elements */}
        {showHidePanel && isAdmin && (
          <>
            <div className="absolute inset-0" style={{ zIndex: 35 }} onClick={() => setShowHidePanel(false)} />
            <div className="absolute top-16 right-3 w-64 rounded-2xl overflow-hidden backdrop-blur-md"
              style={{ zIndex: 45, background: 'rgba(10,13,22,0.97)', border: '1px solid rgba(255,255,255,0.15)', boxShadow: '0 8px 24px rgba(0,0,0,0.5)' }}>
              <div className="px-4 py-3 flex items-center gap-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <Settings2 className="w-4 h-4 text-cyan-400" />
                <p className="text-white font-bold text-xs">{tr("پنهان‌کردن / بلور", "Hide / Blur")}</p>
                <button onClick={() => setShowHidePanel(false)} data-remote className="text-white/40 hover:text-white mr-auto"><X className="w-4 h-4" /></button>
              </div>
              <div className="p-2 space-y-1">
                <button onClick={() => setHideTitle(v => !v)} data-remote
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${hideTitle ? 'text-cyan-400 bg-cyan-500/10' : 'text-white/70 hover:bg-white/5'}`}>
                  <span className="flex items-center gap-2"><EyeOff className="w-3.5 h-3.5" /> {tr("بلور عنوان سریال", "Blur Series Title")}</span>
                  <span className={`w-8 h-4 rounded-full transition-colors flex-shrink-0 ${hideTitle ? 'bg-cyan-500' : 'bg-white/15'} relative`}>
                    <span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${hideTitle ? 'translate-x-4' : 'translate-x-0.5'}`} />
                  </span>
                </button>
                <button onClick={() => setHideEpisodeInfo(v => !v)} data-remote
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${hideEpisodeInfo ? 'text-cyan-400 bg-cyan-500/10' : 'text-white/70 hover:bg-white/5'}`}>
                  <span className="flex items-center gap-2"><EyeOff className="w-3.5 h-3.5" /> {tr("بلور جزئیات قسمت", "Blur Episode Details")}</span>
                  <span className={`w-8 h-4 rounded-full transition-colors flex-shrink-0 ${hideEpisodeInfo ? 'bg-cyan-500' : 'bg-white/15'} relative`}>
                    <span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${hideEpisodeInfo ? 'translate-x-4' : 'translate-x-0.5'}`} />
                  </span>
                </button>
                <button onClick={() => setHideLogos(v => !v)} data-remote
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${hideLogos ? 'text-cyan-400 bg-cyan-500/10' : 'text-white/70 hover:bg-white/5'}`}>
                  <span className="flex items-center gap-2"><EyeOff className="w-3.5 h-3.5" /> {tr("پنهان‌کردن لوگوها", "Hide Logos/Branding")}</span>
                  <span className={`w-8 h-4 rounded-full transition-colors flex-shrink-0 ${hideLogos ? 'bg-cyan-500' : 'bg-white/15'} relative`}>
                    <span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${hideLogos ? 'translate-x-4' : 'translate-x-0.5'}`} />
                  </span>
                </button>
                <button onClick={() => { setHideTitle(false); setHideEpisodeInfo(false); setHideLogos(false); setHideInfo(false); }} data-remote
                  className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold text-white/50 hover:text-white hover:bg-white/5 transition-colors"
                  style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
                  {tr("غیرفعال‌کردن همه", "Disable All")}
                </button>
              </div>
            </div>
          </>
        )}

        {/* Episode sidebar — overlay drawer on the right (toggle with the List button) */}
        {showSidebar && (
          <>
          <div className="absolute inset-0 z-30" onClick={() => setShowSidebar(false)} />
          <div className="absolute top-0 right-0 bottom-0 w-72 z-40 flex flex-col overflow-hidden"
            style={{ background: 'rgba(10,13,22,0.96)', borderLeft: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="px-3 py-2.5 flex items-center gap-2 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
              <List className="w-3.5 h-3.5 text-purple-400" />
              <p className="text-white/60 text-xs font-bold uppercase tracking-widest">{tr("قسمت‌ها", "Episodes")}</p>
              <span className="text-white/30 text-[10px] mr-auto">{episodes.length}</span>
              <button onClick={() => setShowSidebar(false)} className="text-white/40 hover:text-white p-0.5"><X className="w-4 h-4" /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-2 py-2">
              {episodes.map((ep, i) => {
                const isActive = playingEpisode.videoId === ep.videoId;
                return (
                  <button key={`${ep.videoId}-${i}`} onClick={() => onPlayEpisode(ep)} data-remote
                    className={`tv-focusable group w-full flex items-center gap-2 rounded-lg p-1.5 mb-1 text-left transition-all ${isActive ? 'bg-purple-600/25 border border-purple-500/50' : 'hover:bg-white/5 border border-transparent'}`}>
                    <div className="relative w-20 h-12 flex-shrink-0 rounded overflow-hidden bg-black/40">
                      {ep.embedUrl ? (
                        <div className="w-full h-full flex items-center justify-center bg-black/40">
                          <Film className="w-4 h-4 text-white/40" />
                        </div>
                      ) : ep.fileUrl ? (
                        <video src={ep.fileUrl} className="w-full h-full object-cover" muted preload="metadata" />
                      ) : (
                        <img src={`https://img.youtube.com/vi/${ep.videoId}/mqdefault.jpg`} alt={ep.title}
                          className="w-full h-full object-cover" onError={e => { e.target.style.display = 'none'; }} />
                      )}
                      {isActive ? (
                        <div className="absolute inset-0 flex items-center justify-center" style={{ background: 'rgba(123,44,191,0.5)' }}>
                          <Play className="w-4 h-4 fill-white text-white" />
                        </div>
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: 'rgba(0,0,0,0.4)' }}>
                          <Play className="w-4 h-4 fill-white text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-semibold truncate ${isActive ? 'text-white' : 'text-white/70'}`}>
                        {/^(قسمت|Episode)\s+\d+$/i.test((ep.title || '').trim()) ? `${tr("قسمت", "Episode")} ${ep.number}` : (ep.title || `${tr("قسمت", "Episode")} ${ep.number}`)}
                      </p>
                      <p className="text-purple-400/60 text-[10px] mt-0.5">{tr("قسمت", "Episode")} {ep.number}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
          </>
        )}
      </div>
    );
  }

  // ── Default mode: hero header + episode list ──
  return (
    <div className="fixed inset-0 flex flex-col text-white overflow-hidden" style={{ background: '#0a0d16' }}>
      {/* Hero header with series poster */}
      <div className="relative flex-shrink-0" style={{ height: '200px' }}>
        {series.poster && (
          <img src={series.poster} alt={series.title} className="absolute inset-0 w-full h-full object-cover" onError={e => { e.target.style.display = 'none'; }} />
        )}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(10,13,22,0.4) 0%, rgba(10,13,22,0.85) 70%, #0a0d16 100%)' }} />

        <div className="absolute top-0 left-0 right-0 flex items-center justify-between px-4 py-3 z-10">
          <button onClick={onBack} data-remote className="flex items-center gap-2 text-white/80 hover:text-white bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-sm font-semibold transition-colors">
            <ArrowLeft className="w-4 h-4" /> {tr("بازگشت", "Back")}
          </button>
          <div className="flex items-center gap-2">
            {downloadableEps.length > 0 && (
              <button onClick={handleDownloadAll} disabled={downloadingAll || allDownloaded} data-remote
                className="flex items-center gap-1.5 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors disabled:opacity-60 hover:bg-cyan-500/20"
                style={{ color: allDownloaded ? '#34d399' : '#22d3ee' }}>
                {downloadingAll ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    {dlProgress.current}/{dlProgress.total}
                  </>
                ) : allDownloaded ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> {tr("دانلود شده", "Downloaded")}
                  </>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5" /> {tr("دانلود همه", "Download All")}
                  </>
                )}
              </button>
            )}
            {onAddEpisode && (
              <button onClick={() => setShowAddEpisode(true)} data-remote
                className="flex items-center gap-1.5 text-cyan-300 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors hover:bg-cyan-500/20">
                <Plus className="w-3.5 h-3.5" /> {tr("افزودن قسمت", "Add Episode")}
              </button>
            )}
            <button onClick={() => setHideInfo(v => !v)} data-remote
              className={`flex items-center gap-1.5 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors ${hideInfo ? 'text-cyan-400' : 'text-white/60 hover:text-white'}`}>
              {hideInfo ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              {hideInfo ? tr("نمایش اطلاعات", "Show Info") : tr("پنهان‌کردن اطلاعات", "Hide Info")}
            </button>
            {isAdmin && (
              <label className="flex items-center gap-1.5 text-amber-300 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors hover:bg-amber-500/20 cursor-pointer">
                <Music className="w-3.5 h-3.5" />
                {series.coverMusic ? tr("موسیقی ✓", "Music ✓") : tr("موسیقی کاور", "Cover Music")}
                <input type="file" accept="audio/*" className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    try {
                      const { file_url } = await base44.integrations.Core.UploadFile({ file });
                      await base44.entities.Series.update(series.id, { coverMusic: file_url });
                      window.location.reload();
                    } catch { window.alert(tr("آپلود ناموفق", "Upload failed")); }
                  }} />
              </label>
            )}
            {onDelete && (
              <button onClick={() => { if (window.confirm(fa ? 'حذف این سریال؟' : 'Delete this series?')) onDelete(); }} data-remote
                className="flex items-center gap-1.5 text-red-400 bg-black/40 backdrop-blur-md rounded-xl px-3 py-2 text-xs font-semibold transition-colors hover:bg-red-500/20">
                <Trash2 className="w-3.5 h-3.5" /> {tr("حذف", "Delete")}
              </button>
            )}
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
          <h1 className="text-white font-black text-xl md:text-2xl mb-1 drop-shadow-lg"
            style={(hideInfo || hideTitle) ? { filter: 'blur(10px)', opacity: 0.3 } : {}}>{series.title}</h1>
          <div className="flex items-center gap-3" style={(hideInfo || hideEpisodeInfo) ? { filter: 'blur(8px)', opacity: 0.2 } : {}}>
            <span className="flex items-center gap-1 text-purple-300 text-xs font-semibold bg-purple-600/20 border border-purple-500/30 rounded-full px-2.5 py-0.5">
              <List className="w-3 h-3" /> {allEpisodes.length} {tr("قسمت", "episodes")}
            </span>
            <span className="flex items-center gap-1 text-white/50 text-xs">
              <Clock className="w-3 h-3" /> {tr("پخش از داخل برنامه", "In-app playback")}
            </span>
          </div>
        </div>
      </div>

      {/* Episode list */}
      <div ref={episodeListRef} className="flex-1 overflow-y-auto px-4 py-4">
        {/* Season selector — horizontal tabs */}
        {seasons.length > 1 && (
          <div className="flex gap-2 mb-4 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
            {seasons.map(s => (
              <button key={s} onClick={() => setSelectedSeason(s)} data-remote
                className={`tv-focusable flex-shrink-0 px-4 py-2 rounded-xl text-sm font-bold transition-all ${currentSeason === s ? 'text-white' : 'text-white/50 hover:text-white/80'}`}
                style={currentSeason === s
                  ? { background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)', boxShadow: '0 2px 12px rgba(123,44,191,0.4)' }
                  : { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
                {tr(`فصل ${s}`, `Season ${s}`)}
              </button>
            ))}
          </div>
        )}
        <p className="text-white/40 text-xs font-bold uppercase tracking-widest mb-3">
          {seasons.length > 1 ? tr(`فصل ${currentSeason} — قسمت‌ها`, `Season ${currentSeason} — Episodes`) : tr("قسمت‌ها — از اول به آخر", "Episodes — first to last")}
        </p>
        <div className="flex flex-col gap-2 max-w-2xl mx-auto w-full">
          {episodes.map((ep, i) => (
            <div key={`${ep.videoId}-${i}`} onClick={() => onPlayEpisode(ep)} tabIndex={0} data-remote
              className="tv-focusable group flex items-center gap-3 rounded-xl overflow-hidden text-left transition-all hover:scale-[1.01] w-full cursor-pointer"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center m-1.5 rounded-lg"
                style={{ background: 'rgba(123,44,191,0.2)', border: '1px solid rgba(123,44,191,0.4)' }}>
                {editingEpIdx === i ? (
                  <input type="number" min="1" value={epNumValue}
                    onChange={e => setEpNumValue(e.target.value)}
                    onBlur={() => {
                      const newNum = Number(epNumValue);
                      if (newNum > 0 && newNum !== ep.number && onEditEpisodeNumber) {
                        onEditEpisodeNumber(i, newNum);
                      }
                      setEditingEpIdx(null);
                    }}
                    onKeyDown={e => { if (e.key === 'Enter') e.target.blur(); if (e.key === 'Escape') setEditingEpIdx(null); }}
                    className="w-8 bg-transparent text-center text-purple-300 font-bold text-sm outline-none"
                    autoFocus />
                ) : onEditEpisodeNumber ? (
                  <button onClick={(e) => { e.stopPropagation(); setEditingEpIdx(i); setEpNumValue(String(ep.number)); }}
                    className="text-purple-300 font-bold text-sm hover:text-cyan-400 transition-colors">
                    {ep.number}
                  </button>
                ) : (
                  <span className="text-purple-300 font-bold text-sm">{ep.number}</span>
                )}
              </div>
              <div className="relative w-28 h-16 flex-shrink-0 bg-black/40 rounded-lg overflow-hidden">
                {ep.embedUrl ? (
                  <div className="w-full h-full flex items-center justify-center bg-black/40">
                    <Film className="w-5 h-5 text-white/30" />
                  </div>
                ) : ep.fileUrl ? (
                  <video src={ep.fileUrl} className="w-full h-full object-cover" muted preload="metadata" />
                ) : (
                  <img src={`https://img.youtube.com/vi/${ep.videoId}/mqdefault.jpg`} alt={ep.title}
                    className="w-full h-full object-cover" onError={e => { e.target.style.display = 'none'; }} />
                )}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ background: 'rgba(123,44,191,0.5)' }}>
                  <Play className="w-5 h-5 fill-white text-white" />
                </div>
              </div>
              <div className="flex-1 min-w-0 py-2" style={(hideInfo || hideEpisodeInfo) ? { filter: 'blur(7px)', opacity: 0.25 } : {}}>
                <p className="text-white text-sm font-semibold truncate">
                  {/^(قسمت|Episode)\s+\d+$/i.test((ep.title || '').trim()) ? `${tr("قسمت", "Episode")} ${ep.number}` : (ep.title || `${tr("قسمت", "Episode")} ${ep.number}`)}
                </p>
                <p className="text-purple-400/60 text-xs mt-0.5">{tr("قسمت", "Episode")} {ep.number}</p>
              </div>
              {onReorderEpisodes && (
                <div className="flex flex-col gap-0.5 flex-shrink-0">
                  <button onClick={(e) => { e.stopPropagation(); if (i > 0) onReorderEpisodes(i, i - 1); }}
                    disabled={i === 0}
                    className="w-7 h-6 rounded flex items-center justify-center hover:bg-white/10 transition-colors disabled:opacity-20 disabled:hover:bg-transparent">
                    <ChevronUp className="w-4 h-4 text-cyan-400" />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); if (i < episodes.length - 1) onReorderEpisodes(i, i + 1); }}
                    disabled={i === episodes.length - 1}
                    className="w-7 h-6 rounded flex items-center justify-center hover:bg-white/10 transition-colors disabled:opacity-20 disabled:hover:bg-transparent">
                    <ChevronDown className="w-4 h-4 text-cyan-400" />
                  </button>
                </div>
              )}
              {onDeleteEpisode && (
                <button onClick={(e) => { e.stopPropagation(); if (window.confirm(fa ? 'حذف این قسمت؟' : 'Delete this episode?')) onDeleteEpisode(i); }} data-remote
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-colors hover:bg-red-500/20"
                  style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              )}
              <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mr-3 transition-colors"
                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
                <Play className="w-4 h-4 text-white/50 group-hover:text-purple-400 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddEpisode && (
        <AddEpisodeForm
          nextNumber={nextEpNumber}
          currentSeason={currentSeason}
          isFa={fa}
          onAdd={(ep) => { onAddEpisode(ep); setShowAddEpisode(false); }}
          onClose={() => setShowAddEpisode(false)}
        />
      )}
    </div>
  );
}