import { useState, useEffect } from "react";

export function checkIsTV() {
  try { if (document.documentElement.classList.contains('is-tv')) return true; } catch {}
  try {
    const flag = localStorage.getItem("ayeneh_force_tv");
    if (flag === "1") return true;
    if (flag === "0") return false;
  } catch {}
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get("tv") === "1") return true;
    if (params.get("tv") === "0") return false;
  } catch {}
  const ua = navigator.userAgent || "";
  if (/tv|smarttv|google ?tv|netcast|baidutv|crkey|smart-tv|googletv|webos|tizen|bravia|firetv|fire-tv|aftt|aftm|aftb|aftd|shield|leanback|onn/i.test(ua)) return true;
  try {
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const isAndroid = /android/i.test(ua);
    if (isAndroid && !hasTouch) return true;
  } catch {}
  try {
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const isCoarse = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    const sw = (window.screen && window.screen.width) || 0;
    const sh = (window.screen && window.screen.height) || 0;
    if (!hasTouch && isCoarse && (sw >= 1280 || sh >= 1280 || window.innerWidth >= 1000 || window.innerHeight >= 1000)) return true;
  } catch {}
  try {
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    if (window.innerWidth < 768 && hasTouch) return false;
  } catch {}
  return false;
}

export function setForceTV(val) {
  try { localStorage.setItem("ayeneh_force_tv", val ? "1" : "0"); } catch {}
  window.dispatchEvent(new Event("ayeneh-tv-toggle"));
}

export function useIsTV() {
  const [isTV, setIsTV] = useState(() => checkIsTV());
  useEffect(() => {
    const handler = () => setIsTV(checkIsTV());
    window.addEventListener("popstate", handler);
    window.addEventListener("pushstate", handler);
    window.addEventListener("ayeneh-tv-toggle", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("popstate", handler);
      window.removeEventListener("pushstate", handler);
      window.removeEventListener("ayeneh-tv-toggle", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return isTV;
}