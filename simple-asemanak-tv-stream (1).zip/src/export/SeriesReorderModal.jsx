import { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { X, GripVertical, Save, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function SeriesReorderModal({ series, onClose, onSaved, isFa = true }) {
  const [items, setItems] = useState(() =>
    [...series].sort((a, b) => {
      const aOrder = Number(a.sortOrder) || 0;
      const bOrder = Number(b.sortOrder) || 0;
      if (aOrder !== bOrder) return aOrder - bOrder;
      return new Date(b.created_date || 0) - new Date(a.created_date || 0);
    })
  );
  const [saving, setSaving] = useState(false);
  const tr = (fa, en) => isFa ? fa : en;

  const onDragEnd = (result) => {
    if (!result.destination) return;
    const reordered = Array.from(items);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    setItems(reordered);
  };

  const save = async () => {
    setSaving(true);
    try {
      const updates = items.map((s, i) => ({ id: s.id, sortOrder: i }));
      await base44.entities.Series.bulkUpdate(updates);
      if (onSaved) onSaved();
      onClose();
    } catch { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-center justify-center bg-black/85" onClick={onClose}>
      <div className="w-full max-w-lg mx-4 rounded-2xl flex flex-col max-h-[85vh] overflow-hidden"
        style={{ background: 'rgba(13,17,30,0.98)', border: '1px solid rgba(168,85,247,0.25)' }}
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <p className="text-white font-bold text-base">{tr("ترتیب نمایش سریال‌ها", "Reorder Series")}</p>
          <button onClick={onClose} data-remote className="text-white/40 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <p className="text-white/40 text-xs px-5 py-2.5 flex-shrink-0">{tr("برای جابجایی، کارت‌ها را بکشید و رها کنید", "Drag and drop cards to reorder")}</p>
        <div className="flex-1 overflow-y-auto px-3 pb-3">
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="series-list">
              {(provided) => (
                <div ref={provided.innerRef} {...provided.droppableProps} className="flex flex-col gap-2">
                  {items.map((s, i) => (
                    <Draggable key={s.id} draggableId={s.id} index={i}>
                      {(prov, snapshot) => (
                        <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                          className="flex items-center gap-3 rounded-xl p-2.5 transition-all"
                          style={{ background: snapshot.isDragging ? 'rgba(168,85,247,0.2)' : 'rgba(255,255,255,0.04)', border: snapshot.isDragging ? '1px solid rgba(168,85,247,0.5)' : '1px solid rgba(255,255,255,0.08)', ...prov.draggableProps.style }}>
                          <GripVertical className="w-5 h-5 text-white/30 flex-shrink-0" />
                          <span className="text-white/30 text-xs font-bold w-6 text-center flex-shrink-0">{i + 1}</span>
                          <div className="w-10 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-black/40">
                            {s.poster ? <img src={s.poster} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-white/20 text-[10px]">{tr("بدون کاور", "No cover")}</div>}
                          </div>
                          <p className="text-white text-sm font-semibold truncate flex-1">{s.title}</p>
                          <span className="text-white/30 text-[10px] flex-shrink-0">{(s.episodes || []).length} {tr("قسمت", "eps")}</span>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </div>
        <div className="flex gap-2 px-5 py-4 flex-shrink-0" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <button onClick={onClose} data-remote className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white/70 transition-colors hover:bg-white/5" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>{tr("انصراف", "Cancel")}</button>
          <button onClick={save} disabled={saving} data-remote className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-colors disabled:opacity-50 flex items-center justify-center gap-2" style={{ background: 'linear-gradient(135deg, #7b2cbf, #9d4edd)' }}>
            {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> {tr("ذخیره...", "Saving...")}</> : <><Save className="w-4 h-4" /> {tr("ذخیره ترتیب", "Save Order")}</>}
          </button>
        </div>
      </div>
    </div>
  );
}