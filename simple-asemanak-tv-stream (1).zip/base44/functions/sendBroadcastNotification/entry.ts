import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Only admins can send broadcast notifications
    if (user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { title, body: messageBody, type, send_email } = body;

    if (!title) return Response.json({ error: 'title required' }, { status: 400 });

    // Create the notification record
    const notification = await base44.asServiceRole.entities.Notification.create({
      title,
      body: messageBody || '',
      type: type || 'general',
      is_active: true,
    });

    // Optionally send email to all users
    if (send_email) {
      try {
        const users = await base44.asServiceRole.entities.User.list('-created_date', 500);
        const emailSubject = `[Asemanak TV] ${title}`;
        for (const u of users) {
          if (u.email) {
            try {
              await base44.asServiceRole.integrations.Core.SendEmail({
                to: u.email,
                subject: emailSubject,
                body: `${messageBody || title}\n\n— Asemanak TV`,
              });
            } catch (e) {
              // Continue even if individual email fails
            }
          }
        }
      } catch (e) {
        // Email sending is best-effort
      }
    }

    return Response.json({ success: true, notification_id: notification.id, emails_sent: send_email });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});