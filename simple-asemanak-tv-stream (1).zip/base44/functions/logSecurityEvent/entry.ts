import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { event_type, details, severity, target_email, target_user_id } = body;

    if (!event_type) return Response.json({ error: 'event_type required' }, { status: 400 });

    // Extract device info from headers
    const userAgent = req.headers.get('user-agent') || 'unknown';
    const forwarded = req.headers.get('x-forwarded-for') || '';
    const ip = forwarded.split(',')[0].trim() || 'unknown';
    const deviceId = req.headers.get('x-device-id') || userAgent.slice(0, 50);

    const log = await base44.asServiceRole.entities.SecurityLog.create({
      event_type,
      user_email: target_email || user.email,
      user_id: target_user_id || user.id,
      ip_address: ip,
      device_id: deviceId,
      device_info: userAgent,
      details: details || '',
      severity: severity || 'info',
    });

    return Response.json({ success: true, log_id: log.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});