import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { device_id, device_info } = body;

    if (!device_id) return Response.json({ error: 'device_id required' }, { status: 400 });

    const userAgent = req.headers.get('user-agent') || 'unknown';
    const forwarded = req.headers.get('x-forwarded-for') || '';
    const ip = forwarded.split(',')[0].trim() || 'unknown';

    // Check for existing active sessions for this user
    const existingSessions = await base44.asServiceRole.entities.DeviceSession.filter({
      user_email: user.email,
      is_active: true,
    });

    const mySession = existingSessions.find(s => s.device_id === device_id);
    const otherSessions = existingSessions.filter(s => s.device_id !== device_id);

    if (mySession) {
      // Update last seen
      await base44.asServiceRole.entities.DeviceSession.update(mySession.id, {
        last_seen: new Date().toISOString(),
        ip_address: ip,
        device_info: device_info || userAgent,
      });

      // Log concurrent login if another device is active
      if (otherSessions.length > 0) {
        await base44.asServiceRole.entities.SecurityLog.create({
          event_type: 'concurrent_login',
          user_email: user.email,
          user_id: user.id,
          ip_address: ip,
          device_id: device_id,
          device_info: device_info || userAgent,
          details: `Concurrent login detected. ${otherSessions.length} other active session(s).`,
          severity: 'warning',
        });
      }

      return Response.json({ valid: true, device_id, other_devices: otherSessions.length });
    }

    // No session for this device — deactivate all other sessions (one device per email)
    if (existingSessions.length > 0) {
      // Deactivate old sessions
      for (const s of existingSessions) {
        await base44.asServiceRole.entities.DeviceSession.update(s.id, { is_active: false });
      }

      // Log device mismatch
      await base44.asServiceRole.entities.SecurityLog.create({
        event_type: 'device_mismatch',
        user_email: user.email,
        user_id: user.id,
        ip_address: ip,
        device_id: device_id,
        device_info: device_info || userAgent,
        details: `New device login. Previous sessions deactivated.`,
        severity: 'warning',
      });
    }

    // Create new session
    await base44.asServiceRole.entities.DeviceSession.create({
      user_email: user.email,
      user_id: user.id,
      device_id: device_id,
      device_info: device_info || userAgent,
      ip_address: ip,
      is_active: true,
      last_seen: new Date().toISOString(),
    });

    // Log successful login
    await base44.asServiceRole.entities.SecurityLog.create({
      event_type: 'login_success',
      user_email: user.email,
      user_id: user.id,
      ip_address: ip,
      device_id: device_id,
      device_info: device_info || userAgent,
      details: 'New device session created',
      severity: 'info',
    });

    return Response.json({ valid: true, device_id, new_session: true, other_devices: 0 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});