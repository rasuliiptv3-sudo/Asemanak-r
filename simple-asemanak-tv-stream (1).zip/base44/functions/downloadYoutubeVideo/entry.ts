import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Resolves a direct downloadable video URL for a YouTube video ID.
// Tries multiple public APIs (piped, invidious) as fallbacks.
// The frontend then fetches this URL and caches the blob in IndexedDB for offline playback.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { videoId } = body;
    if (!videoId) return Response.json({ error: 'videoId required' }, { status: 400 });

    // 1. Try piped.video API (multiple instances)
    const pipedInstances = [
      'https://pipedapi.kavin.rocks',
      'https://pipedapi.adminforge.de',
      'https://api.piped.projectsegfau.lt',
    ];
    for (const base of pipedInstances) {
      try {
        const res = await fetch(`${base}/streams/${videoId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.videoStreams && data.videoStreams.length > 0) {
            const stream = data.videoStreams.find(s => s.videoOnly === false) || data.videoStreams[0];
            if (stream && stream.url) {
              return Response.json({ fileUrl: stream.url });
            }
          }
        }
      } catch {}
    }

    // 2. Try invidious API (multiple instances)
    const invInstances = [
      'https://inv.nadeko.net',
      'https://invidious.fdn.fr',
      'https://yewtu.be',
    ];
    for (const base of invInstances) {
      try {
        const res = await fetch(`${base}/api/v1/videos/${videoId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.formatStreams && data.formatStreams.length > 0) {
            const stream = data.formatStreams.find(s => s.quality && s.quality.includes('720')) || data.formatStreams[0];
            if (stream && stream.url) {
              return Response.json({ fileUrl: stream.url });
            }
          }
        }
      } catch {}
    }

    return Response.json({ error: 'Could not resolve video URL — YouTube may be blocking server-side downloads' }, { status: 500 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}