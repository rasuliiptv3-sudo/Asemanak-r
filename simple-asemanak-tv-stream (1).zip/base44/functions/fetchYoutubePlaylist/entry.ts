import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Public YouTube web innerTube key (works for unauthenticated browse requests)
const API_KEY = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8';
const CLIENT_VERSION = '2.20240101.00.00';
const BROWSE_URL = `https://www.youtube.com/youtubei/v1/browse?key=${API_KEY}`;

const HEADERS = {
  'Content-Type': 'application/json',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
  'Accept-Language': 'en-US,en;q=0.9',
  'X-YouTube-Client-Name': '1',
  'X-YouTube-Client-Version': CLIENT_VERSION,
  'X-Origin': 'https://www.youtube.com',
  'Origin': 'https://www.youtube.com',
  'Referer': 'https://www.youtube.com/',
};

const CONTEXT = {
  client: { clientName: 'WEB', clientVersion: CLIENT_VERSION, hl: 'en', gl: 'US' },
};

function readTitle(data) {
  try {
    const header = data?.header?.playlistHeaderRenderer;
    if (header?.title?.simpleText) return header.title.simpleText;
    if (header?.title?.runs) return header.title.runs.map(r => r.text).join('');
  } catch {}
  return '';
}

// Handles both the legacy playlistVideoListRenderer and the new lockupViewModel layout
function parsePlaylistData(data) {
  const episodes = [];
  let nextToken = null;

  const extractLockup = (lv) => {
    let videoId = null;
    let title = '';
    // 1) Thumbnail URL (supports /vi/ and /vi_webp/)
    try {
      const sources = lv?.contentImage?.thumbnailViewModel?.image?.sources || [];
      for (const s of sources) {
        if (s?.url) {
          const m = s.url.match(/\/(?:vi|vi_webp)\/([a-zA-Z0-9_-]{6,})\//);
          if (m) { videoId = m[1]; break; }
        }
      }
    } catch {}
    // 2) Navigation endpoint
    if (!videoId) {
      try {
        const tap = lv?.navigationViewModel?.onTap || {};
        const we = tap?.innertubeCommand?.watchEndpoint || tap?.watchEndpoint;
        if (we?.videoId) videoId = we.videoId;
      } catch {}
    }
    // 3) Fallback: first videoId anywhere in the lockup JSON
    if (!videoId) {
      try {
        const json = JSON.stringify(lv);
        const m = json.match(/"videoId":"([a-zA-Z0-9_-]{6,})"/);
        if (m) videoId = m[1];
      } catch {}
    }
    try { title = lv?.metadata?.lockupMetadataViewModel?.title?.content || ''; } catch {}
    if (videoId) {
      episodes.push({ videoId, title });
    }
  };

  const extractVideo = (videoId, title) => {
    if (!videoId) return;
    episodes.push({ videoId, title: title || '' });
  };

  const processItem = (item) => {
    if (!item || typeof item !== 'object') return;
    if (item.lockupViewModel) { extractLockup(item.lockupViewModel); }
    else if (item.playlistVideoRenderer) {
      const v = item.playlistVideoRenderer;
      extractVideo(v.videoId, (v.title?.runs || []).map(r => r.text).join(''));
    } else if (item.playlistPanelVideoRenderer) {
      const v = item.playlistPanelVideoRenderer;
      const rawTitle = v.title?.simpleText || (v.title?.runs || []).map(r => r.text).join('');
      extractVideo(v.videoId, rawTitle);
    }
    const tok =
      item?.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token ||
      item?.continuationItemRenderer?.button?.buttonRenderer?.command?.continuationCommand?.token;
    if (tok) nextToken = tok;
  };

  const visit = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    if (Array.isArray(obj)) { obj.forEach(visit); return; }

    // Continuation page: raw items array
    if (Array.isArray(obj.continuationItems)) obj.continuationItems.forEach(processItem);
    // Continuation action wrapper
    if (obj.appendContinuationItemsAction?.continuationItems) obj.appendContinuationItemsAction.continuationItems.forEach(processItem);
    // New layout: itemSectionRenderer holding lockupViewModel items
    if (obj.itemSectionRenderer) {
      const contents = obj.itemSectionRenderer.contents || [];
      if (contents.some(c => c?.lockupViewModel)) contents.forEach(processItem);
    }
    // Legacy layout: playlistVideoListRenderer
    if (obj.playlistVideoListRenderer) {
      (obj.playlistVideoListRenderer.contents || []).forEach(processItem);
    }

    for (const k of Object.keys(obj)) {
      if (k === 'continuationItems') continue;
      visit(obj[k]);
    }
  };
  visit(data);
  return { title: readTitle(data), episodes, nextToken };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const playlistId = body?.playlistId;
    if (!playlistId) return Response.json({ error: 'playlistId required' }, { status: 400 });

    // Initial browse request for the playlist (browseId = "VL" + playlistId)
    const initBody = JSON.stringify({ context: CONTEXT, browseId: `VL${playlistId}` });
    const initRes = await fetch(BROWSE_URL, { method: 'POST', headers: HEADERS, body: initBody });
    if (!initRes.ok) return Response.json({ error: `browse failed: ${initRes.status}` }, { status: 502 });
    const initData = await initRes.json();

    const { title, episodes: initEps, nextToken } = parsePlaylistData(initData);
    const all = [...initEps];
    let token = nextToken;
    let pages = 0;

    // Follow continuation pages to retrieve ALL episodes (supports 300+)
    while (token && pages < 200) {
      pages++;
      let cjson = null;
      try {
        const cbody = JSON.stringify({ context: CONTEXT, continuation: token });
        const cres = await fetch(BROWSE_URL, { method: 'POST', headers: HEADERS, body: cbody });
        cjson = await cres.json();
      } catch (e) {
        break;
      }
      const { episodes: cEps, nextToken: ntok } = parsePlaylistData(cjson);
      all.push(...cEps);
      token = ntok;
      if (cEps.length === 0 && !ntok) break;
    }

    // Deduplicate by videoId
    const seen = new Set();
    const dedup = [];
    for (const ep of all) {
      if (!seen.has(ep.videoId)) {
        seen.add(ep.videoId);
        dedup.push(ep);
      }
    }
    // Assign episode numbers by playlist position (1, 2, 3, ...) — matches YouTube's order
    dedup.forEach((ep, i) => { ep.number = i + 1; });

    return Response.json({ title, episodes: dedup, total: dedup.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});