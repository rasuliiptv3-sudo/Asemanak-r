# کد کامل بخش سریال‌ها — راهنمای کپی به برنامه دیگر

این فایل شامل تمام کد بخش «سریال‌ها» است. برای استفاده در برنامه دیگر، هر فایل را در مسیر مشخص‌شده ایجاد کنید.

## فهرست فایل‌ها

### ۱. Entity (دیتابیس)
- `base44/entities/Series.jsonc`

### ۲. صفحه اصلی
- `src/pages/Media.jsx`

### ۳. کامپوننت‌های media
- `src/components/media/SeriesDetail.jsx`
- `src/components/media/SeriesCard.jsx`
- `src/components/media/YouTubePlayer.jsx`
- `src/components/media/HlsVideoPlayer.jsx`
- `src/components/media/HeroVideo.jsx`
- `src/components/media/TrailerHero.jsx`
- `src/components/media/TrailerPlayer.jsx`
- `src/components/media/MediaSplash.jsx`
- `src/components/media/SeriesCoverOverlay.jsx`
- `src/components/media/VideoControls.jsx`
- `src/components/media/AddPlaylistForm.jsx`
- `src/components/media/AddEpisodeForm.jsx`
- `src/components/media/SeriesReorderModal.jsx`
- `src/components/media/SeriesContextMenu.jsx`

### ۴. کتابخانه‌های کمکی
- `src/lib/useIsTV.js`
- `src/lib/useIsMobile.js`
- `src/lib/usePullToRefresh.js`
- `src/lib/idb.js`
- `src/lib/brandAssets.js`
- `src/lib/offlineVideo.js`

### ۵. تابع بک‌اند
- `base44/functions/fetchYoutubePlaylist/entry.ts`

### ۶. مسیریابی (App.jsx)
اضافه‌کردن `<Route path="/Media" element={<Media />} />` و `import Media from '@/pages/Media'`

### ۷. پکیج‌های مورد‌نیاز
- `hls.js` (برای پخش HLS)
- `@hello-pangea/dnd` (برای drag-and-drop reorder)
- `lucide-react` (آیکون‌ها)
- `framer-motion` (انیمیشن)

---

## ۱. Entity: `base44/entities/Series.jsonc`

```jsonc
{
  "name": "Series",
  "type": "object",
  "properties": {
    "title": { "type": "string" },
    "description": { "type": "string" },
    "playlistId": { "type": "string" },
    "playlistUrl": { "type": "string" },
    "category": {
      "type": "string",
      "enum": ["series", "movies", "animation", "comedy", "drama", "occasional"],
      "default": "series"
    },
    "type": { "type": "string", "default": "youtube" },
    "poster": { "type": "string" },
    "posterPosition": { "type": "string", "default": "center 20%" },
    "coverMusic": { "type": "string" },
    "hideOverlays": { "type": "boolean", "default": false },
    "sortOrder": { "type": "number", "default": 0 },
    "episodes": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "videoId": { "type": "string" },
          "embedUrl": { "type": "string" },
          "fileUrl": { "type": "string" },
          "title": { "type": "string" },
          "number": { "type": "number" },
          "season": { "type": "number", "default": 1 }
        }
      }
    }
  },
  "required": ["title"],
  "rls": {
    "create": { "user_condition": { "role": "admin" } },
    "read": null,
    "update": { "user_condition": { "role": "admin" } },
    "delete": { "user_condition": { "role": "admin" } }
  }
}
```

---

## ۲. صفحه اصلی: `src/pages/Media.jsx`

این فایل بزرگ است — محتوای کامل آن را از فایل موجود در برنامه فعلی کپی کنید.
نکات کلیدی:
- از `base44.entities.Series` برای CRUD استفاده می‌کند
- از `usePullToRefresh`, `useIsTV`, `useIsMobile` استفاده می‌کند
- از کامپوننت‌های `SeriesDetail`, `SeriesCard`, `YouTubePlayer`, `HlsVideoPlayer`, `HeroVideo`, `TrailerHero`, `MediaSplash`, `AddPlaylistForm`, `AddEpisodeForm`, `SeriesReorderModal`, `SeriesContextMenu` استفاده می‌کند
- از `idbGet`, `idbSet` برای کش آفلاین استفاده می‌کند

---

## ۳. کامپوننت‌های media

تمام فایل‌های زیر را در پوشه `src/components/media/` ایجاد کنید. محتوای هر فایل را از برنامه فعلی کپی کنید:

### `src/components/media/SeriesDetail.jsx`
نمای سریال — لیست قسمت‌ها، پخش‌کننده تمام‌صفحه، مدیریت آفلاین، کنترل‌های ادمین

### `src/components/media/SeriesCard.jsx`
کارت سریال — تصویر کاور، نشانگر قسمت‌ها، پیش‌نمایش، نشانگر آفلاین

### `src/components/media/YouTubePlayer.jsx`
پخش‌کننده YouTube با API — کنترل‌های کامل، زیرنویس، کنترل از راه دور TV

### `src/components/media/HlsVideoPlayer.jsx`
پخش‌کننده HLS با hls.js — برای پخش فایل‌های .m3u8 و ویدیوهای آپلودی

### `src/components/media/HeroVideo.jsx`
ویدیوی هیرو — چرخه خودکار بین قسمت‌های سریال‌ها

### `src/components/media/TrailerHero.jsx`
تریلر هیرو — پخش قسمت اول سریال در هدر

### `src/components/media/TrailerPlayer.jsx`
پخش‌کننده تریلر تمام‌صفحه با دکمه Skip

### `src/components/media/MediaSplash.jsx`
صفحه بارگذاری ساده با لوگو و اسپینر

### `src/components/media/SeriesCoverOverlay.jsx`
اورلی کاور سریال — اسپینر بارگذاری + دکمه تماشای دوباره

### `src/components/media/VideoControls.jsx`
کنترل‌های ویدیو — seek، صدا، روشنایی، کیفیت، سایز صفحه، زبان

### `src/components/media/AddPlaylistForm.jsx`
فرم افزودن سریال — یوتیوب، لینک مستقیم، آپلود از گالری

### `src/components/media/AddEpisodeForm.jsx`
فرم افزودن قسمت — یوتیوب، لینک مستقیم، آپلود از گالری

### `src/components/media/SeriesReorderModal.jsx`
مدال مرتب‌سازی سریال‌ها با drag-and-drop

### `src/components/media/SeriesContextMenu.jsx`
منوی راست‌کلیک سریال — تغییر اسم، عکس، موسیقی، دانلود، حذف

---

## ۴. کتابخانه‌های کمکی

### `src/lib/useIsTV.js`
```js
import { useState, useEffect } from "react";

export function checkIsTV() {
  try { if (document.documentElement.classList.contains('is-tv')) return true; } catch {}
  try {
    const flag = localStorage.getItem("ayeneh_force_tv");
    if (flag === "1") return true;
    if (flag === "0") return false;
  } catch {}
  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get("tv") === "1") return true;
    if (params.get("tv") === "0") return false;
  } catch {}
  const ua = navigator.userAgent || "";
  if (/tv|smarttv|google ?tv|netcast|baidutv|crkey|smart-tv|googletv|webos|tizen|bravia|firetv|fire-tv|aftt|aftm|aftb|aftd|shield|leanback|onn/i.test(ua)) return true;
  try {
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const isAndroid = /android/i.test(ua);
    if (isAndroid && !hasTouch) return true;
  } catch {}
  try {
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    const isCoarse = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    const sw = (window.screen && window.screen.width) || 0;
    const sh = (window.screen && window.screen.height) || 0;
    if (!hasTouch && isCoarse && (sw >= 1280 || sh >= 1280 || window.innerWidth >= 1000 || window.innerHeight >= 1000)) return true;
  } catch {}
  try {
    const hasTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
    if (window.innerWidth < 768 && hasTouch) return false;
  } catch {}
  return false;
}

export function setForceTV(val) {
  try { localStorage.setItem("ayeneh_force_tv", val ? "1" : "0"); } catch {}
  window.dispatchEvent(new Event("ayeneh-tv-toggle"));
}

export function useIsTV() {
  const [isTV, setIsTV] = useState(() => checkIsTV());
  useEffect(() => {
    const handler = () => setIsTV(checkIsTV());
    window.addEventListener("popstate", handler);
    window.addEventListener("pushstate", handler);
    window.addEventListener("ayeneh-tv-toggle", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("popstate", handler);
      window.removeEventListener("pushstate", handler);
      window.removeEventListener("ayeneh-tv-toggle", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return isTV;
}
```

### `src/lib/useIsMobile.js`
```js
import { useState, useEffect } from "react";

export function useIsMobile(breakpoint = 768) {
  const [mobile, setMobile] = useState(() =>
    typeof window !== "undefined" ? window.innerWidth < breakpoint : false
  );
  useEffect(() => {
    const onResize = () => setMobile(window.innerWidth < breakpoint);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [breakpoint]);
  return mobile;
}
```

### `src/lib/usePullToRefresh.js`
```js
import { useState, useEffect, useRef } from "react";

export function usePullToRefresh({ onRefresh, disabled, threshold = 70, containerRef }) {
  const ownRef = useRef(null);
  const ref = containerRef || ownRef;
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const st = useRef({ startY: null, pulling: false, refreshing: false, lastDy: 0 });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const isMobile = () => window.innerWidth < 768;

    const onStart = (e) => {
      st.current.startY = e.touches[0].clientY;
      st.current.lastDy = 0;
      st.current.pulling = false;
    };
    const onMove = (e) => {
      if (st.current.startY === null || st.current.refreshing) return;
      const dy = e.touches[0].clientY - st.current.startY;
      st.current.lastDy = dy;
      const atTop = el.scrollTop <= 0;
      if (disabled || !isMobile() || !atTop) {
        if (st.current.pulling) { st.current.pulling = false; setPull(0); }
        return;
      }
      if (dy <= 0) { st.current.pulling = false; setPull(0); return; }
      st.current.pulling = true;
      setPull(Math.min(threshold * 1.6, dy * 0.5));
    };
    const onEnd = async () => {
      if (!st.current.pulling) { st.current.startY = null; return; }
      st.current.pulling = false;
      st.current.startY = null;
      if (st.current.lastDy >= threshold && !st.current.refreshing) {
        st.current.refreshing = true;
        setRefreshing(true);
        setPull(threshold);
        try { await onRefresh?.(); } finally {
          st.current.refreshing = false;
          setRefreshing(false);
          setPull(0);
        }
      } else { setPull(0); }
    };

    el.addEventListener("touchstart", onStart, { passive: true });
    el.addEventListener("touchmove", onMove, { passive: true });
    el.addEventListener("touchend", onEnd, { passive: true });
    return () => {
      el.removeEventListener("touchstart", onStart);
      el.removeEventListener("touchmove", onMove);
      el.removeEventListener("touchend", onEnd);
    };
  }, [ref, disabled, threshold, onRefresh]);

  return { ref, pull, refreshing };
}
```

### `src/lib/idb.js`
```js
const DB_NAME = "ayeneh_db";
const DB_VERSION = 2;
const STORES = ["channels", "series", "meta", "videos"];

let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    try {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        STORES.forEach((s) => { if (!db.objectStoreNames.contains(s)) db.createObjectStore(s); });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    } catch (e) { reject(e); }
  });
  return dbPromise;
}

export async function idbGet(store, key) {
  try {
    const db = await openDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(store, "readonly");
      const req = tx.objectStore(store).get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch { return null; }
}

export async function idbSet(store, key, value) {
  try {
    const db = await openDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(store, "readwrite");
      tx.objectStore(store).put(value, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch { return false; }
}

export async function idbDel(store, key) {
  try {
    const db = await openDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(store, "readwrite");
      tx.objectStore(store).delete(key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch { return false; }
}
```

### `src/lib/brandAssets.js`
```js
export const LOGO_URL = "https://media.base44.com/images/public/69bb192550659e77af7bd3fe/6472c90ea_file_0000000096cc71fd92231a0dad14e023.png";
```

### `src/lib/offlineVideo.js`
```js
import { idbGet, idbSet, idbDel } from "@/lib/idb";

const STORE = "videos";
const INDEX_KEY = "ayeneh_offline_index";
const urlCache = new Map();

function readIndex() {
  try { return JSON.parse(localStorage.getItem(INDEX_KEY) || "[]"); } catch { return []; }
}
function writeIndex(list) {
  localStorage.setItem(INDEX_KEY, JSON.stringify(list));
  window.dispatchEvent(new Event("ayeneh-offline-changed"));
}

export function getOfflineIndex() { return readIndex(); }

export async function getOfflineVideoUrl(fileUrl) {
  if (urlCache.has(fileUrl)) return urlCache.get(fileUrl);
  const blob = await idbGet(STORE, fileUrl);
  if (!blob) return null;
  const objUrl = URL.createObjectURL(blob);
  urlCache.set(fileUrl, objUrl);
  return objUrl;
}

export function getOfflineVideoUrlSync(fileUrl) {
  return urlCache.has(fileUrl) ? urlCache.get(fileUrl) : null;
}

export async function isVideoOffline(fileUrl) {
  if (urlCache.has(fileUrl)) return true;
  const blob = await idbGet(STORE, fileUrl);
  return !!blob;
}

export async function cacheVideoOffline(fileUrl, meta = {}, directUrl) {
  const url = directUrl || fileUrl;
  const res = await fetch(url);
  if (!res.ok) throw new Error("fetch_failed");
  const blob = await res.blob();
  await idbSet(STORE, fileUrl, blob);
  const list = readIndex().filter(e => e.fileUrl !== fileUrl);
  list.push({ fileUrl, label: meta.label || fileUrl, size: blob.size, cachedAt: Date.now() });
  writeIndex(list);
  return true;
}

export async function removeOfflineVideo(fileUrl) {
  if (urlCache.has(fileUrl)) { URL.revokeObjectURL(urlCache.get(fileUrl)); urlCache.delete(fileUrl); }
  await idbDel(STORE, fileUrl);
  writeIndex(readIndex().filter(e => e.fileUrl !== fileUrl));
}

export async function clearAllOffline() {
  const list = readIndex();
  for (const e of list) {
    if (urlCache.has(e.fileUrl)) { URL.revokeObjectURL(urlCache.get(e.fileUrl)); urlCache.delete(e.fileUrl); }
    await idbDel(STORE, e.fileUrl);
  }
  writeIndex([]);
}
```

---

## ۵. تابع بک‌اند: `base44/functions/fetchYoutubePlaylist/entry.ts`

```typescript
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const API_KEY = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8';
const CLIENT_VERSION = '2.20240101.00.00';
const BROWSE_URL = `https://www.youtube.com/youtubei/v1/browse?key=${API_KEY}`;

const HEADERS = {
  'Content-Type': 'application/json',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
  'Accept-Language': 'en-US,en;q=0.9',
  'X-YouTube-Client-Name': '1',
  'X-YouTube-Client-Version': CLIENT_VERSION,
  'X-Origin': 'https://www.youtube.com',
  'Origin': 'https://www.youtube.com',
  'Referer': 'https://www.youtube.com/',
};

const CONTEXT = {
  client: { clientName: 'WEB', clientVersion: CLIENT_VERSION, hl: 'en', gl: 'US' },
};

function readTitle(data) {
  try {
    const header = data?.header?.playlistHeaderRenderer;
    if (header?.title?.simpleText) return header.title.simpleText;
    if (header?.title?.runs) return header.title.runs.map(r => r.text).join('');
  } catch {}
  return '';
}

function parsePlaylistData(data) {
  const episodes = [];
  let nextToken = null;

  const extractLockup = (lv) => {
    let videoId = null;
    let title = '';
    try {
      const sources = lv?.contentImage?.thumbnailViewModel?.image?.sources || [];
      for (const s of sources) {
        if (s?.url) {
          const m = s.url.match(/\/(?:vi|vi_webp)\/([a-zA-Z0-9_-]{6,})\//);
          if (m) { videoId = m[1]; break; }
        }
      }
    } catch {}
    if (!videoId) {
      try {
        const tap = lv?.navigationViewModel?.onTap || {};
        const we = tap?.innertubeCommand?.watchEndpoint || tap?.watchEndpoint;
        if (we?.videoId) videoId = we.videoId;
      } catch {}
    }
    if (!videoId) {
      try {
        const json = JSON.stringify(lv);
        const m = json.match(/"videoId":"([a-zA-Z0-9_-]{6,})"/);
        if (m) videoId = m[1];
      } catch {}
    }
    try { title = lv?.metadata?.lockupMetadataViewModel?.title?.content || ''; } catch {}
    if (videoId) { episodes.push({ videoId, title }); }
  };

  const extractVideo = (videoId, title) => {
    if (!videoId) return;
    episodes.push({ videoId, title: title || '' });
  };

  const processItem = (item) => {
    if (!item || typeof item !== 'object') return;
    if (item.lockupViewModel) { extractLockup(item.lockupViewModel); }
    else if (item.playlistVideoRenderer) {
      const v = item.playlistVideoRenderer;
      extractVideo(v.videoId, (v.title?.runs || []).map(r => r.text).join(''));
    } else if (item.playlistPanelVideoRenderer) {
      const v = item.playlistPanelVideoRenderer;
      const rawTitle = v.title?.simpleText || (v.title?.runs || []).map(r => r.text).join('');
      extractVideo(v.videoId, rawTitle);
    }
    const tok =
      item?.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token ||
      item?.continuationItemRenderer?.button?.buttonRenderer?.command?.continuationCommand?.token;
    if (tok) nextToken = tok;
  };

  const visit = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    if (Array.isArray(obj)) { obj.forEach(visit); return; }
    if (Array.isArray(obj.continuationItems)) obj.continuationItems.forEach(processItem);
    if (obj.appendContinuationItemsAction?.continuationItems) obj.appendContinuationItemsAction.continuationItems.forEach(processItem);
    if (obj.itemSectionRenderer) {
      const contents = obj.itemSectionRenderer.contents || [];
      if (contents.some(c => c?.lockupViewModel)) contents.forEach(processItem);
    }
    if (obj.playlistVideoListRenderer) {
      (obj.playlistVideoListRenderer.contents || []).forEach(processItem);
    }
    for (const k of Object.keys(obj)) {
      if (k === 'continuationItems') continue;
      visit(obj[k]);
    }
  };
  visit(data);
  return { title: readTitle(data), episodes, nextToken };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const playlistId = body?.playlistId;
    if (!playlistId) return Response.json({ error: 'playlistId required' }, { status: 400 });

    const initBody = JSON.stringify({ context: CONTEXT, browseId: `VL${playlistId}` });
    const initRes = await fetch(BROWSE_URL, { method: 'POST', headers: HEADERS, body: initBody });
    if (!initRes.ok) return Response.json({ error: `browse failed: ${initRes.status}` }, { status: 502 });
    const initData = await initRes.json();

    const { title, episodes: initEps, nextToken } = parsePlaylistData(initData);
    const all = [...initEps];
    let token = nextToken;
    let pages = 0;

    while (token && pages < 200) {
      pages++;
      let cjson = null;
      try {
        const cbody = JSON.stringify({ context: CONTEXT, continuation: token });
        const cres = await fetch(BROWSE_URL, { method: 'POST', headers: HEADERS, body: cbody });
        cjson = await cres.json();
      } catch (e) { break; }
      const { episodes: cEps, nextToken: ntok } = parsePlaylistData(cjson);
      all.push(...cEps);
      token = ntok;
      if (cEps.length === 0 && !ntok) break;
    }

    const seen = new Set();
    const dedup = [];
    for (const ep of all) {
      if (!seen.has(ep.videoId)) {
        seen.add(ep.videoId);
        dedup.push(ep);
      }
    }
    dedup.forEach((ep, i) => { ep.number = i + 1; });

    return Response.json({ title, episodes: dedup, total: dedup.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
```

---

## ۶. مسیریابی

در `src/App.jsx` این خطوط را اضافه کنید:

```jsx
import Media from '@/pages/Media';
// ...
<Route path="/Media" element={<Media />} />
```

---

## ۷. پکیج‌های مورد‌نیاز

```bash
npm install hls.js @hello-pangea/dnd lucide-react framer-motion
```

---

## نکات مهم

۱. **LOGO_URL**: آدرس لوگو را در `brandAssets.js` و کامپوننت‌ها با لوگوی برنامه خود جایگزین کنید.

۲. **Entity**: ابتدا `Series.jsonc` را ایجاد کنید تا دیتابیس آماده شود.

۳. **بک‌اند**: تابع `fetchYoutubePlaylist` برای دریافت قسمت‌های پلی‌لیست یوتیوب ضروری است.

۴. **RLS**: تنظیمات RLS در entity فقط به ادمین‌ها اجازه ایجاد/ویرایش/حذف می‌دهد. خواندن برای همه آزاد است.

۵. **آفلاین**: سیستم دانلود آفلاین از IndexedDB استفاده می‌کند و برای ویدیوهای آپلودی (fileUrl) کار می‌کند.

۶. **TV**: تشخیص TV و کنترل با遥控 در `useIsTV.js` و `useTVRemote.js` پیاده‌سازی شده.

۷. **کش**: IndexedDB برای کش سریال‌ها و ویدیوهای آفلاین استفاده می‌شود.